<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-3">
                    <h4 class="page-title">All Projects</h4>
                </div>
            </div>
            <form method="GET" action="<?php echo e(url('documents/projects')); ?>">
            <div class="row filter-row">
                <div class="col-sm-6 col-md-4">
                    <div class="form-group form-focus">
                        <label class="focus-label">Project Name</label>
                        <input type="text" class="form-control floating" name="pname">
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="form-group form-focus select-focus">
                        <label class="focus-label">Type</label>
                        <select class="select floating" name="type">
                            <option value="Content">Content</option>
                            <option value="Image">Image</option>
                            <option value="Code">Code</option>
                            <option value="Transcript">Transcript</option>
                        </select>
                    </div>
                </div>
                <div class="col-sm-12 col-md-4">
                    <button class="btn btn-success btn-block"> Search </button>
                </div>
            </div>
            </form>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <div class="row">
                <?php if(count($documents) > 0): ?>
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped custom-table datatable">
                            <thead>
                                <tr>
                                    <th>S/L</th>
                                    <th>Project Name</th>
                                    <th>Created Date</th>
                                    <th>Type</th>
                                    <th>Words/Size</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($index + 1); ?></td>
                                    
                                    <td>
                                        <i class="text-secondary p-2 <?php echo e($doc->type === 'Content' ? 'fa fa-file' :
                                        ($doc->type === 'Code' ? 'fa fa-code' :
                                        ($doc->type === 'Image' ? 'fa fa-image' :
                                        ($doc->type === 'Transcript' ? 'fa fa-microphone' : '')))); ?>">
                                        </i>
                                        <?php echo e($doc->project_name); ?>

                                    </td>
                                    <td><?php echo e($doc->created_date); ?></td>
                                    <td><?php echo e($doc->type); ?></td>
                                    <td><?php echo e($doc->words_size); ?></td>
                                    <td class="text-right">
                                        <div class="dropdown dropdown-action">
                                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <?php if($doc->type === 'Image'): ?>
                                                <a class="dropdown-item" href="<?php echo e($doc->content); ?>" download><i class="fas fa-download m-r-5"></i> Download</a>
                                                <?php else: ?>
                                                <a class="dropdown-item" href="<?php echo e(route('documents.edit', $doc->id)); ?>"><i class="fas fa-pen m-r-5"></i> Edit</a>
                                                <?php endif; ?>
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_documnet_<?php echo e($doc->id); ?>"><i class="far fa-trash-alt m-r-5"></i> Delete</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <div id="delete_documnet_<?php echo e($doc->id); ?>" class="modal custom-modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content modal-md">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Delete Client</h4>
                                            </div>
                                            <form action="<?php echo e(route('documents.destroy', $doc->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <div class="modal-body card-box">
                                                    <p>Are you sure want to delete this?</p>
                                                    <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                        </tbody>
                    </table>
                </div>
                <?php echo e($documents->links()); ?>

            </div>
            <?php else: ?>
            <p class="p-4"><?php echo e('Projects Not Found!'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/documents/document_index.blade.php ENDPATH**/ ?>