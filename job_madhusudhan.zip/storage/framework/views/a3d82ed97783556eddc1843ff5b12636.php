<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.topheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ============================== Banner Start ==============================-->
    <section class="banner">
        <div class="container">
            <div class="banner_wrapper text-center py-5 mx-auto">
                <h1>Drive better results instantly</h1>
                <p>Write more eCommerce product content and watch your performance on SERPs and conversions skyrocket
                </p>
                <div class="banner_btn">
                    <a href="#" class="btn btn-lg mt-4 py-3 px-4">Get Started for Free</a>
                </div>
            </div>
        </div>
    </section>
    <!-- ============================== Banner End ==============================-->

    <!-- ============================== Pricing Start ==============================-->
    <section class="tabs_wrapper">
        <div class="container ">
            <div class="tabs_section py-5 mx-auto">
                <div class="price_btn rounded-2 my-5">
                    <ul class="nav d-flex justify-content-center" id="myTab" role="tablist">
                        <li class="nav-item tab_btn" role="presentation">
                            <button class="nav-link active fw-bold" id="home-tab" data-bs-toggle="tab"
                                data-bs-target="#home" type="button" role="tab" aria-controls="home"
                                aria-selected="true">Monthly</button>
                        </li>
                        <li class="nav-item tab_btn" role="presentation">
                            <button class="nav-link fw-bold" id="profile-tab" data-bs-toggle="tab"
                                data-bs-target="#profile" type="button" role="tab" aria-controls="profile"
                                aria-selected="false">Yearly</button>
                        </li>
                        <li class="nav-item tab_btn" role="presentation">
                            <button class="nav-link fw-bold" id="contact-tab" data-bs-toggle="tab"
                                data-bs-target="#contact" type="button" role="tab" aria-controls="contact"
                                aria-selected="false">LifeTime</button>
                        </li>
                    </ul>
                </div>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <div class="row">
                            <div class="col-lg-4 col-12 mb-3">
                                <div class="card rounded-3 mt-5 border-0">
                                    <div class="card-body">
                                        <div class="pricing text-center align-items-center py-3">
                                            <h2>Free</h2>
                                            <p>$0/yr</p>
                                        </div>
                                        <div class="banner_btn pb-3 text-center" data-aos="flip-left">
                                            <a href="#" class="btn btn-lg mt-2 mb-3 py-3 px-4">Get Started</a>
                                        </div>
                                        <div class="price_table_feature">
                                            <ul>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Up to 5 Products</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">1 User</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">25 Generations/month</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">CSV Import</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-12 mb-3">
                                <div class="card center_card rounded-3 border-0">
                                    <div class="card-header text-center card_header border-bottom-0">
                                        <p class="mb-0"><strong>Easy to Customize with Add-ons</strong>
                                        </p>
                                    </div>
                                    <div class="card-body pt-4">
                                        <div class="pricing text-center align-items-center py-3">
                                            <h2>Core</h2>
                                            <div class="text-muted my-1">Starting at</div>
                                            <p>$90/yr</p>
                                        </div>
                                        <div class="banner_btn pb-3 text-center" data-aos="flip-left">
                                            <a href="#" class="btn btn-lg mt-2 mb-3 py-3 px-4">Start a Free Trial</a>
                                        </div>
                                        <div
                                            class="price_table_feature justify-content-between align-items-center d-flex">
                                            <ul>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Unlimited AI Copy Generation
                                                </li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Starts with 15 Products</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Manage up to 450 Products
                                                </li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Starts with 3 Users</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Starts with 1 Store
                                                    Connector
                                                </li>

                                                <li class="pb-2 d-flex align-items-start"><img
                                                        src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked" class="me-1"
                                                        width="17" height="17">Starts with 15 Bulk Generations</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">CSV Import/Export</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-12 mb-3">
                                <div class="card rounded-3 mt-5 border-0">
                                    <div class="card-body">
                                        <div class="pricing thard_card text-center align-items-center py-3">
                                            <h2>Enterprise</h2>
                                            <p>Customized For You</p>
                                        </div>
                                        <div class="banner_btn pb-3 text-center" data-aos="flip-left">
                                            <a href="#" class="btn btn-lg mt-2 mb-3 py-3 px-4">Contact Us</a>
                                        </div>
                                        <div class="price_table_feature">
                                            <ul>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Unlimited AI Copy Generation
                                                </li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Custom Products</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Custom Users</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Custom Store Connectors</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Custom Bulk Generations</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">CSV Import/Export</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <div class="row pb-5 justify-content-center">
                            <div class="col-lg-4 col-12 mb-3">
                                <div class="card center_card rounded-3 border-0">
                                    <div class="card-header text-center card_header border-bottom-0">
                                        <p class="mb-0"><strong>Easy to Customize with Add-ons</strong>
                                        </p>
                                    </div>
                                    <div class="card-body pt-4">
                                        <div class="pricing text-center align-items-center py-3">
                                            <h2>Core</h2>
                                            <div class="text-muted my-1">Starting at</div>
                                            <p>$90/yr</p>
                                        </div>
                                        <div class="banner_btn pb-3 text-center" data-aos="flip-left">
                                            <a href="#" class="btn btn-lg mt-2 mb-3 py-3 px-4">Start a Free Trial</a>
                                        </div>
                                        <div
                                            class="price_table_feature justify-content-between align-items-center d-flex">
                                            <ul>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Unlimited AI Copy Generation
                                                </li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Starts with 15 Products</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Manage up to 450 Products
                                                </li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Starts with 3 Users</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Starts with 1 Store
                                                    Connector
                                                </li>

                                                <li class="pb-2 d-flex align-items-start"><img
                                                        src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked" class="me-1"
                                                        width="17" height="17">Starts with 15 Bulk Generations</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">CSV Import/Export</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                        <div class="row pb-5 justify-content-center">
                            <div class="col-lg-4 col-12 mb-3">
                                <div class="card rounded-3 mt-5 border-0">
                                    <div class="card-body">
                                        <div class="pricing text-center align-items-center py-3">
                                            <h2>Free</h2>
                                            <p>$0/yr</p>
                                        </div>
                                        <div class="banner_btn pb-3 text-center" data-aos="flip-left">
                                            <a href="#" class="btn btn-lg mt-2 mb-3 py-3 px-4">Get Started</a>
                                        </div>
                                        <div class="price_table_feature">
                                            <ul>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">Up to 5 Products</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">1 User</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">25 Generations/month</li>
                                                <li class="pb-2"><img src="<?php echo e(url('public/theme_one_assets/images/icon/checked.png')); ?>" alt="checked"
                                                        class="me-1" width="17" height="17">CSV Import</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="money_back__plans text-center fw-semibold text-white pb-5">
                <p>All our plans have a 30-day money-back guarantee</p>
            </div>
        </div>
    </section>
    <!-- ============================== Pricing End==============================-->
    <!-- ============================== Started Free Start ==============================-->
    <div class="how__start py-5">
        <div class="container">
            <div class="Start_Free mx-auto text-center">
                <p>Describely gives you everything you need to create high-performing eCommerce product copy from
                    scratch, rewrite and optimize existing content, and publish where you need your content to be</p>
                <div class="banner_btn pb-3 text-center" data-aos="flip-left">
                    <a href="#" class="btn btn-lg mt-2 mb-3 py-3 px-4">Get Started for Free</a>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================== Started Free End ==============================-->
    <!-- ============================== FAQ Start ==============================-->
    <section class="faq_wrapper pb-5">
        <div class="container">
            <div class="chat_content pt-5 mx-auto text-center" data-aos="fade-up">
                <h1>FAQs</h1>
            </div>
            <div class="accordion accordion-flush pt-5 px-5" id="accordionFlushExample">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="flush-headingOne">
                        <button class="accordion-button collapsed accordion__btn fw-bold" type="button"
                            data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false"
                            aria-controls="flush-collapseOne">
                            What is web application development?
                        </button>
                    </h2>
                    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne"
                        data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body accordion__body">
                            A web application is an interactive software that runs on a web server and is accessible
                            via
                            a
                            web browser. It is structured so that the user interface sends data back to the
                            development
                            team that created it.
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="flush-headingTwo">
                        <button class="accordion-button collapsed accordion__btn fw-bold mt-4" type="button"
                            data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false"
                            aria-controls="flush-collapseTwo">
                            Why should you outsource web application development services From Inletsky?
                        </button>
                    </h2>
                    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo"
                        data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body accordion__body">Placeholder content for this accordion, which is
                            intended to
                            demonstrate the <code>.accordion-flush</code> class. This is the second item's accordion
                            body. Let's imagine this being filled with some actual content.</div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="flush-headingThree">
                        <button class="accordion-button collapsed accordion__btn fw-bold mt-4" type="button"
                            data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false"
                            aria-controls="flush-collapseThree">
                            How much does it cost to develop a web application?
                        </button>
                    </h2>
                    <div id="flush-collapseThree" class="accordion-collapse collapse"
                        aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body accordion__body">Placeholder content for this accordion, which is
                            intended to
                            demonstrate the <code>.accordion-flush</code> class. This is the third item's accordion
                            body. Nothing more exciting happening here in terms of content, but just filling up the
                            space to make it look, at least at first glance, a bit more representative of how this
                            would
                            look in a real-world application.</div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="flush-headingfour">
                        <button class="accordion-button collapsed accordion__btn fw-bold mt-4" type="button"
                            data-bs-toggle="collapse" data-bs-target="#flush-collapsefour" aria-expanded="false"
                            aria-controls="flush-collapsefour">
                            Which programming languages are used for web applications?
                        </button>
                    </h2>
                    <div id="flush-collapsefour" class="accordion-collapse collapse" aria-labelledby="flush-headingfour"
                        data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body accordion__body">Placeholder content for this
                            accordion, which is
                            intended to
                            demonstrate the <code>.accordion-flush</code> class. This is
                            the third
                            item's accordion
                            body. Nothing more exciting happening here in terms of
                            content, but just
                            filling up the
                            space to make it look, at least at first glance, a bit more
                            representative
                            of how this would
                            look in a real-world application.</div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="flush-headingfive">
                        <button class="accordion-button collapsed accordion__btn fw-bold mt-4" type="button"
                            data-bs-toggle="collapse" data-bs-target="#flush-collapsefive" aria-expanded="false"
                            aria-controls="flush-collapsefive">
                            How long does it take to build a web app?
                        </button>
                    </h2>
                    <div id="flush-collapsefive" class="accordion-collapse collapse" aria-labelledby="flush-headingfive"
                        data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body accordion__body">Placeholder content for this
                            accordion, which is
                            intended to
                            demonstrate the <code>.accordion-flush</code> class. This is
                            the third
                            item's accordion
                            body. Nothing more exciting happening here in terms of
                            content, but just
                            filling up the
                            space to make it look, at least at first glance, a bit more
                            representative
                            of how this would
                            look in a real-world application.</div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="flush-headingsix">
                        <button class="accordion-button collapsed accordion__btn fw-bold mt-4" type="button"
                            data-bs-toggle="collapse" data-bs-target="#flush-collapsesix" aria-expanded="false"
                            aria-controls="flush-collapsesix">
                            Which is the best custom web app development company?
                        </button>
                    </h2>
                    <div id="flush-collapsesix" class="accordion-collapse collapse" aria-labelledby="flush-headingsix"
                        data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body accordion__body">Placeholder content for this accordion, which is
                            intended to
                            demonstrate the <code>.accordion-flush</code> class. This is the third
                            item's accordion
                            body. Nothing more exciting happening here in terms of content, but just
                            filling up the
                            space to make it look, at least at first glance, a bit more representative
                            of how this would
                            look in a real-world application.</div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h2 class="accordion-header" id="flush-headingseven">
                        <button class="accordion-button collapsed accordion__btn fw-bold mt-4" type="button"
                            data-bs-toggle="collapse" data-bs-target="#flush-collapseseven" aria-expanded="false"
                            aria-controls="flush-collapseseven">
                            Which is the best custom web app development company?
                        </button>
                    </h2>
                    <div id="flush-collapseseven" class="accordion-collapse collapse"
                        aria-labelledby="flush-headingseven" data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body accordion__body">Placeholder content for this accordion, which is
                            intended to
                            demonstrate the <code>.accordion-flush</code> class. This is the third
                            item's accordion
                            body. Nothing more exciting happening here in terms of content, but just
                            filling up the
                            space to make it look, at least at first glance, a bit more representative
                            of how this would
                            look in a real-world application.</div>
                    </div>
                </div>

                <div class="banner_btn py-3 text-center" data-aos="flip-left">
                    <a href="#" class="btn btn-lg mt-4 py-3 px-4">Get Started for Free</a>
                </div>
            </div>
        </div>
    </section>
    <!-- ============================== FAQ End ==============================-->
    <!-- ============================== Footer Start ==============================-->

<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/theme_1/pricing.blade.php ENDPATH**/ ?>