<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">
<div class="content container-fluid">
<div class="row">
<div class="col-sm-4 col-3">
    <h4 class="page-title">All Academic</h4>
</div>
<div class="col-sm-8 col-9 text-right m-b-20">
    <a href="#" class="btn btn-primary btn-rounded float-right" data-toggle="modal" data-target="#add_grade"><i class="fa fa-plus"></i> Add Academic</a>
</div>
</div>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
<strong>Whoops!</strong> There were some problems with your input.<br><br>
<ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
<p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<div class="row">
<?php if(count($academic) > 0): ?>
<div class="col-md-12">
    <div class="table-responsive">
        <table class="table table-striped custom-table datatable"  id="teachme_table">
            <thead>
                <tr>
                    <th>S/L</th>
                    <th>Title</th>
                    <th>Status</th>
                    <th class="text-right">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $academic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($grade->title); ?></td>
                    <td>
                        <?php if($grade->status === 'active'): ?>
                        <span class="p-2 badge badge-primary">Active</span>
                        <?php else: ?>
                        <span class="p-2 badge badge-secondary">Inactive</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-right">
                        <div class="dropdown dropdown-action">
                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_grade_<?php echo e($grade->id); ?>"><i class="fas fa-pen m-r-5"></i> Edit</a>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_grade_<?php echo e($grade->id); ?>"><i class="far fa-trash-alt m-r-5"></i> Delete</a>
                            </div>
                        </div>
                    </td>
                </tr>
                <div id="delete_grade_<?php echo e($grade->id); ?>" class="modal custom-modal fade" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content modal-md">
                            <div class="modal-header">
                                <h4 class="modal-title">Delete Academic</h4>
                            </div>
                            <form action="<?php echo e(route('academic.destroy', $grade->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <div class="modal-body card-box">
                                    <p>Are you sure want to delete this?</p>
                                    <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div id="edit_grade_<?php echo e($grade->id); ?>" class="modal custom-modal fade" role="dialog">
                <div class="modal-dialog">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <div class="modal-content modal-lg">
                        <div class="modal-header">
                            <h4 class="modal-title">Edit Academic</h4>
                        </div>
                        <div class="modal-body">
                            
                            <form class="m-b-30" action="<?php echo e(route('academic.update', $grade->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label class="col-form-label">Title<span class="text-danger">*</span></label>
                                            <input type="text" name="title" class="form-control" value="<?php echo e($grade->title); ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label class="col-form-label">Status <span class="text-danger">*</span></label>
                                            <select name="status" class="select floating">
                                                <option value="active" <?php if($grade->status === 'active'): ?> selected <?php endif; ?>>Active</option>
                                                <option value="inactive" <?php if($grade->status === 'inactive'): ?> selected <?php endif; ?>>Inactive</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="m-t-20 text-center mb-5">
                                    <button type="submit" class="btn btn-primary btn-lg">Update Academic</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

</div>
<?php else: ?>
<p class="p-4"><?php echo e('Academic Not Found!'); ?></p>
<?php endif; ?>
</div>
</div>
</div>
</div>
<div id="add_grade" class="modal custom-modal fade" role="dialog">
<div class="modal-dialog">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-content modal-lg">
<div class="modal-header">
<h4 class="modal-title">Add Academic</h4>
</div>
<div class="modal-body">
<form class="m-b-30" action="<?php echo e(route('academic.store')); ?>" method="POST" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="form-group">
            <label class="col-form-label">Title<span class="text-danger">*</span></label>
            <input type="text" name="title" class="form-control">
        </div>
    </div>
    
    <div class="col-sm-12">
        <div class="form-group form-focus select-focus">
            <label class="focus-label">Status</label>
            <select class="select floating" name="status">
                <option value="active">Enable</option>
                <option value="inactive">Disable</option>
            </select>
        </div>
    </div>
</div>
<div class="m-t-20 text-center mb-5">
    <button type="submit" class="btn btn-primary btn-lg">Create Academic</button>
</div>
</form>
</div>
</div>
</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\job_madhusudhan\resources\views/golbal_details/academic.blade.php ENDPATH**/ ?>