<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Main content -->
  <main id="profile-section" class="py-5 px-2 px-sm-4 mb-5">
    <div class="container rounded-5 p-4 gap-4 gap-md-5 box-shadow-md bg-white d-sm-flex">
      <!-- Tabs -->
      <ul
        class="nav nav-pills flex-sm-column flex-nowrap flex-sm-wrap overflow-x-auto overflow-x-sm-hidden overflow-x-md-visible gap-3 pe-sm-5 pe-md-4 pt-2 pb-2 pb-sm-0 border-end-sm justify-content-start border-bottom border-bottom-sm-0 "
        id="profile-tabs" role="tablist">
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link active" id="edit-tab" data-bs-toggle="tab" data-bs-target="#edit-tab-pane"
            type="button" role="tab" aria-controls="edit-tab-pane" aria-selected="true">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/user-square-light.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Profile</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="expertise-tab" data-bs-toggle="tab" data-bs-target="#expertise-tab-pane"
            type="button" role="tab" aria-controls="expertise-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/book-saved-light.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Expertise</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="education-tab" data-bs-toggle="tab" data-bs-target="#education-tab-pane"
            type="button" role="tab" aria-controls="education-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/teacher.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Education</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="experience-tab" data-bs-toggle="tab" data-bs-target="#experience-tab-pane"
            type="button" role="tab" aria-controls="experience-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/invoice.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Experience</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="payments-tab" data-bs-toggle="tab" data-bs-target="#payments-tab-pane"
            type="button" role="tab" aria-controls="payments-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/card.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Payments</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="settings-tab" data-bs-toggle="tab" data-bs-target="#settings-tab-pane"
            type="button" role="tab" aria-controls="settings-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/video-octagon-light.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Setting</span>
          </button>
        </li>
      </ul>

      <!-- Tab Panes -->
      <div class="tab-content mt-2 flex-grow-1" id="profile-tabs-content">
        <!-- Profile Panel -->
        <form name="profile-info-form" class="tab-pane fade show active" id="edit-tab-pane" role="tabpanel"
          aria-labelledby="edit-tab" tabindex="0">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">My Profile</h3>

            <button class="btn btn-success rounded-pill btn-sm border-secondary-subtle text-white">Save<i
                class="ms-2 fa-solid fa-save" style="font-size: 12px;"></i></button>
          </div>

          <!-- Profile Info -->
          <div class="card mt-4 p-1">
            <div class="card-body d-flex align-items-center gap-2">
              <div class="position-relative">
                <img src="<?php echo e(asset('public/theme_assets/images/avatar-tutor.png')); ?>" alt="Tutor Avatar" class="img-fluid" width="70" height="70">
                <label class="btn btn-primary btn-sm rounded-circle box-shadow-sm position-absolute"
                  style="bottom: -5px; right: -5px;">
                  <i class="fa-solid fa-pencil"></i>
                  <span class="visually-hidden">Upload New Profile Photo</span>
                  <input type="file" name="profile-photo" class="visually-hidden">
                </label>

              </div>

              <div class="fw-semibold text-uppercase">
                <span class="text-warning" style="font-size:12px;">Tutor</span>
                <h4 class="fs-6 fw-semibold mb-0">Esha Ahmad</h4>
                <span class="text-primary" style="font-size:12px;">Abu Dhabi, UAE</span>
              </div>
            </div>
          </div>

          <!-- Personal Info -->
          <fieldset name="personal-information" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-4">Personal Information</h3>

              <div class="p-2 mt-2">
                <div class="row gutter">
                  <!-- First Name -->
                  <div class="col-12 col-md-6 col-xl-4">
                    <label class="w-100">
                      <p class="title">First Name</p>
                      <input class="form-control mt-2 rounded-3" name="first-name" placeholder="Ahsan" required>
                    </label>
                  </div>
                  <!-- Last Name -->
                  <div class="col-12 col-md-6 col-xl-4">
                    <label class="w-100">
                      <p class="title">Last Name</p>
                      <input class="form-control mt-2 rounded-3" name="last-name" placeholder="Ali" required>
                    </label>
                  </div>
                  <div class="d-none d-xl-block col-xl-4"></div>
                  <!-- Email -->
                  <div class="col-12 col-md-6 col-xl-4">
                    <label class="w-100">
                      <p class="title">Email Address</p>
                      <input class="form-control mt-2 rounded-3" type="email" name="email" value="ahsanali@gmail.com"
                        disabled required>
                    </label>
                  </div>
                  <!-- Phone -->
                  <div class="col-12 col-md-6 col-xl-4">
                    <label class="w-100">
                      <p class="title">Phone</p>
                      <input class="form-control mt-2 rounded-3" name="phone" inputmode="numeric"
                        placeholder="+971 1231234" required>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </fieldset>

          <!-- Bio -->
          <fieldset name="bio" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-2">Bio</h3>

              <div class="py-2 pe-3 col-8">
                <!-- Bio -->
                <textarea name="bio" placeholder="Tell us about yourself" class="form-control" rows="5"
                  style="resize:none;" required aria-label="bio"></textarea>
              </div>
            </div>
          </fieldset>

          <!-- Intro-video -->
          <fieldset name="intro-video" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-2">Intro Video URL</h3>

              <div class="py-2 pe-3 col-8">
                  <input class="form-control mt-2 rounded-3" type="url" name="bio" placeholder="youtu.be/dummyurl" aria-label="intro video url">
              </div>
            </div>
          </fieldset>

        </form>

        <!-- Expertise Panel -->
        <form name="expertise-form" class="tab-pane fade" id="expertise-tab-pane" role="tabpanel"
          aria-labelledby="expertise-tab" tabindex="0">
          <!-- Heading -->
          <h3 class="fs-5">Expertise</h3>

          <!-- Curriculum -->
          <div class="card mt-4 p-2">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-6 fw-semibold">Curriculum</h3>

              <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4"
                style="padding-inline:.8rem;">
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="american" id="curriculum-american">
                  <label class="form-check-label" for="curriculum-american">
                    American
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="british" id="curriculum-british">
                  <label class="form-check-label" for="curriculum-british">
                    British
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="canadian" id="curriculum-canadian">
                  <label class="form-check-label" for="curriculum-canadian">
                    Canadian
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="sabis" id="curriculum-sabis">
                  <label class="form-check-label" for="curriculum-sabis">
                    Sabis
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="international" id="curriculum-international">
                  <label class="form-check-label" for="curriculum-international">
                    International
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="ib" id="curriculum-ib">
                  <label class="form-check-label" for="curriculum-ib">
                    IB
                  </label>
                </div>
              </div>
            </div>
          </div>

          <!-- Grades -->
          <div class="card mt-4 p-2">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-6 fw-semibold">Grades</h3>

              <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4"
                style="padding-inline:.8rem;">
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="early-years-kg" id="grade-early-years-kg">
                  <label class="form-check-label" for="grade-early-years-kg">
                    Early Years/KG
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="primary" id="grade-primary">
                  <label class="form-check-label" for="grade-primary">
                    Primary/Elementary
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="middle-school" id="grade-middle-school">
                  <label class="form-check-label" for="grade-middle-school">
                    Middle School
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="secondary-gsce" id="grade-secondary-gsce">
                  <label class="form-check-label" for="grade-secondary-gsce">
                    Secondary/GSCE
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="sixth-form-a-levels"
                    id="grade-sixth-form-a-levels">
                  <label class="form-check-label" for="grade-sixth-form-a-levels">
                    Sixth Form/A Levels
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="sen-tutor" id="grade-sen-tutor">
                  <label class="form-check-label" for="grade-sen-tutor">
                    SEN Tutor
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="shadow-teacher" id="grade-shadow-teacher">
                  <label class="form-check-label" for="grade-shadow-teacher">
                    Shadow Teacher
                  </label>
                </div>
              </div>
            </div>
          </div>

          <!-- Subjects -->
          <div class="card mt-4 p-2">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-6 fw-semibold">Subjects</h3>

              <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4"
                style="padding-inline:.8rem;">
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="english" id="subject-english">
                  <label class="form-check-label" for="subject-english">
                    English
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="chemistry" id="subject-chemistry">
                  <label class="form-check-label" for="subject-chemistry">
                    Chemistry
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="physics" id="subject-physics">
                  <label class="form-check-label" for="subject-physics">
                    Physics
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="math" id="subject-math">
                  <label class="form-check-label" for="subject-math">
                    Math
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="arabic" id="subject-arabic">
                  <label class="form-check-label" for="subject-arabic">
                    Arabic
                  </label>
                </div>
              </div>
            </div>
          </div>

          <!-- Languages -->
          <div class="card mt-4 p-2">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-6 fw-semibold">Languages spoken</h3>
              <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4"
                style="padding-inline:.8rem;">
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="english" id="language-english">
                  <label class="form-check-label" for="language-english">
                    English
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="spanish" id="language-spanish">
                  <label class="form-check-label" for="language-spanish">
                    Spanish
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="french" id="language-french">
                  <label class="form-check-label" for="language-french">
                    French
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="german" id="language-german">
                  <label class="form-check-label" for="language-german">
                    German
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="mandarin" id="language-mandarin">
                  <label class="form-check-label" for="language-mandarin">
                    Mandarin
                  </label>
                </div>
                <div class="col">
                  <button class="btn btn-link btn-sm text-warning-hover" type="button" More</button>
                </div>
              </div>
            </div>
          </div>
        </form>

        <!-- Education Panel -->
        <form name="education-form" class="tab-pane fade" id="education-tab-pane" role="tabpanel"
          aria-labelledby="education-tab" tabindex="0">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Education</h3>

            <button class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Add<i
                class="ms-2 fa-solid fa-plus" style="font-size: 12px;"></i></button>
          </div>

          <!-- Educations List -->
          <ul class="list-unstyled d-flex flex-column gap-2 mt-4">
            <li class="bg-body-tertiary rounded-3 p-3">
              <div class="row row-cols-1 row-cols-md-2 g-4">
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Degree</span>
                    <input class="form-control mt-2 rounded-3" name="degree" placeholder="PHD, Applied Sciences"
                      required>
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Institution Name</span>
                    <input class="form-control mt-2 rounded-3" name="institution-name"
                      placeholder="London South Bank University, London" required>
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Start Date</span>
                    <input class="form-control mt-2 rounded-3" type="date" name="start-date" required>
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">End Date</span>
                    <input class="form-control mt-2 rounded-3" type="date" name="end-date" required>
                  </label>
                </div>
              </div>
              <div class="mt-4 d-flex gap-3 flex-wrap justify-content-end">
                <button type="reset" class="btn btn-outline-secondary rounded-pill"><i
                    class="me-2 fa-solid fa-close"></i>Discard</button>
                <button type="submit" class="btn btn-success text-white rounded-pill"><i
                    class="me-2 fa-solid fa-save"></i>Save</button>
              </div>
            </li>
          </ul>
        </form>

        <!-- Experience Panel -->
        <form name="experience-form" class="tab-pane fade" id="experience-tab-pane" role="tabpanel"
          aria-labelledby="experience-tab" tabindex="0">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Experience</h3>

            <button class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Add<i
                class="ms-2 fa-solid fa-plus" style="font-size: 12px;"></i></button>
          </div>

          <!-- Experiences List -->
          <ul class="list-unstyled d-flex flex-column gap-2 mt-4">
            <li class="bg-body-tertiary rounded-3 p-3">
              <div class="row row-cols-1 row-cols-md-2 g-4">
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Title</span>
                    <input class="form-control mt-2 rounded-3" name="title" placeholder="Science Teacher" required>
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Institution Name</span>
                    <input class="form-control mt-2 rounded-3" name="institution-name"
                      placeholder="London South Bank University, London" required>
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Start Date</span>
                    <input class="form-control mt-2 rounded-3" type="date" name="start-date" required>
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">End Date</span>
                    <input class="form-control mt-2 rounded-3" type="date" name="end-date" required>
                  </label>
                </div>
                <div class="col">
                  <div class="form-check mt-2">
                    <input class="form-check-input" type="checkbox" value="currently-working" id="currently-working">
                    <label class="form-check-label" for="currently-working">
                      Currently Working
                    </label>
                  </div>
                </div>
              </div>
              <div class="mt-4 d-flex gap-3 flex-wrap justify-content-end">
                <button type="reset" class="btn btn-outline-secondary rounded-pill"><i
                    class="me-2 fa-solid fa-close"></i>Discard</button>
                <button type="submit" class="btn btn-success text-white rounded-pill"><i
                    class="me-2 fa-solid fa-save"></i>Save</button>
              </div>
            </li>
          </ul>
        </form>

        <!-- Payments Panel -->
        <div class="tab-pane fade" id="payments-tab-pane" role="tabpanel" aria-labelledby="setting-tab" tabindex="0">
          <!-- Heading -->
          <h3 class="fs-5">Payments</h3>

          <!-- Content -->
          <div class="mt-4 row g-3">
            <!-- Subscription -->
            <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Subscription</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-9 d-flex flex-column">
              <span>Plan Type: 100 AED / Year</span>
              <span>Status: Active</span>
            </div>
            <!-- Billing Date -->
            <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Billing Date</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-9">
              <span class="d-block">Your next billing date is March 26, 2024.</span>
              <button class="mt-2 btn btn-outline-secondary px-5" type="button">Cancel Membership</button>
            </div>
            <!-- Payment Methods -->
            <div class="col-12 col-sm-6 col-xl-3">
              <p class="fw-semibold">Payment Method</p>
            </div>
            <div class="col-12 col-sm-6 col-xl-9">
              <div class="d-flex gap-3 flex-wrap align-items-center">
                <div class="d-flex flex-column flex-sm-row align-items-sm-center gap-2 gap-sm-3">
                  <img src="<?php echo e(asset('public/theme_assets/images/credit-card.webp')); ?>" class="rounded" width="70" />
                  <div class="d-flex flex-column">
                    <span class="h6 mb-1">Credit Card</span>
                    <span class="small text-muted">**** **** **** 2570</span>
                  </div>
                </div>
                <div>
                  <button class="btn btn-outline-secondary" data-bs-toggle="collapse" data-bs-target="#update-card-info"
                    aria-expanded="false" aria-controls="update-card-info" type="button">
                    <i class="fa-solid fa-pencil"></i>
                    <span class="visually-hidden">Update</span>
                  </button>
                </div>
              </div>
            </div>
            <div class="col-12">
              <!-- Update Card Content -->
              <form name="update-card-info" class="collapse row py-3" id="update-card-info">
                <div class="col-12 col-lg-8 offset-lg-3">
                  <div class="card" style="border-radius: 15px;">
                    <div class="card-body p-4 row g-4">
                      <label class="col">
                        <span>Card Number</span>
                        <input class="form-control mt-2" inputmode="numeric" pattern="[0-9]{16}"
                          placeholder="1234 5678 9012 3457" minlength="16" maxlength="16" name="credit-card-number"
                          required />
                      </label>

                      <label class="col-12 col-md-6">
                        <span>Cardholder's Name</span>
                        <input class="form-control mt-2" size="17" name="card-holder-name" required />
                      </label>

                      <label class="col-12 col-md-6">
                        <span>Expiration</span>
                        <input class="form-control" placeholder="MM/YYYY" size="7" minlength="7" maxlength="7"
                          pattern="[0-9]{2}/20[0-9]{2}" required />
                      </label>
                      <label class="col-12 col-md-6">
                        <span>Cvv</span>
                        <input type="password" class="form-control" placeholder="&#9679;&#9679;&#9679;" size="1"
                          minlength="3" maxlength="3" required inputmode="numeric" pattern="[0-9]{3}" />
                      </label>
                      <div class="col d-flex justify-content-end">
                        <button class="btn btn-success text-white rounded-pill">
                          <i class="me-2 fa-solid fa-save"></i>
                          Save
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>

        <!-- Settings Panel -->
        <form name="settings-form" class="tab-pane fade" id="settings-tab-pane" role="tabpanel"
          aria-labelledby="setting-tab" tabindex="0">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Settings</h3>

            <button class="btn btn-success text-white rounded-pill btn-sm">Save<i class="ms-2 fa-solid fa-save"
                style="font-size: 12px;"></i></button>
          </div>

          <div class="mt-4 row g-3">
            <div class="col-12 col-sm-4 col-xl-3">
              <span class="fw-semibold">Mode of Instruction</span>
            </div>
            <div class="col-12 col-sm-8 col-xl-9">
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="type" id="mode-virtual" value="virtual" checked>
                <label class="form-check-label" for="mode-virtual">Virtual</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="type" id="mode-inperson" value="in-person">
                <label class="form-check-label" for="mode-inperson">In Person</label>
              </div>
            </div>
            <div class="col-12 col-sm-4 col-xl-3">
              <span class="fw-semibold">Password</span>
            </div>
            <div class="col-12 col-sm-8 col-xl-9">
              <div class="row g-4">
                <label class="col-12 col-lg-6">
                  <span class="small">Current Password</span>
                  <input class="form-control mt-2" type="password" name="current-password" required />
                </label>
                <div class="col-lg-6 d-lg-block d-none"></div>
                <label class="col-12 col-lg-6">
                  <span class="small">New Password</span>
                  <input class="form-control mt-2" type="password" name="new-password" required />
                </label>
                <label class="col-12 col-lg-6">
                  <span class="small">Confirm Password</span>
                  <input class="form-control mt-2" type="password" name="confirm-password" required />
                </label>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </main>
  <?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/teachme_editprofile.blade.php ENDPATH**/ ?>