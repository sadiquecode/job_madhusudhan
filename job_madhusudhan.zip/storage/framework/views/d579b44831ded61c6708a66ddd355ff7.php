<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Filter form</title>
    <!-- Custom CSS  -->
    <link href="<?php echo e(url('public/theme_assets/css/style.css')); ?>" rel="stylesheet">
    <!-- Bootstrap CSS  -->
    <link href="<?php echo e(url('public/theme_assets/bootstrap/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/3.0.2/css/buttons.dataTables.min.css">

    <style>
.filter-btn {
    padding: 6px 10px;  /* Smaller padding */
    font-size: 12px;    /* Smaller font size */
    min-width: 40px;    /* Smaller minimum width */
    min-height: 40px;   /* Smaller minimum height */
    margin: 5px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    position: relative;
}

.filter-btn .badge {
    position: absolute;
    top: -8px;
    right: -8px;
    border-radius: 50%;
    font-size: 8px;
    padding: 3px 5px;
}

@media (max-width: 576px) {
    .filter-btn {
        font-size: 10px;
        padding: 4px 8px;
        min-width: 30px;
        min-height: 30px;
    }

    .filter-btn .badge {
        font-size: 6px;
        padding: 2px 4px;
    }
}

    </style>
</head>
 
<body>
<div class="container my-5">
        <div class="jobform">
            
            

            <div class="container">

    <!-- Type Filter Buttons -->
    <div class="headingtext text-center py-3">
        <h6 class="fw-bold">Type</h6>
    </div>
    <div class="d-flex flex-wrap justify-content-center mb-4">
        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('filter-page?typeid=').$type->id); ?>" class="btn btn-sm btn-danger m-1 filter-btn rounded-5" data-filter="datatype-<?php echo e($type->id); ?>">
                <?php echo e($type->title); ?>

                <span class="badge rounded-pill bg-success">
                    <?php echo e($applications->where('data_types_id', $type->id)->count()); ?>

                </span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Speciality Filter Buttons -->
    <div class="headingtext text-center py-3">
        <h6 class="fw-bold">Specialities</h6>
    </div>
    <div class="d-flex flex-wrap justify-content-center mb-4">
        <?php $__currentLoopData = $specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" class="btn btn-sm btn-danger m-1 filter-btn rounded-5" data-filter="speciality-<?php echo e($speciality->id); ?>">
                <?php echo e($speciality->title); ?>

                <span class="badge rounded-pill bg-success">
                    <?php echo e($applications->where('speciality_id', $speciality->id)->count()); ?>

                </span>
            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Non-Academic Filter Buttons -->
    <div class="headingtext text-center">
        <h6 class="fw-bold">Non - Academic</h6>
    </div>
    <div class="d-flex flex-wrap justify-content-center mb-4">
        <?php $__currentLoopData = $nonAcademics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nonAcademic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" class="btn btn-sm btn-secondary m-1 filter-btn rounded-5" data-filter="non_academic-<?php echo e($nonAcademic->id); ?>">
                <?php echo e($nonAcademic->title); ?>

                <span class="badge rounded-pill bg-success">
                    <?php echo e($applications->where('non_academic_id', $nonAcademic->id)->count()); ?>

                </span>
            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Academic Filter Buttons -->
    <div class="headingtext text-center">
        <h6 class="fw-bold">Academic</h6>
    </div>
    <div class="d-flex flex-wrap justify-content-center mb-4">
        <?php $__currentLoopData = $academics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" class="btn btn-sm btn-primary m-1 filter-btn rounded-5" data-filter="academic-<?php echo e($academic->id); ?>">
                <?php echo e($academic->title); ?>

                <span class="badge rounded-pill bg-success">
                    <?php echo e($applications->where('academic_id', $academic->id)->count()); ?>

                </span>
            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Subject Wise Filter Buttons -->
    <div class="headingtext text-center">
        <h6 class="fw-bold">Subject Wise</h6>
    </div>
    <div class="d-flex flex-wrap justify-content-center mb-4">
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" class="btn btn-sm btn-info m-1 filter-btn rounded-5" data-filter="subject-<?php echo e($subject->id); ?>">
                <?php echo e($subject->title); ?>

                <span class="badge rounded-pill bg-success">
                    <?php echo e($applications->where('subject_id', $subject->id)->count()); ?>

                </span>
            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Applications Table -->
    <div class="container">
        <div class="table-responsive">
            <table class="table table-bordered" id="teachme_table">
                <thead>
                    <tr>
                        <th scope="col">SL.</th>
                        <th scope="col">NAME</th>
                        <th scope="col">YEAR AND EXP</th>
                        <th scope="col">SUBJECTS</th>
                        <th scope="col">PLACE</th>
                        <th scope="col">Salary Expected</th>
                        <th scope="col">RESUME</th>
                    </tr>
                </thead>
                <tbody id="applications-table">
                    <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-datatype="datatype-<?php echo e($application->data_types_id); ?>" data-speciality="speciality-<?php echo e($application->speciality_id); ?>" data-academic="academic-<?php echo e($application->academic_id); ?>" data-non-academic="non_academic-<?php echo e($application->non_academic_id); ?>" data-subject="subject-<?php echo e($application->subject_id); ?>">
                            <th scope="row"><?php echo e($key + 1); ?>.</th>
                            <td><a href="<?php echo e(url('application-details/'.$application->id)); ?>" target="_blank"><?php echo e($application->applicant_name); ?></a></td>
                            <td><?php echo e($application->experience_years); ?></td>
                            <td><?php echo e($application->qualification); ?></td>
                            <td><?php echo e($application->address); ?></td>
                            <td><?php echo e($application->salary_expected); ?></td>
                            <td><a href="<?php echo e(url('storage/app/'. $application->cv)); ?>" target="_blank" class="btn w-100 btn-sm rounded-0 btn-success fw-bold">Download</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="py-5">
                <a href="<?php echo e(url('dashboard')); ?>" class="btn d-inline-flex align-items-center fw-bold btn-primary gap-2"><svg
                        xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#ffffff"
                        class="bi bi-sign-turn-left-fill" viewBox="0 0 16 16">
                        <path
                            d="M9.05.435c-.58-.58-1.52-.58-2.1 0L.436 6.95c-.58.58-.58 1.519 0 2.098l6.516 6.516c.58.58 1.519.58 2.098 0l6.516-6.516c.58-.58.58-1.519 0-2.098zM7 8.466a.25.25 0 0 1-.41.192L4.23 6.692a.25.25 0 0 1 0-.384l2.36-1.966a.25.25 0 0 1 .41.192V6h1.5A2.5 2.5 0 0 1 11 8.5V11h-1V8.5A1.5 1.5 0 0 0 8.5 7H7z" />
                    </svg>Back</a>
            </div>

</div>

        </div>
    </div>

<!-- Bootstrap JS -->
<script type="text/javascript" src="<?php echo e(url('public/assets/js/jquery-3.5.1.min.js')); ?>"></script>

<script src="https://cdn.datatables.net/2.0.4/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/2.0.4/js/dataTables.bootstrap4.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.2/js/dataTables.buttons.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.bootstrap4.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.print.min.js"></script>


<script>


$(document).ready(function() {
    var dataTable = $('#teachme_table').DataTable();

    if (dataTable && $.fn.DataTable.isDataTable('#teachme_table')) {
        dataTable.destroy();
    }

    // Re-initialize DataTable
    $('#teachme_table').DataTable({
        "paging": true, // Enable pagination
        "searching": true, // Enable search bar
        "pageLength": 20,
        // "dom": '<"top-left"f><"top-right"B>rt<"bottom-left"l><"bottom-right"ip>',
        // "buttons": [ // Add export buttons
        //     'copy', // Copy to clipboard
        //     'csv', // Export to CSV
        //     'excel', // Export to Excel
        //     'pdf', // Export to PDF
        //     'print' // Print button
        // ]
    });

});



document.addEventListener('DOMContentLoaded', function () {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const tableRows = document.querySelectorAll('#applications-table tr');

    filterButtons.forEach(button => {
        button.addEventListener('click', function () {
            const filter = this.getAttribute('data-filter');
            tableRows.forEach(row => {
                const datatype = row.getAttribute('data-datatype');
                const speciality = row.getAttribute('data-speciality');
                const academic = row.getAttribute('data-academic');
                const nonAcademic = row.getAttribute('data-non-academic');
                const subject = row.getAttribute('data-subject');

                if (datatype === filter || speciality === filter || academic === filter || nonAcademic === filter || subject === filter) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    });
});



</script>

</body>

</html><?php /**PATH D:\server\htdocs\job_madhusudhan\resources\views/main/filter_data.blade.php ENDPATH**/ ?>