<style>
  /* Alert styles */
  .alert {
    padding: 1rem;
    margin-bottom: 1rem;
    border: 1px solid transparent;
    border-radius: 0.25rem;
    position: relative;
  }

  .alert-danger {
    color: #721c24;
    background-color: #f8d7da;
    border-color: #f5c6cb;
  }

  .alert-success {
    color: #155724;
    background-color: #d4edda;
    border-color: #c3e6cb;
  }


  /* Close button styles */
  .close {
    position: absolute;
    top: 0;
    right: 0;
    padding: 0.75rem 1.25rem;
    color: inherit;
    background-color: transparent;
    border: 0;
    cursor: pointer;
  }
</style>

<?php if($errors->any()): ?>
  <div class="alert alert-danger" role="alert">
    
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <p><?php echo e($error); ?></p>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <button type="button" class="close" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
<?php endif; ?>

<?php if($message = Session::get('success')): ?>
  <div class="alert alert-success" role="alert">
    <?php echo e($message); ?>

    <button type="button" class="close" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>
  <div class="alert alert-danger" role="alert">
    <?php echo e($message); ?>

    <button type="button" class="close" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
<?php endif; ?>


<script type="text/javascript">
  
      // Close button functionality
  document.querySelectorAll('.close').forEach(function(closeButton) {
    closeButton.addEventListener('click', function() {
      this.parentNode.style.display = 'none';
    });
  });
</script><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/userprofile/message.blade.php ENDPATH**/ ?>