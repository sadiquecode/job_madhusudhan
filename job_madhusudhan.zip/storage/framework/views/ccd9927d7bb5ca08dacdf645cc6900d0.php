<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">
<div class="content container-fluid">
<div class="row">
<div class="col-sm-8 col-4">
    <h4 class="page-title">Subscription Packages
</h4>
</div>

</div>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
<strong>Whoops!</strong> There were some problems with your input.<br><br>
<ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
<?php if(Session::has('error')): ?>
<div class="alert alert-danger">
    <p><?php echo e(Session::get('error')); ?></p>
</div>
<?php endif; ?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
<p><?php echo e($message); ?></p>
</div>
<?php endif; ?>


<div id="alert-container" class="mt-3" style="display: none;"></div>

<div class="row">
<div class="col-md-12">
    <div class="card-box">
        <h4 class="card-title">Subscription Packages</h4>
        <ul class="nav nav-tabs nav-tabs-solid nav-tabs-rounded">
            <li class="nav-item"><a class="nav-link package active" href="#monthly-tab1" data-toggle="tab" data-package_type="Monthly">Monthly</a></li>
            <li class="nav-item"><a class="nav-link package" href="#yearly-tab2" data-toggle="tab" data-package_type="Yearly">Yearly</a></li>
            <li class="nav-item"><a class="nav-link package" href="#lifetime-tab3" data-toggle="tab" data-package_type="Lifetime">Lifetime</a></li>
        </ul>
    </div>
</div>
</div>
<!-- Monthly -->
<div class="row"> 
<?php if (Auth::user()->type == 'admin') { ?>
<div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
    <div class="tab-content">
        <div class="tab-pane show active" id="monthly-tab1">
            <div class="row">
                <?php $count = 1; ?>
                <?php $__currentLoopData = $monthly_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m_package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                    <div class="pricing-box">
                        <div class="d-flex align-items-center justify-content-between">
                            <h3 class="edit_package_title tt_update_text my-content-editable" data-name="name" contenteditable="true" data-gramm="false" wt-ignore-input="true" data-quillbot-element="i5WZpR9B5rA0xO1kj0Kqm" data-package_id="<?php echo e($m_package->id); ?>"> <?php echo e($m_package->name); ?></h3>
                            <span style="cursor:pointer;">
                                <i class="fas fa-pencil-alt mb-4"></i>
                            </span>
                        </div>
                        <div class="d-flex align-items-center justify-content-between mb-4">
                            <p class="edit_description  my-content-editable" data-name="description" contenteditable="true" data-gramm="false" wt-ignore-input="true" data-package_id="<?php echo e($m_package->id); ?>"> <?php echo e($m_package->description); ?></p>
                            <span style="cursor:pointer;">
                                <i class="fas fa-pencil-alt cursor-pointer mb-4"></i>
                            </span>
                        </div>
                        <div class="d-flex align-items-center justify-content-between">
                            <span>$</span><h1 class="edit_price pricing-rate  my-content-editable" data-name="price" contenteditable="true" data-gramm="false" wt-ignore-input="true" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->price); ?></h1>
                            <span style="cursor:pointer;">
                                <i class="fas fa-pencil-alt cursor-pointer"></i>
                            </span>
                        </div>
                        <ul>
                            
                        <div class="d-flex align-items-center justify-content-between">
                            <li> 
                                <i class="fas fa-check-circle"></i> 
                                <b><?php echo e($m_package->ai_templates); ?></b> AI Templates
                            </li>
                        <span style="cursor: pointer;" class="get_package_temp" data-package_id="<?php echo e($m_package->id); ?>">
                            <i class="fas fa-pencil-alt cursor-pointer"></i>
                        </span>
                        </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas fa-check-circle"></i> <b contenteditable="true" class="edit_words_per_month my-content-editable" data-name="words_per_month" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->words_per_month); ?></b> Words per month</li>
                                <span style="cursor:pointer;">
                                    <i class="fas fa-pencil-alt cursor-pointer"></i>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas fa-check-circle"></i> <b contenteditable="true" class="edit_images_per_month my-content-editable" data-name="images_per_month" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->images_per_month); ?></b> Images per month</li>
                                <span style="cursor:pointer;">
                                    <i class="fas fa-pencil-alt cursor-pointer"></i>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas fa-check-circle"></i> <b contenteditable="true" class="edit_speech_to_text_per_month my-content-editable" data-name="speech_to_text_per_month" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->speech_to_text_per_month); ?></b> Speech to Text per month</li>
                                <span style="cursor:pointer;">
                                    <i class="fas fa-pencil-alt cursor-pointer"></i>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas fa-check-circle"></i> <b contenteditable="true" class="edit_audio_file_size my-content-editable" data-name="audio_file_size" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->audio_file_size); ?></b> MB Audio file size limit</li>
                                <span style="cursor:pointer;">
                                    <i class="fas fa-pencil-alt cursor-pointer"></i>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                    <i class="fas <?php if($m_package->has_ai_chat == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Allow AI Chat
                                </li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_ai_chat.'_has_ai_chat'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_ai_chat" data-value="<?php echo e($m_package->has_ai_chat); ?>" <?php if($m_package->has_ai_chat == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_ai_chat.'_has_ai_chat'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                    <i class="fas <?php if($m_package->has_ai_images == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Allow AI Images
                                </li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_ai_images.'_has_ai_images'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_ai_images" data-value="<?php echo e($m_package->has_ai_images); ?>" <?php if($m_package->has_ai_images == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_ai_images.'_has_ai_images'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->has_ai_code == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Allow AI Code</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_ai_code.'_has_ai_code'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_ai_code" data-value="<?php echo e($m_package->has_ai_code); ?>" <?php if($m_package->has_ai_code == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_ai_code.'_has_ai_code'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->has_speech_to_text == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Speech to Text</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_speech_to_text.'_has_speech_to_text'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_speech_to_text" data-value="<?php echo e($m_package->has_speech_to_text); ?>" <?php if($m_package->has_speech_to_text == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_speech_to_text.'_has_speech_to_text'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->has_custom_templates == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Custom Templates</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_custom_templates.'_has_custom_templates'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_custom_templates" data-value="<?php echo e($m_package->has_custom_templates); ?>" <?php if($m_package->has_custom_templates == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_custom_templates.'_has_custom_templates'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->has_live_support == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Live Support</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_live_support.'_has_live_support'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_live_support" data-value="<?php echo e($m_package->has_live_support); ?>" <?php if($m_package->has_live_support == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_live_support.'_has_live_support'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->has_free_support == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Free Support</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_free_support.'_has_free_support'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_free_support" data-value="<?php echo e($m_package->has_free_support); ?>" <?php if($m_package->has_free_support == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_free_support.'_has_free_support'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->is_featured == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Is Featured?</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->is_featured.'_is_featured'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="is_featured" data-value="<?php echo e($m_package->is_featured); ?>" <?php if($m_package->is_featured == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->is_featured.'_is_featured'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            
                            
                            
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <i class="fas fa-check-circle" aria-hidden="true" style="color:#1d6ad2;"></i>
                            
                            <select class="form-control model-select" style="width:60%;" name="ai_model_id" id="" data-key="ai_model_id" data-package_id="<?php echo e($m_package->id); ?>">
                                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($model->id); ?>" <?php echo e($model->id == $m_package->ai_model_id ? 'selected' : ''); ?>><?php echo e($model->model); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>


                                <span>
                                    <div class="material-switch float-right">
                                        <span class="mr-2">Show?</span>
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->ai_model_status.'_ai_model_status'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="ai_model_status" data-value="<?php echo e($m_package->ai_model_status); ?>" <?php if($m_package->ai_model_status == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->ai_model_status.'_ai_model_status'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            
                        </ul>
                        
                        <style>
                        .active_btn label::before {
                        left: 3px !important;
                        }
                        </style>
                        <div class="material-switch active_btn mt-5">
                            <span class="mr-2"><strong>Is Active?</strong></span>
                            <input id="<?php echo e($m_package->id.'_'.$m_package->status.'_status'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="status" data-value="<?php echo e($m_package->status); ?>" <?php if($m_package->status == 1): ?>
                            checked
                            <?php endif; ?>>
                            <label for="<?php echo e($m_package->id.'_'.$m_package->status.'_status'); ?>" class="badge-primary"></label>
                            <?php if($count == 1): ?>
                                <br><small class="mt-3 text-muted">* If active, this will be applied to new user's registration.</small>
                            <?php else: ?>
                            <a href="<?php echo e(url('deletePackage/'.$m_package->id)); ?>" class="float-right bg-danger p-1" onclick="return confirm('Are you sure you want to delete this Package?');"><i class="p-2 text-white fa fa-trash"></i></a>
                            <?php endif; ?>
                            
                            
                        </div>
                    </div>
                </div>
                <?php $count++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                    <div class="pricing-box add-pricing">
                        <div class="display-table">
                            <div class="table-cell">
                                <a href="#" class="btn add-price-btn btn-rounded" data-toggle="modal" data-target="#add_package_1"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- yearly -->
        <div class="tab-pane" id="yearly-tab2">
            <div class="row">
                <?php $__currentLoopData = $yearly_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m_package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                    <div class="pricing-box">
                        <div class="d-flex align-items-center justify-content-between">
                            <h3 class="edit_package_title tt_update_text my-content-editable" data-name="name" contenteditable="true" data-gramm="false" wt-ignore-input="true" data-quillbot-element="i5WZpR9B5rA0xO1kj0Kqm" data-package_id="<?php echo e($m_package->id); ?>"> <?php echo e($m_package->name); ?></h3>
                            <span style="cursor:pointer;">
                                <i class="fas fa-pencil-alt mb-4"></i>
                            </span>
                        </div>
                        <div class="d-flex align-items-center justify-content-between mb-4">
                            <p class="edit_description my-content-editable" data-name="description" contenteditable="true" data-gramm="false" wt-ignore-input="true" data-package_id="<?php echo e($m_package->id); ?>"> <?php echo e($m_package->description); ?></p>
                            <span style="cursor:pointer;">
                                <i class="fas fa-pencil-alt cursor-pointer mb-4"></i>
                            </span>
                        </div>
                        <div class="d-flex align-items-center justify-content-between">
                            <span>$</span><h1 class="edit_price pricing-rate my-content-editable" data-name="price" contenteditable="true" data-gramm="false" wt-ignore-input="true" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->price); ?></h1>
                            <span style="cursor:pointer;">
                                <i class="fas fa-pencil-alt cursor-pointer"></i>
                            </span>
                        </div>
                        <ul>
                            
                      <div class="d-flex align-items-center justify-content-between">
                            <li> 
                                <i class="fas fa-check-circle"></i> 
                                <b><?php echo e($m_package->ai_templates); ?></b> AI Templates
                            </li>
                        <span style="cursor: pointer;" class="get_package_temp" data-package_id="<?php echo e($m_package->id); ?>">
                            <i class="fas fa-pencil-alt cursor-pointer"></i>
                        </span>
                        </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas fa-check-circle"></i> <b contenteditable="true" class="edit_words_per_month my-content-editable" data-name="words_per_month" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->words_per_month); ?></b> Words per month</li>
                                <span style="cursor:pointer;">
                                    <i class="fas fa-pencil-alt cursor-pointer"></i>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas fa-check-circle"></i> <b contenteditable="true" class="edit_images_per_month my-content-editable" data-name="images_per_month" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->images_per_month); ?></b> Images per month</li>
                                <span style="cursor:pointer;">
                                    <i class="fas fa-pencil-alt cursor-pointer"></i>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas fa-check-circle"></i> <b contenteditable="true" class="edit_speech_to_text_per_month my-content-editable" data-name="speech_to_text_per_month" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->speech_to_text_per_month); ?></b> Speech to Text per month</li>
                                <span style="cursor:pointer;">
                                    <i class="fas fa-pencil-alt cursor-pointer"></i>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas fa-check-circle"></i> <b contenteditable="true" class="edit_audio_file_size my-content-editable" data-name="audio_file_size" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->audio_file_size); ?></b> MB Audio file size limit</li>
                                <span style="cursor:pointer;">
                                    <i class="fas fa-pencil-alt cursor-pointer"></i>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                    <i class="fas <?php if($m_package->has_ai_chat == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Allow AI Chat
                                </li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_ai_chat.'_has_ai_chat'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_ai_chat" data-value="<?php echo e($m_package->has_ai_chat); ?>" <?php if($m_package->has_ai_chat == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_ai_chat.'_has_ai_chat'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                    <i class="fas <?php if($m_package->has_ai_images == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Allow AI Images
                                </li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_ai_images.'_has_ai_images'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_ai_images" data-value="<?php echo e($m_package->has_ai_images); ?>" <?php if($m_package->has_ai_images == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_ai_images.'_has_ai_images'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->has_ai_code == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Allow AI Code</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_ai_code.'_has_ai_code'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_ai_code" data-value="<?php echo e($m_package->has_ai_code); ?>" <?php if($m_package->has_ai_code == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_ai_code.'_has_ai_code'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li> <i class="fas <?php if($m_package->has_speech_to_text == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Speech to Text</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_speech_to_text.'_has_speech_to_text'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_speech_to_text" data-value="<?php echo e($m_package->has_speech_to_text); ?>" <?php if($m_package->has_speech_to_text == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_speech_to_text.'_has_speech_to_text'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->has_custom_templates == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Custom Templates</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_custom_templates.'_has_custom_templates'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_custom_templates" data-value="<?php echo e($m_package->has_custom_templates); ?>" <?php if($m_package->has_custom_templates == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_custom_templates.'_has_custom_templates'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->has_live_support == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Live Support</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_live_support.'_has_live_support'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_live_support" data-value="<?php echo e($m_package->has_live_support); ?>" <?php if($m_package->has_live_support == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_live_support.'_has_live_support'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->has_free_support == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Free Support</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_free_support.'_has_free_support'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_free_support" data-value="<?php echo e($m_package->has_free_support); ?>" <?php if($m_package->has_free_support == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_free_support.'_has_free_support'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->is_featured == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Is Featured?</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->is_featured.'_is_featured'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="is_featured" data-value="<?php echo e($m_package->is_featured); ?>" <?php if($m_package->is_featured == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->is_featured.'_is_featured'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            
                            
                            
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <i class="fas fa-check-circle" aria-hidden="true" style="color:#1d6ad2;"></i>
                            <select class="form-control model-select" style="width:60%;" name="ai_model_id" id="" data-key="ai_model_id" data-package_id="<?php echo e($m_package->id); ?>">
                                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($model->id); ?>" <?php echo e($model->id == $m_package->ai_model_id ? 'selected' : ''); ?>><?php echo e($model->model); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                                <span>
                                    <div class="material-switch float-right">
                                        <span class="mr-2">Show?</span>
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->ai_model_status.'_ai_model_status'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="ai_model_status" data-value="<?php echo e($m_package->ai_model_status); ?>" <?php if($m_package->ai_model_status == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->ai_model_status.'_ai_model_status'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div> 
                            
                        </ul>
                        
                        <style>
                        .active_btn label::before {
                        left: 3px !important;
                        }
                        </style>
                        <div class="material-switch active_btn mt-5">
                            <span class="mr-2"><strong>Is Active?</strong></span>
                            <input id="<?php echo e($m_package->id.'_'.$m_package->status.'_status'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="status" data-value="<?php echo e($m_package->status); ?>" <?php if($m_package->status == 1): ?>
                            checked
                            <?php endif; ?>>
                            <label for="<?php echo e($m_package->id.'_'.$m_package->status.'_status'); ?>" class="badge-primary"></label>
                            <a href="<?php echo e(url('deletePackage/'.$m_package->id)); ?>" class="float-right bg-danger p-1" onclick="return confirm('Are you sure you want to delete this Package?');"><i class="p-2 text-white fa fa-trash"></i></a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                    <div class="pricing-box add-pricing">
                        <div class="display-table">
                            <div class="table-cell">
                                <a href="#" class="btn add-price-btn btn-rounded" data-toggle="modal" data-target="#add_package_1"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- lifetime -->
        <div class="tab-pane" id="lifetime-tab3">
            <div class="row">
                <?php $__currentLoopData = $lifetime_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m_package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                    <div class="pricing-box">
                        <div class="d-flex align-items-center justify-content-between">
                            <h3 class="edit_package_title tt_update_text my-content-editable" data-name="name" contenteditable="true" data-gramm="false" wt-ignore-input="true" data-quillbot-element="i5WZpR9B5rA0xO1kj0Kqm" data-package_id="<?php echo e($m_package->id); ?>"> <?php echo e($m_package->name); ?></h3>
                            <span style="cursor:pointer;">
                                <i class="fas fa-pencil-alt mb-4"></i>
                            </span>
                        </div>
                        <div class="d-flex align-items-center justify-content-between mb-4">
                            <p class="edit_description my-content-editable" data-name="description" contenteditable="true" data-gramm="false" wt-ignore-input="true" data-package_id="<?php echo e($m_package->id); ?>"> <?php echo e($m_package->description); ?></p>
                            <span style="cursor:pointer;">
                                <i class="fas fa-pencil-alt cursor-pointer mb-4"></i>
                            </span>
                        </div>
                        <div class="d-flex align-items-center justify-content-between">
                            <span>$</span><h1 class="edit_price pricing-rate my-content-editable" data-name="price" contenteditable="true" data-gramm="false" wt-ignore-input="true" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->price); ?></h1>
                            <span style="cursor:pointer;">
                                <i class="fas fa-pencil-alt cursor-pointer"></i>
                            </span>
                        </div>
                        <ul>
                            
                      <div class="d-flex align-items-center justify-content-between">
                            <li> 
                                <i class="fas fa-check-circle"></i> 
                                <b><?php echo e($m_package->ai_templates); ?></b> AI Templates
                            </li>
                        <span style="cursor: pointer;" class="get_package_temp" data-package_id="<?php echo e($m_package->id); ?>">
                            <i class="fas fa-pencil-alt cursor-pointer"></i>
                        </span>
                        </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas fa-check-circle"></i> <b contenteditable="true" class="edit_words_per_month my-content-editable" data-name="words_per_month" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->words_per_month); ?></b> Words per month</li>
                                <span style="cursor:pointer;">
                                    <i class="fas fa-pencil-alt cursor-pointer"></i>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas fa-check-circle"></i> <b contenteditable="true" class="edit_images_per_month my-content-editable" data-name="images_per_month" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->images_per_month); ?></b> Images per month</li>
                                <span style="cursor:pointer;">
                                    <i class="fas fa-pencil-alt cursor-pointer"></i>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas fa-check-circle"></i> <b contenteditable="true" class="edit_speech_to_text_per_month my-content-editable" data-name="speech_to_text_per_month" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->speech_to_text_per_month); ?></b> Speech to Text per month</li>
                                <span style="cursor:pointer;">
                                    <i class="fas fa-pencil-alt cursor-pointer"></i>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas fa-check-circle"></i> <b contenteditable="true" class="edit_audio_file_size my-content-editable" data-name="audio_file_size" data-package_id="<?php echo e($m_package->id); ?>"><?php echo e($m_package->audio_file_size); ?></b> MB Audio file size limit</li>
                                <span style="cursor:pointer;">
                                    <i class="fas fa-pencil-alt cursor-pointer"></i>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                    <i class="fas <?php if($m_package->has_ai_chat == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Allow AI Chat
                                </li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_ai_chat.'_has_ai_chat'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_ai_chat" data-value="<?php echo e($m_package->has_ai_chat); ?>" <?php if($m_package->has_ai_chat == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_ai_chat.'_has_ai_chat'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                    <i class="fas <?php if($m_package->has_ai_images == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Allow AI Images
                                </li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_ai_images.'_has_ai_images'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_ai_images" data-value="<?php echo e($m_package->has_ai_images); ?>" <?php if($m_package->has_ai_images == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_ai_images.'_has_ai_images'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->has_ai_code == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Allow AI Code</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_ai_code.'_has_ai_code'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_ai_code" data-value="<?php echo e($m_package->has_ai_code); ?>" <?php if($m_package->has_ai_code == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_ai_code.'_has_ai_code'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->has_speech_to_text == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Speech to Text</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_speech_to_text.'_has_speech_to_text'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_speech_to_text" data-value="<?php echo e($m_package->has_speech_to_text); ?>" <?php if($m_package->has_speech_to_text == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_speech_to_text.'_has_speech_to_text'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->has_custom_templates == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Custom Templates</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_custom_templates.'_has_custom_templates'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_custom_templates" data-value="<?php echo e($m_package->has_custom_templates); ?>" <?php if($m_package->has_custom_templates == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_custom_templates.'_has_custom_templates'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->has_live_support == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Live Support</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_live_support.'_has_live_support'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_live_support" data-value="<?php echo e($m_package->has_live_support); ?>" <?php if($m_package->has_live_support == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_live_support.'_has_live_support'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->has_free_support == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Free Support</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->has_free_support.'_has_free_support'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="has_free_support" data-value="<?php echo e($m_package->has_free_support); ?>" <?php if($m_package->has_free_support == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->has_free_support.'_has_free_support'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <li>
                                <i class="fas <?php if($m_package->is_featured == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?> "></i> Is Featured?</li>
                                <span>
                                    <div class="material-switch float-right">
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->is_featured.'_is_featured'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="is_featured" data-value="<?php echo e($m_package->is_featured); ?>" <?php if($m_package->is_featured == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->is_featured.'_is_featured'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            
                            
                            
                            
                            <div class="d-flex align-items-center justify-content-between">
                                <i class="fas fa-check-circle" aria-hidden="true" style="color:#1d6ad2;"></i>
                            <select class="form-control model-select" style="width:60%;" name="ai_model_id" id="" data-key="ai_model_id" data-package_id="<?php echo e($m_package->id); ?>">
                                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($model->id); ?>" <?php echo e($model->id == $m_package->ai_model_id ? 'selected' : ''); ?>><?php echo e($model->model); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                                <span>
                                    <div class="material-switch float-right">
                                        <span class="mr-2">Show?</span>
                                        <input id="<?php echo e($m_package->id.'_'.$m_package->ai_model_status.'_ai_model_status'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="ai_model_status" data-value="<?php echo e($m_package->ai_model_status); ?>" <?php if($m_package->ai_model_status == 1): ?> checked <?php endif; ?>>
                                        <label for="<?php echo e($m_package->id.'_'.$m_package->ai_model_status.'_ai_model_status'); ?>" class="badge-primary"></label>
                                    </div>
                                </span>
                            </div>
                            
                        </ul>
                        
                        <style>
                        .active_btn label::before {
                        left: 3px !important;
                        }
                        </style>
                        <div class="material-switch active_btn mt-5">
                            <span class="mr-2"><strong>Is Active?</strong></span>
                            <input id="<?php echo e($m_package->id.'_'.$m_package->status.'_status'); ?>" type="checkbox" data-package_id="<?php echo e($m_package->id); ?>" data-key="status" data-value="<?php echo e($m_package->status); ?>" <?php if($m_package->status == 1): ?>
                            checked
                            <?php endif; ?>>
                            <label for="<?php echo e($m_package->id.'_'.$m_package->status.'_status'); ?>" class="badge-primary"></label>
                            <a href="<?php echo e(url('deletePackage/'.$m_package->id)); ?>" class="float-right bg-danger p-1" onclick="return confirm('Are you sure you want to delete this Package?');"><i class="p-2 text-white fa fa-trash"></i></a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                    <div class="pricing-box add-pricing">
                        <div class="display-table">
                            <div class="table-cell">
                                <a href="#" class="btn add-price-btn btn-rounded" data-toggle="modal" data-target="#add_package_1"><i class="fa fa-plus" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } else{ ?>
<div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
    <div class="tab-content">
        <div class="tab-pane show active" id="monthly-tab1">
            <div class="row">
                <?php $package_no=1; ?>
                <?php $__currentLoopData = $monthly_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m_package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                    <div class="pricing-box">
                        <h3 class="pricing-title"><?php echo e($m_package->name); ?>

                            <?php if($m_package->is_featured == 1): ?>
                                <span class="btn-sm btn btn-success" style="font-size: 10px; border-radius: 10px;">Featured</span>
                            <?php endif; ?>
                            
                        </h3>
                        <h1 class="pricing-rate"><sup>$</sup><?php echo e($m_package->price); ?></h1>
                        <p><?php echo e($m_package->description); ?></p>
                        <ul>
                            <li><i class="fas <?php if($m_package->ai_templates > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i> <b><?php echo e($m_package->ai_templates); ?></b> AI Templates</li>
                            <li><i class="fas <?php if($m_package->words_per_month > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i><b> <?php echo e($m_package->words_per_month); ?></b> Words per month</li>
                            <li><i class="fas <?php if($m_package->images_per_month > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i> <b><?php echo e($m_package->images_per_month); ?></b> Images per month</li>

                        <li>
                            <i class="fas <?php if($m_package->speech_to_text_per_month > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>
                            <b><?php echo e($m_package->speech_to_text_per_month); ?></b> Speech to Text per month
                        </li>

                        <li>
                            <i class="fas <?php if($m_package->audio_file_size > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>
                            <b><?php echo e($m_package->audio_file_size); ?></b> MB Audio file size limit
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_ai_chat == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>Allow AI Chat
                        </li>

                        <li>
                            <i class="fas <?php if($m_package->has_ai_images == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>Allow AI Images
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_ai_code == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>Allow AI Code
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_speech_to_text == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>Speech to Text
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_custom_templates == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i> Custom Templates
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_live_support == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>  Live Support
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_free_support == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>   Free Support
                        </li>

                        <?php if($m_package->ai_model_status == 1): ?>
                           <li>
                            <i class="fas fa-check-circle"></i>  
                            <?php echo e(is_ai_model($m_package->ai_model_id)->model); ?>

                            </li> 
                        <?php endif; ?>
                        
                        
                        

                            <li>&nbsp;</li>
                        </ul>
                        <?php if($package_no == 1 && is_active_package_free(Auth::user()->id) == 1): ?>
                            <a href="<?php echo e(url('dashboard/subscriptions/histories')); ?>" class="btn btn-success btn-rounded w-md"> Activated</a>
                            
                        <?php else: ?>
                        <a href="#" data-toggle="modal" data-target="#subscribe_package_<?php echo e($m_package->id); ?>" class="btn btn-primary btn-rounded w-md"> Subscribe</a>
                        <?php endif; ?>
                        
                    </div>

                    <!-- subscribe package -->
<div id="subscribe_package_<?php echo e($m_package->id); ?>" class="modal custom-modal fade" role="dialog">
<div class="modal-dialog modal-dialog-centered">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-content">
    <b><i class="text-danger">During New Package Activation, Activated Package Will Move to Inactive.</i></b>
<div class="modal-header">
<h3 class="modal-title">Select Payment Method</h3>
</div>
<div class="modal-body">
    <form action="<?php echo e(route('add.subscriptions.histories')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="input-group m-b-30">
    <input type="hidden" name="package_id" value="<?php echo e($m_package->id); ?>">
    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
    <input type="hidden" name="package_type" value="monthly">
    <input type="hidden" name="price" value="<?php echo e($m_package->price); ?>">
    
    <select class="form-control search-input" name="payment_method_id">
        <option value="">Select Payment Method</option>
        <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pay->id); ?>"><?php echo e($pay->title); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(get_general_settings()->offline_payment_status == 1): ?>)
            <option value="offline">Offline Payment</option>
        <?php endif; ?>
    </select>
    <span class="input-group-append">
        <button type="submit" class="btn btn-primary">Proceed</button>
    </span>
    </div>
    </form>
</div>
</div>
</div>
</div>
                </div>
                <?php $package_no++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!-- yearly -->
        <div class="tab-pane" id="yearly-tab2">
            <div class="row">
                <?php $__currentLoopData = $yearly_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m_package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                    <div class="pricing-box">
                        <h3 class="pricing-title"><?php echo e($m_package->name); ?>

                            <?php if($m_package->is_featured == 1): ?>
                                <span class="btn-sm btn btn-success" style="font-size: 10px; border-radius: 10px;">Featured</span>
                            <?php endif; ?>
                        </h3>
                        <h1 class="pricing-rate"><sup>$</sup><?php echo e($m_package->price); ?></h1>
                        <p><?php echo e($m_package->description); ?></p>
                        <ul>
                            <li><i class="fas <?php if($m_package->ai_templates > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i> <b><?php echo e($m_package->ai_templates); ?></b> AI Templates</li>
                            <li><i class="fas <?php if($m_package->words_per_month > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i><b> <?php echo e($m_package->words_per_month); ?></b> Words per month</li>
                            <li><i class="fas <?php if($m_package->images_per_month > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i> <b><?php echo e($m_package->images_per_month); ?></b> Images per month</li>

                        <li>
                            <i class="fas <?php if($m_package->speech_to_text_per_month > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>
                            <b><?php echo e($m_package->speech_to_text_per_month); ?></b> Speech to Text per month
                        </li>

                        <li>
                            <i class="fas <?php if($m_package->audio_file_size > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>
                            <b><?php echo e($m_package->audio_file_size); ?></b> MB Audio file size limit
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_ai_chat == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>Allow AI Chat
                        </li>

                        <li>
                            <i class="fas <?php if($m_package->has_ai_images == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>Allow AI Images
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_ai_code == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>Allow AI Code
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_speech_to_text == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>Speech to Text
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_custom_templates == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i> Custom Templates
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_live_support == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>  Live Support
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_free_support == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>   Free Support
                        </li>

                        <?php if($m_package->ai_model_status == 1): ?>
                           <li>
                            <i class="fas fa-check-circle"></i>  
                            <?php echo e(is_ai_model($m_package->ai_model_id)->model); ?>

                            </li> 
                        <?php endif; ?>
                        
                        

                            <li>&nbsp;</li>
                        </ul>
                        <a href="#" data-toggle="modal" data-target="#subscribe_package_<?php echo e($m_package->id); ?>" class="btn btn-primary btn-rounded w-md"> Subscribe</a>
                    </div>

                    <!-- subscribe package -->
<div id="subscribe_package_<?php echo e($m_package->id); ?>" class="modal custom-modal fade" role="dialog">
<div class="modal-dialog modal-dialog-centered">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-content">
    <b><i class="text-danger">During New Package Activation, Activated Package Will Move to Inactive.</i></b>
<div class="modal-header">
<h3 class="modal-title">Select Payment Method</h3>
</div>
<div class="modal-body">
    <form action="<?php echo e(route('add.subscriptions.histories')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="input-group m-b-30">
    <input type="hidden" name="package_id" value="<?php echo e($m_package->id); ?>">
    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
    <input type="hidden" name="package_type" value="yearly">
    <input type="hidden" name="price" value="<?php echo e($m_package->price); ?>">
    
    <select class="form-control search-input" name="payment_method_id">
        <option value="">Select Payment Method</option>
        <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pay->id); ?>"><?php echo e($pay->title); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(get_general_settings()->offline_payment_status == 1): ?>)
            <option value="offline">Offline Payment</option>
        <?php endif; ?>
    </select>
    <span class="input-group-append">
        <button type="submit" class="btn btn-primary">Proceed</button>
    </span>
</div>
</form>
</div>
</div>
</div>
</div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!-- lifetime -->
        <div class="tab-pane" id="lifetime-tab3">
            <div class="row">
                <?php $__currentLoopData = $lifetime_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m_package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                    <div class="pricing-box">
                        <h3 class="pricing-title"><?php echo e($m_package->name); ?>

                            <?php if($m_package->is_featured == 1): ?>
                                <span class="btn-sm btn btn-success" style="font-size: 10px; border-radius: 10px;">Featured</span>
                            <?php endif; ?>
                        </h3>
                        <h1 class="pricing-rate"><sup>$</sup><?php echo e($m_package->price); ?></h1>
                        <p><?php echo e($m_package->description); ?></p>
                        <ul>
                            <li><i class="fas <?php if($m_package->ai_templates > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i> <b><?php echo e($m_package->ai_templates); ?></b> AI Templates</li>
                            <li><i class="fas <?php if($m_package->words_per_month > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i><b> <?php echo e($m_package->words_per_month); ?></b> Words per month</li>
                            <li><i class="fas <?php if($m_package->images_per_month > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i> <b><?php echo e($m_package->images_per_month); ?></b> Images per month</li>

                        <li>
                            <i class="fas <?php if($m_package->speech_to_text_per_month > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>
                            <b><?php echo e($m_package->speech_to_text_per_month); ?></b> Speech to Text per month
                        </li>

                        <li>
                            <i class="fas <?php if($m_package->audio_file_size > 0): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>
                            <b><?php echo e($m_package->audio_file_size); ?></b> MB Audio file size limit
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_ai_chat == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>Allow AI Chat
                        </li>

                        <li>
                            <i class="fas <?php if($m_package->has_ai_images == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>Allow AI Images
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_ai_code == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>Allow AI Code
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_speech_to_text == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>Speech to Text
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_custom_templates == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i> Custom Templates
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_live_support == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>  Live Support
                        </li>
                        
                        <li>
                            <i class="fas <?php if($m_package->has_free_support == 1): ?> fa-check-circle <?php else: ?> fa-times-circle text-danger <?php endif; ?>"></i>   Free Support
                        </li>
                        
                        <?php if($m_package->ai_model_status == 1): ?>
                           <li>
                            <i class="fas fa-check-circle"></i>  
                            <?php echo e(is_ai_model($m_package->ai_model_id)->model); ?>

                            </li> 
                        <?php endif; ?>
                        
                        

                            <li>&nbsp;</li>
                        </ul>
                        <a href="#" data-toggle="modal" data-target="#subscribe_package_<?php echo e($m_package->id); ?>" class="btn btn-primary btn-rounded w-md"> Subscribe</a>
                    </div>

                    <!-- subscribe package -->
<div id="subscribe_package_<?php echo e($m_package->id); ?>" class="modal custom-modal fade" role="dialog">
<div class="modal-dialog modal-dialog-centered">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-content">
    <b><i class="text-danger">During New Package Activation, Activated Package Will Move to Inactive.</i></b>
<div class="modal-header">
<h3 class="modal-title">Select Payment Method</h3>
</div>
<div class="modal-body">
<form action="<?php echo e(route('add.subscriptions.histories')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="input-group m-b-30">
    <input type="hidden" name="package_id" value="<?php echo e($m_package->id); ?>">
    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
    <input type="hidden" name="package_type" value="lifetime">
    <input type="hidden" name="price" value="<?php echo e($m_package->price); ?>">
    
    <select class="form-control search-input" name="payment_method_id">
        <option value="">Select Payment Method</option>
        <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pay->id); ?>"><?php echo e($pay->title); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(get_general_settings()->offline_payment_status == 1): ?>)
            <option value="offline">Offline Payment</option>
        <?php endif; ?>
    </select>
    <span class="input-group-append">
        <button type="submit" class="btn btn-primary">Proceed</button>
    </span>
</div>
</form>
</div>
</div>
</div>
</div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php } ?>
</div>
</div>
</div>
</div>


<!-- add_templates -->
<div id="add_templates" class="modal custom-modal fade" role="dialog">
<div class="modal-dialog">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-content modal-lg">
<div class="modal-header">
<h4 class="modal-title">All Templates</h4>
</div>
<div class="modal-body">


    <button class="btn btn-primary" id="save_button">save</button>

    <div id="template_list"></div>

</div>
</div>
</div>
</div>









<!-- add_packages -->
<div id="add_package_1" class="modal custom-modal fade" role="dialog">
<div class="modal-dialog">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-content modal-lg">
<div class="modal-header">
<h4 class="modal-title">New Package</h4>
</div>
<div class="modal-body">
<form action="<?php echo e(route('add_new_package')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="mt-2 mb-3 text-center">
                <input type="hidden" name="packageType" id="packageType">
                <button type="submit" class="btn btn-primary btn-lg">Create New Package</button>
            </div>
        </div>
    </div><hr>
</form>
<form action="<?php echo e(route('add_new_package')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="justify-content-center d-flex align-items-center">
                <div class="form-group form-focus select-focus" style="width: 40%; margin-bottom: 0 !important;">
                    <input type="hidden" name="copypackageType" id="copypackageType">
                    <label class="focus-label">Copy From Existing</label>
                    <select class="select floating" name="package_name">
                        <option disabled selected> -- Monthly -- </option>
                        <?php $__currentLoopData = $monthly_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month_package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($month_package->id); ?>"> <?php echo e($month_package->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <option disabled> -- Yearly -- </option>
                        <?php $__currentLoopData = $yearly_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year_package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($year_package->id); ?>"> <?php echo e($year_package->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <option disabled> -- LifeTime -- </option>
                        <?php $__currentLoopData = $lifetime_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $life_time_package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($life_time_package->id); ?>"> <?php echo e($life_time_package->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" style="padding: 12px; border-radius: 0 !important;">Copy</button>
            </div>
        </div>
    </div>
</form>
</div>
</div>
</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/subscriptions/index.blade.php ENDPATH**/ ?>