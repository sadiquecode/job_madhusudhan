<!-- Footer -->
  <footer class="pt-5 pb-2 bg-body-tertiary">
    <div class="container">
      <div class="row px-3">
        <div class="col-6 col-md-3 mb-3">
          <a href="./" class="d-flex align-items-center mb-3">
            <img class="footer-logo" src="<?php echo e(url(env('img_path') .get_general_settings()->logo)); ?>" role="img" alt="Teach me logo">
          </a>
          <ul class="list-unstyled fs-6 mt-4">
            <li>
              <p><i class="fa-solid fa-envelope me-3"></i><?php echo e(get_general_settings()->contact_email); ?></p>
            </li>
            <!--<li>-->
            <!--  <p><i class="fa-solid fa-phone me-3"></i><?php echo e(get_general_settings()->contact_phone); ?></p>-->
            <!--</li>-->
            <!--<li class="d-flex">-->
            <!--  <i class="fa-solid fa-location-dot me-3"></i>-->
            <!--  <p><?=get_general_settings()->visit_address?></p>-->
            <!--</li>-->
            <li>
                <p>
                    Join UAE's comprehensive tutor platform to find the right fit for your child. Help us help you to achieve your goals.
                </p>
            </li>
          </ul>
        </div>

        <!-- Links -->
        <div class="offset-1 col-6 col-md-3 mb-3">
          <h5 class="text-primary pb-4 border-bottom border-primary d-inline-block border-3">Tutors By Emirates</h5>
          <ul class="nav flex-column">
             <?php $__currentLoopData = $TeachmeLocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="nav-item mb-2">
              <a href="<?php echo e(url('find-tutors?location_id='.$location->id)); ?>" class="nav-link p-0 text-body-secondary"><?php echo e($location->name); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>

        <div class="col-6 col-md-2 mb-3">
          <h5 class="text-primary pb-4 border-bottom border-primary d-inline-block border-3">Curriculum</h5>
          <ul class="nav flex-column">

            <?php $__currentLoopData = $TeachmeCurriculums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="nav-item mb-2">
              <a href="<?php echo e(url('find-tutors?curriculum_id='.$curriculum->id)); ?>" class="nav-link p-0 text-body-secondary"><?php echo e($curriculum->title); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


          </ul>
        </div>
        <div class="col-6 col-md-2 mb-3">
          <h5 class="text-primary pb-4 border-bottom border-primary d-inline-block border-3">Company</h5>
          <ul class="nav flex-column">
            
            <li class="nav-item mb-2"><a href="<?php echo e(url('how-it-works')); ?>" class="nav-link p-0 text-body-secondary">How it Works</a></li>
            <li class="nav-item mb-2"><a href="<?php echo e(url('contact-us')); ?>" class="nav-link p-0 text-body-secondary">Contact Us</a></li>
            <li class="nav-item mb-2"><a href="<?php echo e(url('terms-of-use')); ?>" class="nav-link p-0 text-body-secondary">Terms of Use</a>
            </li>
            <li class="nav-item mb-2"><a href="<?php echo e(url('privacy-policy')); ?>" class="nav-link p-0 text-body-secondary">Privacy Policy</a>
            </li>
            <li class="nav-item mb-2"><a href="<?php echo e(url('refund-policy')); ?>" class="nav-link p-0 text-body-secondary">Refund Policy</a>
            </li>
          </ul>
        </div>

      </div>
    </div>

    <div class="d-flex flex-column align-items-center pt-4 mt-3 border-top">
      <!-- Social Icons -->
      <ul class="list-unstyled d-flex gap-2 footer-social-icons">
        <li>
          <a class="fs-5 rounded-circle text-white bg-secondary bg-primary-hover" href="<?php echo e(get_general_settings()->facebook); ?>">
            <i class="fa-brands fa-facebook"></i>
            <span class="visually-hidden">Facebook</span>
          </a>
        </li>
        <li>
          <a class="fs-5 rounded-circle text-white bg-secondary bg-primary-hover" href="<?php echo e(get_general_settings()->linkedin); ?>">
            <i class="fa-brands fa-linkedin-in"></i>
            <span class="visually-hidden">LinkedIn</span>
          </a>
        </li>
        <li>
          <a class="fs-5 rounded-circle text-white bg-secondary bg-primary-hover" href="<?php echo e(get_general_settings()->instagram); ?>">
            <i class="fa-brands fa-instagram"></i>
            <span class="visually-hidden">Instagram</span>
          </a>
        </li>
        <!--<li>-->
        <!--  <a class="fs-5 rounded-circle text-white bg-secondary bg-primary-hover" href="<?php echo e(get_general_settings()->youtube); ?>">-->
        <!--    <i class="fa-brands fa-youtube"></i>-->
        <!--    <span class="visually-hidden">Youtube</span>-->
        <!--  </a>-->
        <!--</li>-->
      </ul>
      <!-- Trademark -->
      <p class="text-body-tertiary">&copy; <span id="copyright">
        <script>document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))</script>
    </span> TeachMe. All rights reserved.</p>
    </div>
  </footer>

  <script type="module" src="<?php echo e(url('public/theme_assets/js/main.js')); ?>"></script>
  <script type="module" src="<?php echo e(url('public/theme_assets/js/auth.js')); ?>"></script>
  <script type="module" src="<?php echo e(url('public/theme_assets/js/home.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(url('public/assets/js/jquery-3.5.1.min.js')); ?>"></script>
<script type="text/javascript">
    function previewImage(event, previewId) {
    console.log('previewId:', previewId);
    var input = event.target;
    var reader = new FileReader();
    reader.onload = function(){
        var preview = document.getElementById(previewId);
        console.log('preview:', preview);
        preview.src = reader.result;
        preview.style.display = 'block';
    };
    reader.readAsDataURL(input.files[0]);
}



    $(document).ready(function () {
        $('#location_id').change(function () {
            var base_url = "<?php echo e(url('/')); ?>";
            var locationId = $(this).val();
            if (locationId) {
                $.ajax({
                    type: "GET",
                    url: base_url+"/get-sub-locations/" + locationId,
                    success: function (response) {
                        $('#sub_location').empty();
                        $.each(response, function (key, value) {
                            $('#sub_location').append('<option value="' + key + '">' + value + '</option>');
                        });
                    }
                });
            } else {
                $('#sub_location').empty();
            }
        });
    });

</script>

<script>
    var text = ["exams?", "activities?","schoolwork?"];
var counter = 0;
var elem = $("#mtext");
setInterval(change, 2500);
function change() {
    elem.fadeOut(function(){
        elem.html(text[counter]);
        counter++;
        if(counter >= text.length) { counter = 0; }
        elem.fadeIn();
    });
}


</script>


</body>

</html><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/layouts/footer.blade.php ENDPATH**/ ?>