
<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Main content -->
<main class="bg-white">
  <!-- Tutor Section -->
  <section id="tutor-details-section" class="container pt-4 pb-6">
    <!-- Bread crumbs -->
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb fw-medium">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>" class="text-decoration-none text-warning-hover">Home</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('find-tutors')); ?>" class="text-decoration-none text-warning-hover">Tutors</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($tutor_list->name.' '.$tutor_list->lname); ?></li>
      </ol>
    </nav>
    <!-- Main -->
    <div class="pt-3 row row-cols-1 row-cols-lg-2 g-5">
      <div class="col d-flex flex-column gap-5">
        <!-- Tutor Card -->
        <div id="tutor-details-card" class="card border-0 box-shadow-sm rounded-4 p-2">
          <div class="card-body d-flex flex-column gap-2 small">
            <!-- First Row -->
            <div class="d-flex gap-2">
              <!-- Avatar -->
              <?php if(is_it_paid_user($tutor_list->id) == 'yes'): ?>
              <img src="<?php echo e(url(env('img_path'). $tutor_list->profile_pic)); ?>" alt="Tutor portrait" width="86" height="86" class="rounded-circle">

              <?php if($tutor_list->profile_pic): ?>
                  <img src="<?php echo e(url(env('img_path'). $tutor_list->profile_pic)); ?>" alt="<?php echo e($tutor_list->name); ?>" width="86" height="86" class="rounded-circle">
              <?php else: ?>
              <img src="<?php echo e(asset('public/theme_assets/images/icons/default_images.svg')); ?>" alt="<?php echo e($tutor_list->name); ?>" width="86" height="86" class="rounded-circle">
              <?php endif; ?>
                        
              <?php else: ?>
              <?php if($tutor_list->blur_profile_pic): ?>
                  <img src="<?php echo e(url(env('img_path'). $tutor_list->blur_profile_pic)); ?>" alt="<?php echo e($tutor_list->name); ?>" width="86" height="86" class="rounded-circle">
              <?php else: ?>
              <img src="<?php echo e(asset('public/theme_assets/images/icons/default_images_blur.jpeg')); ?>" alt="<?php echo e($tutor_list->name); ?>" width="86" height="86" class="rounded-circle">
              <?php endif; ?>
              <?php endif; ?>
              <!-- Info -->
              <div>
                <div class="fw-medium">
                  <h1 class="fs-6 m-0">
                  <?php if(is_it_paid_user($tutor_list->id) == 'yes'): ?>
                  <?php echo e($tutor_list->name.' '.$tutor_list->lname); ?>

                  <?php else: ?>
                  <span style="font-size: 18px !important;
                    color: transparent !important;
                  text-shadow: 0 0 8px #00428b;"><?php echo e(str_repeat('*', strlen($tutor_list->name.' '.$tutor_list->lname))); ?></span>
                  <?php endif; ?>
                  </h1>
                  <?php if($tutor_list->grade_names): ?>
                  <?php
                  $grades = explode(',', $tutor_list->grade_names);
                  $formatted_grades = implode(', ', $grades);
                  ?>
                  <p class="text-primary text-opacity-50"><?php echo e($formatted_grades); ?></p>
                  <?php endif; ?>
                </div>
                <!-- Badges -->
                <div class="d-flex gap-1 ms-n5 ps-2">
                  <span class="rounded-pill bg-warning text-white py-1 px-2 fw-light">
                    <i class="fa-solid fa-star" aria-hidden="true"></i>
                    <?php echo $averageRating; ?>
                    <span class="visually-hidden">Rating</span>
                  </span>
                  
                  <?php if($tutor_list->verification_status == 1): ?>
                  <span class="badge rounded-pill bg-success text-white py-1 px-2 fw-light">
                    <i class="fa-regular fa-circle-check" aria-hidden="true"></i>
                    verified
                  </span>
                  <?php endif; ?>
                </div>
              </div>
            </div>
            <!-- Address -->
            <span class="fw-medium"><i class="fa-solid fa-location-dot me-1"></i><?php if($tutor_list->sub_location_names != null): ?>
              <?php echo e($tutor_list->sub_location_names.' ,'); ?> <?php echo e($tutor_list->location_names); ?>

              <?php endif; ?>
            </span>
            <?php if(!empty($tutor_list->virtual_mode)): ?>
            
            <span style="width: fit-content;
    padding: 6px 14px;
    border-radius: 23px;
    color: #f8a721;
    background: #f8a72117;
    margin-right: 5px;"> <i class="fa fa-video-camera"></i> Online</span> 
            <?php endif; ?>
            
            <?php if(!empty($tutor_list->in_person_mode)): ?>
            <span style="width: fit-content;
    padding: 6px 14px;
    border-radius: 23px;
    color: #0a428e;
    background: #0a428e24;
    margin-right: 5px;"> <i class="fa fa-user"></i> In Person</span> 
            <?php endif; ?>
             
            <!-- Subjects -->
            <div>
              <span class="fw-bold text-black fs-6">Subjects</span>
              <ul class="list-unstyled mt-2 d-flex gap-2 flex-wrap">
                <?php if(isset($tutor_list->subject_names)): ?>
                <?php
                $subjects = explode(',', $tutor_list->subject_names);
                ?>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="rounded-pill bg-warning-subtle py-2 px-3"><?php echo e($subject); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </ul>
            </div>
            <!-- Languages -->
            <div>
              <span class="fw-bold text-black fs-6">Speaks</span>
              <ul class="list-unstyled mt-2 d-flex gap-2 flex-wrap">
                <?php if(isset($tutor_list->language_names)): ?>
                <?php
                $languages = explode(',', $tutor_list->language_names);
                ?>
                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="rounded-pill bg-body-tertiary py-2 px-3"><?php echo e($language); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </ul>
            </div>
            <!-- About -->
            <div>
              <span class="fw-bold text-black fs-6">About Me</span>
              <p class="mt-2">
                <?php echo e($tutor_list->description); ?>

              </p>
            </div>
          </div>
        </div>
        <!-- Tutor Experience -->
        <div class="card border-0 box-shadow-sm rounded-4 p-2 pb-0">
          <div class="card-body small pb-2">
            <!-- Title -->
            <h2 class="fw-medium fs-6">Experience</h2>
            
            <!-- Experiences -->
            <ul class="list-unstyled d-flex flex-column gap-2">
              
              <?php $__empty_1 = true; $__currentLoopData = $tutor_experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <li class="bg-body-tertiary rounded-3 p-2">
                <p class="fw-bold mb-1 opacity-75"><?php echo e($experience->company); ?></p>
                <div class="d-flex gap-2 flex-wrap">
                  <span class="opacity-75"><?php echo e($experience->position); ?></span>
                  <span class="fw-medium"><strong><?php echo e(date('d M', strtotime($experience->start_date))); ?></strong> <?php echo e(date('Y', strtotime($experience->start_date))); ?> - <?php if($experience->end_date): ?>
                    <strong><?php echo e(date('d M', strtotime($experience->end_date))); ?></strong> <?php echo e(date('Y', strtotime($experience->end_date))); ?>

                    <?php else: ?>
                    Present
                  <?php endif; ?></span>
                </div>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              
              <?php endif; ?>
              
            </ul>
            
          </div>
        </div>
        
        <!-- Tutor Education -->
        <div class="card border-0 box-shadow-sm rounded-4 p-2 pb-0">
          <div class="card-body small pb-2">
            <!-- Title -->
            <h2 class="fw-medium fs-6">Education</h2>
            
            <!-- Educations -->
            <ul class="list-unstyled d-flex flex-column gap-2">
              <?php $__empty_1 = true; $__currentLoopData = $tutor_educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <li class="bg-body-tertiary rounded-3 p-2">
                <p class="fw-bold mb-1 opacity-75"><?php echo e($education->degree); ?></p>
                <div class="d-flex gap-2 flex-wrap">
                  <span class="opacity-75"><?php echo e($education->institution); ?></span>
                  <span class="fw-medium"><strong><?php echo e(date('d M', strtotime($education->start_date))); ?></strong> <?php echo e(date('Y', strtotime($education->start_date))); ?> - <?php if($education->end_date): ?>
                    <strong><?php echo e(date('d M', strtotime($education->end_date))); ?></strong> <?php echo e(date('Y', strtotime($education->end_date))); ?>

                    <?php else: ?>
                    Present
                  <?php endif; ?></span>
                </div>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              
              <?php endif; ?>
            </ul>
            
          </div>
        </div>
      </div>
      <?php if(is_it_paid_user($tutor_list->id) == 'yes'): ?>
      <!-- Tutor Intro & Contact -->
      <div class="col d-lg-block" id="tutor-intro-contact-container">
        <div data-tm-origin="#tutor-intro-contact-container" data-tm-target="#tutor-details-card" data-tm-toggle="move"
          data-tm-media="max-width: 992px">
          <?php if($tutor_list->embedUrl): ?>
          <!-- Tutor Intro Video -->
          <div class="card border-0 bg-body-tertiary rounded-4 p-2">
            <div class="card-body d-flex flex-column gap-2">
              <h2 class="fs-6 fw-normal">Intro video</h2>
              
              <div class="embedded-video-container bg-black rounded-4">
                <iframe src="<?php echo e($tutor_list->embedUrl); ?>" title="Introduction video" frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowfullscreen></iframe>
              </div>
            </div>
          </div>
          <?php endif; ?>
          <!-- Tutor Contact -->
          <div class="card border-0 box-shadow-sm rounded-4 p-2 mt-4">
            <div class="card-body d-flex flex-column align-items-center gap-2">
              <!-- Avatar -->
              <img src="<?php echo e(url(env('img_path'). $tutor_list->profile_pic)); ?>" alt="Tutor portrait" width="120" height="120"
              class="rounded-circle">
              
              <p class="text-center mx-2 px-2 mx-md-5 px-md-5">Reach out to the tutor at your convenience anytime to get assistance.</p>
              
              <div class="contact-buttons d-flex gap-3 gap-md-2 align-items-center flex-wrap justify-content-center">
                <a class="fs-5 icon-secondary" href="mailto:<?php echo e($tutor_list->email); ?>">
                  <i class="fa-regular fa-envelope"></i>
                  <span class="visually-hidden">Email</span>
                </a>
                <!--<a class="fs-5 icon-secondary" href="tel:+<?php echo e($tutor_list->phone); ?>">-->
                <!--  <i class="fa-solid fa-phone"></i>-->
                <!--  <span class="visually-hidden">Telephone</span>-->
                <!--</a>-->
                <a href="https://wa.me/<?php echo e($tutor_list->phone); ?>" target="_blank" rel="noreferrer"
                  class="btn btn-primary rounded-pill py-2 px-3 small" style="background:#24d366;border-color:#24d366;">
                  <i class="fa-brands fa-whatsapp me-2"></i>
                  Whatsapp Tutor
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php else: ?>
      <!-- Tutor Intro & Contact -->
      <div class="col  d-lg-block" id="tutor-intro-contact-container">
        <div class="position-relative" data-tm-origin="#tutor-intro-contact-container" data-tm-target="#tutor-details-card" data-tm-toggle="move"
          data-tm-media="max-width: 992px">
          <img class="img-fluid" src="<?php echo e(asset('public/theme_assets/images/page-tutor-profile/locked-contact.png')); ?>" alt="Locked tutor contact">
          <div class="position-absolute bottom-0 start-0 end-0 mb-4 mb-md-6 mb-lg-8 d-flex flex-column justify-content-center align-items-center">
            <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->user()->role == 'student'): ?>
            <a href="<?php echo e(url('plans/1')); ?>" id="unlock-btn" class="btn btn-primary py-4 px-5 rounded-pill fw-medium">Unlock Hidden Details</a>
            <?php else: ?>
            <a href="<?php echo e(url('register')); ?>" id="unlock-btn" class="btn btn-primary py-4 px-5 rounded-pill fw-medium">Unlock Hidden Details</a>
            <?php endif; ?>
            
            <?php else: ?>
            <a href="<?php echo e(url('register')); ?>" id="unlock-btn" class="btn btn-primary py-4 px-5 rounded-pill fw-medium">Unlock Hidden Details</a>
            <?php endif; ?>
            <p class="fw-medium px-5 px-lg-5 mx-lg-5 text-capitalize mt-4 text-center">
              
            </p>
            <p class="fw-medium px-5 px-lg-5 mx-lg-5 text-capitalize mt-4 text-center ">
              To access the tutors contact information, kindly subscribe to  <span class="text-primary">TEACH</span><span class="text-warning">ME</span>. 100 AED gives you access to ALL the tutors on this website.
              
              
            </p>
          </div>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</section>
<!-- Reviews Section -->
<section id="reviews-section" class="container">
  <div class="pb-6 row row-cols-1 row-cols-lg-2">
    <div class="col">
      <?php echo $__env->make('theme_1.userprofile.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <hr>
      <!-- Reviews Header -->
      <div class="d-flex justify-content-between flex-wrap p-4">
        <div>
          <h2 class="fs-5 mb-4">Reviews for <?php echo e($tutor_list->name.' '.$tutor_list->lname); ?></h2>
          <div class="fw-semibold d-flex gap-2">
            <ul class="list-unstyled d-flex gap-2" aria-labelledby="total-rating">
              <?php echo $averageRatingStars; ?>
            </ul>
            <span id="total-rating">
              <?php echo $averageRating; ?>
              <span class="visually-hidden">ratings</span>
            </span>
            <span id="total-reviews" class="text-nowrap">
              ( <?php echo e(count($reviews)); ?> Reviews )
            </span>
          </div>
        </div>
        <style type="text/css">
        /* Modal Styles */
        .modal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.4);
        }
        .modal-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 50%;
        }
        .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        }
        .close:hover,
        .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
        }
        * {
        margin: 0;
        padding: 0;
        }
        .rate {
        float: left;
        height: 46px;
        padding: 0 10px;
        }
        .rate:not(:checked) > input {
        position: absolute;
        top: -9999px;
        }
        .rate:not(:checked) > label {
        float: right;
        width: 1em;
        overflow: hidden;
        white-space: nowrap;
        cursor: pointer;
        font-size: 30px;
        color: #ccc;
        }
        .rate:not(:checked) > label:before {
        content: "★ ";
        }
        .rate > input:checked ~ label {
        color: #ffc700;
        }
        .rate:not(:checked) > label:hover,
        .rate:not(:checked) > label:hover ~ label {
        color: #deb217;
        }
        .rate > input:checked + label:hover,
        .rate > input:checked + label:hover ~ label,
        .rate > input:checked ~ label:hover,
        .rate > input:checked ~ label:hover ~ label,
        .rate > label:hover ~ input:checked ~ label {
        color: #c59b08;
        }
        /* Modified from: https://github.com/mukulkant/Star-rating-using-pure-css */
        #reviewText {
        width: 100%;
        height: 100px;
        resize: none;
        }
        </style>
        <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->role == 'student' && auth()->user()->lock_status == 0 && review_count(Auth::user()->id, $tutor_list->id) < 1): ?>
        <div class="d-flex align-items-center">
          <button id="openPopupBtn" class="btn btn-outline-primary rounded-3">Write a Review</button>
        </div>
        <?php endif; ?>
        <!-- Popup Modal -->
        <div id="reviewModal" class="modal">
          <div class="modal-content" style="padding:4%;">
            <span class="close" id="closePopup">&times;</span>
            <h3>Write a Review</h3>
            <form id="reviewForm" action="<?php echo e(route('review.store')); ?>" method="POST" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="student_id" value="<?php echo e(auth()->id()); ?>">
              <input type="hidden" name="tutor_id" value="<?php echo e($tutor_list->id); ?>">
              <div class="rate">
                <input type="radio" name="stars" class="star" id="star1" value="1">
                <label for="star1"></label>
                <input type="radio" name="stars" class="star" id="star2" value="2">
                <label for="star2"></label>
                <input type="radio" name="stars" class="star" id="star3" value="3">
                <label for="star3"></label>
                <input type="radio" name="stars" class="star" id="star4" value="4">
                <label for="star4"></label>
                <input type="radio" name="stars" class="star" id="star5" value="5">
                <label for="star5"></label>
              </div>
              <textarea id="reviewText" placeholder="Write your review here..." name="review_text" style="padding:10px;"></textarea>
              <br><br>
              <button type="submit" class="btn btn-primary">Submit</button>
            </form>
          </div>
        </div>
        <?php endif; ?>
        <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
        // Get all star elements
        // Get all star elements
        const stars = document.querySelectorAll('.star');
        // Loop through each star and add click event listener
        stars.forEach(function(star, index) {
        star.addEventListener('click', function() {
        // Get the index of the clicked star
        const clickedIndex = index;
        // Loop through each star
        stars.forEach(function(s, idx) {
        // Check if the current star index is less than or equal to the clicked star index
        if (idx <= clickedIndex) {
        // If yes, mark the star as checked
        s.checked = true;
        } else {
        // If no, mark the star as unchecked
        s.checked = false;
        }
        });
        });
        });
        // Open the review modal when the button is clicked
        const openPopupBtn = document.getElementById('openPopupBtn');
        const modal = document.getElementById('reviewModal');
        const closePopup = document.getElementById('closePopup');
        openPopupBtn.addEventListener('click', function() {
        modal.style.display = 'block';
        });
        closePopup.addEventListener('click', function() {
        modal.style.display = 'none';
        });
        window.addEventListener('click', function(event) {
        if (event.target === modal) {
        modal.style.display = 'none';
        }
        });
        });
        </script>
      </div>
      <!-- Reviews List -->
      <ul class="list-unstyled px-4 d-flex flex-column gap-5">
        <?php if(count($reviews) > 0): ?>
        <?php
        $currentUserReviewIds = []; // Array to store current user's review IDs
        $latestReviews = []; // Array to store latest reviews
        ?>
        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $studentDetails = $review->student;
        // Check if the review belongs to the current logged-in user
        $isCurrentUserReview = (Auth::check() && Auth::user()->id == $review->student_id);
        // If it's the current user's review, store its ID
        if($isCurrentUserReview) {
        $currentUserReviewIds[] = $review->id;
        } else {
        $latestReviews[] = $review; // Store latest reviews
        }
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <?php $__currentLoopData = $currentUserReviewIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reviewId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $review = $reviews->where('id', $reviewId)->first();
        $studentDetails = $review->student;
        ?>
        <li class="d-flex flex-column flex-lg-row gap-2">
          <!-- Avatar -->
          <?php if($studentDetails->profile_pic): ?>
          <img src="<?php echo e(url(env('img_path'). $studentDetails->profile_pic)); ?>" alt="Student portrait" width="54" height="54" class="rounded-circle">
          <?php else: ?>
          <img src="<?php echo e(asset('public/theme_assets/images/icons/profile-circle.svg')); ?>" alt="Student portrait" width="54" height="54" class="rounded-circle">
          <?php endif; ?>
          <!-- Info -->
          <div>
            <?php if(auth()->guard()->check()): ?>
            <?php if(Auth()->user()->id == $review->student_id): ?>
            <form action="<?php echo e(route('review.destroy', ['review' => $review->id])); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete?')">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn-sm btn btn-danger text-white" style="float:right;">Delete</button>
            </form>
            <?php endif; ?>
            <?php endif; ?>
            <h1 class="fs-6 fw-semibold" style="margin-bottom:0px;"><?php echo e($studentDetails->name.' '.$studentDetails->lname); ?></h1>
            <p class="mb-0" style="font-size:14px;">
              <?php if(sub_location_name($review->sub_location_id)): ?>
              <?php echo e(sub_location_name($review->sub_location_id)->name); ?>

              <?php endif; ?>
              <?php if(sub_location_name($review->location_id)): ?>
              <?php echo e(',' .sub_location_name($review->location_id)->name); ?>

              <?php endif; ?>
            </p>
            <div class="d-flex gap-2 text-warning mb-2">
              <ul class="list-unstyled d-flex gap-2" aria-labelledby="total-rating">
                <?php for($i = 0; $i < $review->stars; $i++): ?>
                <li><i class="fa-solid fa-star" aria-hidden="true"></i></li>
                <?php endfor; ?>
              </ul>
              <span id="total-rating" class="fw-semibold"><?php echo e($review->stars); ?><span class="visually-hidden">ratings</span></span>
            </div>
            <p class="lh-lg">
              <?php echo e($review->review_text); ?>

              
            </p>
          </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <?php $__currentLoopData = $latestReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $studentDetails = $review->student;
        ?>
        <li class="d-flex flex-column flex-lg-row gap-2">
          <!-- Avatar -->
          <?php if($studentDetails->profile_pic): ?>
          <img src="<?php echo e(url(env('img_path'). $studentDetails->profile_pic)); ?>" alt="Student portrait" width="54" height="54" class="rounded-circle">
          <?php else: ?>
          <img src="<?php echo e(asset('public/theme_assets/images/icons/profile-circle.svg')); ?>" alt="Student portrait" width="54" height="54" class="rounded-circle">
          <?php endif; ?>
          <!-- Info -->
          <div>
            <h1 class="fs-6 fw-semibold" style="margin-bottom:0px;"><?php echo e($studentDetails->name.' '.$studentDetails->lname); ?></h1>
            <p class="mb-0" style="font-size:14px;">
              <?php if(sub_location_name($review->sub_location_id)): ?>
              <?php echo e(sub_location_name($review->sub_location_id)->name); ?>

              <?php endif; ?>
              <?php if(sub_location_name($review->location_id)): ?>
              <?php echo e(',' .sub_location_name($review->location_id)->name); ?>

              <?php endif; ?>
            </p>
            <div class="d-flex gap-2 text-warning mb-2">
              <ul class="list-unstyled d-flex gap-2" aria-labelledby="total-rating">
                <?php for($i = 0; $i < $review->stars; $i++): ?>
                <li><i class="fa-solid fa-star" aria-hidden="true"></i></li>
                <?php endfor; ?>
              </ul>
              <span id="total-rating" class="fw-semibold"><?php echo e($review->stars); ?><span class="visually-hidden">ratings</span></span>
            </div>
            <p class="lh-lg">
              <?php echo e($review->review_text); ?>

              
            </p>
          </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <h6>This tutor has not been reviewed yet by anyone.</h6>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</section>
</main>
<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/teachme_tutor_profile.blade.php ENDPATH**/ ?>