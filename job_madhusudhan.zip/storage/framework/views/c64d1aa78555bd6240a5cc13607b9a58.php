<div class="col-sm-8 col-md-8 col-lg-8 col-xl-9">
	<h6 class="card-title m-b-20">Main Page</h6>
	<form class="m-b-30" action="<?php echo e(route('webpage.update', $webpage->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
		<div class="card-box">
			<div class="row">
				
				<div class="col-md-12">
					<h4 class="card-title">Language Model</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Select language:</label>
								<input type="text" class="form-control" name="select_language" value="<?php echo e($webpage->select_language); ?>">
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-12">
					<h4 class="card-title">Hero Section</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Head Line:</label>
								<input type="text" class="form-control" name="head_line" value="<?php echo e($webpage->head_line); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Main Heading:</label>
								<input type="text" class="form-control" name="main_heading" value="<?php echo e($webpage->main_heading); ?>">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Sub Heading:</label>
								<input type="text" class="form-control" name="sub_heading" value="<?php echo e($webpage->sub_heading); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Button:</label>
								<input type="text" class="form-control" name="main_button" value="<?php echo e($webpage->main_button); ?>">
							</div>
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<h4 class="card-title">AI Writing Section</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Writing Line:</label>
								<input type="text" class="form-control" name="writing_line" value="<?php echo e($webpage->writing_line); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Writing Heading:</label>
								<input type="text" class="form-control" name="writing_heading" value="<?php echo e($webpage->writing_heading); ?>">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Button:</label>
								<input type="text" class="form-control" name="writing_button" value="<?php echo e($webpage->writing_button); ?>">
							</div>
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<h4 class="card-title">AI Image Section</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Image Line:</label>
								<input type="text" class="form-control" name="img_line" value="<?php echo e($webpage->img_line); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Image Heading:</label>
								<input type="text" class="form-control" name="img_heading" value="<?php echo e($webpage->img_heading); ?>">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Button:</label>
								<input type="text" class="form-control" name="img_button" value="<?php echo e($webpage->img_button); ?>">
							</div>
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<h4 class="card-title">AI Bot Section</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Bot Line:</label>
								<input type="text" class="form-control" name="bot_line" value="<?php echo e($webpage->bot_line); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Bot Heading:</label>
								<input type="text" class="form-control" name="bot_heading" value="<?php echo e($webpage->bot_heading); ?>">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Button:</label>
								<input type="text" class="form-control" name="bot_button" value="<?php echo e($webpage->bot_button); ?>">
							</div>
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<h4 class="card-title">FAQ Section</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>FAQ Heading:</label>
								<input type="text" class="form-control" name="faq_heading" value="<?php echo e($webpage->faq_heading); ?>">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Button:</label>
								<input type="text" class="form-control" name="faq_button" value="<?php echo e($webpage->faq_button); ?>">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="text-right">
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
		</div>
	</form>
</div><?php /**PATH G:\server\htdocs\advance_ai\resources\views/web/forms/main_page.blade.php ENDPATH**/ ?>