<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Main content -->
  <main id="sign-up-section" class="py-5 px-4 px-md-0 my-md-7 pb-md-7 bg-white">
<div class="container mt-3">
  <h2 class="fw-medium center">Refund Policy</h2>
  <br>
  

<p><strong>No Refunds:</strong> At TeachME, all our subscription plans are non-refundable. We strive to be clear about this policy so that you can subscribe with the full knowledge that once payment is processed, it cannot be returned.</p>

    <h4>Subscription Details</h4>
    <p><strong>Subscription Commitment:</strong> When you subscribe to our services, you agree to the terms of the billing cycle which is annual.</p>
    <p><strong>Automatic Renewal:</strong> Your subscription will automatically renew at the end of each cycle. You will receive a reminder before your subscription renews. It is your responsibility to cancel your subscription if you do not wish to continue.</p>
    <p><strong>Cancellation Policy:</strong> You may cancel your subscription at any time. Upon cancellation, you will continue to have access to the tutoring services through the end of your current billing cycle. No partial refunds are given for cancellations partway through a billing period.</p>

    <h4>Account Cancellation</h4>
    <p><strong>How to Cancel:</strong> You can cancel your subscription through your account settings. If you need assistance, please contact our support team at <a href="mailto:info@teachme.ae">info@teachme.ae</a>.</p>
    <p><strong>Effects of Cancellation:</strong> After cancellation, your account will be deactivated once your current subscription period expires. You will not be charged further.</p>

    <h4>Feedback and Assistance</h4>
    <p>We are committed to your satisfaction and welcome feedback on how we can improve our services. If you have any questions or need assistance with your subscription, please reach out to our customer support team at <a href="mailto:info@teachme.ae">info@teachme.ae</a>.</p>
</body>





</div>
  </main>

<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/teachme_refund_policy.blade.php ENDPATH**/ ?>