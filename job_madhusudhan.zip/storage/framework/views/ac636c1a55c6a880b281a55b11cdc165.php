<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.setting_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper bg-white">
        <div class="content container-fluid">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?> 
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <form action="<?php echo e(route('set_WebGeneralSetting')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <h4 class="page-title">General Informations</h4>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Website Name <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="website_name" class="form-control" value="<?php echo e($WebGeneralSetting->website_name); ?>" type="text">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Website Url <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="website_url" class="form-control" value="<?php echo e($WebGeneralSetting->website_url); ?>" type="text">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Website Title <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="website_title" class="form-control" value="<?php echo e($WebGeneralSetting->website_title); ?>" type="text">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Contact Email <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="contact_email" class="form-control" value="<?php echo e($WebGeneralSetting->contact_email); ?>" type="text">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Contact Phone <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="contact_phone" class="form-control" value="<?php echo e($WebGeneralSetting->contact_phone); ?>" type="text">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Address <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="visit_address" class="form-control" value="<?php echo e($WebGeneralSetting->visit_address); ?>" type="text">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Facebook Link <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="facebook" class="form-control" value="<?php echo e($WebGeneralSetting->facebook); ?>" type="text">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Youtube Link <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="youtube" class="form-control" value="<?php echo e($WebGeneralSetting->youtube); ?>" type="text">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Linkedin Link <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="linkedin" class="form-control" value="<?php echo e($WebGeneralSetting->linkedin); ?>" type="text">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Twitter Link <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="twitter" class="form-control" value="<?php echo e($WebGeneralSetting->twitter); ?>" type="text">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Instagram Link <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="instagram" class="form-control" value="<?php echo e($WebGeneralSetting->instagram); ?>" type="text">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Snapchat Link <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="snapchat" class="form-control" value="<?php echo e($WebGeneralSetting->snapchat); ?>" type="text">
                            </div>
                        </div>
                        
                        <h4 class="page-title mt-5">Dashboard Logo & Favicon</h4>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Logo <span class="text-danger">*</span></label>
                            <div class="col-lg-7">
                            <input class="form-control" type="file" name="logo">
                                <span class="form-text text-muted">Recommended image size is 40px x 40px</span>
                            </div>
                            <div class="col-lg-2">
                                <div class="img-thumbnail float-right">
                                    <?php if(empty($WebGeneralSetting->logo)): ?>
                                    <img src="<?php echo e(url('public/assets/img/logo2.png')); ?>" alt="" width="40" height="40">
                                    <?php else: ?>
                                    <img src="<?php echo e(url(env('img_path'). $WebGeneralSetting->logo)); ?>"  alt="" width="40" height="40">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Favicon <span class="text-danger">*</span></label>
                            <div class="col-lg-7">
                                <input class="form-control" type="file" name="favicon">
                                <span class="form-text text-muted">Recommended image size is 16px x 16px</span>
                            </div>
                            <div class="col-lg-2">
                                <div class="settings-image img-thumbnail float-right">

                                    <?php if(empty($WebGeneralSetting->favicon)): ?>
                                    <img src="<?php echo e(url('public/assets/img/logo2.png')); ?>" class="img-fluid" width="16" height="16" alt="">
                                    <?php else: ?>
                                    <img src="<?php echo e(url(env('img_path'). $WebGeneralSetting->favicon)); ?>"  class="img-fluid" width="16" height="16" alt="">
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                        <h4 class="page-title mt-5">SEO Meta Configuration</h4>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Meta Title <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="meta_title" class="form-control" value="<?php echo e($WebGeneralSetting->meta_title); ?>" type="text">
                                <span class="form-text text-muted">Set a meta tag title. Recommended to be simple and unique.</span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Meta Description <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <textarea class="form-control" rows="5" name="meta_description"><?php echo e($WebGeneralSetting->meta_description); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Meta Keywords <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <textarea class="form-control" rows="2" name="meta_keywords"><?php echo e($WebGeneralSetting->meta_keywords); ?></textarea>
                                <span class="form-text text-muted">Set a meta tag title. Recommended to be simple and unique.</span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Meta Image <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input class="form-control" type="file" name="meta_image">
                                <span class="form-text text-muted">Recommended image size is 1200px x 627px</span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Meta Image Preview</label>
                            <div class="col-lg-9">
                                <div class="float-right_">
                                    <?php if(empty($WebGeneralSetting->meta_image)): ?>
                                    <img src="<?php echo e(url('public/assets/img/logo2.png')); ?>" class="img-fluid img-thumbnail" alt="">
                                    <?php else: ?>
                                    <img src="<?php echo e(url(env('img_path'). $WebGeneralSetting->meta_image)); ?>"  class="img-fluid img-thumbnail" alt="">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="m-t-20 text-center">
                            <button class="btn btn-primary btn-lg">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/settings/general.blade.php ENDPATH**/ ?>