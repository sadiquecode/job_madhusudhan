<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php $code = session('locale'); ?>
 
    <!-- ==============================Auction Card Start==============================-->
    <section class="search_heading">
        <?php echo $__env->make('theme_1.layouts.page_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="search_content">
            <div class="container">
                <form action="<?php echo e(url('search')); ?>" method="GET" class="<?php echo e(session('ar_class')); ?>">
                    <div class="search_check d-flex gap-3 pt-lg-5 pt-3 pb-3">
                    
<?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php 
        $title = ($code == 'en') ? $gender->gender_en : $gender->gender_ar;
        $isChecked = is_array($selectedGender) && in_array($title, $selectedGender) ? 'checked' : '';
    ?>

    <div class="custom_checks p-1 rounded d-inline-flex">
        <input type="checkbox" class="form-check-input shadow-none" name="gender[]" value="<?php echo e($title); ?>" id="flexCheck<?php echo e($gender->id); ?>" <?php echo e($isChecked); ?>>
        <label class="form-check-label ps-2 w-100" for="flexCheck<?php echo e($gender->id); ?>"><?php echo e($title); ?></label>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    <div class="custom_checks p-1 rounded d-inline-flex">
                            <input type="radio" class="form-check-input shadow-none" name="type" value="auction" id="flexCheck_auctions" <?php echo e(($type == 'auction') ? 'checked' : ''); ?>>
                        <label class="form-check-label ps-2 w-100" for="flexCheck_auctions">
                            <?php echo e(__('trans.Auctions')); ?>

                        </label>
                    </div>

                    <div class="custom_checks p-1 rounded d-inline-flex">
                            <input type="radio" class="form-check-input shadow-none" name="type" value="non_auction" id="flexCheck_selling" <?php echo e(($type == 'non_auction') ? 'checked' : ''); ?>>
                        <label class="form-check-label ps-2 w-100" for="flexCheck_selling">
                            <?php echo e(__('trans.Non-Auctions')); ?>

                        </label>
                    </div>


                </div>
                <div class="row g-0 gy-3">
                    <div class="col-md-3 col-sm-6 col-12">
                        <div class="dropdown_wrapper dropdowncategori">
                            <h6 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Categories')); ?></h6>
                            <div class="dropdown d-grid">
                                <a class="btn dropdown-toggle text-start shadow-none" type="button" id="categoryDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside">
                                    <?php echo e(__('trans.All categories')); ?>

                                </a>
                                <ul class="dropdown-menu searchdrop_menu col-12 border-0" aria-labelledby="categoryDropdown">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php 
                   $title = ($code == 'en') ? $category->category_title_en : $category->category_title_ar; 
                   $isChecked = is_array($selectedCategory) && in_array($title, $selectedCategory) ? 'checked' : '';
                   ?>
                       <li>
                            <label class="dropdown-item custom_control <?php echo e(session('ar_class')); ?>"><?php echo e($title); ?>

                                <input class="form-check-input shadow-none" type="checkbox" name="category[]"
                                    value="<?php echo e($title); ?>" <?php echo e($isChecked); ?>>
                            </label>
                        </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-12">
                        <div class="dropdown_wrapper dropdownbrand">
                            <h6 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Brand')); ?></h6>
                            <div class="dropdown d-grid">
                                <a class="btn dropdown-toggle text-start shadow-none" type="button" id="brandDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside">
                                    <?php echo e(__('trans.All brands')); ?>

                                </a>
                                <ul class="dropdown-menu searchdrop_menu col-12 border-0" aria-labelledby="brandDropdown">
                        <?php $__currentLoopData = $post_brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php 
                           $title = ($code == 'en') ? $brand->brand_title_en : $brand->brand_title_ar; 
                           $isChecked = is_array($selectedBrand) && in_array($title, $selectedBrand) ? 'checked' : '';
                           ?>
                               <li>
                                    <label class="dropdown-item custom_control <?php echo e(session('ar_class')); ?>"><?php echo e($title); ?>

                                        <input class="form-check-input shadow-none" type="checkbox" name="brand[]"
                                            value="<?php echo e($title); ?>" <?php echo e($isChecked); ?>>
                                    </label>
                                </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-12">
                        <div class="dropdown_wrapper dropdownregion">
                            <h6 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Region')); ?></h6>
                            <div class="dropdown d-grid">
                                <a class="btn dropdown-toggle text-start shadow-none" type="button" id="regionDropdown" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside">
                                    <?php echo e(__('trans.All regions')); ?>

                                </a>
                                <ul class="dropdown-menu searchdrop_menu col-12 border-0" aria-labelledby="regionDropdown">
                                    


                        <?php $__currentLoopData = $post_region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php 
                           $title = ($code == 'en') ? $region->region_title_en : $region->region_title_ar; 
                           $isChecked = is_array($selectedRegion) && in_array($title, $selectedRegion) ? 'checked' : '';
                           ?>
                               <li>
                                    <label class="dropdown-item custom_control <?php echo e(session('ar_class')); ?>"><?php echo e($title); ?>

                                        <input class="form-check-input shadow-none" type="checkbox" name="region[]"
                                            value="<?php echo e($title); ?>" <?php echo e($isChecked); ?>>
                                    </label>
                                </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-12">
                        <div class="d-grid filter_search">
                            <button type="submit" class="border-0" id="#">
                                <i class="fa-solid fa-magnifying-glass"></i><span><?php echo e(__('trans.Search')); ?></span>
                            </button>
                        </div>
                    </div>
                </div>
                </form>


    <div class="py-5">
        <div class="container mb-5">
            <div class="justify-content-between align-items-center d-flex">
                <div class="heading flex-column d-flex">
                    <h4 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Ongoing Auctions')); ?></h4>
                </div>
            </div>
        </div>
        <div class="row">
            <?php if($auctionData->isEmpty()): ?>
                <p class="p-5">Not Found!</p>
            <?php else: ?>
                <?php $__currentLoopData = $auctionData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-4 col-lg-3 col-6">
                    <div class="card auction_card customsearch__card border-0 px-0 <?php echo e(session('ar_class')); ?>">
                        <div class="text-center active_btn position-relative">
                            <a href="#" class="d-block position-absolute cardactive_btn ">
                                <?php echo e($key->status); ?>

                            </a>
                        <a href="<?php echo e(url('tags/'.$key->slug)); ?>">
                            <img src="<?php echo e(url(env('img_path').post_img($key->id)->img )); ?>" class="card-img-top img-fluid" alt="<?php echo e($key->product_name); ?>">
                        </a>
                        </div>
                        <div class="card-body px-0 heading">
                            <a href="<?php echo e(url('tags/'.$key->slug)); ?>">
                                <h4 class="card-title mb-4">
                                <?php echo e(strlen($key->product_name) > 25 ? substr($key->product_name, 0, 25) . '...' : $key->product_name); ?>

                                </h4>
                            </a>
                        <p class="card_text d-flex">
                            <small>
                                <?php if($key->type == 'auction'): ?>
                                <?php echo e(__('trans.Starting bid')); ?>

                                <?php else: ?>
                                <?php echo e(__('trans.price')); ?>

                                <?php endif; ?>
                                <?php echo e($key->starting_bid); ?>

                            </small>
                        </p>
                            <p class="card_text d-flex">
                                <small>
                                <?php echo e(\Carbon\Carbon::parse($key->created_at)->format('d F H:i')); ?>

                                </small>
                            </p>
                            <p class=" card_text d-flex mb-5"><small>(<?php echo e(__('trans.GMT')); ?>+3) <?php echo e(__('trans.KSA')); ?></small></p>

                        <div class="d-flex align-items-center justify-content-center">
                            <a href="<?php echo e(url('tags/'.$key->slug)); ?>" class="card_bidbtn"><?php echo e(__('trans.Bid')); ?></a>
                            
                        </div>
                            
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </div>
        </div>



    <div class="py-5">
        <div class="container mb-5">
            <div class="justify-content-between align-items-center d-flex">
                <div class="heading flex-column d-flex">
                    <h4 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.selling product')); ?></h4>
                </div>
            </div>
        </div>
        <div class="row">
            <?php if($nonAuctionData->isEmpty()): ?>
                <p class="p-5">Not Found!</p>
            <?php else: ?>
                <?php $__currentLoopData = $nonAuctionData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-4 col-lg-3 col-6">
                    <div class="card auction_card customsearch__card border-0 px-0 <?php echo e(session('ar_class')); ?>">
                        <div class="text-center active_btn position-relative">
                            <a href="#" class="d-block position-absolute cardactive_btn ">
                                <?php echo e($key->status); ?>

                            </a>
                        <a href="<?php echo e(url('tags/'.$key->slug)); ?>">
                            <img src="<?php echo e(url(env('img_path').post_img($key->id)->img )); ?>" class="card-img-top img-fluid" alt="<?php echo e($key->product_name); ?>">
                        </a>
                        </div>
                        <div class="card-body px-0 heading">
                            <a href="<?php echo e(url('tags/'.$key->slug)); ?>">
                                <h4 class="card-title mb-4">
                                <?php echo e(strlen($key->product_name) > 25 ? substr($key->product_name, 0, 25) . '...' : $key->product_name); ?>

                                </h4>
                            </a>
                        <p class="card_text d-flex">
                            <small>
                                <?php if($key->type == 'auction'): ?>
                                <?php echo e(__('trans.Starting bid')); ?>

                                <?php else: ?>
                                <?php echo e(__('trans.price')); ?>

                                <?php endif; ?>
                                <?php echo e($key->starting_bid); ?>

                            </small>
                        </p>
                            <p class="card_text d-flex">
                                <small>
                                <?php echo e(\Carbon\Carbon::parse($key->created_at)->format('d F H:i')); ?>

                                </small>
                            </p>
                            <p class=" card_text d-flex mb-5"><small>(<?php echo e(__('trans.GMT')); ?>+3) <?php echo e(__('trans.KSA')); ?></small></p>
                            <?php if($key->type == 'auction'): ?>
                            <div class="d-flex align-items-center justify-content-center">
                                <a href="<?php echo e(url('tags/'.$key->slug)); ?>" class="card_bidbtn"><?php echo e(__('trans.Bid')); ?></a>
                                
                            </div>
                            <?php else: ?>
                                <div class="d-flex align-items-center justify-content-center">
<?php
    $user = get_user($key->user_id);
    ?>
    <?php if($user->phone): ?>
    <a class="card_bidbtn <?php echo e(session('ar_class')); ?>" href="tel:<?php echo e($user->phone); ?>"><?php echo e(__('trans.CONTACT US')); ?></a>
    <?php elseif($user->email): ?>
    <a class="card_bidbtn <?php echo e(session('ar_class')); ?>" href="mailto:<?php echo e($user->email); ?>"><?php echo e(__('trans.CONTACT US')); ?></a>
<?php endif; ?>
                                </div>
                            <?php endif; ?>
                            
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </div>
        </div>
        </div>
    </div>
</section>
    <!-- ==============================Upcoming Auction Card End ==============================-->
 
    <!-- =============================Contact Us Start==============================-->
    <section class="contact_wrapper py-4 my-3 d-block d-md-none">
        <div class="container">
            <div class="row">
                <div class="col-7">
                    <div class="contect_detail d-flex align-items-center justify-content-between">
                        <h1 class="mb-0 <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.CONTACT2')); ?>

                        </h1>
                        <a href="https://api.whatsapp.com/send?phone=<?php echo e(get_general_settings()->contact_phone); ?>" target="_blank" class="text-dark">
                            <i class="fa-brands fa-whatsapp fa-3x"></i>
                        </a>
                    </div>
                </div>
                <div class="col-5 align-self-center text-end">
                    <div class="contect_detail">
                        <h1 class="mb-0">
                            <a href="https://api.whatsapp.com/send?phone=<?php echo e(get_general_settings()->contact_phone); ?>" target="_blank" class="text-dark">
                                <?php echo e(get_general_settings()->contact_phone); ?>

                            </a>
                        </h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- =============================Contact Us End==============================-->
<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/theme_1/search_post.blade.php ENDPATH**/ ?>