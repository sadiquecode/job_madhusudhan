<div class="right message">
  <p><?php echo e($message); ?></p>
  <img src="https://assets.edlin.app/images/rossedlin/03/rossedlin-03-100.jpg" alt="Profile picture">
</div>
<?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/c/broadcast.blade.php ENDPATH**/ ?>