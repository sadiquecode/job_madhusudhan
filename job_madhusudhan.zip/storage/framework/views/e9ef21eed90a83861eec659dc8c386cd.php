<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Pricing section -->
  <main id="pricing-section" class="py-5 my-md-7 bg-white">
    <div class="container">
      <!-- Title -->
      <div class="text-center">
        <h1 class="text-capitalize display-6 fw-semibold">How it Works</h1>
        <p class="fs-6 text-primary fw-medium text-black-50">It is simple and easy to use.</p>
      </div>
      <div class="d-flex flex-wrap justify-content-center gap-5 mb-3 mt-5">
        <!-- Student Card -->
        <div class="card mb-4 mx-4 mx-lg-0 py-5 px-lg-4 py-lg-6 rounded-5 border-0 student-card">
          <div class="card-header bg-transparent border-0 pb-3">
            <h3 class="mb-0 fw-semibold fs-2">Parents/Students</h3>
          </div>
          <div class="card-body">
            <ul class="icon-list icon-list-square-warning mb-4 d-flex text-start flex-column gap-2">
              <li>
                <span>
                  Pay the yearly subscription of <strong>&nbsp;100 AED/Year</strong>
                </span>
              </li>
              <li>
                <span>Access to qualified and verified tutors</span>
              </li>
              <li>
                <span>Use filters to narrow down your search by either location,
                  curriculum, subject, language and grade level</span>
              </li>
              <li>
                <span>Contact your chosen tutor directly and start learning</span>
              </li>
            </ul>
            <a href="./register"
              class="btn btn-warning bg-transparent-hover text-white text-warning-hover border-warning-hover fw-semibold py-3 px-5 rounded-pill">Subscribe Today</a>
          </div>
        </div>
        <!-- Tutor Card -->
        <div class="card mb-4 mx-4 mx-lg-0 py-5 px-lg-4 py-lg-6 rounded-5 border-0 tutor-card">
          <div class="card-header bg-transparent border-0 pb-3">
            <h3 class="mb-0 fw-semibold fs-2">Tutors</h3>
          </div>
          <div class="card-body">
            <ul class="icon-list icon-list-square list-unstyled mb-4 d-flex text-start flex-column gap-2">
              <li><span>
                  Pay the yearly subscription of <strong>&nbsp;100 AED/Year</strong>
                </span>
              </li>
              <li>
                <span>Upload your details</span>
              </li>
              <li>
                <span>Your profile will be approved by admin</span>
              </li>
              <li>
                <span>Parents and students now have access to your profile and can start contacting you for your
                  tutoring services</span>
              </li>
            </ul>
            <br>
            <a href="./register"
              class="btn btn-primary bg-transparent-hover text-white text-primary-hover border-primary-hover fw-semibold py-3 px-5 rounded-pill">Subscribe Today</a>
          </div>
        </div>
      </div>
    </div>
  </main>
<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/teachme_how_it_works.blade.php ENDPATH**/ ?>