
<?php $code = session('locale'); ?>
<div class="container-fluid">
    <div class="row align-items-center">
        <div class="col-md-6 col-lg-6 col-6">
            <div class="ps-md-5">
                <h4 class="py-4 <?php echo e(session('ar_class')); ?>"><?php echo e($head); ?></h4>
            </div>
        </div>
        <div class="col-md-6 col-lg-6 col-6">
            <div class="d-flex justify-content-end align-items-center gap-4">
                <div class="d-flex align-items-center gap-4 d-none">
                    <div class="msg_btn  d-none d-md-block">
                        <a href="#">Message</a>
                    </div>
                    <div class="rating_star  d-none d-md-block">
                        <a href="#">
                            <ul class="list-unstyled d-flex text-warning mb-0 rounded-3 gap-1">
                                <li><i class="fas fa-star fa-sm"></i></li>
                                <li><i class="fas fa-star fa-sm"></i></li>
                                <li><i class="fas fa-star fa-sm"></i></li>
                                <li><i class="fas fa-star fa-sm"></i></li>
                                <li><i class="fas fa-star fa-sm"></i></li>
                            </ul>
                        </a>
                    </div>
                </div>
                <div class="ownuserprofile">
                    <div class="justify-content-between align-items-center d-flex flex-column">
                        <?php if(auth()->guard()->check()): ?>
                        <div class="d-flex">
                            <a href="<?php echo e(url('profile/'.Crypt::encrypt(auth()->user()->id))); ?>">
                                <?php if(empty(auth()->user()->profile_pic)): ?>
                                    <img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="user" class="img-fluid rounded-circle me-2"  width="32" height="32">
                                    <?php else: ?>
                                    <img src="<?php echo e(url(env('img_path'). auth()->user()->profile_pic)); ?>" alt="user" class="img-fluid rounded-circle me-2" width="32" height="32">
                                <?php endif; ?>
                            </a>
                            <div class="flex-column d-flex text-center">
                                <strong><?php echo e(auth()->user()->name); ?></strong>
                                <small><?php echo e(auth()->user()->email); ?></small>
                                <small><a href="tel:<?php echo e(auth()->user()->phone); ?>"><?php echo e(auth()->user()->phone); ?></a></small>

                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="d-flex align-items-center gap-4 pt-2 d-none">
                            <div class="msg_btn d-block d-md-none">
                                <a href="#">Message</a>
                            </div>
                            <div class="rating_star d-block d-md-none">
                                <a href="#">
                                    <ul class="list-unstyled d-flex text-warning mb-0 rounded-3 gap-1">
                                        <li><i class="fas fa-star fa-sm"></i></li>
                                        <li><i class="fas fa-star fa-sm"></i></li>
                                        <li><i class="fas fa-star fa-sm"></i></li>
                                        <li><i class="fas fa-star fa-sm"></i></li>
                                        <li><i class="fas fa-star fa-sm"></i></li>
                                    </ul>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/theme_1/layouts/page_head.blade.php ENDPATH**/ ?>