<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $code = session('locale'); ?>


<style>
.select2-container .select2-selection--single .select2-selection__rendered {
padding: 0 !important;
}
.select2-container--default .select2-selection--single {
    border: none;
}
.select2-container .select2-selection--single {
                    height: 37px;
            }
.select2-container--default .select2-selection--single .select2-selection__arrow {
    z-index: -1;
}


.select2-dropdown {
    background-color: white;
    border: none;
   filter: drop-shadow(0px 0px 14.5px rgba(0,0,0,0.1 ));
}
.select2-container--default .select2-search--dropdown .select2-search__field {
    border: 1px solid #8F8F8F;
       border-radius: 5px;
}
.select2-container--default .select2-search--dropdown .select2-search__field:focus {
    border-color:#AE7E30;
}
.select2-results__option--selectable {
    cursor: pointer;
        color: #16204A;
}
.select2-container--default .select2-results__option--highlighted.select2-results__option--selectable {
    background-color: #F5F5F5;
    color: #16204A;
}
</style>
    <!-- ==============================Auction Card Start==============================-->
    <section class="addpost_heading">
        <?php echo $__env->make('theme_1.layouts.page_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="addpost_content py-5">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>

            <form action="<?php echo e(route('post.store')); ?>" method="POST" enctype="multipart/form-data" class="<?php echo e(session('ar_class')); ?>">
                    <?php echo csrf_field(); ?>
            <div class="container">
                <div class="addpost_features py-4 px-3">
                    <div class="row align-items-center" dir="<?php echo e(($code == 'en') ? 'ltr' : 'rtl'); ?>">
                        <div class="col-md-4">
                            <div class="product_wrapper">
                                <h6><?php echo e(__('trans.Product name')); ?></h6>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="product_feature">
                                <input class="form-control shadow-none border-0 ps-0" type="text"
                                    placeholder="<?php echo e(__('trans.Type here')); ?>" aria-label="default input example" name="product_name" required>
                            </div>
                        </div>
                        <div class="divide_line"></div>
                        <div class="col-md-4">
                            <div class="product_wrapper">
                                <h6><?php echo e(__('trans.Product description')); ?></h6>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="product_feature">
                                <textarea class="form-control shadow-none border-0 ps-0"
                                    id="exampleFormControlTextarea1" rows="1" placeholder="<?php echo e(__('trans.Type here')); ?>" name="product_description"></textarea>
                            </div>
                        </div>
                        <div class="divide_line "></div>
                        <div class="col-md-4">
                            <div class="product_wrapper">
                                <h6><?php echo e(__('trans.Product Additional Information')); ?></h6>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="product_feature">
                                <textarea class="form-control shadow-none border-0 ps-0"
                                    id="exampleFormControlTextarea2" rows="1" placeholder="<?php echo e(__('trans.Type here')); ?>" name="product_information"></textarea>
                            </div>
                        </div>
                        <div class="divide_line"></div>
                        <div class="col-md-4">
                            <div class="product_wrapper">
                                <h6><?php echo e(__('trans.Product Brand')); ?></h6>
                            </div>
                        </div>
                        <div class="col-md-8" style="overflow: hidden;">
                            <div class="product_feature">
        
            <select id="myFirstSelect2Basic" class="form-control px-0 border-0" name="brand_id">
                <?php $__currentLoopData = $post_brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $title = ($code  == 'en') ? $brand->brand_title_en : $brand->brand_title_ar;
                ?>
                    <option value="<?php echo e($brand->id); ?>"><?php echo e($title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

                            </div>
                        </div>

                        <div class="divide_line"></div>
                        <div class="col-md-4">
                            <div class="product_wrapper">
                                <h6><?php echo e(__('trans.Product Region')); ?></h6>
                            </div>
                        </div>
                        <div class="col-md-8" style="overflow: hidden;">
                            <div class="product_feature">
        
            <select id="myFirstSelect2Basic_" class="form-control px-0 border-0" name="region_id">
                <?php $__currentLoopData = $post_region; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $title = ($code  == 'en') ? $region->region_title_en : $region->region_title_ar;
                ?>
                    <option value="<?php echo e($region->id); ?>"><?php echo e($title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="divide_line pt-4"></div>
            </div>
            <div class="container pt-4">
                <div class="row">
                    <div class="col-md-4"></div>
                    <div class="col-md-8">
                        <div class="custom_control d-flex justify-content-start gap-5">
                            <div class="custom_checks p-1 px-2 rounded d-inline-flex">
                                <input type="radio" class="form-check-input shadow-none" id="flexCheckAuction" name="type" value="auction" onclick="change_price_type('auction')" checked>
                                <label class="form-check-label ps-2" for="flexCheckAuction"><?php echo e(__('trans.Auction')); ?></label>
                            </div>
                            <div class="custom_checks p-1 px-2 rounded d-inline-flex" style="margin-left: 35px;">
                                <input type="radio" class="form-check-input shadow-none" id="customCheckNonAuction" name="type" value="non_auction" onclick="change_price_type('non_auction')">
                                <label class="form-check-label ps-2" for="customCheckNonAuction"><?php echo e(__('trans.Non auction')); ?></label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="addpost_features p-3 my-3">
                    <div class="row align-items-center" dir="<?php echo e(($code == 'en') ? 'ltr' : 'rtl'); ?>">
                        <div class="col-md-4">
                            <div class="product_wrapper">
                                <p class="mb-0 fw-lighter" id="change_price_text">
                                <?php echo e(__('trans.Starting bid')); ?></p>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="product_feature">
                                <input class="form-control shadow-none border-0 ps-0" type="number" name="starting_bid" 
                                    placeholder="<?php echo e(__('trans.Type here')); ?>" aria-label="default input example" required>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="divide_line pt-4"></div>
            </div>
            <div class="container">
                <div class="p-3 my-2">
                    <div class="row align-items-center">
                        <div class="col-md-4">
                            <div class="product_wrapper">
                                <p class="mb-0 fw-lighter"><?php echo e(__('trans.Gender')); ?></p>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="custom_control gap-5 d-flex justify-content-start">
                            <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $title = ($code == 'en') ? $gender->gender_en : $gender->gender_ar;
                            ?>
                            <div class="custom_checks p-1 rounded">
                                <input type="radio" class="form-check-input shadow-none" id="flexCheck<?php echo e($gender->id); ?>" name="gender_id" value="<?php echo e($gender->id); ?>" <?php if($key === 0): ?> checked <?php endif; ?>>
                                <label class="form-check-label ps-2" for="flexCheck<?php echo e($gender->id); ?>"><?php echo e($title); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <div class="col-md-4 pt-3">
                            <div class="product_wrapper">
                                <p class="mb-0 fw-lighter"><?php echo e(__('trans.Categories')); ?></p>
                            </div>
                        </div>
                        <div class="col-md-8 pt-3">
                            <div class="custom_control d-flex justify-content-between">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $title = ($code == 'en') ? $category->category_title_en : $category->category_title_ar;
                    ?>

                    <div class="custom_checks p-1 rounded d-inline-flex">
                        <input type="checkbox" class="form-check-input shadow-none" id="customCheck<?php echo e($category->id); ?>" name="category_ids[]" value="<?php echo e($category->id); ?>" <?php echo e($key === 0 ? 'checked' : ''); ?>>
                        <label class="form-check-label ps-2 w-100" for="customCheck<?php echo e($category->id); ?>">
                            <?php echo e($title); ?>

                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </div>
                        </div>
                    </div>
                </div>
                <div class="divide_line"></div>
            </div>
            <div class="container pt-4">
                <div class="row">
                    <div class="col-md-4">
                        <div class="d-grid">
                            <div class="file btn fw-lighter">
                                <?php echo e(__('trans.Upload images')); ?>

                                <input type="file" name="post_img[]" multiple />
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="justify-content-between align-items-center d-flex">
                            <div class="d-flex align-items-start">
                                <div class="policieschecks mt-1">
                                    <input type="checkbox" class="form-check-input shadow-none mt-0 me-2" id="emailupdates" name="terms">
                                </div>
                                <div class="flex-column d-flex">
                                    <p><?php echo e(__('trans.I have read and agree to the')); ?> <a href="#" data-bs-toggle="modal" data-bs-target="#privacy"
                                            rel="noopener noreferrer"><?php echo e(__('trans.privacy policy')); ?></a> <?php echo e(__('trans.&')); ?>

                                        jeddahmazad.com <a href="#" data-bs-toggle="modal" data-bs-target="#Terms" rel="noopener noreferrer"><?php echo e(__('trans.Terms & conditions')); ?></a>
                                    </p> 
                                </div>
                            </div>
                        </div>

                        <div class="justify-content-between align-items-center d-flex">
                            <div class="d-flex align-items-start">
                                <div class="policieschecks mt-1">
                                <input type="checkbox" class="form-check-input shadow-none mt-0 me-2" id="agreement" name="agreement">
                                </div>
                                <div class="flex-column d-flex">
                                    <p><?php echo e(__('trans.I have read and agree to the')); ?> <a href="#" data-bs-toggle="modal" data-bs-target="#Agreement" rel="noopener noreferrer"><?php echo e(__('trans.Agreement')); ?></a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="d-grid done_btn">
                            <button class="btn fw-bolder" type="submit"><?php echo e(__('trans.Done')); ?></button>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        </div>
    </section>
    





<?php echo $__env->make('theme_1.layouts.terms_policy_popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- jQuery first, then Popper.js and Bootstrap JS. -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>

<script>
    function change_price_type(type) {
        var code = "<?php echo e($code); ?>";
        if(type == 'auction'){
            $('#change_price_text').text("<?php echo e(__('trans.Starting bid')); ?>");
        }else{
            $('#change_price_text').text("<?php echo e(__('trans.price')); ?>");
        }
        // Add your custom logic here
    }

</script>


<?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/theme_1/post/create_post_data.blade.php ENDPATH**/ ?>