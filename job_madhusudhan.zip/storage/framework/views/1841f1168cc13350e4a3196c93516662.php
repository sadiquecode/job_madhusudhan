<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<div class="main-wrapper">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper" style="background-color:rgb(159 249 199);">



<div style="
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    width: 100vw;
    height: 100vh;
    font-family: Arial, sans-serif;
    font-weight: 700;
">
    <div>
        <h1 style="font-size: 7vw; margin: 0;">MarkNotifier!</h1>
        <p style="font-size: 2vw;">Effortless Result Sharing via WhatsApp</p>
    </div>
</div>



</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\server\htdocs\Wstudent\resources\views/main/dashboard.blade.php ENDPATH**/ ?>