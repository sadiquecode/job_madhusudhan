<!doctype HTML>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AI Chat Assistants | Web</title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(url('public/theme_one_assets/images/logo/favicon.svg')); ?>" type="image/svgicon">
    <!-- font Awesome  -->
    <script src="https://kit.fontawesome.com/31cf530d7e.js" crossorigin="anonymous"></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(url('public/theme_one_assets/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/theme_one_assets/bootstrap/bootstrap.min.css')); ?>.map">
    <!-- Custom CSS -->
    <?php if(!empty(session('direction')) && session('direction') == 'rtl'): ?>
    <link rel="stylesheet" href="<?php echo e(url('public/theme_one_assets/css/style-rtl.css')); ?>">
    <?php else: ?>
    <link rel="stylesheet" href="<?php echo e(url('public/theme_one_assets/css/style.css')); ?>">
    <?php endif; ?>
</head>

<body>
    <div class="container">
        <div class="log_in__form">
            <div class="logo_icon">
                <a class="navbar-brand d-flex align-items-center justify-content-center" href="homeindex.html"><img
                        src="<?php echo e(url('public/theme_one_assets/images/logo/logo.svg')); ?>" width="33" height="27" alt="Logo">
                </a>
                <h3>Sign in to Describely</h3>
                <div class="main">
                	<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    <?php if(session('status')): ?>
                    <div class="mb-4 font-medium text-sm text-green-600">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row gy-2">
                            <div class="col-md-12 p-0">
                                <div class="form-group input_group">
                                    <label for="inputThree" class="form-label fw-bold">Email
                                        address*</label>
                                    <span class="form-control-feedback"> <img src="<?php echo e(url('public/theme_one_assets/images/icon/email.png')); ?>"
                                            width="20" height="20" alt=""></span>
                                    <input class="form-control" type="email" name="email" :value="old('email')" required autofocus autocomplete="username"
                                        placeholder="email@domain.com">
                                </div>
                            </div>
                            <div class="col-md-12 p-0">
                                <div class="form-group input_group">
                                    <label for="inputFour" class="form-label fw-bold">Password*</label>
                                    <span class="form-control-feedback"> <img src="<?php echo e(url('public/theme_one_assets/images/icon/password.png')); ?>"
                                            width="20" height="20" alt=""></span>
                                    <input class="form-control floating" type="password" name="password" required autocomplete="current-password">
                                </div>
                            </div>
                            <div class="col-md-12 d-grid p-0 mx-auto">
                                <button class="btn btn-primary" type="submit">Sign in</button>
                            </div>
                            <div class="other text-center py-2">
                                <p class="mb-0">OR</p>
                            </div>
                            <div class="d-grid gap-2 col-md-12 p-0 mx-auto">
                                <a class="btn btn-outline-danger fw-bold btn_icon" href="<?php echo e(url('login/google')); ?>"><img
                                        src="<?php echo e(url('public/theme_one_assets/images/icon/google-color.png')); ?>" alt="google" width="20"
                                        height="20">
                                    Sign in with Google
                                </a>
                                <a class="btn btn-outline-primary fw-bold btn_icon" href="<?php echo e(url('login/facebook')); ?>"><img
                                        src="<?php echo e(url('public/theme_one_assets/images/icon/facebook.png')); ?>" alt="facebook" width="20" height="20">Sign
                                    in with facebook
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
<!-- Bootstrap JS -->
<script src="<?php echo e(url('public/theme_one_assets/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('public/theme_one_assets/bootstrap/bootstrap.bundle.min.js.map')); ?>"></script>

</html><?php /**PATH G:\server\htdocs\advance_ai\resources\views/auth/weblogin.blade.php ENDPATH**/ ?>