<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">

                <div class="card-header text-center mb-3">
                    You will be charged AED <?php echo e(number_format($plan->price, 2)); ?> for <?php echo e($plan->title); ?> Plan
                </div>
  
  



<form id="payment-form" action="<?php echo e(route('addmoney.paystripe')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
    <input type="hidden" name="plan" id="plan" value="<?php echo e($plan->id); ?>">


                <div class="col-12 col-lg-8 offset-lg-3">
                  <div class="card" style="border-radius: 15px;">
                    <div class="card-body p-4 row g-4">

                      <label class="col-12 col-md-12">
                        <span>Cardholder's Name</span>
                        <input class="form-control mt-2" size="17" name="card_holder" id="card-holder-name" required />
                      </label>

                      <label class="col-12 col-md-12">
                        <span>Card details</span>
                       <div id="card-element" style="width: 100%;"></div>
                        <div id="card-errors" role="alert"></div>
                      </label>

                      <div class="col d-flex justify-content-end">
                        <button type="submit" class="btn btn-success text-white rounded-pill" id="card-button" data-secret="<?php echo e($intent->client_secret); ?>">
                          <i class="me-2 fa-solid fa-save"></i>
                          Purchase
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </form><br><br>



        </div>
    </div>
</div>


<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript"></script>

<script src="https://js.stripe.com/v3/"></script>
<script>

    const stripe = Stripe('<?php echo e(env('STRIPE_KEY')); ?>')
  
    const elements = stripe.elements()
    const cardElement = elements.create('card', {hidePostalCode: true});
  
    cardElement.mount('#card-element')
  
    const form = document.getElementById('payment-form')
    const cardBtn = document.getElementById('card-button')
    const cardHolderName = document.getElementById('card-holder-name')
  
    form.addEventListener('submit', async (e) => {
        e.preventDefault()
  
        cardBtn.disabled = true
        const { setupIntent, error } = await stripe.confirmCardSetup(
            cardBtn.dataset.secret, {
                payment_method: {
                    card: cardElement,
                    billing_details: {
                        name: cardHolderName.value
                    }   
                }
            }
        )
  
        if(error) {
            cardBtn.disable = false
        } else {
            let token = document.createElement('input')
            token.setAttribute('type', 'hidden')
            token.setAttribute('name', 'token')
            token.setAttribute('value', setupIntent.payment_method)
            form.appendChild(token)
            form.submit();
        }
    })
</script>
<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/payment/subscription.blade.php ENDPATH**/ ?>