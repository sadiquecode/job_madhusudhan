<div class="slider_wrapper mx-auto text-center">
    <p>From same company that built</p>
    <div class="slider">
        <div class="slide-track">
            <div class="slide "> <img src="<?php echo e(url('public/theme_one_assets/images/main/download.svg')); ?>" alt=""></div>
            <div class="slide "> <img src="<?php echo e(url('public/theme_one_assets/images/main/download.svg')); ?>" alt=""></div>
            <div class="slide "> <img src="<?php echo e(url('public/theme_one_assets/images/main/download.svg')); ?>" alt=""></div>
            <div class="slide "> <img src="<?php echo e(url('public/theme_one_assets/images/main/download.svg')); ?>" alt=""></div>
            <div class="slide "> <img src="<?php echo e(url('public/theme_one_assets/images/main/download.svg')); ?>" alt=""></div>
        </div>
    </div>
</div><?php /**PATH G:\server\htdocs\advance_ai\resources\views/theme_1/layouts/company_logo.blade.php ENDPATH**/ ?>