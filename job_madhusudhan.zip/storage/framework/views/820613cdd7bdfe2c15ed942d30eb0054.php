<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('public/assets/img/favicon.png')); ?>">
        <title>Register as User</title>
        <link href="https://fonts.googleapis.com/css?family=Fira+Sans:400,500,600,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/plugins/fontawesome/css/all.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/assets/css/theme-light.css')); ?>">
        <!--[if lt IE 9]>
        <script src="<?php echo e(url('public/assets/js/html5shiv.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/assets/js/respond.min.js')); ?>"></script>
        <![endif]-->
    </head>
    <body>
        <div class="main-wrapper">
            <div class="account-page">
                <div class="container">
                    <h3 class="account-title">Register</h3>
                    <div class="account-box">
                        <div class="account-wrapper">
                            <div class="account-logo">
                                <a href="index.html">
                                    <img src="<?php echo e(url('public/assets/img/logo2.png')); ?>" alt="Preadmin">
                                </a>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group form-focus">
            <label class="focus-label">Name</label>
            <input class="form-control floating" type="text" name="name" :value="old('name')" required autofocus autocomplete="name" />
            </div>

            <div class="form-group form-focus">
            <label class="focus-label">Phone</label>
            <input class="form-control floating" type="number" name="phone" :value="old('phone')" required autofocus autocomplete="phone" />
            </div>

            <div class="form-group form-focus">
            <label class="focus-label">Email</label>
            <input class="form-control floating" type="email" name="email" :value="old('email')" required autofocus autocomplete="email" />
            </div>

            <div class="form-group form-focus">
            <label class="focus-label">Password</label>
            <input class="form-control floating" type="password" name="password" :value="old('password')" required autofocus autocomplete="password" />
            </div>

            <div class="form-group form-focus">
            <label class="focus-label">Confirm Password</label>
            <input class="form-control floating" type="password" name="password_confirmation" :value="old('password_confirmation')" required autofocus autocomplete="password_confirmation" />
            </div>

            <div class="form-group text-center">
                <button class="btn btn-primary btn-block account-btn" type="submit">Register</button>
            </div>



            <div class="flex items-center justify-end mt-4">
                <a class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500" href="<?php echo e(route('login')); ?>">
                    <?php echo e(__('Already registered?')); ?>

                </a>
            </div>
        </form>
    </div>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript" src="<?php echo e(url('public/assets/js/jquery-3.5.1.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(url('public/assets/js/popper.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(url('public/assets/js/bootstrap.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(url('public/assets/js/app.js')); ?>"></script>
    </body>
</html><?php /**PATH G:\server\htdocs\advance_ai\resources\views/auth/register.blade.php ENDPATH**/ ?>