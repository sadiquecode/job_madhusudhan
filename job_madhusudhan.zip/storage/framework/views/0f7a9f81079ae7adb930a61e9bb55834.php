<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-3">
                    <h4 class="page-title"><?php echo e($head); ?></h4>
                </div>
            </div>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-sm-4 col-md-4 col-lg-4 col-xl-3">
                    <div class="roles-menu">
                        <ul>
                            <li class="<?php if($head == 'About Page'): ?><?php echo e('active'); ?><?php endif; ?>">
                                <a href="<?php echo e(url('about-page')); ?>">About</a>
                            </li>
                            <li class="<?php if($head == 'Services Page'): ?><?php echo e('active'); ?><?php endif; ?>">
                                <a href="<?php echo e(url('services-page')); ?>">Services</a>
                            </li>
                            <li class="<?php if($head == 'Policy Page'): ?><?php echo e('active'); ?><?php endif; ?>">
                                <a href="<?php echo e(url('policy-page')); ?>">Policy</a>
                            </li>
                            <li class="<?php if($head == 'Terms Page'): ?><?php echo e('active'); ?><?php endif; ?>">
                                <a href="<?php echo e(url('terms-page')); ?>">Terms</a>
                            </li>
                            <li class="<?php if($head == 'Agreement Page'): ?><?php echo e('active'); ?><?php endif; ?>">
                                <a href="<?php echo e(url('agreement-page')); ?>">Agreement</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <?php echo $__env->make('web.forms.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/web/webpage.blade.php ENDPATH**/ ?>