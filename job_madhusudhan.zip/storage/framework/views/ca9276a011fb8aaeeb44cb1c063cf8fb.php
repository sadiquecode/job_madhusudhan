<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Main content -->
  <main id="contact-us-section" class="py-5 mb-7">
    <div class="container d-flex flex-column gap-4 gap-lg-8">
      <!-- Title -->
      <div class="text-center">
        <h1 class="text-capitalize display-6 fw-semibold">Contact Us
        </h1>
        <p class="fs-6 text-primary fw-medium text-black-50">Any question or remarks? Just write us a message!</p>
      </div>

      <!-- Form Container -->
      <div class="row row-cols-2 p-2 rounded-4" style="box-shadow: 0 0 60px 30px rgba(0, 0, 0, 0.03);">
        <!-- Contact info -->
        <ul
          class="col-12 col-md-5 m-0 p-5 bg-warning text-white rounded-4 d-flex flex-column justify-content-between contact-info-container list-unstyled">
          <li>
            <h2 class="fw-semibold">Reach to us</h2>
            <p class="fs-5">Connect. Learn. Succeed.</p>
          </li>

          <li class="fs-6">
            <p> <a href="mailto:<?php echo e(get_general_settings()->contact_email); ?>" style="text-decoration:none;color:#fff;"><i class="fa-solid fa-envelope me-3"></i><?php echo e(get_general_settings()->contact_email); ?> </a></p>
            <div class="d-flex pt-4">
              <!--<i class="fa-solid fa-location-dot me-3"></i>-->
              
              <p style="display:none;"><?=get_general_settings()->visit_address?></p>
              
            </div>
          </li>

          <li>
            <ul class="list-unstyled d-flex gap-2 footer-social-icons">
              <!--<li>-->
              <!--  <a class="fs-5 rounded-circle text-white bg-secondary bg-primary-hover" href="<?php echo e(get_general_settings()->twitter); ?>">-->
              <!--    <i class="fa-brands fa-twitter"></i>-->
              <!--    <span class="visually-hidden">Twitter</span>-->
              <!--  </a>-->
              <!--</li>-->
              <li>
                <a class="fs-5 rounded-circle text-white bg-secondary bg-primary-hover" href="<?php echo e(get_general_settings()->linkedin); ?>">
                  <i class="fa-brands fa-linkedin-in"></i>
                  <span class="visually-hidden">LinkedIn</span>
                </a>
              </li>
              <li>
                <a class="fs-5 rounded-circle text-white bg-secondary bg-primary-hover" href="<?php echo e(get_general_settings()->instagram); ?>">
                  <i class="fa-brands fa-instagram"></i>
                  <span class="visually-hidden">Instagram</span>
                </a>
              </li>
              <li>
                <a class="fs-5 rounded-circle text-white bg-secondary bg-primary-hover" href="<?php echo e(get_general_settings()->youtube); ?>">
                  <i class="fa-brands fa-facebook"></i>
                  <span class="visually-hidden">facebook</span>
                </a>
              </li>
            </ul>
          </li>

          <div></div>
        </ul>

        <!-- Form Fields -->
        <form class="col-12 col-md p-5 pb-md-10" action="<?php echo e(route('add_teachme_contacts')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo $__env->make('theme_1.userprofile.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="row g-5">
            <div class="col-12">
              <label for="type" class="form-label fw-medium d-block mb-3">Are you ?</label>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="type" id="type-student" value="student" checked>
                <label class="form-check-label" for="type-student">Student/Parent</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="type" id="type-tutor" value="tutor">
                <label class="form-check-label" for="type-tutor">Tutor</label>
              </div>
            </div>
            <div class="col-12 col-md-6">
              <label for="first-name" class="form-label fw-medium">First Name</label>
              <input type="text" name="fname"
                class="form-control-plaintext border-2 border-top-0 border-start-0 border-end-0 border-primary border-opacity-50"
                id="fname" required>
            </div>
            <div class="col-12 col-md-6">
              <label for="last-name" class="form-label fw-medium">Last Name</label>
              <input type="text" name="lname"
                class="form-control-plaintext border-2 border-top-0 border-start-0 border-end-0 border-primary border-opacity-50"
                id="lname" required>
            </div>
            <div class="col-12 col-md-6">
              <label for="email" class="form-label fw-medium">Email</label>
              <input type="email" name="email"
                class="form-control-plaintext border-2 border-top-0 border-start-0 border-end-0 border-primary border-opacity-50"
                id="email" required>
            </div>
            <div class="col-12 col-md-6">
              <label for="phone-number" class="form-label fw-medium">Phone Number</label>
              <input type="number" name="phone"
                class="form-control-plaintext border-2 border-top-0 border-start-0 border-end-0 border-primary border-opacity-50"
                id="phone" required>
            </div>
            <div class="col-12">
              <label for="message" class="form-label fw-medium">Message</label>
              <textarea type="text" name="message"
                class="form-control-plaintext border-2 border-top-0 border-start-0 border-end-0 border-primary border-opacity-50" id="message" placeholder="Write your message.." required> </textarea>
            </div>
            <div class="col-12 d-flex justify-content-end">
              <button type="submit" class="btn btn-primary py-3 px-5">Send Message</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </main>

<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/teachme_contact_us.blade.php ENDPATH**/ ?>