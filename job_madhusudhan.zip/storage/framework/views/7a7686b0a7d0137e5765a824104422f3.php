<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<div class="main-wrapper">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">
<div class="content container-fluid">
<div class="row">
<div class="col-sm-4 col-4">
    <h4 class="page-title">All Templates</h4>
</div>



<?php if (Auth::user()->type == 'admin') { ?>
<div class="col-sm-8 col-8 text-right m-b-30">
    <a href="#" class="btn btn-primary btn-rounded float-right" data-toggle="modal" data-target="#add_template"><i class="fa fa-plus"></i> Create Template</a>
    <div class="view-icons d-none">
        <a href="projects.html" class="grid-view btn btn-link active"><i class="fa fa-th"></i></a>
        <a href="project-list.html" class="list-view btn btn-link"><i class="fa fa-bars"></i></a>
    </div>
</div>
<?php }else{echo "<style>
.profile-action{
    display:none;
}
</style>";} ?>
</div>


<div class="row">
<div class="col-md-12 ">
    
    <div class="card-box">
        <div class="row filter-row">
            <div class="col-sm-12 col-md-8 mx-auto my-5">
                <div class="input-group">
                    <input type="text" class="form-control" name="search" id="ai_temp_search" placeholder="Search your favorite template..." aria-label="Recipient's username" aria-describedby="button-addon2" style="border-radius: 25px 25px 25px 25px; height: 50px;" >
                    
                </div>
            </div>
        </div>



<div id="alert-container" class="mt-3" style="display: none;"></div>

        <div class="row">
            <div class="col-sm-10 mx-auto">
                <ul id="category-tabs" class="nav nav-tabs nav-tabs-solid nav-tabs-rounded text-center justify-content-center">
                </ul>
            </div>
        </div>


<div id="loader" class="mt-5 mb-5 text-center"></div>


        <div class="tab-content">
            <div class="tab-pane show active" id="all_templates">
                <div class="row" id="ai-templates-container"></div>
                <div style="display: none;" class="no_data_found text-center">Data not found</div>
            </div>

            <div class="tab-pane" id="cat_related">
                <div class="row" id="cat_related_container"></div>
                <div style="display: none;" class="no_data_found text-center">Data not found</div>
            </div>
        </div>

    </div>
</div>
</div>
</div>
</div>

<div id="add_template" class="modal custom-modal fade" role="dialog">
<div class="modal-dialog">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-content modal-lg">
<div class="modal-header">
    <h4 class="modal-title">Create Template</h4>
</div>
<div class="modal-body">
    <form id="template_added" class="mb-5">
        <div class="row">
            <div class="col-sm-12">
                <div class="form-group">
                    <label>Template</label>
                    <input class="form-control" type="text" name="template" id="template-input">
                </div>
            </div>
            <div class="col-sm-12">
                <div class="form-group">
                    <label>Slug</label>
                    <input class="form-control" type="text" name="slug" id="slug-input">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Icon</label>
                    <input class="form-control" type="text" name="icon">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label>Category</label>
                    <select class="select" name="category_id">
                        <?php $__currentLoopData = $activeCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="form-group">
                    <label>Description</label>
                    <textarea rows="4" cols="5" class="form-control summernote_" placeholder="Enter your description here" name="description"></textarea>
                </div>
            </div>
        </div>







<!-- Container to hold all the form fields -->
<div id="formFieldsContainer" class="main_custom_field d-none">
    <div class="row mt-5_ custom_field">
        <!-- Original form fields -->
        <div class="col-sm-6">
            <!-- Title input -->
            <div class="form-group">
                <label>Input Name</label>
                <input class="form-control parameter_title" type="text" name="parameter_title[]" placeholder="Input Name">
            </div>
        </div>
        <div class="col-sm-6">
            <!-- Type select -->
            <div class="form-group">
                <label>Type</label>
                <div class=" d-flex align-items-center">
                <select class="form-control parameter_type" name="parameter_type[]">
                    <option value="text" selected>Text Field</option>
                    <option value="textarea">Textarea Field</option>
                    <option value="select">Select List Field</option>
                </select>
                <i class="fa fa-trash hide_custom_form" 
                    style="padding: 10px;
                    font-size: 20px;
                    color: red;
                    cursor: pointer;">
                </i>
                </div>
            </div>
        </div>

        <div class="col-sm-12 optionsField d-none" id="optionsField">
            <!-- Options input -->
            <div class="form-group">
                <label>Options</label>
                <input class="form-control" type="text" name="parameter_options[]" placeholder="Enter comma separated values for the select list.">
            </div>
        </div>
    </div>
</div>

<!-- Add Field button -->
<div class="form-group p-3_">
    
    <input class="form-control btn btn-sm btn-primary" type="button" value="Add Field" id="add_field" style="width: 20%;">
</div>





        <div class="row">
            <div class="col-sm-12" id="custom_inputs">
                <div class="form-group custom_inputs">
                    
                    <div class="buttons-container d-none">
                    <div class="custom_buttons">
                    </div>

                    <div class="mb-2">
                      <span>* Click on variable to set the user input of it in your prompts</span>
                    </div>
                    </div>

                    <label>prompt</label>
                    <textarea rows="4" cols="5" class="form-control summernote_" placeholder="Enter your prompt here" name="prompt"></textarea>
                </div>
            </div>
        </div>






        <div class="row">
            <div class="col-sm-12">
                <div class="form-group">
                    <label class="display-block">Status</label>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="temp_cat_enable" value="enable" checked>
                        <label class="form-check-label" for="temp_cat_enable">
                            enable
                        </label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="temp_cat_disable" value="disable">
                        <label class="form-check-label" for="temp_cat_disable">
                            disable
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <div class="m-t-20 text-center">
            <button class="btn btn-primary btn-lg submit_added_form">Create Template</button>
        </div>
    </form>
</div>
</div>
</div>
</div>


<div id="edit_ai_templates" class="modal custom-modal fade" role="dialog">
<div class="modal-dialog">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-content modal-lg">
<div class="modal-header">
    <h4 class="modal-title">Edit AI Templates</h4>
</div> 
<div class="modal-body">
    <form id="ai_templates_edit">
        <div class="row">
        <div class="col-sm-12">
            <div class="form-group">
                <label>Template</label>
                <input class="form-control" type="hidden" id="ai_template">
                <input class="form-control" type="text" name="template" id="edit_template">
            </div>
        </div>
        <div class="col-sm-12">
            <div class="form-group">
                <label>Slug</label>
                <input class="form-control" type="text" name="slug" id="edit_slug">
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Icon</label>
                <input class="form-control" type="text" name="icon" id="edit_temp_icon">
            </div>
        </div>

        <div class="col-sm-6">
            <div class="form-group">
                <label>Category</label>
            <select class="select" name="category_id" id="temp_category_id">
                <option value=""></option>
                </select>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12">
            <div class="form-group">
                <label>Description</label>
                <textarea rows="4" cols="5" class="form-control summernote_" placeholder="Enter your Description here" name="description" id="temp_description"></textarea>
            </div>
        </div>
    </div>








<!-- Container to hold all the form fields -->
<div id="edit_formFieldsContainer" class="main_custom_field d-none">
    <div class="row mt-5_ edit_custom_field">
        <!-- Original form fields -->
        <div class="col-sm-6">
            <!-- Title input -->
            <div class="form-group">
                <label>Input Name</label>
                <input class="form-control edit_parameter_title" type="text" name="parameter_title[]" placeholder="Input Name">
            </div>
        </div>
        <div class="col-sm-6">
            <!-- Type select -->
            <div class="form-group">
                <label>Type</label>
                <div class=" d-flex align-items-center">
                <select class="form-control edit_parameter_type" name="parameter_type[]">
                    <option value="text" selected>Text Field</option>
                    <option value="textarea">Textarea Field</option>
                    <option value="select">Select List Field</option>
                </select>
                <i class="fa fa-trash hide_edit_custom_form" 
                    style="padding: 10px;
                    font-size: 20px;
                    color: red;
                    cursor: pointer;">
                </i>
                </div>
            </div>
        </div>

        <div class="col-sm-12 optionsField d-none" id="optionsField">
            <!-- Options input -->
            <div class="form-group">
                <label>Options</label>
                <input class="form-control" type="text" name="parameter_options[]" placeholder="Enter comma separated values for the select list.">
            </div>
        </div>
    </div>
</div>

<!-- Add Field button -->
<div class="form-group p-3_">
    <input class="form-control btn btn-sm btn-primary" type="button" value="Add Field" id="add_edit_field" style="width: 20%;" onclick="confirm('Are you sure you want to proceed? When you add new fields, the old fields will be replaced!')">
</div>


        <div class="row">
            <div class="col-sm-12" id="custom_inputs">
                <div class="form-group custom_inputs">
                    
                    <div class="edit_buttons-container d-none">
                    <div class="edit_custom_buttons">
                    </div>

                    <div class="mb-2">
                      <span>* Click on variable to set the user input of it in your prompts</span>
                    </div>
                    </div>

                    <label>prompt</label>
                    <textarea rows="4" cols="5" class="form-control summernote_" placeholder="Enter your prompt here" name="prompt" id="temp_prompt"></textarea>
                </div>
            </div>
        </div>



        <div class="row">
            <div class="col-sm-12">
                <div class="form-group">
                    <label class="display-block">Status</label>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="temp_status_active" value="enable" checked>
                        <label class="form-check-label" for="temp_status_active">
                            enable
                        </label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="temp_status_inactive" value="disable">
                        <label class="form-check-label" for="temp_status_inactive">
                            disable
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <div class="m-t-20 text-center mb-5">
            <button class="btn btn-primary btn-lg">Edit AI Template</button>
        </div>
    </form>
</div>
</div>
</div>
</div>
<div id="delete_aitemplate" class="modal custom-modal fade" role="dialog">
<div class="modal-dialog">
<div class="modal-content modal-md">
<div class="modal-header">
    <h4 class="modal-title">Delete AI Template</h4>
</div>
    <form id="aitemplate_delete">
        <input class="form-control" type="hidden" id="dele_aitemp_id">
        <div class="modal-body card-box">
            <p>Are you sure want to delete this AI Template?</p>
            <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                <button class="btn btn-danger">Delete</button>
            </div>
        </div>
    </form>
</div>
</div>
</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/template/show_aitemp.blade.php ENDPATH**/ ?>