<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.topheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ================blog=========-->
    <div class="how__start py-5 mt-5">
        <div class="container">
            <div class="row mt-5">
                <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card mt-5 p-5">
                        <div class="card-title">
                        <?= isset($pages->page_title) ? $pages->page_title : '' ?>
                        </div>
                        <div class="card-body">
                            <?= isset($pages->body) ? $pages->body : 'Empty' ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ===============end blog========-->
<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/theme_1/pages.blade.php ENDPATH**/ ?>