<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-sm-4 col-3">
                <h4 class="page-title">All Reviews</h4>
            </div>
            <div class="col-sm-8 col-9 text-right m-b-20 d-none">
                <a href="#" class="btn btn-primary btn-rounded float-right" data-toggle="modal" data-target="#add_review"><i class="fa fa-plus"></i> Add Reviews</a>
            </div>
        </div>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <div class="row">
            <?php if(count($TeachmeReview) > 0): ?>
            <div class="col-md-12">
                <div class="table-responsive">
                    <table class="table table-striped custom-table datatable" id="teachme_table">
                        <thead>
                            <tr>
                                <th>S/L</th>
                                <th>Student</th>
                                <th>Tutor</th>
                                <th>Review</th>
                                <th>Status</th>
                                <th class="text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $TeachmeReview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($review->student_name); ?></td>
                                <td><?php echo e($review->tutor_name); ?></td>
                                <td>
                                    <?php for($i = 0; $i < $review->stars; $i++): ?>
                                    <i class="text-warning fas fa-star m-r-5"></i>
                                    <?php endfor; ?> <br>
                                    <span class="short-text"><?php echo e(str_limit($review->review_text, 20)); ?></span>
                                    <span class="full-text" style="display: none;"><?php echo e($review->review_text); ?></span>
                                    <a href="#" class="expand-btn">Read More</a>
                                </td>
                                <td>
                                    <?php if($review->status === 'approve'): ?>
                                    <span class="p-2 badge badge-success">Approved</span>
                                    <?php else: ?>
                                    <span class="p-2 badge badge-warning">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-right">
                                    <div class="dropdown dropdown-action">
                                        <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_review_<?php echo e($review->id); ?>"><i class="fas fa-pen m-r-5"></i> Edit</a>
                                            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_review_<?php echo e($review->id); ?>"><i class="far fa-trash-alt m-r-5"></i> Delete</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <div id="delete_review_<?php echo e($review->id); ?>" class="modal custom-modal fade" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content modal-md">
                                        <div class="modal-header">
                                            <h4 class="modal-title">Delete Review</h4>
                                        </div>
                                        <form action="<?php echo e(route('review.destroy', $review->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="modal-body card-box">
                                                <p>Are you sure want to delete this?</p>
                                                <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div id="edit_review_<?php echo e($review->id); ?>" class="modal custom-modal fade" role="dialog">
                            <div class="modal-dialog">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <div class="modal-content modal-lg">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Edit Review</h4>
                                    </div>
                                    <div class="modal-body">
                                        
                                        <form class="m-b-30" action="<?php echo e(route('review.update', $review->id)); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label class="col-form-label">Status <span class="text-danger">*</span></label>
                                                        <select name="status" class="select floating">
                                                            <option value="approve" <?php if($review->status === 'approve'): ?> selected <?php endif; ?>>Approved</option>
                                                            <option value="pending" <?php if($review->status === 'pending'): ?> selected <?php endif; ?>>Pending</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="m-t-20 text-center mb-5">
                                                <button type="submit" class="btn btn-primary btn-lg">Update Review</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
        </div>
        <?php else: ?>
        <p class="p-4"><?php echo e('Reviews Not Found!'); ?></p>
        <?php endif; ?>
    </div>
</div>
</div>
</div>
<div id="add_review" class="modal custom-modal fade" role="dialog">
<div class="modal-dialog">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-content modal-lg">
    <div class="modal-header">
        <h4 class="modal-title">Add Reviews</h4>
    </div>
    <div class="modal-body">
        <form class="m-b-30" action="<?php echo e(route('review.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label class="col-form-label">Title<span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control">
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="form-group">
                        <label class="col-form-label">Grade Image <span class="text-danger">*</span></label>
                        <input type="file" name="curriculum_image" class="form-control" required>
                    </div>
                </div>
                
                
                <div class="col-sm-12">
                    <div class="form-group form-focus select-focus">
                        <label class="focus-label">Status</label>
                        <select class="select floating" name="status">
                            <option value="active">Enable</option>
                            <option value="inactive">Disable</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="m-t-20 text-center mb-5">
                <button type="submit" class="btn btn-primary btn-lg">Create Curriculum</button>
            </div>
        </form>
    </div>
</div>
</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/golbal_details/teachme_review.blade.php ENDPATH**/ ?>