<div class="sidebar" id="sidebar"> 
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <!-- Supper admin -->
            <ul>
                <li class="menu-title">MAIN</li>
                <li class="<?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('/dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                </li>


                <!-- <li class="menu-title">USERS</li>
                <li class="<?php echo e(request()->is('dashboard/customers') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('dashboard/customers')); ?>"><i class="fas fa-users"></i> Students</a>
                </li> -->
                

                <li class="<?php echo e(request()->is('dashboard/result') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('dashboard/result')); ?>"><i class="fas fa-school"></i> Results</a>
                </li>
               
                

                <br><br><br>
            </ul>

        </div>
    </div>
</div><?php /**PATH D:\server\htdocs\Wstudent\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>