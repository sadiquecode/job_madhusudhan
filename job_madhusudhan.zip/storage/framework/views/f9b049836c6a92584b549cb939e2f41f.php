<?php $code = session('locale'); ?>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
                <div class="auction_user bg-white p-3 <?php echo e(session('ar_class')); ?>">
                        <div class="justify-content-between align-items-center d-flex">
                            <div class="flex-column d-flex">
                                <h5><?php echo e(__('trans.profile details')); ?></h5>
                            </div>
                            <?php if($isOwner): ?>
                            <div class="profileyour">
                                <h5 class="mb-0 p-2" data-bs-toggle="modal" data-bs-target="#edit_profile" style="cursor: pointer; color: white;"><?php echo e(__('trans.complete your profile')); ?></h5>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class=" pt-2">
                            <div class="user_name">

                                <?php if($isOwner): ?>
                                    <p><?php echo e($profile->title.' '.$profile->name); ?> - <?php echo e($profile->lname); ?></p>
                                    <p><?php echo e(auth()->user()->email); ?></p>
                                <?php endif; ?>

                                <?php if($isOwner): ?>
                                    <div class="justify-content-between d-flex">
                                    <div class="flex-column d-flex">
                                        <p><?php echo e(__('trans.password')); ?></p>
                                        <p>*****</p>
                                    </div>
                                    <div class="profile_edit">
                                        <button type="button" class="btn shadow-none fw-bold" data-bs-toggle="modal" data-bs-target="#passwordModal">
                                        <?php echo e(__('trans.change password')); ?>

                                        </button>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                        <?php if($isOwner): ?>
                        <div class="accountpreference py-2" dir="<?php echo e(($code == 'en') ? 'ltr' : 'rtl'); ?>">
                            <h5><?php echo e(__('trans.accounts and auction preferences')); ?></h5>
                            <h5><?php echo e(__('trans.your available accounts to bid, buy and sell with us:')); ?>.</h5>
                        </div>
                        <?php endif; ?>
                        <div class="card">
                            <div class="card-body">
                                <div class="justify-content-between align-items-center d-flex">
                                    <div class="flex-column d-flex">
                                        <h5><?php echo e(__('trans.Individual')); ?></h5>
                                    </div>
                                </div>
                                <div class="preferenceaddress">
                                    <p><?php echo e($profile->name); ?> - <?php echo e($profile->lname); ?> <i class="fa fa-phone"></i> <?php echo e($profile->phone); ?></p>
                                    <p><?php echo e(__('trans.Billing address')); ?> </p>

                                    <p><?php echo e(($code == 'en') ? $profile->billing_address_en : $profile->billing_address_ar); ?></p>

                                    <p><?php echo e(__('trans.Shipping address')); ?></p>
                                    <p><?php echo e(($code == 'en') ? $profile->shipping_address_en : $profile->shipping_address_ar); ?></p>
                                </div>
                            </div>
                        </div>

                    <div class="accountpreference py-3">
                        <h5><?php echo e(__('trans.Address book')); ?></h5>
                    </div>
                    <?php if($address->isEmpty()): ?>
                        <p class="p-2"><?php echo e(__('trans.Empty')); ?></p>
                        <button type="button" class="btn newaddress rounded-0 shadow-none"data-bs-toggle="modal" data-bs-target="#addAddressbookModal"><i class="fa-solid fa-plus me-2"></i> <?php echo e(__('trans.Add new address')); ?></button>
                    <?php endif; ?>
                    <?php $no = 1; ?>
                    <?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">
                            <div class="card-body">
                                <div class="justify-content-between align-items-center d-flex">
                                    <div class="flex-column d-flex">
                                        <h5><?php echo e(__('trans.Home')); ?></h5>
                                    </div>

                                    <?php if($isOwner): ?>
                                    <div class="profile_edit">
                                        <h5 class="mb-0 p-2"></h5>
                                        <button type="button" class="btn shadow-none fw-bold" data-bs-toggle="modal" data-bs-target="#editAddressbookModal_<?php echo e($key->id); ?>">
                                        <?php echo e(__('trans.edit')); ?></button>
                                        <a href="<?php echo e(url('del/data/'.$key->id)); ?>" class="btn shadow-none fw-bold text-danger" onclick="return confirm('<?php echo e(__('trans.Are You Sure?')); ?>')"><?php echo e(__('trans.delete')); ?></a>
                                    </div>
                                    <?php endif; ?>

                                </div>
                                <div class="preferenceaddress">

                            <?php if($isOwner || $key->data_status == 1): ?>
                                <div class="preferenceprimary">
                                    <p class="d-inline p-2"><?php echo e(__('trans.Primary address')); ?></p>
                                </div>

                                
                                <?php
                                $address_ = ($code == 'en') ? $key->address_en : $key->address_ar; 
                                ?>
                                        
                                <p class="pt-2"><?php echo e(__('trans.Shipping address')); ?> (<?php echo e($no); ?>)</p>
                                <p><?php echo e($address_); ?></p>
                            <?php else: ?>
                            <p class="pt-2"><?php echo e(__('trans.private')); ?></p>
                            <?php endif; ?>

                                <?php if($isOwner): ?>
                                    <button type="button" class="btn newaddress rounded-0 shadow-none"data-bs-toggle="modal" data-bs-target="#addAddressbookModal"><i class="fa-solid fa-plus me-2"></i> <?php echo e(__('trans.Add new address')); ?></button>
                                <?php endif; ?>
                                </div>
                                <?php if($isOwner): ?>
                                <div class="d-flex px-0 pt-5">
                                    <p><?php echo e(__('trans.Public')); ?>/<?php echo e(__('trans.private')); ?></p>
                                    <label class="onoffbtn ms-2 <?php echo e($key->data_status == 1 ? 'active' : ''); ?>" data-id="<?php echo e($key->id); ?>">
                                        <input type="checkbox" onclick="togglePermission(<?php echo e($key->id); ?>,<?php echo e($key->data_status); ?>);">
                                    </label>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    




<!-- Address book Modal -->
<div class="modal fade" id="editAddressbookModal_<?php echo e($key->id); ?>" tabindex="-1" aria-labelledby="editAddressbookModal_<?php echo e($key->id); ?>" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content rounded-0 ">
    <div class="modal-header">
        <h1 class="modal-title fs-5 <?php echo e(session('ar_class')); ?>" id="editAddressbookModal_<?php echo e($key->id); ?>"><?php echo e(__('trans.Address book')); ?></h1>
        <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <form action="<?php echo e(url('update-address')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="data_id" value="<?php echo e($key->id); ?>">
        <input type="hidden" name="user_id" value="<?php echo e($key->user_id); ?>">
        <div class="modal-body">
            <div class="row">
                <div class="col-lg-6">
                    <div class="mb-3 editprofile">
                        <label for="Input1" class="form-label"><?php echo e(__('trans.Add new address')); ?></label>
                        <input type="text" class="form-control shadow-none" id="Input1" name="address_en" value="<?php echo e($key->address_en); ?>">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3 editprofile">
                        <label for="Input2" class="form-label"><?php echo e(__('trans.Translation')); ?></label>
                        <input type="text" class="form-control shadow-none" id="Input2" name="address_ar" value="<?php echo e($key->address_ar); ?>">
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer editprofile">
            <button type="submit" class="btn btn-md shadow-none"><?php echo e(__('trans.Save')); ?></button>
        </div>
    </form>
</div>
</div>
</div>



<?php $no ++; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                        <div class="accountpreference py-3">
                            <h5><?php echo e(__('trans.Phone book')); ?></h5>
                        </div>

                        <?php if($numbers->isEmpty()): ?>
                        <p class="p-2"><?php echo e(__('trans.Empty')); ?></p>
                        <?php if($isOwner): ?>
                            <button type="button" class="btn newaddress rounded-0 shadow-none"data-bs-toggle="modal" data-bs-target="#addPhonebookModal"><i class="fa-solid fa-plus me-2"></i> <?php echo e(__('trans.Add new phone number')); ?></button>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php $__currentLoopData = $numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">
                            <div class="card-body">
                                <div class="justify-content-between align-items-center d-flex">
                                    <div class="flex-column d-flex">
                                        <h5><?php echo e(__('trans.Landline')); ?> </h5>
                                    </div>
                                    <?php if($isOwner): ?>
                                    <div class="profile_edit">
                                        <h5 class="mb-0 p-2"></h5>
                                        <button type="button" class="btn shadow-none fw-bold" data-bs-toggle="modal" data-bs-target="#editPhonebookModal_<?php echo e($key->id); ?>">
                                        <?php echo e(__('trans.edit')); ?></button>
                                        <a href="<?php echo e(url('del/data/'.$key->id)); ?>" class="btn shadow-none fw-bold text-danger" onclick="return confirm('<?php echo e(__('trans.Are You Sure?')); ?>')"><?php echo e(__('trans.delete')); ?></a>
                                    </div>
                                    <?php endif; ?>

                                </div>
                                <div class="preferenceaddress">
                                     <?php if($isOwner || $key->data_status == 1): ?>
                                    <div class="preferenceprimary">
                                        <p class="d-inline p-2"><?php echo e(__('trans.Primary phone')); ?></p>
                                    </div>


                                
                                <p class="pt-2"></p>
                                <p>+<?php echo e($key->number); ?></p>
                                
                                    <?php else: ?>
                                    <p class="pt-2"><?php echo e(__('trans.private')); ?></p>
                                    <?php endif; ?>

                                    <?php if($isOwner): ?>
                                    <button type="button" class="btn newaddress rounded-0 shadow-none"data-bs-toggle="modal" data-bs-target="#addPhonebookModal"><i class="fa-solid fa-plus me-2"></i> <?php echo e(__('trans.Add new phone number')); ?></button>
                                    <?php endif; ?>
                                </div>
                                <?php if($isOwner): ?>
                                <div class=" d-flex px-0 pt-5">
                                    <p><?php echo e(__('trans.Public')); ?>/<?php echo e(__('trans.private')); ?></p>
                                  <label class="onoffbtn ms-2 <?php echo e($key->data_status == 1 ? 'active' : ''); ?>" data-id="<?php echo e($key->id); ?>">
                                        <input type="checkbox" onclick="togglePermission(<?php echo e($key->id); ?>,<?php echo e($key->data_status); ?>);">
                                    </label>

                                </div>
                                <?php endif; ?>
                            </div>
                        </div>






<!-- Phone book Modal -->
<div class="modal fade" id="editPhonebookModal_<?php echo e($key->id); ?>" tabindex="-1" aria-labelledby="editPhonebookModal_<?php echo e($key->id); ?>" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content rounded-0">
    <form action="<?php echo e(url('update-address')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="data_id" value="<?php echo e($key->id); ?>">
        <input type="hidden" name="user_id" value="<?php echo e($key->user_id); ?>">
        <div class="modal-header">
            <h1 class="modal-title fs-5 <?php echo e(session('ar_class')); ?>" id="editPhonebookModal_<?php echo e($key->id); ?>"><?php echo e(__('trans.edit phone number')); ?></h1>
            <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="mb-3 editprofile">
                <label for="exampleFormControlTextarea0" class="form-label"><?php echo e(__('trans.Phone book')); ?></label>
                <input type="number" class="form-control shadow-none" id="exampleFormControlTextarea0" rows="3" name="number" value="<?php echo e($key->number); ?>">
            </div>
        </div>
        <div class="modal-footer editprofile">
            <button type="submit" class="btn btn-md shadow-none"><?php echo e(__('trans.Save')); ?></button>
        </div>
    </form>
</div>
</div>
</div>




<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>



<div class="modal fade" id="edit_profile" tabindex="-1" aria-labelledby="edit_profile" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content rounded-0 <?php echo e(session('ar_class')); ?>">
    <div class="modal-header">
        <h1 class="modal-title fs-5 <?php echo e(session('ar_class')); ?>" id="edit_profile"><?php echo e(__('trans.Edit Profile')); ?></h1>
        <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
<form method="POST" action="<?php echo e(route('update_profile.update', ['user' => $profile->id])); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
        <div class="modal-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="mb-3 editprofile">
                        <label for="profile_pic" class="form-label"><?php echo e(__('trans.picture')); ?></label>
                        <input type="file" class="form-control shadow-none" id="profile_pic" name="profile_pic" value="<?php echo e($profile->profile_pic); ?>">
                    </div>
                </div>

                <div class="mt-5"></div>
                <div class="col-lg-2">
                    <div class="mb-3 editprofile">
                        <label for="title" class="form-label"><?php echo e(__('trans.Title')); ?></label>
                        <input type="text" class="form-control shadow-none" id="title" name="title" value="<?php echo e($profile->title); ?>">
                        <input type="hidden" name="password">
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="mb-3 editprofile">
                        <label for="name" class="form-label"><?php echo e(__('trans.fname')); ?></label>
                        <input type="text" class="form-control shadow-none" id="name" name="name" value="<?php echo e($profile->name); ?>">
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="mb-3 editprofile">
                        <label for="fname" class="form-label"><?php echo e(__('trans.lname')); ?></label>
                        <input type="text" class="form-control shadow-none" id="lname" name="lname" value="<?php echo e($profile->lname); ?>">
                    </div>
                </div>

                <div class="mt-5"></div>
                <div class="col-lg-6">
                    <div class="mb-3 editprofile">
                        <label for="email" class="form-label"><?php echo e(__('trans.email address')); ?></label>
                        <input type="email" class="form-control shadow-none" id="email" name="email" value="<?php echo e($profile->email); ?>">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3 editprofile">
                        <label for="number" class="form-label"><?php echo e(__('trans.phone')); ?></label>
                        <input type="number" class="form-control shadow-none" id="number" name="phone" value="<?php echo e($profile->phone); ?>">
                    </div>
                </div>

                <div class="mt-5"></div>
                <div class="col-lg-6">
                    <div class="mb-3 editprofile">
                        <label for="baddress_1" class="form-label"><?php echo e(__('trans.Billing address')); ?></label>
                        <input type="text" class="form-control shadow-none" id="baddress_1" name="billing_address_en" value="<?php echo e($profile->billing_address_en); ?>">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3 editprofile">
                        <label for="baddress_2" class="form-label"><?php echo e(__('trans.Translation')); ?></label>
                        <input type="text" class="form-control shadow-none" id="baddress_2" name="billing_address_ar" value="<?php echo e($profile->billing_address_ar); ?>">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3 editprofile">
                        <label for="saddress_1" class="form-label"><?php echo e(__('trans.Shipping address')); ?></label>
                        <input type="text" class="form-control shadow-none" id="saddress_1" name="shipping_address_en" value="<?php echo e($profile->shipping_address_en); ?>">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3 editprofile">
                        <label for="saddress_2" class="form-label"><?php echo e(__('trans.Translation')); ?></label>
                        <input type="text" class="form-control shadow-none" id="saddress_2" name="shipping_address_ar" value="<?php echo e($profile->shipping_address_ar); ?>">
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer editprofile">
            <button type="submit" class="btn btn-md shadow-none"><?php echo e(__('trans.Save')); ?></button>
        </div>
    </form>
</div>
</div>
</div>


<!-- Password Modal -->
<div class="modal fade" id="passwordModal" tabindex="-1" aria-labelledby="passwordModal" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered ">
<div class="modal-content rounded-0 <?php echo e(session('ar_class')); ?>">
    <div class="modal-header">
        <h1 class="modal-title fs-5 <?php echo e(session('ar_class')); ?>" id="passwordModal"><?php echo e(__('trans.change password')); ?></h1>
        <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
<form method="POST" action="<?php echo e(route('update_profile.update', ['user' => $profile->id])); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
        <div class="modal-body">
            <div class="row">

                <div class="col-lg-12">
                    <div class="mb-3 editprofile">
                        <label for="newpassword" class="form-label"><?php echo e(__('trans.password')); ?></label>
                        <input type="text" class="form-control shadow-none" id="newpassword" name="password">
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer editprofile">
            <button type="submit" class="btn btn-md shadow-none"><?php echo e(__('trans.change password')); ?></button>
        </div>
    </form>
</div>
</div>
</div>






<!-- Address book Modal -->
<div class="modal fade" id="addAddressbookModal" tabindex="-1" aria-labelledby="addAddressbookModal" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content rounded-0 <?php echo e(session('ar_class')); ?>">
    <div class="modal-header">
        <h1 class="modal-title fs-5 <?php echo e(session('ar_class')); ?>" id="editIndividualModal"><?php echo e(__('trans.Add new address')); ?></h1>
        <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <form action="<?php echo e(url('add-address')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="data_id" value="<?php echo e($profile->id); ?>">
        <div class="modal-body">
            <div class="row">
                <div class="col-lg-6">
                    <div class="mb-3 editprofile">
                        <label for="Input1" class="form-label"><?php echo e(__('trans.Add new address')); ?></label>
                        <input type="text" name="address_en" class="form-control shadow-none" id="Input1">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="mb-3 editprofile">
                        <label for="Input2" class="form-label"><?php echo e(__('trans.Translation')); ?></label>
                        <input type="text" name="address_ar" class="form-control shadow-none" id="Input2">
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer editprofile">
            <button type="submit" class="btn btn-md shadow-none"><?php echo e(__('trans.Save')); ?></button>
        </div>
    </form>
</div>
</div>
</div>

<!-- Phone book Modal -->
<div class="modal fade" id="addPhonebookModal" tabindex="-1" aria-labelledby="addPhonebookModal" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content rounded-0 <?php echo e(session('ar_class')); ?>">
    <form action="<?php echo e(url('add-address')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="data_id" value="<?php echo e($profile->id); ?>">
        <div class="modal-header">
            <h1 class="modal-title fs-5 <?php echo e(session('ar_class')); ?>" id="addPhonebookModal"><?php echo e(__('trans.Add new phone number')); ?></h1>
            <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="mb-3 editprofile">
                <label for="example1" class="form-label"><?php echo e(__('trans.Phone book')); ?></label>
                <input class="form-control shadow-none" id="example1" type="number" name="number">
            </div>
        </div>
        <div class="modal-footer editprofile">
            <button type="submit" class="btn btn-md shadow-none"><?php echo e(__('trans.Save')); ?></button>
        </div>
    </form>
</div>
</div>
</div>



<?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/theme_1/post/user_profile.blade.php ENDPATH**/ ?>