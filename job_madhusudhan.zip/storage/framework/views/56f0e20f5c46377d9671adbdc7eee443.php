  <!-- Filters -->
  <form id="search-tutors-form" class="container mt-5 pb-4 position-relative" name="search-tutors"  action="<?php echo e(route("find.tutors")); ?>" method="GET">
    <h2 class="fs-5 mb-4">Apply the filters to search the relevant tutors</h2>
    <div class="overflow-y-visible overflow-x-auto">
      <div class="btn-group gap-3 position-static">
        <!-- Language Filter -->
        <div class="dropdown position-static">
          <button
            class="btn btn-outline-primary py-2 px-4 dropdown-toggle rounded-pill d-flex align-items-center fs-5 gap-2"
            type="button" data-bs-toggle="dropdown" aria-expanded="false" data-tm-target="language">
            <img src="<?php echo e(url('public/theme_assets/images/languages/english.png')); ?>" aria-hidden="true" class="d-none">
            <i class="fa-solid fa-book"></i>
            <span>
            <?php if(isset($_GET['language_id'])): ?> 
                <?php echo e(filter_data($_GET['language_id'], 'language')); ?>

              <?php else: ?>
              Language
            <?php endif; ?>
          </span>
          </button>
          <div class="dropdown-menu mt-3 border-0">
            <!-- List of available languages -->
            <div class="list-group list-group-checkable d-grid px-2 gap-2 border-0">
              <input class="list-group-item-check pe-none search_data" type="radio" name="language_id" id="language-all" value="" <?php if(request()->has('language_id') && request('language_id') == ''): ?> checked <?php endif; ?>>
              <label class="list-group-item rounded-4 py-2" for="language-all" data-tm-label="Language">
                All
              </label>

              <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <input class="list-group-item-check pe-none search_data" type="radio" name="language_id" id="language-<?php echo e($key->name); ?>" value="<?php echo e($key->id); ?>" <?php if(isset($_GET['language_id']) && $_GET['language_id'] == $key->id): ?> 
                <?php echo e('checked'); ?><?php endif; ?>>
              <label class="list-group-item rounded-4 py-2" for="language-<?php echo e($key->name); ?>">
              <img src="<?php echo e(url(env('img_path'). $key->lang_img)); ?>" aria-hidden="true">
              <?php echo e($key->name); ?>

              </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              
            </div>
          </div>
        </div>
  
        <!-- City Filter -->
        <div class="dropdown position-static">
          <button
            class="btn btn-outline-primary py-2 px-4 dropdown-toggle rounded-pill d-flex align-items-center fs-5 gap-2"
            type="button" data-bs-toggle="dropdown" aria-expanded="false" data-tm-target="city">
            <i class="fa-solid fa-globe"></i>

            <span>
            <?php if(isset($_GET['location_id'])): ?> 
                <?php echo e(filter_data($_GET['location_id'], 'city')); ?>

              <?php else: ?>
              City
            <?php endif; ?>
          </span>

          </button>
          <div class="dropdown-menu mt-3 border-0">
            <!-- List of available cities -->
            <div class="list-group list-group-checkable d-grid px-2 gap-2 border-0">
              <input class="list-group-item-check pe-none search_data" type="radio" name="location_id" id="city-all" value="" <?php if(request()->has('location_id') && request('location_id') == ''): ?> checked <?php endif; ?>>
              <label class="list-group-item rounded-4 py-2" for="city-all" data-tm-label="City">
                All
              </label>
  
              <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <input class="list-group-item-check pe-none search_data" type="radio" name="location_id" id="city-<?php echo e($key->name); ?>" value="<?php echo e($key->id); ?>" <?php if(isset($_GET['location_id']) && $_GET['location_id'] == $key->id): ?> 
                <?php echo e('checked'); ?><?php endif; ?>>
              <label class="list-group-item rounded-4 py-2" for="city-<?php echo e($key->name); ?>" data-tm-label="City">
                <?php echo e($key->name); ?>

              </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
          </div>
        </div>
  
        <!-- Subjects Filter -->
        <div class="dropdown position-static">
          <button
            class="btn btn-outline-primary py-2 px-4 dropdown-toggle rounded-pill d-flex align-items-center fs-5 gap-2"
            type="button" data-bs-toggle="dropdown" aria-expanded="false" data-tm-target="subject">
            <img src="<?php echo e(url('public/theme_assets/images/icons/book-saved.svg')); ?>" aria-hidden="true">
            
            <span>
            <?php if(isset($_GET['subject_id'])): ?> 
                <?php echo e(filter_data($_GET['subject_id'], 'subject')); ?>

              <?php else: ?>
              Subject
            <?php endif; ?>
          </span>
          </button>
          <div class="dropdown-menu mt-3 border-0">
            <!-- List of available subjects -->
            <div class="list-group list-group-checkable d-grid px-2 gap-2 border-0">
              <input class="list-group-item-check pe-none search_data" type="radio" name="subject_id" id="subject-all" value="" <?php if(request()->has('subject_id') && request('subject_id') == ''): ?> checked <?php endif; ?>>
              <label class="list-group-item rounded-4 py-2" for="subject-all" data-tm-label="Subject">
                All
              </label>
  
              
              <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <input class="list-group-item-check pe-none search_data" type="radio" name="subject_id" id="subject-<?php echo e($key->title); ?>" value="<?php echo e($key->id); ?>" <?php if(isset($_GET['subject_id']) && $_GET['subject_id'] == $key->id): ?> 
                <?php echo e('checked'); ?><?php endif; ?>>
              <label class="list-group-item rounded-4 py-2" for="subject-<?php echo e($key->title); ?>">
                <?php echo e($key->title); ?>

              </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
          </div>
        </div>
  
        <!-- Grades Filter -->
        <div class="dropdown position-static">
          <button
            class="btn btn-outline-primary py-2 px-4 dropdown-toggle rounded-pill d-flex align-items-center fs-5 gap-2"
            type="button" data-bs-toggle="dropdown" aria-expanded="false" data-tm-target="grade">
            <img src="<?php echo e(url('public/theme_assets/images/icons/book-saved.svg')); ?>" aria-hidden="true">
            <span>
            <?php if(isset($_GET['grade_id'])): ?> 
                <?php echo e(filter_data($_GET['grade_id'], 'grade')); ?>

              <?php else: ?>
              Grade
            <?php endif; ?>
            </span>
          </button>
          <div class="dropdown-menu mt-3 border-0">
            <!-- List of available grades -->
            <div class="list-group list-group-checkable d-grid px-2 gap-2 border-0">
              <input class="list-group-item-check pe-none search_data" type="radio" name="grade_id" id="grade-all" value="" <?php if(request()->has('grade_id') && request('grade_id') == ''): ?> checked <?php endif; ?>>
              <label class="list-group-item rounded-4 py-2" for="grade-all" data-tm-label="Grade">
                All
              </label>
  
              
              <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <input class="list-group-item-check search_data pe-none search_data" type="radio" name="grade_id" id="grade-<?php echo e($key->title); ?>" value="<?php echo e($key->id); ?>" <?php if(isset($_GET['grade_id']) && $_GET['grade_id'] == $key->id): ?>  <?php echo e('checked'); ?><?php endif; ?>>
              <label class="list-group-item rounded-4 py-2" for="grade-<?php echo e($key->title); ?>">
                <?php echo e($key->title); ?>

              </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
          </div>
        </div>
  
        <!-- Curriculum Filter -->
        <div class="dropdown position-static">
          <button
            class="btn btn-outline-primary py-2 px-4 dropdown-toggle rounded-pill d-flex align-items-center fs-5 gap-2"
            type="button" data-bs-toggle="dropdown" aria-expanded="false" data-tm-target="curriculum">
            <img src="<?php echo e(url('public/theme_assets/images/icons/book-saved.svg')); ?>" aria-hidden="true">
            <span>
            <?php if(isset($_GET['curriculum_id'])): ?> 
                <?php echo e(filter_data($_GET['curriculum_id'], 'curriculum')); ?>

              <?php else: ?>
              Curriculum
            <?php endif; ?>
            </span>
          </button>
          <div class="dropdown-menu mt-3 border-0">
            <!-- List of available curriculum -->
            <div class="list-group list-group-checkable d-grid px-2 gap-2 border-0">
              <input class="list-group-item-check pe-none search_data" type="radio" name="curriculum_id" id="curriculum-all" value="" <?php if(request()->has('curriculum_id') && request('curriculum_id') == ''): ?> checked <?php endif; ?>>
              <label class="list-group-item rounded-4 py-2" for="curriculum-all" data-tm-label="Curriculum">
                <img src="<?php echo e(url('public/theme_assets/images/icons/book-saved.svg')); ?>" aria-hidden="true">All
              </label>
  
              <?php $__currentLoopData = $curriculums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <input class="list-group-item-check search_data pe-none" type="radio" name="curriculum_id" id="curriculum-<?php echo e($key->title); ?>" value="<?php echo e($key->id); ?>" <?php if(isset($_GET['curriculum_id']) && $_GET['curriculum_id'] == $key->id): ?>  <?php echo e('checked'); ?><?php endif; ?>>
              <label class="list-group-item rounded-4 py-2" for="curriculum-<?php echo e($key->title); ?>">
                <img src="<?php echo e(url(env('img_path'). $key->curriculum_image)); ?>" aria-hidden="true">
                <?php echo e($key->title); ?>

              </label>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
          </div>
        </div>
  
        <!-- Instruction Mode Filter -->
        <div class="dropdown position-static">
          <button
            class="btn btn-outline-primary py-2 px-4 dropdown-toggle rounded-pill d-flex align-items-center fs-5 gap-2"
            type="button" data-bs-toggle="dropdown" aria-expanded="false" data-tm-target="instruction-mode">
            <img src="<?php echo e(url('public/theme_assets/images/icons/user-square.svg')); ?>" aria-hidden="true">
            <span>
            <?php if(isset($_GET['availability'])): ?> 
                <?php echo e(filter_data($_GET['availability'], 'availability')); ?>

              <?php else: ?>
              Availability
            <?php endif; ?>
            </span>
          </button>
          <div class="dropdown-menu mt-3 border-0">
            <!-- List of available instruction Mode -->
          


            <div class="list-group list-group-checkable d-grid px-2 gap-2 border-0">
              <input class="list-group-item-check search_data pe-none" type="radio" name="availability" id="instruction-mode-in-person" value="in_person" <?php if(isset($_GET['availability']) && $_GET['availability'] == 'in_person'): ?>  <?php echo e('checked'); ?><?php endif; ?>>
              <label class="list-group-item rounded-4 py-2 text-nowrap" for="instruction-mode-in-person">
                <img src="<?php echo e(url('public/theme_assets/images/icons/user-square.svg')); ?>" aria-hidden="true">In Person
              </label>
  
              <input class="list-group-item-check search_data pe-none" type="radio" name="availability" id="instruction-mode-virtual" value="virtual" <?php if(isset($_GET['availability']) && $_GET['availability'] == 'virtual'): ?>  <?php echo e('checked'); ?><?php endif; ?>>
              <label class="list-group-item rounded-4 py-2" for="instruction-mode-virtual">
                <img src="<?php echo e(url('public/theme_assets/images/icons/video-octagon.svg')); ?>" aria-hidden="true">Virtual
              </label>
            </div>

          </div>
        </div>
      </div>
    </div>
  </form>
  <script>
  // Add onchange event listener to language options
  const languageOptions = document.querySelectorAll('.search_data');
  languageOptions.forEach(option => {
    option.addEventListener('change', function() {
      // Submit the form when a language is selected
      document.getElementById('search-tutors-form').submit();
    });
  });
</script><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/layouts/teachme_filters.blade.php ENDPATH**/ ?>