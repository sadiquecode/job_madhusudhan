  <!-- Student profile content -->
  <main id="profile-section" class="py-5 px-2 px-sm-4 mb-5">
    <div class="container rounded-5 p-4 gap-4 gap-md-5 box-shadow-md bg-white d-sm-flex">
      <ul
        class="nav nav-pills flex-sm-column flex-nowrap flex-sm-wrap overflow-x-auto overflow-x-sm-hidden overflow-x-md-visible gap-3 pe-sm-5 pe-md-4 pt-2 pb-2 pb-sm-0 border-end-sm justify-content-start border-bottom border-bottom-sm-0 "
        id="profile-tabs" role="tablist">
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link active" id="edit-tab" data-bs-toggle="tab" data-bs-target="#edit-tab-pane"
            type="button" role="tab" aria-controls="edit-tab-pane" aria-selected="true">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/user-square-light.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Profile</span>
          </button>
        </li>

        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="education-tab" data-bs-toggle="tab" data-bs-target="#education-tab-pane"
            type="button" role="tab" aria-controls="education-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/teacher.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Education</span>
          </button>
        </li>

        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="payments-tab" data-bs-toggle="tab" data-bs-target="#payments-tab-pane"
            type="button" role="tab" aria-controls="payments-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/card.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Payments</span>
          </button>
        </li>
        <?php if(Auth::user()->role != 'admin'): ?>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="settings-tab" data-bs-toggle="tab" data-bs-target="#settings-tab-pane"
            type="button" role="tab" aria-controls="settings-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/video-octagon-light.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Settings</span>
          </button>
        </li>
        <?php endif; ?>
      </ul>
      <!-- Tab Panes -->
    <div class="tab-content mt-2 flex-grow-1" id="profile-tabs-content">
        <?php echo $__env->make('theme_1.userprofile.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Profile Panel -->
        <form name="profile-info-form" class="tab-pane fade show active" id="edit-tab-pane" role="tabpanel"
          aria-labelledby="edit-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">My Profile</h3>

            <?php if(Auth::user()->role != 'admin'): ?>
            <a href="<?php echo e(url('edit-profile/'.encrypt(Auth::user()->id))); ?>?itsmain=yes" class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Edit<i
                class="ms-2 fa-solid fa-pencil text-decoration-underline" style="font-size: 12px;"></i></a>
            <?php endif; ?>

          </div>

          <!-- Profile Info -->
          <div class="card mt-4 p-1">
            <div class="card-body d-flex align-items-center gap-2">
              
              <?php if(empty($profile->profile_pic)): ?>
                <img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="Tutor Avatar" class="img-fluid rounded-circle" width="70" height="70">
                <?php else: ?>
                <img alt="Tutor Avatar" class="img-fluid rounded-circle" width="70" height="70" src="<?php echo e(url(env('img_path'). $profile->profile_pic)); ?>">
                <?php endif; ?>

              <div class="fw-semibold text-uppercase">
                <span class="text-warning" style="font-size:12px;"><?php echo e(ucfirst($profile->role)); ?></span>
                <h4 class="fs-6 fw-semibold mb-0"><?php echo e(ucfirst($profile->name.' '.$profile->lname)); ?></h4>
                <span class="text-primary" style="font-size:12px;">

                  <?php echo e($TeachmeLocationRelationship ? sub_location_name($TeachmeLocationRelationship->sub_location_id)->name ?? 'null' : 'null'); ?>,

                  <?php echo e($TeachmeLocationRelationship ? sub_location_name($TeachmeLocationRelationship->location_id)->name ?? 'null' : 'null'); ?>


                  

                </span>
              </div>
            </div>
          </div>



          <!-- Personal Info -->
          <fieldset name="personal-information" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-4">Personal Information</h3>

              <div class="p-2 mt-2">
                <div class="row gutter">
                  <!-- First Name -->
                  <div class="col-12 col-md-4 col-xl-4">
                    <p class="title">First Name</p>
                    <span class="text-secondary"><?php echo e(ucfirst($profile->name)); ?></span>
                  </div>
                  <!-- Last Name -->
                  <div class="col-12 col-md-4 col-xl-4">
                    <p class="title">Last Name</p>
                    <span class="text-secondary"><?php echo e(ucfirst($profile->lname)); ?></span>
                  </div>
                  <!-- Email -->
                  <div class="col-12 col-md-4 col-xl-4">
                    <p class="title">Email Address</p>
                    <span class="text-secondary"><?php echo e($profile->email); ?></span>
                  </div>

                </div>
              </div>
            </div>
          </fieldset>

          <!-- Bio -->
          <fieldset name="bio" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-2">Bio</h3>

              <p class="py-2 mb-0">
                <?php echo e($profile->description); ?>

              </p>
            </div>
          </fieldset>

        </form>


        <!-- Education Panel -->
        <form name="education-form" class="tab-pane fade" id="education-tab-pane" role="tabpanel"
          aria-labelledby="education-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5 mb-4">Education</h3>

            <?php if(Auth::user()->role != 'admin'): ?>
             <a href="<?php echo e(url('edit-profile/'.encrypt(Auth::user()->id))); ?>?addeducation=true" class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Edit<i
              class="ms-2 fa-solid fa-pencil text-decoration-underline" style="font-size: 12px;"></i></a>
              <?php endif; ?>

            </div>

          <fieldset name="personal-information" class="card mt-4 p-1">
            <div class="card-body">
              <div class="p-2 mt-2">
                <div class="row gutter">
                  <!-- First Name -->
                  <div class="col-12 col-md-4 col-xl-4">
                    <b class="title">School</b><br><br>
                    <?php if(!empty(auth()->user()->student_school)): ?>
                        <span class="text-secondary"><?php echo e(ucfirst(auth()->user()->student_school)); ?></span>
                    <?php else: ?>
                    <?php echo e('Null'); ?>

                    <?php endif; ?>

                  </div>
                  <!-- Last Name -->
                  <div class="col-12 col-md-4 col-xl-4">
                    <b class="title">Curriculum</b><br><br>
                    
                    <?php
                        $filteredCurriculum = ucfirst(filter_data(auth()->user()->student_curriculum, 'curriculum'));
                    ?>

                    <?php if($filteredCurriculum !== "Curriculum"): ?>
                        <span class="text-secondary"><?php echo e($filteredCurriculum); ?></span>
                    <?php else: ?>
                    Null
                    <?php endif; ?>


                  </div>
                  <!-- Email -->
                  <div class="col-12 col-md-4 col-xl-4">
                    <b class="title">Grade</b><br><br>
                    <?php
                        $filteredGrade = ucfirst(filter_data(auth()->user()->student_grade, 'grade'));
                    ?>

                    <?php if($filteredGrade !== "Grade"): ?>
                        <span class="text-secondary"><?php echo e($filteredGrade); ?></span>
                    <?php else: ?>
                    Null
                    <?php endif; ?>


                  </div>

                </div>
              </div>
            </div>
          </fieldset>
        </form>

        <!-- Payments Panel -->
        <form name="payments-form" class="tab-pane fade" id="payments-tab-pane" role="tabpanel"
          aria-labelledby="setting-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Payments</h3>

            <?php if(Auth::user()->role != 'admin'): ?>
            <a href="<?php echo e(url('edit-profile/'.encrypt(Auth::user()->id))); ?>?itspayments=yes" class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Manage<i
                class="ms-2 fa-solid fa-pencil" style="font-size: 12px;"></i></a>
            <?php endif; ?>

          </div>

          <div class="mt-4 row g-3">

            <?php if($TeachmePayment): ?>
              <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Subscription</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-9 d-flex flex-column">
              <span>Plan Type: 100 AED / Year</span>
              <span>Subscription: <?php echo e(ucfirst($TeachmePayment->stripe_status)); ?></span>
            </div>
            <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Billing Date</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-9">
              <span class="d-block">
                <?php if($TeachmePayment->stripe_status == 'active'): ?>
                  Your next billing date is 
                  <?php echo e(\Carbon\Carbon::parse($TeachmePayment->created_at)->addYear()->format('F d, Y')); ?>.
                <?php else: ?>
              Your subscription has been cancelled, but you remain a premium member until your purchased subscription expires on 
                <?php echo e(\Carbon\Carbon::parse($TeachmePayment->ends_at)->format('F d, Y')); ?>.
                <?php endif; ?>
              </span>
            </div>
            <?php else: ?>
            <span>You currently do not have an active plan.</span>
            <?php endif; ?>
            


            <div class="col-12 col-sm-6 col-xl-3">
              <p class="fw-semibold">Payment Method</p>
            </div>

            <?php if(!empty($profile->pm_last_four)): ?>
              <div class="col-12 col-sm-6 col-xl-9">
              <div class="d-flex flex-column flex-sm-row align-items-sm-center gap-2 gap-sm-3">
                <img src="<?php echo e(asset('public/theme_assets/images/credit-card.webp')); ?>" class="rounded" width="70" />
                <div class="d-flex flex-column">
                  <span class="h6 mb-1">Credit Card</span>
                  <span class="small text-muted"><?php echo e('**** **** **** ' . $profile->pm_last_four); ?></span>
                </div>
              </div>
            </div>
            <?php else: ?>
            <div class="col-12 col-sm-6 col-xl-9">
              <div class="d-flex flex-column flex-sm-row align-items-sm-center gap-2 gap-sm-3">
                You currently have no connected payment method.
              </div>
            </div>
            <?php endif; ?>
            
          </div>
        </form>

        <!-- Settings Panel -->
        <form name="settings-form" class="tab-pane fade" id="settings-tab-pane" role="tabpanel"
          aria-labelledby="setting-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Settings</h3>

            <?php if(Auth::user()->role != 'admin'): ?>
            <a href="<?php echo e(url('edit-profile/'.encrypt(Auth::user()->id))); ?>?itsettings=yes" class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Edit<i
                class="ms-2 fa-solid fa-pencil text-decoration-underline" style="font-size: 12px;"></i></a>
            <?php endif; ?>
                
          </div>

          <div class="mt-4 row g-3">
            <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Password</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-9">
              <span>*********</span>
            </div>
          </div>
        </form>
      </div>
    </div>
  </main><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/userprofile/student_profile.blade.php ENDPATH**/ ?>