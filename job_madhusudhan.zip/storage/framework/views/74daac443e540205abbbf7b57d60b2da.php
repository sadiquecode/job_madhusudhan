<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-3">
                    <h4 class="page-title">All Translation (<?php echo e($lang_name); ?>)</h4>
                </div>
                <?php if($lang_code == 'en'): ?>
                    <div class="col-sm-8 col-9 text-right m-b-20">
                    <a href="#" class="btn btn-primary btn-rounded float-right" data-toggle="modal" data-target="#add_translation"><i class="fa fa-plus"></i> Add Translation</a>
                </div>
                <?php endif; ?>
            </div>
        <form method="GET" action="<?php echo e(url('edit_language')); ?>">
            <div class="row filter-row">
                <div class="col-sm-6 col-md-9">
                    <div class="form-group form-focus">
                        <label class="focus-label"><?php echo e(__('trans.Search By key or Value')); ?></label>
                        <input type="text" class="form-control floating" name="search_query">
                        <input type="hidden" class="form-control floating" name="file" value="<?php echo e($lang_name); ?>">
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <button class="btn btn-success btn-block"> Search </button>
                </div>
            </div>
        </form>
                        
<div id="alert-container" class="mt-3" style="display: none;"></div>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <div class="row">
                <?php if(count($paginatedTranslations) > 0): ?>
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped custom-table datatable">
                            <thead>
                                <tr>
                                    <th>S/L</th>
                                    <th>Key (English)</th>
                                    <th>Value</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $count = 1; ?>
                                <?php $__currentLoopData = $paginatedTranslations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $translate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($count); ?></td>
                                    <td><?php echo e($key); ?></td>
                                    <td>
                                    <form method="post" name="f1" id="f1">
                                        <span class="text" style="display: inline;"><?php echo e($translate); ?></span>
                                        <br>

                                        <div class="edit-container" style="display: none;" data-id="<?php echo e($key); ?>">
                                            <input name="lang_key" type="hidden" value="<?php echo e($key); ?>">
                                            <input name="lang_code" type="hidden" value="<?php echo e($lang_code); ?>">
                                            <input name="lang_value" type="text" value="<?php echo e($translate); ?>" id="<?php echo e($key); ?>" class="form-control">

                                            <button type="button" class="btn btn-sm btn-success mt-1 savebutton" style="font-size: 10px !important; padding: 1px !important;">Save</button>
                                            <a href="javascript:void(0)" class="btn btn-sm btn-warning mt-1 cancelbutton" style="font-size: 10px !important; padding: 1px !important;">Cancel</a>
                                        </div>

                                        <button type="button" class="btn btn-sm btn-primary editbutton" style="display: inline-block; font-size: 10px !important; padding: 1px !important;">Edit this content</button>
                                    </form>
                                        </td>
                                    
                                    <td class="text-right">
                                        <div class="dropdown dropdown-action">
                                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_translate_<?php echo e(str_replace(' ', '_', $key)); ?>"><i class="far fa-trash-alt m-r-5"></i> Delete</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                               

                               <div id="delete_translate_<?php echo e(str_replace(' ', '_', $key)); ?>" class="modal custom-modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content modal-md">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Delete Client</h4>
                                            </div>
                                            <form action="<?php echo e(url('destroy'.'/'.$lang_code.'/'.$key)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-body card-box">
                                                    <p>Are you sure want to delete this?</p>
                                                    <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>


                            <?php $count++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>




<nav aria-label="Page navigation">
    <ul class="pagination justify-content-center">
        <?php if(ceil($totalTranslations / $itemsPerPage) > 1): ?>
            <!-- Previous Page Link -->
            <?php if($currentPage > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e(route('edit_language.index', ['page' => $currentPage - 1])); ?>&file=<?php echo e($lang_name); ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
            <?php endif; ?>

            <!-- Pagination Links -->
            <?php for($i = 1; $i <= ceil($totalTranslations / $itemsPerPage); $i++): ?>
                <li class="page-item" <?php if($i === $currentPage): ?> style="background-color: red!important;" <?php endif; ?>>
                    <a class="page-link" href="<?php echo e(route('edit_language.index', ['page' => $i])); ?>&file=<?php echo e($lang_name); ?>"><?php echo e($i); ?></a>
                </li>
            <?php endfor; ?>

            <!-- Next Page Link -->
            <?php if($currentPage < ceil($totalTranslations / $itemsPerPage)): ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e(route('edit_language.index', ['page' => $currentPage + 1])); ?>&file=<?php echo e($lang_name); ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            <?php endif; ?>
        <?php endif; ?>
    </ul>
</nav>








            </div>
            <?php else: ?>
            <p class="p-4"><?php echo e('Translation Not Found!'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>







<div id="add_translation" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="modal-content modal-lg">
            <div class="modal-header">
                <h4 class="modal-title">Add Translate</h4>
            </div>
            <div class="modal-body">
                <form class="m-b-30" action="<?php echo e(route('edit_language.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Language <span class="text-danger">*</span></label>
                                <input type="text" name="lang_name" class="form-control" value="<?php echo e($language->name); ?>" readonly>
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Name <span class="text-danger">*</span></label>
                                <input type="text" name="lang_code" class="form-control" value="<?php echo e($language->code); ?>" readonly>
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Key <span class="text-danger">*</span></label>
                                <input type="text" name="key" class="form-control" required>
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Value <span class="text-danger">*</span></label>
                                <textarea class="form-control" rows="5" name="text"></textarea>
                            </div>
                        </div>


                    </div>
                    <div class="m-t-20 text-center mb-5">
                        <button type="submit" class="btn btn-primary btn-lg">Create Translate</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/translation/translation.blade.php ENDPATH**/ ?>