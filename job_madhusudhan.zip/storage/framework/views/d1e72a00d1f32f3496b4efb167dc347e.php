<div class="left message">
  <img src="https://assets.edlin.app/images/rossedlin/03/rossedlin-03-100.jpg" alt="Avatar">
  <p><?php echo e($message); ?></p>
</div>
<?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/c/receive.blade.php ENDPATH**/ ?>