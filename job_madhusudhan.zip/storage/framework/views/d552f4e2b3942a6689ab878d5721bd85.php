<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<section class="search_heading">
<?php echo $__env->make('theme_1.layouts.page_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $code = session('locale'); ?>


<style type="text/css">
    #chat-messages {

}
</style>
<div class="container">
<div class="row">
<div class="col-12">
<div class="chat-area">
    <!-- chatlist -->
    <div class="chatlist">
        <div class="modal-dialog-scrollable">
            <div class="modal-content">
                <div class="chat-header">
                    <div class="msg-search">
                        <input type="text" class="form-control <?php echo e(session('ar_class')); ?>" id="chat_user"
                        placeholder="<?php echo e(__('trans.Conversation details')); ?>" aria-label="search">
                    </div>
                    <div class="chatsearchbtn">
                        <button class="border-0 shadow-none" type="submit" title="Search"><i
                        class="fa-solid fa-magnifying-glass btn"></i></button>
                    </div>
                </div>
                <div class="chat-lists">
                    <div class="modal-body">
                        <!-- chat-list -->
                        <div class="chat-list" id="user-list">
                            <?php $__currentLoopData = $latestMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php  $active_user = ''; ?>
                            <?php if($user->from_user == $userid): ?>
                          <?php  $active_user = 'chat_user'; ?>
                            <?php endif; ?>
                            <a href="<?php echo e(url('chat/'.Crypt::encrypt($user->from_user))); ?>" class="d-flex <?php echo e($active_user); ?> p-2">
                                <div class="flex-shrink-0 cimg">
                                    <?php if(empty($user->profile_pic)): ?>
                                    <img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="user" class="img-fluid rounded-pill"  width="45" height="45">
                                    <?php else: ?>
                                    <img src="<?php echo e(url(env('img_path'). $user->profile_pic)); ?>" alt="user" class="img-fluid rounded-pill" width="45" height="45">
                                    <?php endif; ?>
                                    
                                </div>
                            <div class="flex-grow-1 ms-3 nameuserchat">
                                <h3><?php echo e($user->from_user_name); ?></h3>
                                <p><?php echo e(Str::limit($user->content, 10)); ?></p>
                            </div>
                                <div class="flex-grow-2 timehours">
                                    <p class="text-lowercase"><?php echo e(get_data_format($user->created_at)); ?></p>
                                </div>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- chat-list -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- chatbox -->
    <div class="chatbox showbox">
        <div class="modal-dialog-scrollable">
            <div class="modal-content">
                <div class="msg-head bg-white">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <div class="d-flex align-items-center">
                                <span class="chat-icon">
                                    
                                <?php if(empty(get_user($user_details->id)->profile_pic)): ?>
                                    <img class="img-fluid" src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="image title">
                                    <?php else: ?>
                                    <img class="img-fluid" src="<?php echo e(url(env('img_path'). get_user($user_details->id)->profile_pic)); ?>" alt="image title">
                                <?php endif; ?>

                                </span>
                                <div class="">
                                    <h5 class="mb-0"><?php echo e($user_details->name); ?></h5>
                                </div>
                                <div class="ms-5 mb-0 online">
                                    <span class="activedot"></span>
                                    <p class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Online')); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="msghead_smalscreen bg-white py-2">
                    <div class="row align-items-center">
                        <div class="col-7">
                            <div class="d-flex align-items-center justify-content-between">
                                <span class="chat-icon d-flex">
                                    <img class="img-fluid" src="<?php echo e(url('public/theme_assets/images/icons/leftarrow - Copy.png')); ?>" alt="image title">
                                    <a href="#">
                                        <h5 class="mb-0 ms-2 <?php echo e(session('ar_class')); ?>">
                                        <?php echo e(__('trans.All Chats')); ?>

                                    </h5>
                                    </a>
                                </span>
                                <div class="mb-0 online">
                                    <h5><?php echo e($user_details->name); ?></h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-5 text-end">
                            <div class="moreoption">
                                <div class="mb-0 online d-flex align-items-center">
                                    <span class="activedotsmall"></span>
                                    <h5 class="mb-0 me-1 <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Online')); ?></h5>

                                    <?php if(empty(get_user($user_details->id)->profile_pic)): ?>
                                    <a href="#" class="">
                                    <img class="img-fluid rounded-pill"
                                        src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="user img" width="45"
                                        height="40">
                                    </a>
                                    <?php else: ?>
                                    <a href="#" class="">
                                    <img class="img-fluid rounded-pill"
                                        src="<?php echo e(url(env('img_path'). get_user($user_details->id)->profile_pic)); ?>" alt="user img" width="45"
                                        height="40">
                                    </a>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-body">
                    <div class="msg-body">
                        <ul class="p-0 chat" id="chat-messages">
                            

                            





                        </ul>
                    </div>
                </div>
                <div class="send-box <?php echo e($chat_room); ?>">
                    <form id="chat-form">
                        <?php echo csrf_field(); ?>
                        <div class="sendbtn">
                            <button class="btn shadow-none" type="submit" id="chat_btn"><img src="<?php echo e(url('public/theme_assets/images/icons/send.png')); ?>" alt="send" width="16" height="14">
                            </button>
                        </div>
                        <input type="text" class="form-control" aria-label="message…" placeholder="Send your message" name="content">
                        <input type="hidden" name="from_user" value="<?php echo e($fromUser); ?>">
                        <input type="hidden" name="to_user" value="<?php echo e($userid); ?>">
                        <input type="hidden" name="post_id" value="<?php echo e($post_id); ?>">
                        <div class="plusbtn">
                        
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="userprofile <?php echo e(session('ar_class')); ?>">
        <div class="modal-dialog-scrollable">
            <div class="modal-content">
                <span class="profile-icon"><img class="img-fluid"
                src="<?php echo e(url('public/theme_assets/images/icons/leftarrow - Copy.png')); ?>" alt="image title"></span>
                <div class="profile-head text-center bg-white">

        <?php if(empty(get_user($user_details->id)->profile_pic)): ?>
            <img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="user" class="img-fluid rounded-pill"  width="45" height="45">
            <?php else: ?>
            <img src="<?php echo e(url(env('img_path'). get_user($user_details->id)->profile_pic)); ?>" alt="user" class="img-fluid rounded-pill" width="45" height="45">
        <?php endif; ?>


                <h5><?php echo e($user_details->name.' '.$user_details->lname); ?></h5>
                </div>
                <div class="profile_drop pt-5">
                    <ul class="navbar-nav">
                        <li class="list-unstyled nav-item dropdown custom_dropdown">
                            <a href="#" class="nav-link dropdown-toggle p-0" data-bs-toggle="dropdown"
                                id="navbarDropdownMenu" role="button">
                                <?php echo e(__('trans.About')); ?>

                            </a>
                            <ul class="dropdown-menu drop_menu rounded-0 col-12"
                                aria-labelledby="navbarDropdownMenu">
                                <li><a class="dropdown-item" href="<?php echo e(url('profile/'.Crypt::encrypt($user_details->id))); ?>">Profile</a></li>
                                
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="userdetail">
                    <h6 class="pt-3 <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.fname')); ?></h6>
                    <p><?php echo e($user_details->name); ?> </p>
                </div>
                <div class="userdetail">
                    <h6 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.lname')); ?></h6>
                    <p><?php echo e($user_details->lname); ?></p>
                </div>
                <div class="userdetail">
                    <h6 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.email address')); ?></h6>
                    <p><?php echo e($user_details->email); ?></p>
                </div>
                <div class="userdetail">
                    <h6 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Number')); ?></h6>
                    <p><?php echo e($user_details->phone); ?></p>
                </div>
                <div class="userdetail pt-5">
                    <h6 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Lifecycle stage')); ?></h6>
                    <p><?php echo e($user_details->type); ?></p>
                </div>
                <div class="profile_drop w-100">
                    <ul class="navbar-nav">
                        <li class="list-unstyled nav-item dropdown custom_dropdown">
                            <a href="#" class="nav-link dropdown-toggle p-0" data-bs-toggle="dropdown"
                                id="navbarDropdownMenu" role="button">
                                <?php echo e(__('trans.Conversation details')); ?>

                            </a>
                            <ul class="dropdown-menu drop_menu rounded-0 col-12"
                                aria-labelledby="navbarDropdownMenu">
                                <li class="userdetail">
                                    <h6 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Created date')); ?></h6>
                                    <p><?php echo e(date('M d, Y h:i:a',strtotime($user_details->created_at))); ?></p>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
</section>
<?php echo $__env->make('theme_1.layouts.contact_us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
<script>
$(document).ready(function () {


  

// var userListItems = $("#user-list a");

// $("#chat_user").on("keyup", function () {
//     var value = $(this).val().toLowerCase();
//     console.log("Input Value:", value);

//     userListItems.each(function () {
//         var userName = $(this).find('.nameuserchat h3').text().toLowerCase();
//         console.log("User Name:", userName);
//         var userListItems_ = $("#user-list a .cimg, .nameuserchat, .timehours");
//         if(userName == value){
//             userListItems_.show();
//         }else{
//             userListItems_.hide();
//         }
//         // userName.toggle(userName.indexOf(value) > -1);
//     });
// });



    const getChatMessagesUrl = `<?php echo e(route('getLoadLatestMessages.user_id', ['user_id' => $user_details->id])); ?>`;

    const chatMessagesContainer = $('#chat-messages');

    // Initialize Pusher
    const pusher = new Pusher('<?php echo e(config('broadcasting.connections.pusher.key')); ?>', {
    cluster: '<?php echo e(config('broadcasting.connections.pusher.options.cluster')); ?>',
    });




    // Subscribe to the Pusher channel for real-time updates
    const channel = pusher.subscribe('jeddah_mazad_chat');
    channel.bind('jeddah_mazad_message', function (data) {
        displayChatMessages();
    });



  //Receive messages
//     function displayChatMessages_() {
//     $.ajax({
//         url: getChatMessagesUrl,
//         type: 'GET',
//         success: function (data) {
//             chatMessagesContainer.html('');

//             var chat_not_found = `<li class="sender d-flex justify-content-between"><div class="flex-column">
//                     <p> <?php echo e(__('trans.Chat not found')); ?></p></div></li>`;

//             if (data.length > 0) {
//             data.forEach(function (message) {
//                 let messageHtml;
//                 const messageClass = (message.from_user == <?php echo e(Auth::user()->id); ?>) ? 'sender' : 'repaly';
//                 if (messageClass == 'sender') {
//                     messageHtml = `
//                     <li class="sender d-flex justify-content-between">
//                     <img class="rounded-pill me-2 align-self-start" src="<?php echo e($p2); ?>" alt="user img" width="38" height="38">
//                         <div class="flex-column">
//                             <p>${message.content}</p>
//                             <span class="time">${formatChatTime(message.created_at)}</span>
//                         </div>
//                     </li>
//                 `;
//                 } else {
//                     messageHtml = `
//                     <li class="repaly d-flex justify-content-between">
//                     <div class="flex-column">
//                         <p>${message.content}</p>
//                         <span class="time text-end">${formatChatTime(message.created_at)}</span>
//                     </div>
//                     <img class="rounded-pill ms-2 align-self-end" src="<?php echo e($p1); ?>" alt="user img" width="38" height="38">
//                 </li>`;
//                 }

//                 chatMessagesContainer.append(messageHtml);
//             });
//             }else{
//                 chatMessagesContainer.append(chat_not_found);
//             }
            
//         },
//         error: function (error) {
//             console.log(error);
//         }
//     });
// }




function displayChatMessages() {
    

    $.ajax({
        url: getChatMessagesUrl,
        type: 'GET',
        success: function (response) {
            // Assuming response has a property 'combined_data'
            const combinedData = response.combined_data;

            // Clear the container before appending new data
            chatMessagesContainer.html('');

            // Iterate through combined_data
            combinedData.forEach(chatData => {
    // Append post data
    if (Object.keys(chatData.post_data).length > 0) {
        const postHtml = `
            <li class="repaly d-flex justify-content-between">
                <div class="card text-center" style="max-width: 120px;">
                    <a href="${chatData.post_data.link}">
                        <img class="card-img-top img-fluid" src="${chatData.post_data.post_img}" alt="Card image cap">
                        <div class="card-body p-0" style="background-color: #E8E9ED;">
                            <h5 class="card-title text-dark" style="padding-top: 5px; font-size: 14px; margin: 0;">${chatData.post_data.title}</h5>
                            <p class="">${chatData.post_data.details}</p>
                        </div>
                    </a>
                </div>
            </li>
            <li>
                <div class="divider">
                    <i class="fa-solid fa-turn-down text-secondary"></i>
                </div>
            </li>
        `;
        chatMessagesContainer.append(postHtml);
    }

    // Append messages
    chatData.messages.forEach(message => {
        const messageClass = (message.from_user == <?php echo e(Auth::user()->id); ?>) ? 'sender' : 'repaly';
        let messageHtml;

        if (messageClass === 'sender') {
            messageHtml = `
                <li class="sender d-flex justify-content-between">
                    <img class="rounded-pill me-2 align-self-start" src="<?php echo e($p2); ?>" alt="user img" width="38" height="38">
                    <div class="flex-column">
                        <p>${message.content}</p>
                        <span class="time">${formatChatTime(message.created_at)}</span>
                    </div>
                </li>
            `;
        } else {
            // Check if it's a new chat and add a button accordingly
            const isLastMessage = index === combinedData.length - 1 && messageIndex === chatData.messages.length - 1;
            
            if (isLastMessage) {
                const chatId = getChatIdFromUrl();

                messageHtml = `
                    <li class="repaly d-flex justify-content-between">
                        <div class="flex-column">
                            <p>Old Chat Closed From Other User! Click and Start new chat</p>
                            <a href="${chatData.chat_url}/${chatId}?post=${chatData.post_id}" class="btn-sm btn btn-danger">New Chat</a>
                        </div>
                    </li>`;
            } else {
                messageHtml = `
                    <li class="repaly d-flex justify-content-between">
                        <div class="flex-column">
                            <p>${message.content}</p>
                            <span class="time text-end">${formatChatTime(message.created_at)}</span>
                        </div>
                        <img class="rounded-pill ms-2 align-self-end" src="<?php echo e($p1); ?>" alt="user img" width="38" height="38">
                    </li>`;
            }
        }

        chatMessagesContainer.append(messageHtml);
    });
});


        },
        error: function (error) {
            console.log(error);
        }
    });
}

function startNewChat(chatUrl, postId) {
    alert('ok');
    // You can implement logic to handle starting a new chat
    // For example, redirect the user to the new chat URL
    window.location.href = `${chatUrl}/${postId}`;
}

function getChatIdFromUrl() {
    const url = window.location.href;
    const chatIdStartIndex = url.indexOf('chat/') + 5; // Length of 'chat/'
    const chatIdEndIndex = url.indexOf('?post=');
    const chatId = url.substring(chatIdStartIndex, chatIdEndIndex);
    return chatId;
}

// Function to format time as needed
function formatChatTime(timestamp) {
    // Implement your time formatting logic here
    // Example: return moment(timestamp).format('h:mm a');
    return timestamp; // Placeholder, replace with actual formatting
}


    // Handle the chat form submission
    $('#chat-form').submit(function (e) {
        e.preventDefault();
        const content = $('input[name="content"]').val();
        const from_user = <?php echo e(auth()->user()->id); ?>;
        const to_user = <?php echo e($userid); ?>;
        const post_id = <?php echo e($post_id); ?>;

        if (content.trim() !== '') {
            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('sendMessage')); ?>",
                data: {
                    content: content,
                    from_user: from_user,
                    to_user: to_user,
                    post_id: post_id,
                    _token: '<?php echo e(csrf_token()); ?>',
                },
                success: function (data) {
                    $('input[name="content"]').val('');
                    displayChatMessages();
                    scrollToLastMessage();
                },
                error: function (xhr, status, error) {
                    // Handle the error if the message sending fails
                },
            });
        }
    });




    // // Load and display initial messages
    displayChatMessages();
    




    function formatChatTime(timestamp) {
    const now = new Date();
    const messageTime = new Date(timestamp);
    
    // Calculate the time difference in milliseconds
    const timeDifference = now - messageTime;
    
    // Calculate the time difference in minutes and hours
    const minutesDifference = Math.floor(timeDifference / 60000); // 1 minute = 60,000 milliseconds
    const hoursDifference = Math.floor(timeDifference / 3600000); // 1 hour = 3,600,000 milliseconds
    
    // Display the time based on the time difference
    if (minutesDifference < 1) {
        return 'just now';
    } else if (minutesDifference < 60) {
        return `${minutesDifference} m`;
    } else if (hoursDifference < 24) { // 24 hours in a day
        return `${hoursDifference} hr`;
    } else if (hoursDifference < 168) { // 168 hours in a week (7 days)
        const days = Math.floor(hoursDifference / 24);
        return `${days} days`;
    } else {
        return messageTime.toLocaleString('en-US', { month: 'short', day: 'numeric' });
    }
}




// Function to scroll to the last message
function scrollToLastMessage() {
    // alert('ok');
  const chatMessagesContainer = document.getElementById('chat-messages');
  const lastMessage = chatMessagesContainer.lastElementChild;

  console.log(lastMessage);
  if (lastMessage) {
    lastMessage.scrollIntoView();
  }
}


scrollToLastMessage();



});
</script>
<?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/theme_1/c_home.blade.php ENDPATH**/ ?>