<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper bg-white">
        <div class="content container-fluid">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <form action="<?php echo e(route('set_api_configuration')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <h4 class="page-title">Open AI Secret Key</h4>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Secret Key <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="secret_key" class="form-control" value="<?php echo e($SecretKey->secret_key); ?>" placeholder="Secret Key" type="text">
                            </div>
                        </div>

                        <h4 class="page-title mt-5">AI Settings</h4>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Quality type <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <select class="form-control select" name="quality_type_id">
                                <?php $__currentLoopData = $AIQuality; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($AISettings->quality_type_id == $quality->id): ?>
                                    <option value="<?php echo e($quality->id); ?>" selected><?php echo e($quality->quality); ?></option>
                                    <?php else: ?>
                                    <option value="<?php echo e($quality->id); ?>"><?php echo e($quality->quality); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Tone of Voice <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <select class="form-control select" name="tone_of_voice_id">
                                <?php $__currentLoopData = $AiTone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($AISettings->tone_of_voice_id == $tone->id): ?>
                                    <option value="<?php echo e($tone->id); ?>" selected><?php echo e($tone->tone); ?></option>
                                    <?php else: ?>
                                    <option value="<?php echo e($tone->id); ?>"><?php echo e($tone->tone); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Number of Results <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <select class="form-control select" name="number_of_results">
                                    <?php $number_arr = array(1,2,3,4,5); ?>
                                    <?php $__currentLoopData = $number_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($val == $AISettings->number_of_results): ?>
                                        <option value="<?php echo e($val); ?>" selected><?php echo e($val); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($val); ?>"><?php echo e($val); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Max Results Length <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="max_results_length" class="form-control" value="<?php echo e($AISettings->max_results_length); ?>" type="number">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Bad Words <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input class="form-control" name="words" value="<?php echo e($AiBadWord->words); ?>" />
                            </div>
                        </div>

                        <h4 class="page-title mt-5">Feature Activation</h4>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">AI Chat <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <select class="form-control select" name="ai_chat">
                                <option value="enable" <?php if($AiFeature->ai_chat == 'enable'): ?> selected <?php endif; ?>>Enable</option>
                                <option value="disable" <?php if($AiFeature->ai_chat == 'disable'): ?> selected <?php endif; ?>>Disable</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Built In Templates <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <select class="form-control select" name="built_in_templates">
                                <option value="enable" <?php if($AiFeature->built_in_templates == 'enable'): ?> selected <?php endif; ?>>Enable</option>
                                <option value="disable" <?php if($AiFeature->built_in_templates == 'disable'): ?> selected <?php endif; ?>>Disable</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Custom Templates <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <select class="form-control select" name="custom_templates">
                                <option value="enable" <?php if($AiFeature->custom_templates == 'enable'): ?> selected <?php endif; ?>>Enable</option>
                                <option value="disable" <?php if($AiFeature->custom_templates == 'disable'): ?> selected <?php endif; ?>>Disable</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Speech to Text <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <select class="form-control select" name="speech_to_text">
                                <option value="enable" <?php if($AiFeature->speech_to_text == 'enable'): ?> selected <?php endif; ?>>Enable</option>
                                <option value="disable" <?php if($AiFeature->speech_to_text == 'disable'): ?> selected <?php endif; ?>>Disable</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">Generate Images <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <select class="form-control select" name="generate_images">
                                <option value="enable" <?php if($AiFeature->generate_images == 'enable'): ?> selected <?php endif; ?>>Enable</option>
                                <option value="disable" <?php if($AiFeature->generate_images == 'disable'): ?> selected <?php endif; ?>>Disable</option>
                                </select>
                            </div>
                        </div>
                        
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label">Generate Code <span class="text-danger">*</span></label>
                        <div class="col-lg-9">
                        <select class="form-control select" name="generate_code">
                            <option value="enable" <?php if($AiFeature->generate_code == 'enable'): ?> selected <?php endif; ?>>Enable</option>
                            <option value="disable" <?php if($AiFeature->generate_code == 'disable'): ?> selected <?php endif; ?>>Disable</option>
                        </select>
                        </div>
                    </div>

                    <h4 class="page-title mt-5">Open AI Model</h4>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label">Default AI Model <span class="text-danger">*</span></label>
                        <div class="col-lg-9">
                            <select class="form-control select" name="default_module">
                                <?php $__currentLoopData = $AiModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($SecretKey->default_module == $model->id): ?>
                                    <option value="<?php echo e($model->id); ?>" selected><?php echo e($model->model); ?></option>
                                    <?php else: ?>
                                    <option value="<?php echo e($model->id); ?>"><?php echo e($model->model); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label">AI Chat Model <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <select class="form-control select" name="ai_chat_module">
                                <?php $__currentLoopData = $AiModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($SecretKey->ai_chat_module == $model->id): ?>
                                    <option value="<?php echo e($model->id); ?>" selected><?php echo e($model->model); ?></option>
                                    <?php else: ?>
                                    <option value="<?php echo e($model->id); ?>"><?php echo e($model->model); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="m-t-20 text-center">
                            <button class="btn btn-primary btn-lg">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/api/api_configuration.blade.php ENDPATH**/ ?>