<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- ==============================Auction Card Start==============================-->
    <section class="auction_cardtrack py-5">
        <div class="container">
            <div class="justify-content-between align-items-center d-flex">
                <div class="heading flex-column d-flex">
                    <h4 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Ongoing Auctions')); ?></h4>
                </div>
                <div class="me-md-5 all_auction d-none d-lg-block">
                    <a href="<?php echo e(url('search')); ?>" class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.View all')); ?></a>
                </div>
            </div>
        </div>
        <div class="container px-0 mx-auto">
            <div class="auctionslide__cards d-flex overflow-hidden">

                <?php $__currentLoopData = $post_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="px-2 py-5">
                <div class="card auction_card maincards border-0 px-0">
                    <div class="text-center active_btn position-relative">
                        <a href="#" class="d-block position-absolute text-capitalize"><?php echo e($key->status); ?></a>
                        <img src="<?php echo e(url(env('img_path').post_img($key->id)->img )); ?>"
                            class="card-img-top img-fluid" alt="...">
                    </div>
                    <div class="card-body px-0 heading">
                        <a href="<?php echo e(url('tags/'.$key->slug)); ?>">
                            <h4 class="card-title mb-4"><?php echo e($key->product_name); ?></h4>
                        </a>
                        <p class="card_text d-flex"><small><?php echo e(\Carbon\Carbon::parse($key->created_at)->format('d F H:i')); ?></small>
                        </p>
                        <p class=" card_text d-flex mb-5"><small>(GMT+3) KSA</small></p>
                        <div class="d-flex align-items-center justify-content-center">
                                <a href="<?php echo e(url('tags/'.$key->slug)); ?>" class="card_bidbtn <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Bid')); ?></a>
                                
                            </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

            </div>
            <div class="me-md-5 all_auction d-block d-lg-none text-center">
                <a href="<?php echo e(url('search')); ?>" class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.View all')); ?></a>
            </div>
        </div>
    </section>
    <!-- ==============================Upcoming Auction Card End ==============================-->
    <!-- ==============================Upcoming Auction Card Start ==============================-->
    <section class="auction_cardtrack">
        <div class="container">
            <div class="justify-content-between align-items-center d-flex">
                <div class="heading flex-column d-flex">
                    <h4 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.selling product')); ?></h4>
                </div>
                <div class="me-md-5 all_auction d-none d-lg-block">
                    <a href="<?php echo e(url('search')); ?>" class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.View all')); ?></a>
                </div>
            </div>
        </div>
        <div class="container px-0 pb-5 m-auto">
            <div class="auctionslide__cards d-flex overflow-hidden ">
                
                <?php $__currentLoopData = $sele_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="px-2 py-5">
                <div class="card auction_card border-0 px-0">
                    <div class="text-center active_btn position-relative">
                        <a href="#" class="d-block position-absolute text-capitalize"><?php echo e($key->status); ?></a>
                        <img src="<?php echo e(url(env('img_path').post_img($key->id)->img )); ?>"
                            class="card-img-top img-fluid" alt="...">
                    </div>
                    <div class="card-body px-0 heading">
                        <a href="<?php echo e(url('tags/'.$key->slug)); ?>">
                            <h4 class="card-title mb-4"><?php echo e($key->product_name); ?></h4>
                        </a>
                        <p class="card_text d-flex"><small><?php echo e(\Carbon\Carbon::parse($key->created_at)->format('d F H:i')); ?></small>
                        </p>
                        <p class=" card_text d-flex mb-5"><small>(GMT+3) KSA</small></p>
                        <div class="d-flex align-items-center justify-content-center">
                                <a href="<?php echo e(url('chat/'.$key->user_id)); ?>" class="card_bidbtn <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Contract')); ?></a>
                                
                            </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="me-md-5 all_auction d-block d-lg-none text-center">
                <a href="<?php echo e(url('search')); ?>" class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.View all')); ?></a>
            </div>
        </div>
        <!-- ////////// -->
        <div class="container-fluid px-sm-5">
            <div class="justify-content-between align-items-center d-flex">
                <div class="notification_icon justify-content-center flex-column d-flex">
                    <!-- Default dropup button -->
<style>
    .dropupnotif  {
  position: fixed;
    bottom: 10px;
    left: 5px;
  z-index: 1;
}
    .dropupinbox  {
  position: fixed;
    bottom: 10px;
    right:  20px;   
  z-index: 1;
}
</style>
                    <div class="dropup dropupnotif d-none">
                        <a href="#"
                            class="dropdown-toggle notification_toggle d-flex align-items-center justify-content-center  rounded-circle"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="<?php echo e(url('public/theme_assets/images/icons/notification.png')); ?>" alt="notification" width="36" height="49">
                            <span class="badge bg-danger badge-number rounded-circle">4</span>
                        </a>
                        <ul class="dropdown-menu notifications border-0 px-2">
                            <li class="dropdown-header text-center">
                                <img src="<?php echo e(url('public/theme_assets/images/icons/notification.png')); ?>" alt="notification" width="26"
                                    height="35">
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li class="notification-item">
                                <div class="justify-content-between align-items-center d-flex">
                                    <div class="d-flex align-items-start">
                                        <div class="flex-column d-flex">
                                            <p class="mb-0"><small>Ahmad Kabbani liked your post</small></p>
                                        </div>
                                    </div>
                                    <div class="view_btn me-2">
                                        <a href="#"><small>View</small></a>
                                    </div>
                                </div>
                            </li>

                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li class="notification-item">
                                <div class="justify-content-between align-items-center d-flex">
                                    <div class="d-flex align-items-start">
                                        <div class="flex-column d-flex">
                                            <p class="mb-0"><small>Ahmad Kabbani liked your post</small></p>
                                        </div>
                                    </div>
                                    <div class="view_btn me-2">
                                        <a href="#"><small>View</small></a>
                                    </div>
                                </div>
                            </li>

                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li class="notification-item">
                                <div class="justify-content-between viewed align-items-center d-flex">
                                    <div class="d-flex align-items-start">
                                        <div class="flex-column d-flex">
                                            <p class="mb-0"><small>Tammam Hamdan commented on your post</small></p>
                                        </div>
                                    </div>
                                    <div class="viewed_btn">
                                        <a href="#"><small>Viewed</small></a>
                                    </div>
                                </div>
                            </li>

                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li class="notification-item">
                                <div class="justify-content-between viewed align-items-center d-flex">
                                    <div class="d-flex align-items-start">
                                        <div class="flex-column d-flex">
                                            <p class="mb-0"><small>Tammam Hamdan commented on your post</small></p>
                                        </div>
                                    </div>
                                    <div class="viewed_btn">
                                        <a href="#"><small>Viewed</small></a>
                                    </div>
                                </div>
                            </li>

                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li class="notification-item">
                                <div class="justify-content-between viewed align-items-center d-flex">
                                    <div class="d-flex align-items-start">
                                        <div class="flex-column d-flex">
                                            <p class="mb-0"><small>Tammam Hamdan commented on your post</small></p>
                                        </div>
                                    </div>
                                    <div class="viewed_btn">
                                        <a href="#"><small>Viewed</small></a>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="notification_icon d-none">
                    <div class="dropup dropupinbox">
                        <a href="#"
                            class="dropdown-toggle notification_toggle d-flex align-items-center justify-content-center  rounded-circle"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="<?php echo e(url('public/theme_assets/images/icons/inbox.png')); ?>" alt="inbox" width="50" height="47">
                            <span class="badge bg-danger badge-number rounded-circle">4</span>
                        </a>
                        <ul class="dropdown-menu notifications border-0 px-2">
                            <li class="dropdown-header text-center">
                                <img src="<?php echo e(url('public/theme_assets/images/icons/notification.png')); ?>" alt="notification" width="26"
                                    height="35">
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li class="notification-item">
                                <div class="justify-content-between align-items-center d-flex">
                                    <div class="d-flex align-items-start">
                                        <div class="flex-column d-flex">
                                            <p class="mb-0"><small>Ahmad Kabbani sent you a message</small></p>
                                        </div>
                                    </div>
                                    <div class="view_btn me-2">
                                        <a href="#"><small>View</small></a>
                                    </div>
                                </div>
                            </li>

                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li class="notification-item">
                                <div class="justify-content-between align-items-center d-flex">
                                    <div class="d-flex align-items-start">
                                        <div class="flex-column d-flex">
                                            <p class="mb-0"><small>Tammam Hamdan sent you a message</small></p>
                                        </div>
                                    </div>
                                    <div class="view_btn me-2">
                                        <a href="#"><small>View</small></a>
                                    </div>
                                </div>
                            </li>

                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li class="notification-item">
                                <div class="justify-content-between viewed align-items-center d-flex">
                                    <div class="d-flex align-items-start">
                                        <div class="flex-column d-flex">
                                            <p class="mb-0"><small>Tammam Hamdan sent you a message</small></p>
                                        </div>
                                    </div>
                                    <div class="viewed_btn">
                                        <a href="#"><small>Viewed</small></a>
                                    </div>
                                </div>
                            </li>

                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li class="notification-item">
                                <div class="justify-content-between viewed align-items-center d-flex">
                                    <div class="d-flex align-items-start">
                                        <div class="flex-column d-flex">
                                            <p class="mb-0"><small>Ahmad Kabbani sent you a message</small></p>
                                        </div>
                                    </div>
                                    <div class="viewed_btn">
                                        <a href="#"><small>Viewed</small></a>
                                    </div>
                                </div>
                            </li>

                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li class="notification-item">
                                <div class="justify-content-between viewed align-items-center d-flex">
                                    <div class="d-flex align-items-start">
                                        <div class="flex-column d-flex">
                                            <p class="mb-0"><small>Ahmad Kabbani sent you a message</small></p>
                                        </div>
                                    </div>
                                    <div class="viewed_btn">
                                        <a href="#"><small>Viewed</small></a>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- ////////// -->
    </section>
    <!-- ==============================Upcoming Auction End==============================-->
    <!-- ==============================Luxury Brand Start==============================-->
    <section class="Brand_wrapper">
        <div class="container">
            <div class="heading pt-5">
                <h4><span>Our Luxury</span> Brands</h4>
            </div>
            <div class="row mt-5 gy-3">
                <div class="col-md-2 col-12">
                    <div class="custom_control">
                        <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $title = ($code == 'en') ? $key->gender_en : $key->gender_ar;
                        ?>
                            <div class="custom_checks p-1 rounded d-inline-flex w-100 mb-2">
                                <input type="checkbox" class="form-check-input shadow-none" id="gen_<?php echo e($key->id); ?>">
                                <label class="form-check-label w-100 <?php echo e(session('ar_class')); ?>" for="gen_<?php echo e($key->id); ?>"><?php echo e($title); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
                <div class="col-md-2 col-12">
                    <div class="custom_control">

                        <?php $__currentLoopData = $manu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $title = ($code == 'en') ? $key->category_title_en : $key->category_title_ar;
                        ?>
                        <div class="custom_checks p-1 rounded d-inline-flex w-100 mb-2">
                                <input type="checkbox" class="form-check-input shadow-none" id="cat_<?php echo e($key->id); ?>">
                                <label class="form-check-label w-100 <?php echo e(session('ar_class')); ?>" for="cat_<?php echo e($key->id); ?>"><?php echo e($title); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <div class="col-md-8 col-12">
                    <div class="row">
                        <div class="col-10 mx-auto">
                            <div class="slideimgs slidertlimgs">
                        <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="slide_item">
                            <img src="<?php echo e(url(env('img_path').$key->brand_logo)); ?>" class="img-fluid m-auto" alt="montblance">
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- =============================Luxury Brand End==============================-->

<?php echo $__env->make('theme_1.layouts.contact_us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/theme_1/home.blade.php ENDPATH**/ ?>