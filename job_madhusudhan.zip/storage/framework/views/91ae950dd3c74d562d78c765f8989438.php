<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <style type="text/css">
        .nav-pills > .nav-link{
            padding: 0.5rem 2rem;
        }
    </style>

    <section class="addpost_heading">
        <?php echo $__env->make('theme_1.layouts.page_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            
        <div class="profil_wrapper  d-flex align-items-start px-3">
            <div class="container-fluid px-0">
                <div class="row">
                    <div class="col-sm-12 col-md-2 col-12">
                        <div class="nav nav-pills auction_navs me-3 mt-5 <?php echo e(session('ar_class')); ?>" id="v-pills-tab" role="tablist"
                            aria-orientation="vertical">
                    <?php if($isOwner): ?>
                    <a href="<?php echo e(url('profile/'.Crypt::encrypt(auth()->id()))); ?>" class="nav-link text-start <?php echo e(($title == 'Profile') ? 'active' : ' '); ?>">
                        <?php echo e(__('trans.My Profile')); ?>

                    </a>

                    <a href="<?php echo e(url('auctions/'.Crypt::encrypt(auth()->id()))); ?>" class="nav-link text-start <?php echo e(($title == 'Auctions') ? 'active' : ' '); ?>">
                        <?php echo e(__('trans.My Auctions')); ?>

                    </a>

                    <a href="<?php echo e(url('non-auctions/'.Crypt::encrypt(auth()->id()))); ?>" class="nav-link text-start <?php echo e(($title == 'Non-Auctions') ? 'active' : ' '); ?>">
                        <?php echo e(__('trans.My Selling')); ?>

                    </a>

                    <a href="<?php echo e(url('bid-auctions')); ?>" class="nav-link text-start <?php echo e(($title == 'Bid-Auctions') ? 'active' : ' '); ?>">
                        <?php echo e(__('trans.My Bid')); ?>

                    </a>

                    <a href="<?php echo e(url('favourite-auctions')); ?>" class="nav-link text-start <?php echo e(($title == 'Favourite-Auctions') ? 'active' : ''); ?>">
                        <?php echo e(__('trans.My Favourite')); ?>

                    </a>
                    <?php else: ?>
                    <a href="<?php echo e(url('profile/'.Crypt::encrypt($userid))); ?>" class="nav-link text-start <?php echo e(($title == 'Profile') ? 'active' : ' '); ?>">
                        <?php echo e(__('trans.Profile')); ?>

                    </a>

                    <a href="<?php echo e(url('auctions/'.Crypt::encrypt($userid))); ?>" class="nav-link text-start <?php echo e(($title == 'Auctions') ? 'active' : ' '); ?>">
                        <?php echo e(__('trans.Auctions')); ?>

                    </a>

                    <a href="<?php echo e(url('non-auctions/'.Crypt::encrypt($userid))); ?>" class="nav-link text-start <?php echo e(($title == 'Non-Auctions') ? 'active' : ' '); ?>">
                        <?php echo e(__('trans.Selling')); ?>

                    </a>
                    <?php endif; ?>
                    

                        </div>
                    </div>
                    <div class="col-sm-12 col-md-10 col-12 mx-auto">
                        <div class="tab-content profile_features bg-white my-5" id="v-pills-tabContent">
                            <div class="tab-pane fade show active" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab" tabindex="0">
                                <?php echo $__env->make('theme_1.post.'.$content, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/theme_1/post/post_data.blade.php ENDPATH**/ ?>