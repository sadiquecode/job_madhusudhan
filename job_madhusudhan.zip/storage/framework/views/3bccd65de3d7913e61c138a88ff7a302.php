<div class="col-sm-8 col-md-8 col-lg-8 col-xl-9">
	<h6 class="card-title m-b-20">Features Page</h6>
	<form class="m-b-30" action="<?php echo e(route('webpage.update', $webpage->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
		<div class="card-box">
			<div class="row">
				
				<div class="col-md-12">
					<h4 class="card-title">Features Section</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Main Heading:</label>
								<input type="text" class="form-control" name="feature_heading" value="<?php echo e($webpage->feature_heading); ?>">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Sub Heading:</label>
								<input type="text" class="form-control" name="feature_sub_heading" value="<?php echo e($webpage->feature_sub_heading); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Button:</label>
								<input type="text" class="form-control" name="feature_button" value="<?php echo e($webpage->feature_button); ?>">
							</div>
						</div>

						<div class="col-md-12">
							<div class="form-group">
								<label>List Heading:</label>
								<input type="text" class="form-control" name="feature_list_heading" value="<?php echo e($webpage->feature_list_heading); ?>">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="text-right">
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
		</div>
	</form>
</div><?php /**PATH G:\server\htdocs\advance_ai\resources\views/web/forms/feature_page.blade.php ENDPATH**/ ?>