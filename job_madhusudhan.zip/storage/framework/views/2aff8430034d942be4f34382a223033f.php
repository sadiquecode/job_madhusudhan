<div class="sidebar" id="sidebar"> 
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="">
                    <a href="<?php echo e(url('/')); ?>" target="_blank"><i class="fa fa-globe"></i><?php echo e(__('trans.website')); ?></a>
                </li>
            </ul>
            <!-- Supper admin -->
            <?php if (Auth::user()->type == 'admin') { ?>
            <ul>
                <li class="menu-title"><?php echo e(__('trans.MAIN')); ?></li>
                <li class="active">
                    <a href="<?php echo e(url('/dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> <?php echo e(__('trans.dashboard')); ?></a>
                </li>
                <li class="submenu">
                    <a href="#"><i class="fas fa-box"></i> <span> <?php echo e(__('trans.subscriptions')); ?></span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a href="<?php echo e(url('dashboard/subscriptions/histories')); ?>"><?php echo e(__('trans.histories')); ?></a></li>
                        <li><a href="<?php echo e(url('dashboard/subscriptions')); ?>"><?php echo e(__('trans.Package')); ?></a></li>
                    </ul>
                </li>
                <li class="submenu d-none">
                    <a href="#"><i class="fas fa-percent"></i> <span> Affiliate System</span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a href="<?php echo e(url('affiliate/configurations')); ?>">Configurations</a></li>
                        <li><a href="<?php echo e(url('affiliate/withdraw-requests')); ?>">Withdraw Requests</a></li>
                        <li><a href="<?php echo e(url('affiliate/earning-histories')); ?>">Earning Histories</a></li>
                        <li><a href="<?php echo e(url('affiliate/payments')); ?>">Payments Histories</a></li>
                    </ul>
                </li>
                <li class="menu-title"><?php echo e(__('trans.MANAGE DOCUMENTS')); ?></li>
                <li class="">
                    <a href="<?php echo e(url('documents/folders')); ?>"><i class="fas fa-folder"></i> <?php echo e(__('trans.Folders')); ?></a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('documents/projects')); ?>"><i class="fa fa-copy"></i> <?php echo e(__('trans.All Projects')); ?></a>
                </li>
                <li class="menu-title"><?php echo e(__('trans.AI TOOLS')); ?></li>
                <li class="submenu">
                    <a href="#"><i class="fa fa-comments"></i> <span> <?php echo e(__('trans.AI Chat Bote')); ?></span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li class=""><a href="<?php echo e(url('prompts/ai-chat-prompts')); ?>"> <?php echo e(__('trans.AI Chat Prompts')); ?></a></li>
                        <li><a href="<?php echo e(url('chat-bots/ai-chat-bots')); ?>"><?php echo e(__('trans.AI Chat Bote')); ?></a></li>
                        <li><a href="<?php echo e(url('chat-bots/ai-chat-bots-categories')); ?>"><?php echo e(__('trans.Category')); ?></a></li>

                    </ul>
                </li>
                <li class="">
                    <a href="<?php echo e(url('templates/ai-templates')); ?>"><i class="fa fa-edit"></i> <?php echo e(__('trans.Templates')); ?></a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('templates/ai-template-categories')); ?>"><i class="fas fa-pen-square"></i> <?php echo e(__('trans.Ai Category')); ?></a>
                </li>
                <li class="submenu d-none">
                    <a href="#"><i class="fas fa-pen-square"></i> <span> <?php echo e(__('trans.Custom Template')); ?></span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a href="<?php echo e(url('templates/ai-template-categories')); ?>"><?php echo e(__('trans.Category')); ?></a></li>
                        <li><a href="<?php echo e(url('templates/ai-custom-templates')); ?>"><?php echo e(__('trans.Custom Templates')); ?></a></li>
                    </ul>
                </li>
                <li class="">
                    <a href="<?php echo e(url('speech/ai-speech-text')); ?>"><i class="fas fa-microphone"></i> <?php echo e(__('trans.Speech To Text')); ?></a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('images/ai-images')); ?>"><i class="fa fa-image"></i> <?php echo e(__('trans.Generate Images')); ?></a>
                </li>

                <li class="">
                    <a href="<?php echo e(url('templates/popular')); ?>"><i class="fas fa-chart-line"></i> <?php echo e(__('trans.Popular Templates')); ?></a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('templates/favorites')); ?>"><i class="fas fa-heart"></i> <?php echo e(__('trans.Favorite Template')); ?></a>
                </li>
                <li class="menu-title"> <?php echo e(__('trans.REPORTS')); ?></li>
                <li class="submenu">
                    <a href="#"><i class="fas fa-chart-pie"></i> <span> <?php echo e(__('trans.REPORTS')); ?></span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a href="<?php echo e(url('reports/words-generated')); ?>"><?php echo e(__('trans.Words Report')); ?></a></li>
                        <li><a href="<?php echo e(url('reports/codes-generated')); ?>"><?php echo e(__('trans.Codes Report')); ?></a></li>
                        <li><a href="<?php echo e(url('reports/images-generated')); ?>"><?php echo e(__('trans.Images Report')); ?></a></li>
                        <li><a href="<?php echo e(url('reports/speech-to-text-generated')); ?>"><?php echo e(__('trans.Speech to text')); ?></a></li>
                        <li><a href="<?php echo e(url('reports/most-used-templates')); ?>"><?php echo e(__('trans.Most Used Template')); ?></a></li>
                        <li><a href="<?php echo e(url('reports/subscriptions')); ?>"><?php echo e(__('trans.Subscriptions Report')); ?></a></li>
                    </ul>
                </li>
                <li class="menu-title"><?php echo e(__('trans.MANAGE USERS')); ?></li>
                <li class="">
                    <a href="<?php echo e(url('dashboard/customers')); ?>"><i class="fas fa-users"></i> <?php echo e(__('trans.Customers')); ?></a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('dashboard/employee')); ?>"><i class="fas fa-user"></i> <?php echo e(__('trans.employee')); ?></a>
                </li>
                
                <li class="menu-title"><?php echo e(__('trans.MANAGE CONTENTS')); ?></li>
                <li class="submenu">
                    <a href="#"><i class="fas fa-home"></i> <span> <?php echo e(__('trans.home page')); ?></span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a href="<?php echo e(url('all_menu')); ?>"><?php echo e(__('trans.menus')); ?></a></li>
                        <li><a href="<?php echo e(url('webpage')); ?>"><?php echo e(__('trans.pages')); ?></a></li>
                        <li><a href="<?php echo e(url('web_features_list')); ?>"><?php echo e(__('trans.features list')); ?></a></li>
                        <li><a href="<?php echo e(url('web_faq')); ?>"><?php echo e(__('trans.faq')); ?></a></li>
                    </ul>
                </li>
                
                
                <li class="submenu">
                    <a href="#"><i class="fas fa-cube"></i> <span> <?php echo e(__('trans.blogs')); ?></span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a href="<?php echo e(url('web_blog')); ?>"><?php echo e(__('trans.all blog')); ?></a></li>
                        <li><a href="<?php echo e(url('web_category')); ?>"><?php echo e(__('trans.categories')); ?></a></li>
                    </ul>
                </li>
                <li class="d-none">
                    <a href="index.html"><i class="fas fa-file"></i> <?php echo e(__('trans.Pages')); ?></a>
                </li>

                <li class="menu-title"><?php echo e(__('trans.MANAGE SETTINGS')); ?></li>
                <li class="">
                    <a href="<?php echo e(url('dashboard/apis/configuration')); ?>"><i class="fas fa-hashtag"></i> <?php echo e(__('trans.api configuration')); ?></a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('all_languages')); ?>"><i class="fas fa-language"></i> <?php echo e(__('trans.languages')); ?></a>
                </li>
                <li class="submenu">
                    <a href="#"><i class="fas fa-cogs"></i> <span> <?php echo e(__('trans.system settings')); ?></span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li>
                            <a href="<?php echo e(url('dashboard/settings/general-settings')); ?>"><?php echo e(__('trans.general')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('dashboard/settings/auth')); ?>"><?php echo e(__('trans.auth settings')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('dashboard/settings/smtp')); ?>"><?php echo e(__('trans.SMTP')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('dashboard/settings/offline-payment')); ?>"><?php echo e(__('trans.Offline Payment')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('dashboard/settings/payment-methods')); ?>"><?php echo e(__('trans.payment methods')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('dashboard/settings/social-media-login')); ?>"><?php echo e(__('trans.social login')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('dashboard/settings/purchase-code')); ?>"><?php echo e(__('trans.purchase code')); ?></a>
                        </li>
                    </ul>
                </li>
                <li class="menu-title"><?php echo e(__('trans.UPDATE')); ?></li>
                <li class="">
                    <a href="<?php echo e(url('dashboard/update')); ?>"><i class="fas fa-bell"></i> <?php echo e(__('trans.UPDATE')); ?></a>
                </li>
                <br><br><br>
            </ul>


            <!-- User -->
        <?php }else{ ?>
            <ul>
                <li class="menu-title">Main</li>
                <li class="active">
                    <a href="<?php echo e(url('dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                </li>
                <li class="submenu">
                    <a href="#"><i class="fas fa-box"></i> <span> Subscriptions</span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a href="<?php echo e(url('dashboard/subscriptions/histories')); ?>">Histories</a></li>
                        <li><a href="<?php echo e(url('dashboard/subscriptions')); ?>">Package</a></li>
                    </ul>
                </li>
                <li class="submenu d-none">
                    <a href="#"><i class="fas fa-percent"></i> <span> Affiliate System</span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a href="<?php echo e(url('affiliate/overview')); ?>">Overview</a></li>
                        <li><a href="<?php echo e(url('affiliate/configure-payouts')); ?>">Payout Configurations</a></li>
                        <li><a href="<?php echo e(url('affiliate/withdraw-requests')); ?>">Withdraw Requests</a></li>
                        <li><a href="<?php echo e(url('affiliate/earning-histories')); ?>">Earning Histories</a></li>
                        <li><a href="<?php echo e(url('affiliate/payments')); ?>">Payments Histories</a></li>
                    </ul>
                </li>
                <li class="menu-title">MANAGE DOCUMENTS</li>
                <li class="">
                    <a href="<?php echo e(url('documents/folders')); ?>"><i class="fas fa-folder"></i> Folders</a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('documents/projects')); ?>"><i class="fa fa-copy"></i> All Projects</a>
                </li>
                <li class="menu-title">AI TOOLS</li>

                <li class="">
                    <a href="<?php echo e(url('chat-bots/ai-chat-bots')); ?>"><i class="fa fa-comments"></i>AI Chat Bote</a>
                </li>

                <li class="">
                    <a href="<?php echo e(url('templates/ai-templates')); ?>"><i class="fa fa-edit"></i> Templates</a>
                </li>
                
                <li class="">
                    <a href="<?php echo e(url('speech/ai-speech-text')); ?>"><i class="fas fa-microphone"></i> Speech To Text</a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('images/ai-images')); ?>"><i class="fa fa-image"></i> Generate Images</a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('code/ai-code')); ?>"><i class="fa fa-code"></i> AI Code</a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('templates/popular')); ?>"><i class="fas fa-chart-line"></i> Popular Templates</a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('templates/favorites')); ?>"><i class="fas fa-heart"></i> Favorite Templatess</a>
                </li>
            </ul>
        <?php } ?>
        </div>
    </div>
</div><?php /**PATH G:\server\htdocs\advance_ai\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>