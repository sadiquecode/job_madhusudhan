<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ============page Start============-->

    <style type="text/css">
        
        <?php if(session('ar_class') == 'arabic'): ?>
            .about_heading {
                font-family: 'Cairo Play', sans-serif !important;
            }
        <?php endif; ?>


    </style>
    <section class="about_heading">
        <div class="container">
            <div class="px-2 about" dir="<?php echo e(($code == 'en') ? 'ltr' : 'rtl'); ?>">
                <h1 class="pt-5 pb-3 <?php echo e(session('ar_class')); ?>"><?php echo e($heading); ?></h1>
            </div>
            <div class="service_content py-5" dir="<?php echo e(($code == 'en') ? 'ltr' : 'rtl'); ?>">
                <p>
                    <?= $body ?>
                </p>
            </div>
        </div>
    </section>
    <!-- ======page End=====-->
        

<?php echo $__env->make('theme_1.layouts.contact_us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/theme_1/pages.blade.php ENDPATH**/ ?>