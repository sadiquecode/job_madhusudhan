
<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Student profile content -->
   <?php if($check_user_type->role == 'student'): ?>
     <?php echo $__env->make('theme_1.userprofile.student_profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php else: ?>
  <!-- Tutor profile content -->
  
  
  
   <style>
            
/* Live icon and animation*/

.live-icon {
  display: inline-block;
  position: relative;
  top: calc(50% - 5px);
  background-color: #48b02d;
  width: 10px;
  height: 10px;
  margin-left: 20px;
  border: 1px solid rgba(black, 0.1);
  border-radius: 50%;
  z-index: 1;
  &:before {
    content: "";
    display: block;
    position: absolute;
    background-color: rgba(red, 0.6);
    width: 100%;
    height: 100%;
    border-radius: 50%;
    animation: live 2s ease-in-out infinite;
    z-index: -1;
  }
}

@keyframes live {
  0% {
    transform: scale(1, 1);
  }
  100% {
    transform: scale(1.5, 1.5);
    background-color: #48b02d;
  }
}

.profile_complete_status{
    border-left: 4px solid #48b02d;
    border-radius: 3px !important;
}

.blink_me {
    color: #fff !important;
    background: #48b02d;
  animation: blinker 1s linear infinite;
}

@keyframes blinker {
  50% {
    opacity: 0;
  }
}
        </style>
  
  <main id="profile-section" class="py-5 px-2 px-sm-4 mb-5">
    <div class="container rounded-5 p-4 gap-4 gap-md-5 box-shadow-md bg-white d-sm-flex">
      <!-- Tabs -->
      <ul
        class="nav nav-pills flex-sm-column flex-nowrap flex-sm-wrap overflow-x-auto overflow-x-sm-hidden overflow-x-md-visible gap-3 pe-sm-5 pe-md-4 pt-2 pb-2 pb-sm-0 border-end-sm justify-content-start border-bottom border-bottom-sm-0 "
        id="profile-tabs" role="tablist">
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php echo e($itsmainbtn); ?> <?php if(profile_complete_status($profile->id)->profile == 1): ?> profile_complete_status <?php endif; ?>" id="edit-tab" data-bs-toggle="tab" data-bs-target="#edit-tab-pane"
            type="button" role="tab" aria-controls="edit-tab-pane" aria-selected="true">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/user-square-light.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Profile</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php if(profile_complete_status($profile->id)->expertise == 1): ?> profile_complete_status <?php endif; ?>" id="expertise-tab" data-bs-toggle="tab" data-bs-target="#expertise-tab-pane"
            type="button" role="tab" aria-controls="expertise-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/book-saved-light.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Expertise</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php if(profile_complete_status($profile->id)->education == 1): ?> profile_complete_status <?php endif; ?>" id="education-tab" data-bs-toggle="tab" data-bs-target="#education-tab-pane"
            type="button" role="tab" aria-controls="education-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/teacher.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Education</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php if(profile_complete_status($profile->id)->experience == 1): ?> profile_complete_status <?php endif; ?>" id="experience-tab" data-bs-toggle="tab" data-bs-target="#experience-tab-pane"
            type="button" role="tab" aria-controls="experience-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/invoice.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Experience</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php echo e($itslicensebtn); ?>" id="documents-tab" data-bs-toggle="tab" data-bs-target="#documents-tab-pane"
            type="button" role="tab" aria-controls="documents-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/document.svg')); ?>" aria-hidden="true" class="me-3">
            <span>License/Certificate</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="payments-tab" data-bs-toggle="tab" data-bs-target="#payments-tab-pane"
            type="button" role="tab" aria-controls="payments-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/card.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Payments</span>
          </button>
        </li>
        <?php if(Auth::user()->role != 'admin'): ?>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="settings-tab" data-bs-toggle="tab" data-bs-target="#settings-tab-pane"
            type="button" role="tab" aria-controls="settings-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/video-octagon-light.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Settings</span>
          </button>
        </li>
        <?php endif; ?>
      </ul>

      <!-- Tab Panes -->
      <div class="tab-content mt-2 flex-grow-1" id="profile-tabs-content">
        <?php echo $__env->make('theme_1.userprofile.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Profile Panel -->
        <form name="profile-info-form" class="tab-pane fade <?php echo e($itsmain); ?>" id="edit-tab-pane" role="tabpanel"
          aria-labelledby="edit-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">My Profile</h3>

        

              

            <?php if(Auth::user()->role != 'admin'): ?>
            <a href="<?php echo e(url('edit-profile/'.encrypt(Auth::user()->id))); ?>?itsmain=yes" class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Edit<i
                class="ms-2 fa-solid fa-pencil text-decoration-underline" style="font-size: 12px;"></i></a>
            <?php endif; ?>
          </div>

          <!-- Profile Info -->
          <div class="card mt-4 p-1">
            <div class="card-body d-flex align-items-center gap-2">
              
              <?php if(empty($profile->profile_pic)): ?>
                <img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="Tutor Avatar" class="img-fluid rounded-circle" width="70" height="70" style="height: 70px;
    object-fit: cover;">
                <?php else: ?>
                <img alt="Tutor Avatar" class="img-fluid rounded-circle" width="70" height="70" style="height: 70px;
    object-fit: cover;" src="<?php echo e(url(env('img_path'). $profile->profile_pic)); ?>">
                <?php endif; ?>

              <div class="fw-semibold text-uppercase">
                <span class="text-warning" style="font-size:12px;"><?php echo e(ucfirst($profile->role)); ?></span>
                <h4 class="fs-6 fw-semibold mb-0"><?php echo e(ucfirst($profile->name.' '.$profile->lname)); ?></h4>
                <span class="text-primary" style="font-size:12px;">

                  <?php echo e($TeachmeLocationRelationship ? sub_location_name($TeachmeLocationRelationship->sub_location_id)->name ?? 'null' : 'null'); ?>,

                  <?php echo e($TeachmeLocationRelationship ? sub_location_name($TeachmeLocationRelationship->location_id)->name ?? 'null' : 'null'); ?>


                  

                </span>
                
          <?php if($profile->approval_status == 1 && $profile->askforapproval == 'done' && $profile->lock_status == 0): ?>
                <p style="font-weight: 300;
    text-transform: capitalize;">Profile Status : <span style="color:green;"> <span class="live-icon"></span> Live</span></p>
              <?php else: ?>
              
               <p style="font-weight: 300;
    text-transform: capitalize;">Profile Status : <span>Not Active</span></p>
              <?php endif; ?>
              </div>
            </div>
          </div>



          <!-- Mode of Instruction -->
          <fieldset name="personal-information" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-4">Availability</h3>
              <div class="p-2 mt-2">
                <div class="row gutter">

                  <?php if($profile->in_person_mode && $profile->in_person_mode === 'in_person'): ?>
                  <div class="col-6 col-sm-6 col-xl-6">
                    <div class="form-check form-check-inline">
                      <img src="<?php echo e(asset('public/theme_assets/images/square.png')); ?>" class="rounded" width="20" />
                      <label class="form-check-label" for="mode-virtual">
                        In Person
                      </label>
                    </div>
                  </div>
                  <?php endif; ?>

                  <?php if($profile->virtual_mode && $profile->virtual_mode === 'virtual'): ?>
                  <div class="col-6 col-sm-6 col-xl-6">
                    <div class="form-check form-check-inline">
                      <img src="<?php echo e(asset('public/theme_assets/images/square.png')); ?>" class="rounded" width="20" />
                      <label class="form-check-label" for="mode-virtual">
                        Virtual
                      </label>
                    </div>
                  </div>
                   <?php endif; ?>

                </div>
              </div>
            </div>
          </fieldset>

          <!-- Personal Info -->
          <fieldset name="personal-information" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-4">Personal Information</h3>

              <div class="p-2 mt-2">
                <div class="row gutter">
                  <!-- First Name -->
                  <div class="col-12 col-md-6 col-xl-4">
                    <p class="title">First Name</p>
                    <span class="text-secondary"><?php echo e(ucfirst($profile->name)); ?></span>
                  </div>
                  <!-- Last Name -->
                  <div class="col-12 col-md-6 col-xl-8">
                    <p class="title">Last Name</p>
                    <span class="text-secondary"><?php echo e(ucfirst($profile->lname)); ?></span>
                  </div>
                  <!-- Email -->
                  <div class="col-12 col-md-6 col-xl-4">
                    <p class="title">Email Address</p>
                    <span class="text-secondary"><?php echo e($profile->email); ?></span>
                  </div>

                  
                  <?php if($profile->phone): ?>
                  <div class="col-12 col-md-6 col-xl-8">
                    <p class="title">Whatsapp Numbe</p>
                    <span class="text-secondary">+<?php echo e($profile->phone); ?></span>
                  </div>
                  <?php endif; ?>
                  


                </div>
              </div>
            </div>
          </fieldset>

          <!-- Bio -->
          <fieldset name="bio" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-2">Bio</h3>

              <p class="py-2 mb-0">
                <?php echo e($profile->description); ?>

              </p>
            </div>
          </fieldset>

          <?php if(!empty($profile->embedUrl)): ?>
            <!-- Intro video -->
          <fieldset name="intro video" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-2">Intro Video</h3>

              <div class="py-2 mb-0">
                <div class="embedded-video-container bg-black rounded-4">
                  <iframe src="<?php echo e($profile->embedUrl); ?>"></iframe>
                </div>
              </div>
              
            </div>
          </fieldset>
          <?php endif; ?>
          
          <br><br><br><br>
        </form>

        <!-- Expertise Panel -->
        <form name="expertise-form" class="tab-pane fade" id="expertise-tab-pane" role="tabpanel"
          aria-labelledby="expertise-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
          <h3 class="fs-5">Expertise</h3>
          <?php if(Auth::user()->role != 'admin'): ?>
            <a href="<?php echo e(url('edit-profile/'.encrypt(Auth::user()->id))); ?>?itsexpertise=yes" class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Manage<i
                class="ms-2 fa-solid fa-pencil" style="font-size: 12px;"></i></a>
            <?php endif; ?>
          </div>
          <!-- Curriculum -->
          <fieldset name="curriculum" class="card mt-4 p-2">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-6 fw-semibold">Curriculum</h3>

              <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-3 g-4" style="padding-inline:.8rem;">
                  <?php $__currentLoopData = $TeachmeCurriculum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                      $checked = optional($profile->teachme_curriculum_relationships)->contains('curriculum_id', $curriculum->id);
                  ?>
                  <?php if($checked): ?>
                      <div class="col form-check">
                          <label class="form-check-label" for="curriculum-<?php echo e($curriculum->id); ?>">
                            <img src="<?php echo e(asset('public/theme_assets/images/square.png')); ?>" class="rounded" width="20" />
                              <?php echo e($curriculum->title); ?>

                          </label>
                      </div>
                      <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </fieldset>

          <!-- Grades -->
          <fieldset name="grades" class="card mt-4 p-2">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-6 fw-semibold">Grades</h3>

              <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-3 g-4" style="padding-inline:.8rem;">
                  <?php $__currentLoopData = $TeachmeGrade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                      $checked = optional($profile->teachme_grades_relationships)->contains('grade_id', $grade->id);
                  ?>
                  <?php if($checked): ?>
                      <div class="col form-check">
                          <label class="form-check-label" for="grade-<?php echo e($grade->id); ?>">
                            <img src="<?php echo e(asset('public/theme_assets/images/square.png')); ?>" class="rounded" width="20" />
                              <?php echo e($grade->title); ?>

                          </label>
                      </div>
                      <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </fieldset>

          <!-- Subjects -->
          <fieldset name="subjects" class="card mt-4 p-2">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-6 fw-semibold">Subjects</h3>

              <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-3 g-4" style="padding-inline:.8rem;">
                  <?php $__currentLoopData = $TeachmeSubject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                      $checked = optional($profile->teachme_subject_relationships)->contains('subject_id', $subject->id);
                  ?>
                  <?php if($checked): ?>
                      <div class="col form-check">
                          <label class="form-check-label" for="grade-<?php echo e($subject->id); ?>">
                            <img src="<?php echo e(asset('public/theme_assets/images/square.png')); ?>" class="rounded" width="20" />
                              <?php echo e($subject->title); ?>

                          </label>
                      </div>
                      <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </fieldset>

          <!-- Languages -->
          <fieldset name="languages" class="card mt-4 p-2">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-6 fw-semibold">Languages spoken</h3>
               <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-3 g-4" style="padding-inline:.8rem;">
                  <?php $__currentLoopData = $TeachmeLanguage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                      $checked = optional($profile->teachme_languages_relationships)->contains('language_id', $language->id);
                  ?>
                  <?php if($checked): ?>
                      <div class="col form-check">
                          <label class="form-check-label" for="language-<?php echo e($language->id); ?>">
                            <img src="<?php echo e(asset('public/theme_assets/images/square.png')); ?>" class="rounded" width="20" />
                              <?php echo e($language->name); ?>

                          </label>
                      </div>
                      <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </fieldset>
        </form>

        <!-- Education Panel -->
        <form name="education-form" class="tab-pane fade" id="education-tab-pane" role="tabpanel"
          aria-labelledby="education-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Education</h3>

            <?php if(Auth::user()->role != 'admin'): ?>
            <a href="<?php echo e(url('edit-profile/'.encrypt(Auth::user()->id))); ?>?addeducation=true" class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Add<i
                class="ms-2 fa-solid fa-plus" style="font-size: 12px;"></i></a>
            <?php endif; ?>

          </div>

          <!-- Education -->
          <ul class="list-unstyled d-flex flex-column gap-2 mt-4">
            <?php $__empty_1 = true; $__currentLoopData = $education_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <li
              class="bg-body-tertiary rounded-3 p-3 d-flex flex-column flex-sm-row justify-content-between align-items-end align-items-sm-center gap-2">
              <div>
                <p class="fw-bold mb-1 opacity-75"><?php echo e($education->degree); ?></p>
                <div class="d-flex gap-2 flex-wrap">
                  <span class="opacity-75"><?php echo e($education->institution); ?></span>
                  <span class="fw-medium">
                    <strong><?php echo e(date('M', strtotime($education->start_date))); ?></strong> <?php echo e(date('Y', strtotime($education->start_date))); ?>

                    -
                    <?php if($education->end_date): ?>
                        <strong><?php echo e(date('M', strtotime($education->end_date))); ?></strong> <?php echo e(date('Y', strtotime($education->end_date))); ?>

                    <?php else: ?>
                        Present
                    <?php endif; ?>
                </span>
                </div>
              </div>
              <?php if(Auth::user()->role != 'admin'): ?>
              <div class="d-flex flex-wrap gap-2">

              <a href="<?php echo e(url('edit-profile/'.encrypt(Auth::user()->id))); ?>?editeducation=<?php echo e($education->id); ?>" class="btn btn-outline-primary" data-bs-toggle="tooltip" data-bs-title="Edit"> <i class="fa-solid fa-pencil"></i>
              <span class="visually-hidden">Edit</span>
              </a>
                <?php if(count($education_data) > 1): ?>
                  <a href="<?php echo e(route('del_data', ['type' => 'education', 'data_id' => $education->id])); ?>" class="btn btn-outline-danger" onclick="return confirm('Are you sure you want to delete this data?');" data-bs-toggle="tooltip" data-bs-title="Delete">
                    <i class="fa-solid fa-trash"></i>
                    <span class="visually-hidden">Delete</span>
                </a>
                <?php else: ?>
                <a href="#" class="btn btn-outline-danger" onclick="return confirm('Cannot delete the only education record!');" data-bs-toggle="tooltip" data-bs-title="Cannot delete the only education record">
                    <i class="fa-solid fa-trash"></i>
                    <span class="visually-hidden">Delete</span>
                </a>
                <?php endif; ?>
                

              </div>
              <?php endif; ?>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            You have not added any education yet.
            <?php endif; ?>
          </ul>
        </form>

        <!-- Experience Panel -->
        <form name="experience-form" class="tab-pane fade" id="experience-tab-pane" role="tabpanel"
          aria-labelledby="experience-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Experience</h3>

            <?php if(Auth::user()->role != 'admin'): ?>
            <a href="<?php echo e(url('edit-profile/'.encrypt(Auth::user()->id))); ?>?addexperience=true" class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Add<i
                class="ms-2 fa-solid fa-plus" style="font-size: 12px;"></i></a>
            <?php endif; ?>
          </div>

          <!-- Education -->
          <ul class="list-unstyled d-flex flex-column gap-2 mt-4">
            <?php $__empty_1 = true; $__currentLoopData = $experience_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <li
              class="bg-body-tertiary rounded-3 p-3 d-flex flex-column flex-sm-row justify-content-between align-items-end align-items-sm-center gap-2">
              <div>
                <p class="fw-bold mb-1 opacity-75">
                  <?php echo e($experience->company); ?>

                </p>
                <div class="d-flex gap-2 flex-wrap">
                  <span class="opacity-75"><?php echo e($experience->position); ?></span>
                  <span class="fw-medium">
                    <strong><?php echo e(date('M', strtotime($experience->start_date))); ?></strong> <?php echo e(date('Y', strtotime($experience->start_date))); ?>

                    -
                    <?php if($experience->end_date): ?>
                        <strong><?php echo e(date('M', strtotime($experience->end_date))); ?></strong> <?php echo e(date('Y', strtotime($experience->end_date))); ?>

                    <?php else: ?>
                        Present
                    <?php endif; ?>
                </span>
                </div>
              </div>

              <?php if(Auth::user()->role != 'admin'): ?>
              <div class="d-flex flex-wrap gap-2">
              <a href="<?php echo e(url('edit-profile/'.encrypt(Auth::user()->id))); ?>?editexperience=<?php echo e($experience->id); ?>" class="btn btn-outline-primary" data-bs-toggle="tooltip" data-bs-title="Edit"> <i class="fa-solid fa-pencil"></i>
              <span class="visually-hidden">Edit</span>
              </a>

              <?php if(count($experience_data) > 1): ?>
                <a href="<?php echo e(route('del_data', ['type' => 'experience', 'data_id' => $experience->id])); ?>" class="btn btn-outline-danger" onclick="return confirm('Are you sure you want to delete this data?');" data-bs-toggle="tooltip" data-bs-title="Delete">
                    <i class="fa-solid fa-trash"></i>
                    <span class="visually-hidden">Delete</span>
                </a>
                <?php else: ?>
                <a href="#" class="btn btn-outline-danger" onclick="return confirm('Cannot delete the only experience record!');" data-bs-toggle="tooltip" data-bs-title="Cannot delete the only experience record">
                    <i class="fa-solid fa-trash"></i>
                    <span class="visually-hidden">Delete</span>
                </a>
                <?php endif; ?>
              </div>
              <?php endif; ?>

            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            You have not added any experience yet.
            <?php endif; ?>
          </ul>
        </form>
        
       

        <!-- documents Panel -->
        <div name="documents-form" class="tab-pane fade <?php echo e($itslicense); ?>" id="documents-tab-pane" role="tabpanel"
          aria-labelledby="documents-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">License / Certificate</h3>
            


            <?php if($profile->askforapproval == 'ask'  && $profile->reject_status == 1 && $check_profile->status == 1): ?>
            <?php $approval_status = 'Your profile has been Rejected!. Please Update your License and send again for approval.'; 
            ?>
              <b style="font-weight: 300;
              color: red;
              width: 50%;"><?php echo e($approval_status); ?></b>
            <?php endif; ?>

            <?php if(Auth::user()->role == 'tutor' && $check_profile->status == 1 && $profile->askforapproval == 'ask'): ?>
            <?php $approval_status = 'Submit for Approval'; ?>
                  <a href="<?php echo e(url('tutor-status/askapproval/asked/'.$profile->id)); ?>" onclick="return confirm('Are you sure you want to submit for approval this profile?')" class="btn btn-outline-success m-t-10 text-dark blink_me"><?php echo e($approval_status); ?></a>
            <?php endif; ?>



            <?php if(Auth::user()->role == 'tutor' && $check_profile->status == 1 && $profile->askforapproval == 'asked'): ?>
            <?php $approval_status = 'Your profile has been submitted for approval. You will receive an email upon verification.'; ?>
              <b style="font-weight: 300;
    color: #4caf50e0;
    width: 50%;"><?php echo e($approval_status); ?></b>
            <?php endif; ?>


        


            <?php if($check_profile->status == 2 && $document_data && count($document_data) < 1 || Auth::user()->role == 'tutor' && $check_profile->status == 0 && $check_profile->msg == 'license not found'): ?>
              <a href="<?php echo e(url('edit-profile/'.encrypt(Auth::user()->id))); ?>?adddocument=true" class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">
                <i class="ms-2 fa-solid fa-upload" style="font-size: 12px;"></i> Upload License
              </a>
            <?php elseif(Auth::user()->role == 'tutor' && $check_profile->status == 2): ?>
            <?php echo e(// $check_profile->msg
              'Please complete all the sections profile , expertise , education , experience and upload your valid license / teaching certificate, then you would be able to submit your profile for approval'); ?>

            <?php elseif($profile->askforapproval == 'done' && $check_profile->status == 1): ?>
            <b style="font-weight: 300;" class="text-success d-flex justify-content-between">Your profile has been approved!</b>
            <?php endif; ?>
            <?php if(Auth::user()->role == 'admin' && $profile->askforapproval == 'done' && $profile->reject_status == 0 && $check_profile->status == 1): ?>
              <form action="<?php echo e(route('reject_profile')); ?>" method="POST" onclick="return confirm('Are you sure you want to disable this profile?')">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="user_id" value="<?php echo e($profile->id); ?>">
                  <input type="hidden" name="note" value="">
                  <button type="submit" class="btn btn-secondary btn-sm m-t-10 text-white">Disable Tutor</button>
              </form>
              <?php endif; ?>
          </div>
          
          
          <div class="row">
              <div class="col-md-12">
            <?php if(Auth::user()->role == 'admin' && $profile->askforapproval == 'asked' && $profile->reject_status == 0 && $check_profile->status == 1): ?>
                  


              <form action="<?php echo e(route('reject_profile')); ?>" method="POST" onsubmit="return confirm('Are you sure you want to disable this profile?')">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="user_id" value="<?php echo e($profile->id); ?>">
                  <textarea type="" name="note" rows="5" style="width: 100%;padding:10px;" placeholder="Please include your comment here. It will be shared with the tutor in the rejection email to ensure their profile is aligned according to the provided feedback." required></textarea>
                  <br>
                  <button type="submit" class="btn btn-secondary btn-sm m-t-10 text-white">Disapprove Tutor</button>
              </form>
              



                  <a href="<?php echo e(url('tutor-status/approval/1/'.$profile->id)); ?>" onclick="return confirm('Are you sure you want to approve this profile?')" class="btn btn-success btn-sm m-t-10 text-white" style="margin: -4%;
                    margin-right: 0%;
                    width: 45%;
                    float: right;">Approve Tutor
                  </a>
            <?php endif; ?>
            
</div>
</div>

          <!-- Education -->
          <ul class="list-unstyled d-flex flex-column gap-2 mt-4">
            <?php $__empty_1 = true; $__currentLoopData = $document_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <li
              class="bg-body-tertiary rounded-3 p-3 d-flex flex-column flex-sm-row justify-content-between align-items-end align-items-sm-center gap-2">
              <div>
                <p class="fw-bold mb-1 opacity-75">
                  <?php echo e($documents->title); ?>

                  <p><i>Valid until</i>:
                    <?php echo e(\Carbon\Carbon::parse($documents->expiry_date)->format('F d, Y')); ?>

                  <?php if($documents->expiry_status == 1): ?>
                    <span class="text-danger">Expired</span>
                  <?php else: ?>
                  <span class="text-success"> <i> -Valid</i></span>
                  <?php endif; ?>
                  </p>
                </p>
              </div>
              
              <div class="d-flex flex-wrap gap-2">

              <a target="_blank" href="<?php echo e(url(env('img_path'). $documents->document)); ?>" class="btn btn-outline-info" data-bs-toggle="tooltip" data-bs-title="View"> <i class="fa-solid fa-eye"></i>
              <span class="visually-hidden">View</span>
              </a>

              <?php if(Auth::user()->role == 'tutor' && $check_profile->status == 0 && $check_profile->msg == 'license have expiry date' || $profile->reject_status == 1): ?>
              <a href="<?php echo e(url('edit-profile/'.encrypt(Auth::user()->id))); ?>?editdocument=<?php echo e($documents->id); ?>" class="btn btn-outline-primary" data-bs-toggle="tooltip" data-bs-title="Edit"> <i class="fa-solid fa-pencil"></i>
              <span class="visually-hidden">Edit</span>
              </a>
              <?php endif; ?>

                <?php if(Auth::user()->role == 'tutor' && $profile->askforapproval == 'ask' && $check_profile->msg != 'license have expiry date'): ?>
                <a href="<?php echo e(route('del_data', ['type' => 'document', 'data_id' => $documents->id])); ?>" class="btn btn-outline-danger" onclick="return confirm('Are you sure you want to delete this data?');" data-bs-toggle="tooltip" data-bs-title="Delete">
                    <i class="fa-solid fa-trash"></i>
                    <span class="visually-hidden">Delete</span>
                </a>
                <?php endif; ?>

              </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            
            <?php endif; ?>
          </ul>

<div class="container mt-3">
  
  
  <div style="color: #ff0000a8;">

<p>Mandatory! Tutors are required to upload their "Private teacher work permit" as required by the MoHRE and MOE. </p>
<ul>
<li>We will also accept valid teaching certificates. Please upload either your Permit OR Teaching Certificate.</li>

<li>If you choose to upload your teaching certificate - please choose a one year expiry that will coincide with your subcription. </li>

<li>If you choose to upload your Permit, instructions on how to obtain the permit are below</li>
</ul>

<p class="text-info">If you are uploading a teacher certificate, kindly email <a href="mailto:info@teachme.ae">info@teachme.ae</a>  your most recent police clearance certificate in order to process your application.</p>
</div>
<br><br>
  <!-- Nav tabs -->
  <ul class="nav nav-tabs" role="tablist">
    <li class="nav-item">
      <a class="nav-link active" data-bs-toggle="tab" href="#eligibility">Eligibility</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="tab" href="#process-to-obtain">Process to obtain</a>
    </li>
  </ul>
  <!-- Tab panes -->
  <div class="tab-content">
    <div id="eligibility" class="container tab-pane active"><br>
        <br>
        <p>If you fall under any of the following categories, then you may be eligible for a UAE Private Teacher Work Permit:</p>
        <ul>
          <li>Registered teachers at public or private UAE schools.</li>
          <li>School students aged 15 to 18.</li>
          <li>University students.</li>
          <li>Federal and private sector employees.</li>
          <li>Unemployed individuals with a valid UAE residency (under family/spouse's sponsorship, or freelance).</li>
        </ul>
    </div>

    <div id="process-to-obtain" class="container tab-pane fade"><br>
      <br>
      <p>Eligible applicants can submit their requests for the permit through the MoHRE's digital platform.</p>
      <p>The permit, issued free of charge, aims to regulate private tuitions and curb illegal practices in the sector. Applicants can apply through the digital platforms of the MoHRE, specifically under the 'Private Teacher Work Permit' section in the 'Services' tab on the ministry’s website.</p>
      
          <ul>
              <ol>1- Visit the official <a href="https://www.mohre.gov.ae/en/home.aspx">MoHRE digital platform</a>.</ol>
              <ol>2- Go to the 'Services' tab and click the "<em>New Inquiry Services</em>".</ol>
              <ol>3- From the choose the service drop down menu choose "<em>Private Teacher Work Permit</em>".</ol>
              <ol>4- Enter your Emirates ID number.</ol>
              <ol>5- Enter the OTP code you received.</ol>
              <ol>6- Begin your application.</ol>
          </ul>
          
    </div>
  </div>
</div>

        </div>

        <!-- Payments Panel -->
        <form name="payments-form" class="tab-pane fade" id="payments-tab-pane" role="tabpanel"
          aria-labelledby="setting-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5"><i class="fa fa-bookmark-o"></i> Subscription</h3>

            <?php if(Auth::user()->role != 'admin'): ?>
            <a href="<?php echo e(url('edit-profile/'.encrypt(Auth::user()->id))); ?>?itspayments=yes" class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Manage<i
                class="ms-2 fa-solid fa-pencil" style="font-size: 12px;"></i></a>
            <?php endif; ?>

          </div>

          <div class="mt-4 row g-3">

            <?php if($TeachmePayment): ?>
              <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Subscription</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-9 d-flex flex-column">
              <span>Plan Type: 100 AED / Year</span>
              <span>Status: <?php echo e(ucfirst($TeachmePayment->stripe_status)); ?></span>
            </div>
            <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Billing Date</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-9">
              <span class="d-block">
                <?php if($TeachmePayment->stripe_status == 'active'): ?>
                 Your upcoming billing date is 
                  <?php echo e(\Carbon\Carbon::parse($TeachmePayment->created_at)->addYear()->format('F d, Y')); ?>.
                <?php else: ?>
               Your subscription has been cancelled, but you remain a premium member until your purchased subscription expires on 
                <?php echo e(\Carbon\Carbon::parse($TeachmePayment->ends_at)->format('F d, Y')); ?>.
                <?php endif; ?>
                
                 
               </span>
            </div>
            <?php else: ?>
            <span>You currently do not have an active plan.</span>
            <?php endif; ?>
            


            <div class="col-12 col-sm-6 col-xl-3">
              <p class="fw-semibold">Payment Method</p>
            </div>

            <?php if(!empty($profile->pm_last_four)): ?>
              <div class="col-12 col-sm-6 col-xl-9">
              <div class="d-flex flex-column flex-sm-row align-items-sm-center gap-2 gap-sm-3">
                <img src="<?php echo e(asset('public/theme_assets/images/credit-card.webp')); ?>" class="rounded" width="70" />
                <div class="d-flex flex-column">
                  <span class="h6 mb-1">Credit Card</span>
                  <span class="small text-muted"><?php echo e('**** **** **** ' . $profile->pm_last_four); ?></span>
                </div>
              </div>
            </div>
            <?php else: ?>
            <div class="col-12 col-sm-6 col-xl-9">
              <div class="d-flex flex-column flex-sm-row align-items-sm-center gap-2 gap-sm-3">
               You currently have no connected payment method.
              </div>
            </div>
            <?php endif; ?>
            
          </div>
        </form>

        <!-- Settings Panel -->
        <form name="settings-form" class="tab-pane fade" id="settings-tab-pane" role="tabpanel"
          aria-labelledby="setting-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Settings</h3>

            <?php if(Auth::user()->role != 'admin'): ?>
            <a href="<?php echo e(url('edit-profile/'.encrypt(Auth::user()->id))); ?>?itsettings=yes" class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Edit<i
                class="ms-2 fa-solid fa-pencil text-decoration-underline" style="font-size: 12px;"></i></a>
            <?php endif; ?>

          </div>

          <div class="mt-4 row g-3">
            <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Password</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-9">
              <span>*********</span>
            </div>
          </div>
        </form>
      </div>
    </div>
  </main>
  
  
  
  
  <?php endif; ?>
  <?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/userprofile/profile.blade.php ENDPATH**/ ?>