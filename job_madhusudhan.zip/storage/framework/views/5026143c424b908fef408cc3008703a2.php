<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ============================== product detail start==============================-->
<style type="text/css">
.picZoomer {
position: relative;
/*margin-left: 40px;
padding: 15px;*/
}
.picZoomer-pic-wp {
position: relative;
overflow: hidden;
text-align: center;
}
.picZoomer-pic-wp:hover .picZoomer-cursor {
display: block;
}
.picZoomer-zoom-pic {
position: absolute;
top: 0;
left: 0;
}
.picZoomer-zoom-wp {
display: none;
position: absolute;
z-index: 999;
overflow: hidden;
height: 460px;
width: 100%;
margin-top: -19px;
}
.picZoomer-cursor {
display: none;
cursor: crosshair;
width: 100px;
height: 100px;
position: absolute;
top: 0;
left: 0;
border-radius: 50%;
border: 1px solid #eee;
background-color: rgba(0, 0, 0, 0.1);
}
.picZoomCursor-ico {
width: 23px;
height: 23px;
position: absolute;
top: 40px;
left: 40px;
background: url(images/zoom-ico.png) left top no-repeat;
}
.my_img {
vertical-align: middle;
position: absolute;
top: 0;
bottom: 0;
margin: auto;
height: 100%;
}
.piclist li {
display: inline-block;
width: 99px;
height: 96px;
}
.piclist li img {
width: 97%;
height: auto;
}
/* custom style */
/* .picZoomer-pic-wp,
.picZoomer-zoom-wp {
border: 1px solid #eee;
} */
.section-bg {
background-color: #fff1e0;
}
section {
padding: 60px 0;
}
.row-sm .col-md-6 {
padding-left: 5px;
padding-right: 5px;
}
/*===pic-Zoom===*/
._boxzoom .zoom-thumb {
width: 90px;
display: inline-block;
vertical-align: top;
margin-top: 0px;
}
._boxzoom .zoom-thumb ul.piclist {
padding-left: 0px;
top: 0px;
}
._boxzoom ._product-images {
width: 80%;
display: inline-block;
}
._boxzoom ._product-images .picZoomer {
width: 100%;
height: auto;
}
._boxzoom ._product-images .picZoomer .picZoomer-pic-wp img {
left: 35px;
}
._boxzoom ._product-images .picZoomer img.my_img {
width: 100%;
height: auto;
}
.piclist li img {
height: 100px;
object-fit: cover;
}
@media (max-width: 1227px) {
/* Adjust the maximum width as needed */
._boxzoom {
display: flex;
flex-direction: column;
}
.zoom-thumb {
order: 2;
}
._product-images {
order: 1;
}
._boxzoom .zoom-thumb {
width: 100%;
display: inline-block;
vertical-align: top;
}


.picZoomer-pic-wp {
overflow: hidden;
text-align: center;
}

}
</style>
<section class="product_detail <?php echo e(session('ar_class')); ?>">
    <div class="container-fluid py-3">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
        <div class="row px-md-3">
            <!-- /////////////// -->
            <div class="col-12 pt-2 smallscreenlistinghead">
                <div class=" d-flex justify-content-between align-items-center py-4">
                    <div class="country">
                        <a href="#">
                            <img src="<?php echo e(url('public/theme_assets/images/flag/saudiarabia.png')); ?>" class="me-2"
                        alt="saudiarabia" width="32" height="32"><?php echo e(__('trans.SAR')); ?></a>
                    </div>
                    <?php if(auth()->guard()->check()): ?>
                    <div class="favourite">
                        <a href="<?php echo e(url('favourite-user/'.Crypt::encrypt($post_details->id))); ?>"><i class="fa-regular fa-heart fa-2x fw-lighter <?php echo e((favourite($post_details->id) == 1) ? 'text-danger' : ''); ?> me-2"></i></a>
                    </div>
                    <?php endif; ?>
                    <div class="msg_btn">
                        <a href="<?php echo e(url('chat/'.$post_details->user_id)); ?>">
                            <?php echo e(__('trans.Message')); ?>

                        </a>
                    </div>
                    <div class="justify-content-between align-items-center d-flex">
                        <div class="d-flex align-items-center">
                            <div class="user_profile flex-column d-flex text-center">
                                <strong><?php echo e(get_user($post_details->user_id)->name.' '.get_user($post_details->user_id)->lname); ?></strong>
                                <small><?php echo e(get_user($post_details->user_id)->email); ?></small>
                            </div>
                            <a href="<?php echo e(url('profile/'.Crypt::encrypt($post_details->user_id))); ?>">

                                <?php if(empty(get_user($post_details->user_id)->profile_pic)): ?>
                                    <img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="user" class="img-fluid"  width="32" height="32">
                                    <?php else: ?>
                                    <img src="<?php echo e(url(env('img_path'). get_user($post_details->user_id)->profile_pic)); ?>" alt="user" class="img-fluid" width="32" height="32">
                                <?php endif; ?>

                            </a>
                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- /////////////// -->
            <div class="col-md-6 _boxzoom">
                <div class="zoom-thumb">
                    <ul class="piclist">
                        <?php $__currentLoopData = $post_img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgkey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="thumb_image_ my-2">
                            <img class="img-fluid" src="<?php echo e(url(env('img_path').$imgkey->img )); ?>" alt="">
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="_product-images">
                    <div class="picZoomer">
                        <img class="my_img img-fluid" src="<?php echo e(url(env('img_path').post_img($post_details->id)->img )); ?>" alt="">
                    </div>
                </div>
            </div>
            <style>
            /* START MODULE STYLING */
            .slider-preview {
            margin-bottom: 15px;
            }
            .slider-preview img {
            width: 100%;
            min-height: 100%;
            }
            .slider-thumb .thumb_image img {
            max-width: 100%;
            height: auto;
            background-size: cover;
            background-position: center;
            }
            .slider-preview .preview_image img {
            max-width: 100%;
            height: auto;
            background-size: cover;
            background-position: center;
            }
            .product_detail .slider-wrapper {
            display: flex;
            overflow: hidden;
            }
            .product_detail .slider-thumb {
            max-width: 125px;
            }
            .product_detail .slider-thumb li {
            max-height: 100px;
            }
            .slick-track .slick-track {
            display: none;
            }
            @media (max-width: 767px) {
            .product_detail .slider-wrapper {
            flex-direction: column-reverse;
            }
            .product_detail .slider-thumb {
            max-width: 100%;
            }
            }
            </style>
            <div class="col-md-6 col-lg-6 col-12">
                <div class="row">
                    <div class="col-12 pt-2 largescreenlistinghead">
                        <div class=" d-flex justify-content-between align-items-center">
                            <div class="country">
                                <a href="#"><img src="<?php echo e(url('public/theme_assets/images/flag/saudiarabia.png')); ?>" class="me-2"
                                alt="saudiarabia" width="32" height="32"><?php echo e(__('trans.SAR')); ?></a>
                            </div>
                            <?php if(auth()->guard()->check()): ?>
                            <div class="favourite">
                                <a href="<?php echo e(url('favourite-user/'.Crypt::encrypt($post_details->id))); ?>"><i class="fa-regular fa-heart fa-2x fw-lighter <?php echo e((favourite($post_details->id) == 1) ? 'text-danger' : ''); ?>"></i></a>
                            </div>
                            <?php endif; ?>
                            
                            <div class="msg_btn">
                                <a href="<?php echo e(url('chat/'.$post_details->user_id)); ?>"><?php echo e(__('trans.Message')); ?></a>
                            </div>
                            <div class="user_profile justify-content-between align-items-center d-flex">
                                <div class="d-flex align-items-center">
                                    <div class="flex-column d-flex text-center">
                                        <strong><?php echo e(get_user($post_details->user_id)->name.' '.get_user($post_details->user_id)->lname); ?></strong>
                                        <small><?php echo e(get_user($post_details->user_id)->email); ?></small>
                                    </div>
                                <a href="<?php echo e(url('profile/'.Crypt::encrypt($post_details->user_id))); ?>">
                                <?php if(empty(get_user($post_details->user_id)->profile_pic)): ?>
                                    <img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="user" class="img-fluid me-2"  width="32" height="32">
                                    <?php else: ?>
                                    <img src="<?php echo e(url(env('img_path'). get_user($post_details->user_id)->profile_pic)); ?>" alt="user" class="img-fluid me-2" width="32" height="32">
                                <?php endif; ?>
                                    </a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="col-12">
                    <div class="product_heading pt-5">
                        <h5><?php echo e($post_details->product_name); ?></h5>
                    </div>
                    <div class="product_time pt-2" dir="<?php echo e(($code == 'en') ? 'ltr' : 'rtl'); ?>">
                        <p class="mb-0"><?php echo e(__('trans.live auction begins on')); ?>:</p>
                        <p class="mb-0"><?php echo e(\Carbon\Carbon::parse($post_details->created_at)->isoFormat('Do MMMM h:mm a')); ?> (<?php echo e(__('trans.GMT')); ?>+3) <?php echo e(__('trans.KSA')); ?></p>
                    </div>
                    <div class="divide_line pt-2"></div>
                    <div class="product_time pt-2 d-none">
                        <p class="mb-0">Estimate:</p>
                        <p class="mb-0">7,000 - 10,000 SAR</p>
                    </div>
                    <div class="divide_line"></div>


            <?php if($post_details->type == 'auction'): ?>
                <form action="<?php echo e(route('do-bid')); ?>" method="POST" class="">
                <?php echo csrf_field(); ?>
                <div class="bid mt-4">
                    <div class="d-grid">
                        <button class="btn shadow-none" type="submit">  <?php echo e(__('trans.Place Bid')); ?></button>
                    </div>
                    <div class="p-1">
                        <input type="hidden" name="post_id" value="<?php echo e($post_details->id); ?>">
                        <input type="hidden" name="start_bid" value="<?php echo e($post_details->starting_bid); ?>">
                        <input type="hidden" name="seller_id" value="<?php echo e($post_details->user_id); ?>">
                        <?php if(auth()->guard()->check()): ?>
                        <input type="hidden" name="buyer_id" value="<?php echo e(auth()->user()->id); ?>">
                        <input type="hidden" name="user_type" value="<?php echo e(auth()->user()->type); ?>">
                        <?php endif; ?>
                        <input type="number" name="bid_amount" class="form-control shadow-none" id="exampleFormControlInput1" placeholder="Add Amount" required>
                    </div>
                    <div class="text-center pb-1">
                        
                        <small><?php echo e(__('trans.Starting bid')); ?>: <?php echo e($post_details->starting_bid); ?> <?php echo e(__('trans.SAR')); ?></small>
                    </div>
                </div>
            </form>
            <?php else: ?>
            <div class="d-flex align-items-center" dir="<?php echo e(($code == 'en') ? 'ltr' : 'rtl'); ?>">
                <a href="<?php echo e(url('chat/'.$post_details->user_id)); ?>" class="card_bidbtn mt-3 <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Contract')); ?></a>
            </div>
            <?php endif; ?>
            


                </div>
                <!-- ////////////// -->
                <div class="col-12 user_detailssmall">
                    <div class="card border-0 pt-3">
                        <ul class="list-group list-group-flush">

                            <?php $__currentLoopData = $latestBids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex align-items-center justify-content-between">
                                <?php if(empty(get_user($bider->buyer_id)->profile_pic)): ?>
                                    <img class="rounded-circle shadow-1-strong me-3" src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="user" class="img-fluid" width="66" height="66">
                                    <?php else: ?>
                                    <img class="rounded-circle shadow-1-strong" src="<?php echo e(url(env('img_path'). get_user($bider->buyer_id)->profile_pic)); ?>" alt="user" class="img-fluid" width="66" height="66">
                                <?php endif; ?>

                                <p class="mb-0">
                                    <?php echo e(get_user($bider->buyer_id)->name.' '.get_user($bider->buyer_id)->lname); ?>

                                </p>
                                <p class="mb-0"><?php echo e($bider->bid_amount); ?> <?php echo e(__('trans.SAR')); ?></p>
                                <div class="btn-group dropend custom_dropdown user_dropbtn">
                                    <button type="button" class="btn dropdown-toggle"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fa-solid fa-ellipsis-vertical"></i>
                                    </button>
                                    <ul class="dropdown-menu drop_menu profiledrop rounded-3 ms-3">



                                    <?php if(auth()->guard()->check()): ?>
                                    <?php if($post_details->user_id == auth()->user()->id): ?>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(url('block-user/'.Crypt::encrypt($post_details->id).'/'.Crypt::encrypt($bider->buyer_id))); ?>">

                                            <?php echo e((block_user($post_details->id,$bider->buyer_id) == 1) ? __('trans.Unblock user') : __('trans.block user')); ?>


                                        </a>
                                    </li>
                                     <?php endif; ?>
                                     <?php endif; ?>


                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(url('profile/'.Crypt::encrypt($bider->buyer_id))); ?>"><?php echo e(__('trans.visit profile')); ?></a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            

                            
                        </ul>
                    </div>
                </div>
                <!-- ////////////// -->
            </div>
        </div>
    </div>
</div>
</section>
<!-- ============================== product detail End==============================-->
<!-- ============================== product user chet Start==============================-->
<section class="gradient-custom <?php echo e(session('ar_class')); ?>">
<div class="container-fluid">
    <div class="row d-flex justify-content-center">
        <div class="col-md-6 col-lg-6 col-xl-6 col-12">
            <div class="divide_line"></div>
            <ul class="nav nav-pills mb-3 product_navs gap-3" id="pills-tab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active px-0" id="pills-about-tab" data-bs-toggle="pill"
                    data-bs-target="#pills-about" type="button" role="tab" aria-controls="pills-about"
                    aria-selected="true"><?php echo e(__('trans.Ask a question about this item')); ?></button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link px-0" id="pills-dec-tab" data-bs-toggle="pill"
                    data-bs-target="#pills-dec" type="button" role="tab" aria-controls="pills-dec"
                    aria-selected="false"><?php echo e(__('trans.description')); ?></button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link px-0" id="pills-info-tab" data-bs-toggle="pill"
                    data-bs-target="#pills-info" type="button" role="tab" aria-controls="pills-info"
                    aria-selected="false"><?php echo e(__('trans.additional information')); ?></button>
                </li>
            </ul>
<div class="tab-content" id="pills-tabContent">
<div class="tab-pane fade show active" id="pills-about" role="tabpanel"
aria-labelledby="pills-about-tab" tabindex="0">
<div class="card conversation border-0">
    <div class="card-body p-md-4">
        <div class="row">
            <div class="col">
                <div class="d-flex flex-start">

                    <?php if(auth()->guard()->check()): ?>
                    <?php if(empty(auth()->user()->profile_pic)): ?>
                    <img class="rounded-circle shadow-1-strong me-3"
                    src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="avatar" width="66"
                    height="66"/>
                    <?php else: ?>
                    <img class="rounded-circle shadow-1-strong me-3"
                    src="<?php echo e(url(env('img_path'). auth()->user()->profile_pic)); ?>" alt="avatar" width="66"
                    height="66"/>
                    <?php endif; ?>
                    <?php endif; ?>
                    <div class="flex-grow-1 flex-shrink-1">
                        <div>
                            <?php if(auth()->guard()->check()): ?>
                            <?php if($isBuyer): ?>
                                <div class="d-flex justify-content-start">
                                <h6 class="mb-1">
                                <?php echo e(__('trans.bid')); ?>: <?php echo e($latest_bider->bid_amount); ?> <?php echo e(__('trans.sar')); ?>

                                </h6>
                            </div>
                            <?php endif; ?>
                            <?php endif; ?>
                            
                            <form action="<?php echo e(route('add-comment')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                                <div>
                                <input type="hidden" name="post_id" value="<?php echo e($post_details->id); ?>">
                                <input type="hidden" name="seller_id" value="<?php echo e($post_details->user_id); ?>">
                                <?php if(auth()->guard()->check()): ?>
                                <input type="hidden" name="buyer_id" value="<?php echo e(auth()->user()->id); ?>">
                                <?php endif; ?>
                                    <textarea class="form-control shadow-none"
                                    id="formControlTextarea" placeholder="Ask a question"
                                    rows="3" name="comment"></textarea>
                                </div>
                                
                                <div class="bid_sendbtn mt-2">
                                      <button type="submit" class="btn btn-sm shadow-none"><?php echo e(__('trans.Send')); ?></button>
                                </div>
                            </form>
                        </div>
                       


                        <?php if($post_comments->isEmpty()): ?>
                            
                        <?php else: ?>
                        <?php $__currentLoopData = $post_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex flex-start mt-4">

                            <?php if($comment->seller_id == null): ?>
                            <a class="me-3" href="<?php echo e(url('profile/'.Crypt::encrypt($comment->buyer_id))); ?>">
                                <?php if(empty(get_user($comment->buyer_id)->profile_pic)): ?>
                                    <img class="rounded-circle shadow-1-strong" src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="user" class="img-fluid" width="66" height="66">
                                    <?php else: ?>
                                    <img class="rounded-circle shadow-1-strong" src="<?php echo e(url(env('img_path'). get_user($comment->buyer_id)->profile_pic)); ?>" alt="user" class="img-fluid" width="66" height="66">
                                <?php endif; ?>
                            </a>

                            <div class="flex-grow-1 flex-shrink-1">
                                <div>
                                    <div
                                        class="d-flex justify-content-between align-items-center">
                                        <h6 class="mb-1">
                                        <?php echo e(get_user($comment->buyer_id)->name); ?>

                                        </h6>
                                        <p class="mb-0" dir="<?php echo e(($code == 'en') ? 'ltr' : 'rtl'); ?>"> <?php echo e(\Carbon\Carbon::parse($comment->created_at)->isoFormat('Do MMMM')); ?></p>
                                    </div>
                                    <div>
                                        <p class="form-control shadow-none"
                                        id="formControlTextarea"
                                        placeholder="Ask a question"
                                        rows="3"><?php echo e($comment->comment); ?></p>
                                    </div>
                                </div>
                            </div>
                            <?php else: ?>
                            <a class="me-3" href="<?php echo e(url('profile/'.Crypt::encrypt($comment->seller_id))); ?>">
                                <?php if(empty(get_user($comment->seller_id)->profile_pic)): ?>
                                    <img class="rounded-circle shadow-1-strong" src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="user" class="img-fluid" width="66" height="66">
                                    <?php else: ?>
                                    <img class="rounded-circle shadow-1-strong" src="<?php echo e(url(env('img_path'). get_user($comment->seller_id)->profile_pic)); ?>" alt="user" class="img-fluid" width="66" height="66">
                                <?php endif; ?>
                            </a>
                            <div class="flex-grow-1 flex-shrink-1">
                                <div>
                                    <div
                                        class="d-flex justify-content-between align-items-center">
                                        <h6 class="mb-1">
                                        <?php echo e(get_user($comment->seller_id)->name); ?>

                                        </h6>
                                        <p class="mb-0" dir="<?php echo e(($code == 'en') ? 'ltr' : 'rtl'); ?>"> <?php echo e(\Carbon\Carbon::parse($comment->created_at)->isoFormat('Do MMMM')); ?></p>
                                    </div>
                                    <div>
                                        <p class="form-control shadow-none"
                                        id="formControlTextarea"
                                        placeholder="Ask a question"
                                        rows="3"><?php echo e($comment->comment); ?></p>
                                    </div>
                                </div>
                            </div>
                                <?php endif; ?>

                            
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        



                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div class="tab-pane fade" id="pills-dec" role="tabpanel" aria-labelledby="pills-dec-tab"
tabindex="0">
<div class="product_info p-4">
    <p><?php echo e($post_details->product_description); ?></p>
</div>
</div>
<div class="tab-pane fade" id="pills-info" role="tabpanel" aria-labelledby="pills-info-tab"
tabindex="0">
<div class="product_info p-4">
    <p><?php echo e($post_details->product_information); ?></p>
</div>
</div>
</div>
        </div>
        <div class="col-md-6 col-lg-6 col-xl-6 col-12">
            <div class="row">
                <div class="col-8">
                    <?php if($latestBids->isEmpty()): ?>
                        
                    <?php else: ?>
                    <div class="user_details">
                        <div class="card border-0" style="height:380px">
                            <ul class="list-group list-group-flush">

                        <?php $__currentLoopData = $latestBids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex align-items-center justify-content-between">
                                <?php if(empty(get_user($bider->buyer_id)->profile_pic)): ?>
                                    <img class="rounded-circle shadow-1-strong me-3" src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="user" class="img-fluid" width="66" height="66">
                                    <?php else: ?>
                                    <img class="rounded-circle shadow-1-strong" src="<?php echo e(url(env('img_path'). get_user($bider->buyer_id)->profile_pic)); ?>" alt="user" class="img-fluid" width="66" height="66">
                                <?php endif; ?>

                                <p class="mb-0">
                                    <?php echo e(get_user($bider->buyer_id)->name.' '.get_user($bider->buyer_id)->lname); ?>

                                </p>
                                <p class="mb-0"><?php echo e($bider->bid_amount); ?> <?php echo e(__('trans.SAR')); ?></p>
                                <div class="btn-group dropend custom_dropdown user_dropbtn">
                                    <button type="button" class="btn dropdown-toggle"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fa-solid fa-ellipsis-vertical"></i>
                                    </button>
                                    <ul class="dropdown-menu drop_menu profiledrop rounded-3 ms-3">

                                    <?php if(auth()->guard()->check()): ?>
                                    <?php if($post_details->user_id == auth()->user()->id): ?>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(url('block-user/'.Crypt::encrypt($post_details->id).'/'.Crypt::encrypt($bider->buyer_id))); ?>">

                                            <?php echo e((block_user($post_details->id,$bider->buyer_id) == 1) ? __('trans.Unblock user') : __('trans.block user')); ?>


                                        </a>
                                    </li>
                                     <?php endif; ?>
                                    <?php endif; ?>

                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(url('profile/'.Crypt::encrypt($bider->buyer_id))); ?>"><?php echo e(__('trans.visit profile')); ?></a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                


                            </ul>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
<!-- ============================== product user chet End==============================-->
<!-- ==============================Upcoming Auction Card Start ==============================-->
<section class="auction_cardtrack pt-5 similar_auction <?php echo e(session('ar_class')); ?>">
<div class="container">
    <div class="justify-content-between align-items-center d-flex">
        <div class="heading flex-column d-flex">
            <h4 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Similar auctions')); ?></h4>
        </div>
        <div class="me-md-5 all_auction d-none d-lg-block">
            <a href="<?php echo e(url('search')); ?>"><?php echo e(__('trans.View all')); ?></a>
        </div>
    </div>
</div>
<div class="container px-0 pb-5 m-auto">
    <div class="auctionslide__cards d-flex overflow-hidden">

            <?php if($similar_posts->isEmpty()): ?>
                    <p class="text-center">No similar products found.</p>
                <?php else: ?>
                <?php $__currentLoopData = $similar_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="px-2 py-5">
                <div class="card auction_card border-0 px-0">
                    <div class="text-center active_btn position-relative">
                        <a href="#" class="d-block position-absolute text-capitalize"><?php echo e($key->status); ?></a>
                        <img src="<?php echo e(url(env('img_path').post_img($key->id)->img )); ?>"
                            class="card-img-top img-fluid" alt="...">
                    </div>
                    <div class="card-body px-0 heading">
                        <a href="<?php echo e(url('tags/'.$key->slug)); ?>">
                            <h4 class="card-title mb-4"><?php echo e($key->product_name); ?></h4>
                        </a>
                        <p class="card_text d-flex"><small><?php echo e(\Carbon\Carbon::parse($key->created_at)->format('d F H:i')); ?></small>
                        </p>
                        <p class=" card_text d-flex mb-5"><small>(GMT+3) KSA</small></p>
                        <?php if($key->type == 'auction'): ?>
                            <div class="d-flex align-items-center justify-content-center">
                                <a href="<?php echo e(url('tags/'.$key->slug)); ?>" class="card_bidbtn"><?php echo e(__('trans.Bid')); ?></a>
                                
                            </div>
                            <?php else: ?>
                            <div class="d-flex align-items-center justify-content-center">
                                <a href="<?php echo e(url('chat/'.$key->user_id)); ?>" class="card_bidbtn <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Contract')); ?></a>
                            </div>
                            <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>


    </div>
    <div class="me-md-5 all_auction d-block d-lg-none text-center">
        <a href="<?php echo e(url('search')); ?>"><?php echo e(__('trans.View all')); ?></a>
    </div>
</div>
</section>
<?php echo $__env->make('theme_1.layouts.contact_us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/theme_1/post_details.blade.php ENDPATH**/ ?>