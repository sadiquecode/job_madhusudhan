<?php app()->setLocale(session('locale')); ?>
<?php $code = session('locale'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jeddah Mazad Website</title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(url('public/theme_assets/images/logo/OG Logo.png')); ?>" type="image/svgicon">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(url('public/theme_assets/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/theme_assets/default-font/Acumin-BdItPro.otf')); ?>">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(url('public/theme_assets/css/style.css')); ?>">
    <!-- Custom RTL CSS -->
    <!-- <link rel="stylesheet" href="<?php echo e(url('public/theme_assets/css/stylertl.css')); ?>"> -->
    <!-- Slick slider css  -->
    <link rel="stylesheet" href="<?php echo e(url('public/theme_assets/css/slick.css')); ?>">
    <!-- Slick slider theme css  -->
    <link rel="stylesheet" href="<?php echo e(url('public/theme_assets/css/slick-theme.css')); ?>">
    <!-- fontawesome kit  -->
    <script src="<?php echo e(url('public/theme_assets/js/kit-fontawesome.js')); ?>"></script>
 <!-- Select2 -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css')}}" rel="stylesheet" /> -->
    <link rel="stylesheet" href="<?php echo e(url('public/theme_assets/select-2/select2.min.css')); ?>">
</head>
</head>

<body>
    <header class="header_features fixed-top">
        <!-- ==============================Topbar Start==============================-->
        <div class="container-fluid topbar px-md-5">
            <nav class="navbar navbar-expand-lg py-0">

                <?php if(auth()->guard()->check()): ?>
                <ul class="navbar-nav">
                <?php if(auth()->user()->type == 'user'): ?>
                <li class="nav-item">
                    <a class="nav-link pt-0 <?php echo e(session('ar_class')); ?>" href="<?php echo e(url('profile/'.Crypt::encrypt(auth()->user()->id))); ?>"><?php echo e(__('trans.MY ACCOUNT')); ?></a>
                </li>
                <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link pt-0 <?php echo e(session('ar_class')); ?>" href="<?php echo e(url('dashboard')); ?>"><?php echo e(__('trans.MY ACCOUNT')); ?></a>
                </li>
                <?php endif; ?>
                </ul>
                <?php else: ?>
                <ul class="navbar-nav d-flex align-items-center">
                    <li class="list-unstyled nav-item dropdown custom_dropdown">
                        <a href="#" class="nav-link dropdown-toggle p-0 <?php echo e(session('ar_class')); ?>" data-bs-toggle="dropdown"
                            id="navbarDropdownMenu" role="button"><i class="fa-regular fa-user"></i>
                            <?php echo e(__('trans.MY ACCOUNT')); ?>

                        </a>
                        <ul class="dropdown-menu drop_menu rounded-0 <?php echo e(session('ar_class')); ?>" aria-labelledby="navbarDropdownMenu">
                            <li><a class="dropdown-item " href="<?php echo e(url('login')); ?>"><?php echo e(__('trans.Login')); ?></a></li>
                            <li><a class="dropdown-item" href="<?php echo e(url('register')); ?>"><?php echo e(__('trans.SignUp')); ?></a></li>

                            
                        </ul>
                    </li>
                </ul>
                <?php endif; ?>

                
                <?php if(auth()->guard()->check()): ?>
                <ul class="navbar-nav logout">
                    <li class="nav-item">
                        <a class="nav-link pt-0 text-uppercase <?php echo e(session('ar_class')); ?>" href="<?php echo e(url('logout')); ?>"><?php echo e(__('trans.Log out')); ?></a>
                    </li>
                </ul>
                <?php endif; ?>
                <div class="align-items-center navsbtns">
                    <ul class="navbar-nav d-flex align-items-center gap-lg-4">


                    <?php $__currentLoopData = $other_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $title = ($code == 'en') ? $key->heading_en : $key->heading_ar;
                        ?>

                        <?php if($key->slug == 'services' || $key->slug == 'about'): ?>
                            <li class="nav-item">
                                <a class="nav-link text-uppercase <?php echo e(session('ar_class')); ?>" href="<?php echo e(url('page/'.$key->slug)); ?>"><?php echo e($title); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <li class="nav-item dropdown custom_dropdown">
                            <a class="nav-link dropdown-toggle btn <?php echo e(session('ar_class')); ?>" href="#" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false">
                                <?php echo e(__('trans.Language')); ?>

                            </a>
                            <ul class="dropdown-menu drop_menu2 rounded-0 border-0 m-0">
                                <li>
                                    <a class="dropdown-item justify-content-center d-flex" href="<?php echo e(url('language/en')); ?>">
                                        English</a>
                                    </li>
                                <li>
                                    <a class="dropdown-item justify-content-center d-flex arabic" href="<?php echo e(url('language/ar')); ?>">
                                        عَرَبِيّ</a>
                                    </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <div class="bottom_line d-none d-md-block">
            <hr>
        </div>
        <!-- ==============================Topbar End==============================-->
        <!-- ==============================Navbar Start==============================-->
        <div class="container-fluid px-0 px-lg-5"style="box-shadow: 0px 15px 10px -15px #111;">
            <nav class="navbar navbar-expand-lg bottom_bar">
                <a href="<?php echo e(url('/')); ?>" class="navbar-brand branding ps-lg-0 ps-2">
                    <img src="<?php echo e(url('public/theme_assets/images/logo/Logojeddah_11zon.png')); ?>" alt="logo">
                </a>
                <div class=" ml-auto d-flex gap-3">
                    <div class="searchaddicon">
                        <div class=" d-flex align-items-center gap-3">
                            <ul class="p-0 m-0">
                                <li class="list-unstyled"><a href="<?php echo e(route('post.create')); ?>"><i class="fa-solid fa-circle-plus fs-3"></i></a>
                                </li>
                            </ul>
                            <ul class="p-0 m-0">
                                <li class="list-unstyled">
                                    <a href="#" class="btn float-end shadow-none" data-bs-toggle="offcanvas"
                                        data-bs-target="#offcanvas" role="button">
                                        <i class="fa-solid fa-magnifying-glass fs-3" data-bs-toggle="offcanvas"
                                            data-bs-target="#offcanvas"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <!-- /////////// -->
                        <div class="container-fluid">
                            <div class="offcanvas offcanvas-start w-100 h-75" tabindex="-1" id="offcanvas"
                                data-bs-keyboard="false" data-bs-backdrop="false">
                                <div class="offcanvas-header">
                                    <div class="search-box w-100">
                                    <form class="search-form d-flex align-items-center <?php echo e(session('ar_class')); ?>" method="GET" action="<?php echo e(url('search')); ?>">
                                        <img src="<?php echo e(url('public/theme_assets/images/icons/leftarrow_11x16.png')); ?>" alt="leftarrow"
                                        class="me-2">
                                        <input type="search" placeholder="<?php echo e(__('trans.Search')); ?>" title="<?php echo e(__('trans.Search')); ?>" name="custom_search" value="<?php echo e($custom_search ?? ''); ?>" />
                                        <button type="submit" title="<?php echo e(__('trans.Search')); ?>"><i
                                        class="fa-solid fa-magnifying-glass"></i></button>
                                    </form>
                                    </div>
                                    <button type="button" class="btn-close text-reset shadow-none ms-2"
                                        data-bs-dismiss="offcanvas" aria-label="Close"></button>
                                </div>
                                <div class="offcanvas-body offcanvasbody px-4 d-none">
                                    <h5 class="px-3">Top Searches</h5>
                                    <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-start" id="menu">
                                        <li class="nav-item">
                                            <a href="#" class="nav-link">
                                                <i
                                                    class="fa-solid fa-magnifying-glass me-3"></i>hermes
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#submenu1" data-bs-toggle="collapse"
                                                class="nav-link">
                                                                                              <i
                                                    class="fa-solid fa-magnifying-glass me-3"></i>rolex </a>
                                        </li>
                                        <li>
                                            <a href="#" class="nav-link">
                                                                                      <i
                                                    class="fa-solid fa-magnifying-glass me-3"></i>chanel</a>
                                        </li>
                                        <li>
                                            <a href="#" class="nav-link">
                                                                                             <i
                                                    class="fa-solid fa-magnifying-glass me-3"></i>louis vitton</a>
                                        </li>
                                        <li>
                                            <a href="#" class="nav-link">
                                                                                               <i
                                                    class="fa-solid fa-magnifying-glass me-3"></i>bracelet</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- /////////// -->
                    </div>
                    <button
                        class="navbar-toggler collapsed d-flex d-lg-none flex-column justify-content-around align-self-center me-lg-0 me-2"
                        type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="toggler-icon top-bar"></span>
                        <span class="toggler-icon middle-bar"></span>
                        <span class="toggler-icon bottom-bar"></span>
                    </button>
                </div>

            
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav justify-content-center m-auto gap-lg-4 ms_screennav_item">

                        <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $title = ($code == 'en') ? $key->gender_en : $key->gender_ar;
                        $url = url('search') . '?' . http_build_query(['gender[]' => $title]);
                        ?>

                        <li class="nav-item womenlarge">
                            <a class="nav-link <?php echo e(session('ar_class')); ?>" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal"><?php echo e($title); ?></a>
                        </li>

                        <li class="nav-item womensmall">
                            <a class="nav-link <?php echo e(session('ar_class')); ?>" href="<?php echo e($url); ?>"><?php echo e($title); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php $__currentLoopData = $manu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $title = ($code == 'en') ? $key->category_title_en : $key->category_title_ar;
                        $url = url('search') . '?' . http_build_query(['category[]' => $title]);
                        ?>

                        <li class="nav-item womenlarge">
                            <a class="nav-link <?php echo e(session('ar_class')); ?>"  type="button" data-bs-toggle="modal" data-bs-target="#BrandModal_<?php echo e($key->id); ?>"><?php echo e($title); ?></a>
                        </li>

                        <li class="nav-item womensmall">
                            <a class="nav-link <?php echo e(session('ar_class')); ?>" href="<?php echo e($url); ?>"><?php echo e($title); ?></a>
                        </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="bottom_line px-0 d-block d-md-none w-100">
                        <hr>
                    </div>
                    <div class="small_screennav">
                        <ul class="navbar-nav pt-2">
                        <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item">
                            <a class="nav-link text-uppercase <?php echo e(session('ar_class')); ?>" aria-current="page" href="<?php echo e(url('logout')); ?>"><?php echo e(__('trans.Log out')); ?></a>
                        </li>
                        <?php endif; ?>
                            <div class="nav-item dropdown custom_dropdown">
                                <a href="#" class="nav-link dropdown-toggle p-0 <?php echo e(session('ar_class')); ?>" data-bs-toggle="dropdown"
                                    id="navbarDropdownMenu" role="button">
                                    <?php echo e(__('trans.MY ACCOUNT')); ?>

                                </a>
                                <ul class="dropdown-menu drop_menu rounded-0 m-0 <?php echo e(session('ar_class')); ?>" aria-labelledby="navbarDropdownMenu">
                                    <?php if(auth()->guard()->check()): ?>
                                    <?php if(auth()->user()->type == 'user'): ?>
                                    <li><a class="dropdown-item" href="<?php echo e(url('profile/'.Crypt::encrypt(auth()->user()->id))); ?>"><?php echo e(__('trans.Profile')); ?></a>
                                    </li>
                                    <?php else: ?>
                                    <li><a class="dropdown-item" href="<?php echo e(url('dashboard')); ?>"><?php echo e(__('trans.Profile')); ?></a>
                                    </li>
                                    <?php endif; ?>
                                    
                                    <?php else: ?>
                                    <li><a class="dropdown-item" href="<?php echo e(url('login')); ?>"><?php echo e(__('trans.Login')); ?></a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(url('register')); ?>"><?php echo e(__('trans.SignUp')); ?></a></li>
                                    <?php endif; ?>
                                    

                                    

                                </ul>
                            </div>

                    <?php $__currentLoopData = $other_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $title = ($code == 'en') ? $key->heading_en : $key->heading_ar;
                        ?>

                        <?php if($key->slug == 'services' || $key->slug == 'about'): ?>
                            <li class="nav-item">
                                <a class="nav-link text-uppercase <?php echo e(session('ar_class')); ?>" href="<?php echo e(url('page/'.$key->slug)); ?>"><?php echo e($title); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <li class="nav-item dropdown custom_dropdown">
                                <a class="nav-link dropdown-toggle btn p-0 d-flex align-items-center gap-0 <?php echo e(session('ar_class')); ?>" href="#"
                                    role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <?php echo e(__('trans.Language')); ?>

                                </a>
                                <ul class="dropdown-menu drop_menu2 rounded-0 border-0 m-0">
                                    <li><a class="dropdown-item justify-content-center d-flex" href="<?php echo e(url('language/en')); ?>">
                                            English</a></li>
                                    <li><a class="dropdown-item justify-content-center d-flex arabic" href="<?php echo e(url('language/ar')); ?>">
                                            عَرَبِيّ</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="ml-auto d-flex gap-3">
                        <div class="navbar-nav add_post justify-content-between align-items-center d-flex">
                            <div class="nav-item">
                                <a class="nav-link p-0  d-flex align-items-center" href="<?php echo e(route('post.create')); ?>"><i
                                        class="fa-solid fa-circle-plus"></i>
                                    <span style="line-height: 17px;" class="<?php echo e(session('ar_class')); ?> text-uppercase"><?php echo e(__('trans.Add')); ?> <br>
                                        <?php echo e(__('trans.post')); ?></span></a>
                            </div>
                        </div>
                        <div class="search-bar">
                            <form class="search-form d-flex align-items-center <?php echo e(session('ar_class')); ?>" method="GET" action="<?php echo e(url('search')); ?>">
                                <input type="search" placeholder="<?php echo e(__('trans.Search')); ?>" title="<?php echo e(__('trans.Search')); ?>" name="custom_search" value="<?php echo e($custom_search ?? ''); ?>" />
                                <button type="submit" title="<?php echo e(__('trans.Search')); ?>"><i
                                        class="fa-solid fa-magnifying-glass"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
        <!-- ==============================Navbar End==============================-->
    </header>


<?php $__currentLoopData = $manu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Modal -->
<div class="modal fade brandmodal" id="BrandModal_<?php echo e($key->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-body">
                <div class="row">
                    <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $url = url('search') . '?' . http_build_query(['brand[]' => $brand_data->brand_title_en]); ?>
                    <?php if(get_category_brand($key->id)->contains('brand_id', $brand_data->id)): ?>
                    <div class="col-sm-1 col-md-1 col-lg-1 col-1 px-0 g-0">
                        <div class="brand_content">
                            <a href="<?php echo e($url); ?>">
                                <img src="<?php echo e(url(env('img_path'). $brand_data->brand_logo)); ?>" alt="brand" class="img-fluid" width="80" height="80">
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





<!-- Modal -->
<div class="modal fade brandmodal" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-body">
                <div class="row">

<?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php 
    $url = url('search') . '?' . http_build_query(['brand[]' => $brand_data->brand_title_en]);
    ?>
<div class="col-sm-1 col-md-1 col-lg-1 col-1 px-0 g-0">
    <div class="brand_content">
    <a href="<?php echo e($url); ?>">
        <img src="<?php echo e(url(env('img_path'). $brand_data->brand_logo)); ?>" alt="brand" class="img-fluid" width="80" height="80">
    </a>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </div>
            </div>
        </div>
    </div>
</div>

    <!-- ==============================BanModalner End==============================--><?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/theme_1/layouts/head.blade.php ENDPATH**/ ?>