<?php if($message->from_user == \Auth::user()->id): ?>

<div class="row msg_container base_sent d-none" data-message-id="<?php echo e($message->id); ?>">
    <div class="col-md-10 col-xs-10">
        <div class="messages msg_sent text-right">
            <p><?php echo $message->content; ?></p>
            <time datetime="<?php echo e(date("Y-m-dTH:i", strtotime($message->created_at->toDateTimeString()))); ?>"><?php echo e($message->fromUser->name); ?> • <?php echo e($message->created_at->diffForHumans()); ?></time>
        </div>
    </div>
    <div class="col-md-2 col-xs-2 avatar">
        <img src="<?php echo e(url('images/user-avatar.png')); ?>" width="50" height="50" class="img-responsive">
    </div>
</div>

<li class="sender d-flex justify-content-between">
    <img class="rounded-pill me-2 align-self-start" src="<?php echo e(url('public/theme_assets/images/user/user1.png')); ?>" alt="user img" width="38" height="38">
    <div class="flex-column">
        <p> I just have a couple of question to see if it’s the right fit
        for us</p>
        <span class="time">10:16 am</span>
    </div>
</li>





<?php else: ?>

<li class="repaly d-flex justify-content-between">
    <div class="flex-column">
        <p> Hey Kassem, thanks for reaching out. Would love to set up some
            time to chat with you more about your needs. What’s a
        good number to reach you at?</p>
        <span class="time text-end">10:30 am</span>
    </div>
    <img class="rounded-pill ms-2 align-self-end"
    src="<?php echo e(url('public/theme_assets/images/user/user1.png')); ?>" alt="user img" width="38"
    height="38">
</li>

<div class="row msg_container base_receive d-none" data-message-id="<?php echo e($message->id); ?>">
    <div class="col-md-2 col-xs-2 avatar">
        <img src="<?php echo e(url('images/user-avatar.png')); ?>" width="50" height="50" class=" img-responsive ">
    </div>
    <div class="col-md-10 col-xs-10">
        <div class="messages msg_receive text-left">
            <p><?php echo $message->content; ?></p>
            <time datetime="<?php echo e(date("Y-m-dTH:i", strtotime($message->created_at->toDateTimeString()))); ?>"><?php echo e($message->fromUser->name); ?> • <?php echo e($message->created_at->diffForHumans()); ?></time>
        </div>
    </div>
</div>

<?php endif; ?><?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/theme_1/message-line.blade.php ENDPATH**/ ?>