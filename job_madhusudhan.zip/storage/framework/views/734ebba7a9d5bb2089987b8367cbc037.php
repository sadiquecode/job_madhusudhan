<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-3">
                    <h4 class="page-title"><?php echo e($head); ?></h4>
                </div>
            </div>
            <div class="row filter-row">
                <div class="col-sm-12 col-md-12">
                    <form id="FaqlanguageForm" method="GET" action="<?php echo e($url); ?>">
                        <div class="form-group form-focus select-focus">
                            <label class="focus-label">Language</label>
                            <select class="select floating" id="FaqlanguageSelect" name="lang_code">
                                
                                <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($lang->code == $code): ?>
                                <option value="<?php echo e($lang->code); ?>" selected><?php echo e($lang->name); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($lang->code); ?>"><?php echo e($lang->name); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </form>
                </div>
            </div>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-sm-4 col-md-4 col-lg-4 col-xl-3">
                    <div class="roles-menu">
                        <ul>
                            <li class="<?php if($head == 'Main Page'): ?><?php echo e('active'); ?><?php endif; ?>">
                                <a href="<?php echo e(url('webpage')); ?>">Home</a>
                            </li>
                            <li class="<?php if($head == 'Features Page'): ?><?php echo e('active'); ?><?php endif; ?>">
                                <a href="<?php echo e(url('featurepage')); ?>">Features</a>
                            </li>
                            <li class="<?php if($head == 'Blog Page'): ?><?php echo e('active'); ?><?php endif; ?>">
                                <a href="<?php echo e(url('blogpage')); ?>">Blog</a>
                            </li>
                            <li class="<?php if($head == 'Price Page'): ?><?php echo e('active'); ?><?php endif; ?>">
                                <a href="<?php echo e(url('pricingpage')); ?>">Pricing</a>
                            </li>
                            <li class="<?php if($head == 'Signin Page'): ?><?php echo e('active'); ?><?php endif; ?>">
                                <a href="<?php echo e(url('signinpage')); ?>">Sign in</a>
                            </li>
                            <li class="<?php if($head == 'SignUp Page'): ?><?php echo e('active'); ?><?php endif; ?>">
                                <a href="<?php echo e(url('signuppage')); ?>">Sign Up</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <?php echo $__env->make('web.forms.'.$form, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/web/webpage.blade.php ENDPATH**/ ?>