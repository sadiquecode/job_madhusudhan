<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">
<div class="content container-fluid">
    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
    <?php endif; ?>

    <?php if (Auth::user()->type == 'admin') { ?>


    <div class="row">
        <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
            <div class="dash-widget dash-widget5">
                <span class="dash-widget-icon bg-success">
                    <i class="far fa-copy"></i>
                </span>
                <div class="dash-widget-info">
                    <h3><?php echo e($report['module']['words']); ?></h3>
                    <span>Words Generated</span>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
            <div class="dash-widget dash-widget5">
                <span class="dash-widget-icon bg-info">
                    <i class="fa fa-image"></i>
                </span>
                <div class="dash-widget-info">
                    <h3><?php echo e($report['module']['image']); ?></h3>
                    <span>Image Generated</span>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
            <div class="dash-widget dash-widget5">
                <span class="dash-widget-icon bg-warning">
                    <i class="fa fa-code"></i>
                </span>
                <div class="dash-widget-info">
                    <h3><?php echo e($report['module']['code']); ?></h3>
                    <span>Code Generated</span>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
            <div class="dash-widget dash-widget5">
                <span class="dash-widget-icon bg-danger">
                    <i class="fa fa-microphone"></i>
                </span>
                <div class="dash-widget-info">
                    <h3><?php echo e($report['module']['speech']); ?></h3>
                    <span>Speech to Text</span>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8">
            <div class="card-box">
                <style type="text/css">
                .highcharts-credits{
                display: none;
                }
                </style>
                <div id="used_words"></div>
            </div>
        </div>
        <div class="col-lg-6 col-md-12 col-sm-12 col-xl-4">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title text-center">All Modules Report</h4>
                    <div id="donutChart_" class="rad-chart"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-table">
                <div class="card-header bg-white">
                    <h4 class="card-title m-b-0">Recent Projects</h4>
                </div>
                <?php if(count($documents) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped custom-table m-b-0">
                        <thead>
                            <tr>
                                <th>S/L</th>
                                <th>Project Name</th>
                                <th>Created Date</th>
                                <th>Type</th>
                                <th>Words/Size</th>
                                <th class="text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($index + 1); ?></td>
                                    
                                    <td>
                                        <i class="text-secondary p-2 <?php echo e($doc->type === 'Content' ? 'fa fa-file' :
                                        ($doc->type === 'Code' ? 'fa fa-code' :
                                        ($doc->type === 'Image' ? 'fa fa-image' :
                                        ($doc->type === 'Transcript' ? 'fa fa-microphone' : '')))); ?>">
                                        </i>
                                        <?php echo e($doc->project_name); ?>

                                    </td>
                                    <td><?php echo e($doc->created_date); ?></td>
                                    <td><?php echo e($doc->type); ?></td>
                                    <td><?php echo e($doc->words_size); ?></td>
                                    <td class="text-right">
                                        <div class="dropdown dropdown-action">
                                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <?php if($doc->type === 'Image'): ?>
                                                <a class="dropdown-item" href="<?php echo e($doc->content); ?>" download><i class="fas fa-download m-r-5"></i> Download</a>
                                                <?php else: ?>
                                                <a class="dropdown-item" href="<?php echo e(route('documents.edit', $doc->id)); ?>"><i class="fas fa-pen m-r-5"></i> Edit</a>
                                                <?php endif; ?>
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_documnet_<?php echo e($doc->id); ?>"><i class="far fa-trash-alt m-r-5"></i> Delete</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <div id="delete_documnet_<?php echo e($doc->id); ?>" class="modal custom-modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content modal-md">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Delete Client</h4>
                                            </div>
                                            <form action="<?php echo e(route('documents.destroy', $doc->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <div class="modal-body card-box">
                                                    <p>Are you sure want to delete this?</p>
                                                    <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer bg-white text-center">
                    <a href="<?php echo e(route('documents.index')); ?>" class="text-muted">View all projects</a>
                </div>
            <?php else: ?>
            <p class="p-4"><?php echo e('Projects Not Found!'); ?></p>
            <?php endif; ?>
            </div>
        </div>
    </div>

<!-- User Dashboard -->
    <?php }else{?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-lg-12 col-xl-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <div class="profile-pic">

                        <?php if(empty($current_user->profile_pic)): ?>
                            <img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" class="img-thumbnail rounded-circle" alt="Profile Picture" height="140" width="140">
                            <?php else: ?>
                            <img src="<?php echo e(url(env('img_path') . $current_user->profile_pic)); ?>" class="img-thumbnail rounded-circle" alt="Profile Picture" height="140" width="140">
                        <?php endif; ?>

                            
                        </div>
                        <div class="profile-details ml-4 text-left">
                            <h5 class="card-title"><?php echo e($current_user->name); ?></h5>
                            <p class="card-text"><i class="fas fa-phone-square-alt"></i> <?php echo e($current_user->phone); ?></p>
                            <p class="card-text"><i class="fas fa-envelope"></i> <?php echo e($current_user->email); ?></p>
                        </div>
                    </div>
                    <span class="mt-5"><b><?php echo e($report['used_words']); ?></b> Used out of <b><?php echo e($report['useable_words']); ?></b> Words</span>
                    <div class="progress">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: <?php echo e($report['percentage']); ?>%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"><?php echo e($report['percentage']); ?>%</div>
                    </div>
                    <style>.four_btn{border-radius: 0px !important;}</style>
                    <div class="mt-4 d-flex justify-content-between">
                        <a href="<?php echo e(route('dashboard')); ?>" class="four_btn btn-sm btn btn-primary border-0 flex-grow-1 mr-2">Overview</a>
                        <a href="<?php echo e(route('subscription-packages.index')); ?>" class="four_btn btn-sm btn btn-secondary flex-grow-1 mr-2">Subscriptions</a>
                        <a href="<?php echo e(route('subscription-packages.index')); ?>" class="four_btn btn-sm btn btn-success flex-grow-1 mr-2">Histories</a>
                        <a href="<?php echo e(url('dashboard/profile/'.encrypt(Auth::user()->id))); ?>" class="four_btn btn-sm btn btn-danger flex-grow-1">Profile</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-sm-12 col-lg-12 col-xl-6">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-6">
                    <div class="dash-widget dash-widget5">
                        <span class="dash-widget-icon bg-success">
                            <i class="far fa-copy"></i>
                        </span>
                        <div class="dash-widget-info">
                            <h3><?php echo e($report['module']['words']); ?></h3>
                            <span>Words Generated</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-6">
                    <div class="dash-widget dash-widget5">
                        <span class="dash-widget-icon bg-info">
                            <i class="fa fa-image"></i>
                        </span>
                        <div class="dash-widget-info">
                            <h3><?php echo e($report['module']['image']); ?></h3>
                            <span>Image Generated</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-6">
                    <div class="dash-widget dash-widget5">
                        <span class="dash-widget-icon bg-warning">
                            <i class="fa fa-code"></i>
                        </span>
                        <div class="dash-widget-info">
                            <h3><?php echo e($report['module']['code']); ?></h3>
                            <span>Code Generated</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-6 col-xl-6">
                    <div class="dash-widget dash-widget5">
                        <span class="dash-widget-icon bg-danger">
                            <i class="fa fa-microphone"></i>
                        </span>
                        <div class="dash-widget-info">
                            <h3><?php echo e($report['module']['speech']); ?></h3>
                            <span>Speech to Text</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-8">
            <div class="card-box">
                <style type="text/css">
                .highcharts-credits{
                display: none;
                }
                </style>
                <div id="used_words"></div>
            </div>
        </div>
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-4">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title text-center">All Modules Report</h4>
                    <div id="donutChart_" class="rad-chart"></div>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-md-12">
            <div class="card card-table">
                <div class="card-header bg-white">
                    <h4 class="card-title m-b-0">Recent Projects</h4>
                </div>
                <?php if(count($documents) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped custom-table m-b-0">
                        <thead>
                            <tr>
                                <th>S/L</th>
                                <th>Project Name</th>
                                <th>Created Date</th>
                                <th>Type</th>
                                <th>Words/Size</th>
                                <th class="text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($index + 1); ?></td>
                                    
                                    <td>
                                        <i class="text-secondary p-2 <?php echo e($doc->type === 'Content' ? 'fa fa-file' :
                                        ($doc->type === 'Code' ? 'fa fa-code' :
                                        ($doc->type === 'Image' ? 'fa fa-image' :
                                        ($doc->type === 'Transcript' ? 'fa fa-microphone' : '')))); ?>">
                                        </i>
                                        <?php echo e($doc->project_name); ?>

                                    </td>
                                    <td><?php echo e($doc->created_date); ?></td>
                                    <td><?php echo e($doc->type); ?></td>
                                    <td><?php echo e($doc->words_size); ?></td>
                                    <td class="text-right">
                                        <div class="dropdown dropdown-action">
                                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <?php if($doc->type === 'Image'): ?>
                                                <a class="dropdown-item" href="<?php echo e($doc->content); ?>" download><i class="fas fa-download m-r-5"></i> Download</a>
                                                <?php else: ?>
                                                <a class="dropdown-item" href="<?php echo e(route('documents.edit', $doc->id)); ?>"><i class="fas fa-pen m-r-5"></i> Edit</a>
                                                <?php endif; ?>
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_documnet_<?php echo e($doc->id); ?>"><i class="far fa-trash-alt m-r-5"></i> Delete</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <div id="delete_documnet_<?php echo e($doc->id); ?>" class="modal custom-modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content modal-md">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Delete Client</h4>
                                            </div>
                                            <form action="<?php echo e(route('documents.destroy', $doc->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <div class="modal-body card-box">
                                                    <p>Are you sure want to delete this?</p>
                                                    <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer bg-white text-center">
                    <a href="<?php echo e(route('documents.index')); ?>" class="text-muted">View all projects</a>
                </div>
            <?php else: ?>
            <p class="p-4"><?php echo e('Projects Not Found!'); ?></p>
            <?php endif; ?>
            </div>
        </div>
    </div>

    <?php }?>
    <div class="themes">
        <div class="themes-icon"><i class="fa fa-cog"></i></div>
        <div class="themes-body">
            <ul id="theme-change" class="theme-colors">
                <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(url('change/theme').'/'.$theme->color); ?>"><span class="<?php echo e($theme->color); ?>"></span></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>

</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH G:\server\htdocs\advance_ai\resources\views/main/dashboard.blade.php ENDPATH**/ ?>