<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.teachme_filters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Main content -->
  <main class="bg-white">
    <div class="container pt-4 pb-6">
      <!-- Bread crumbs -->
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb fw-medium">
          <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>" class="text-decoration-none text-warning-hover">Home</a></li>
          <li class="breadcrumb-item active" aria-current="page">Tutors</li>
        </ol>
      </nav>

      <h1 class="pt-4 pb-5 fs-2 fw-semibold">Best tutors in <?php if(isset($_GET['location_id'])): ?>  <?php echo e(filter_data($_GET['location_id'], 'city')); ?>

              <?php else: ?>
              United Arab Emirates
            <?php endif; ?>
      </h1>

      <!-- Tutors List -->
      <ul class="list-unstyled row row-cols-1 row-cols-md-2 row-cols-xl-3 gx-4 gy-5">

        <?php if($tutor_list->isEmpty()): ?>
          <h5 class="px-3">No Results Found!</h5>
          <p>We're actively listing more tutors who are relevant to our platform. If you have any questions or suggestions, please reach out to us <a href="<?php echo e(url('contact-us')); ?>">here.</a></p>
        <?php else: ?>
        <?php $__currentLoopData = $tutor_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tutor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Column -->
    <li class="col">
        <!-- Card -->
        <a href="<?php echo e(url('tutor-profile/'.strtolower($tutor->name).'/'.$tutor->id)); ?>" class="card border-0 box-shadow-sm rounded-4 text-decoration-none">
            <div class="card-body d-flex flex-column gap-3 small" style="min-height: 370px;
    max-height: 370px;
">
                <!-- First Row -->
                <div class="d-flex gap-2">
                    <!-- Avatar -->
                    <?php if(is_it_paid_user($tutor->id) == 'yes'): ?>
                        <?php if($tutor->profile_pic): ?>
                            <img src="<?php echo e(url(env('img_path'). $tutor->profile_pic)); ?>" alt="<?php echo e($tutor->name); ?>" width="86" height="86" class="rounded-circle">
                        <?php else: ?>
                        <img src="<?php echo e(asset('public/theme_assets/images/icons/default_images.svg')); ?>" alt="<?php echo e($tutor->name); ?>" width="86" height="86" class="rounded-circle">
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if($tutor->blur_profile_pic): ?>
                        <img src="<?php echo e(url(env('img_path'). $tutor->blur_profile_pic)); ?>" alt="<?php echo e($tutor->name); ?>" width="86" height="86" class="rounded-circle">
                        <?php else: ?>
                        <img src="<?php echo e(asset('public/theme_assets/images/icons/default_images_blur.jpeg')); ?>" alt="<?php echo e($tutor->name); ?>" width="86" height="86" class="rounded-circle">
                        <?php endif; ?>
                    <?php endif; ?>
                    <!-- Info -->
                    <div>
                        <div class="fw-medium">
                            <span class="fs-6 m-0 text-decoration-none text-warning-hover text-black">
                                <?php if(is_it_paid_user($tutor->id) == 'yes'): ?>
                                    <?php echo e($tutor->name); ?>

                                <?php else: ?>
                                    <span style="font-size: 18px !important; color: transparent !important; text-shadow: 0 0 8px #00428b;"><?php echo e(str_repeat('*', strlen($tutor->name))); ?></span> 
                                <?php endif; ?>
                            </span>
                            <?php if($tutor->grade_names): ?>
                                <?php
                                    $grades = explode(',', $tutor->grade_names);
                                    $formatted_grades = implode(', ', $grades);
                                ?>
                                <p class="text-primary text-opacity-50" style="font-size:12px;"><?php echo e($formatted_grades); ?></p>
                            <?php endif; ?>
                        </div>
                        <!-- Badges -->
                        <div class="d-flex gap-1 ms-n5 ps-2">
                            <span class="badge rounded-pill bg-warning text-white py-1 px-2 fw-light">
                                <i class="fa-solid fa-star" aria-hidden="true"></i>
                                <?php echo e(averageRating($tutor->id)); ?>

                                <span class="visually-hidden">Rating</span>
                            </span>
                            <?php if($tutor->verification_status == 1): ?>
                                <span class="badge rounded-pill bg-success text-white py-1 px-2 fw-light">
                                    <i class="fa-regular fa-circle-check" aria-hidden="true"></i>
                                    verified
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <!-- Address -->
                <span class="fw-medium"><i class="fa-solid fa-location-dot me-1"></i><?php if($tutor->sub_location_names != null): ?>
                    <?php echo e($tutor->sub_location_names.' ,'); ?> <?php echo e($tutor->location_names); ?> 
                <?php endif; ?></span>
                <!-- Subjects -->
                <div>
                    <span class="fw-bold text-black">Subjects</span>
                    <ul class="list-unstyled mt-2 d-flex gap-2 flex-wrap">
                        <?php if(isset($tutor->subject_names)): ?>
                            <?php
                                $subjects = explode(',', $tutor->subject_names);
                                $remaining_subjects_count = count($subjects) - 3;
                            ?>
                            <?php $__currentLoopData = array_slice($subjects, 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge rounded-pill bg-warning-subtle py-2 px-2"><?php echo e($subject); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($remaining_subjects_count > 0): ?>
                                <span class="badge rounded-pill bg-warning-subtle py-2 px-3">+<?php echo e($remaining_subjects_count); ?></span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                    
                </div>
                <!-- Languages -->
                <div>
                    <span class="fw-bold text-black">Speaks</span>
                    <ul class="list-unstyled mt-2 d-flex gap-2 flex-wrap">
                        <?php if(isset($tutor->language_names)): ?>
                            <?php
                                $languages = explode(',', $tutor->language_names);
                                $remaining_languages_count = count($languages) - 3;
                            ?>
                            <?php $__currentLoopData = array_slice($languages, 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge rounded-pill bg-body-tertiary py-2 px-3"><?php echo e($language); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($remaining_languages_count > 0): ?>
                                <span class="badge rounded-pill bg-body-tertiary py-2 px-3">+<?php echo e($remaining_languages_count); ?></span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>


      </ul>
    </div>
  </main>

<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/teachme_find_tutors.blade.php ENDPATH**/ ?>