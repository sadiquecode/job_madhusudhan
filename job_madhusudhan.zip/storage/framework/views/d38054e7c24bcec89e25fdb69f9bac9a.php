<div class="header">
    <div class="header-left">
        <a href="<?php echo e(url('/dashboard')); ?>" class="logo">
            <img src="<?php echo e(url(env('img_path') .get_general_settings()->logo)); ?>" width="40" height="40" alt="">
        </a>
    </div>
    <div class="page-title-box float-left">
        <h3><?php echo e(get_general_settings()->website_name); ?></h3>
    </div>
    <a id="mobile_btn" class="mobile_btn float-left" href="#sidebar"><i class="fa fa-bars" aria-hidden="true"></i></a>
    <ul class="nav user-menu float-right">
        <?php
        $current_lang = get_user(auth()->id())->lang;
        $current_lang_code = get_active_lang($current_lang)->code;

        if(count(get_languages())  == 1){
            $arrow = '';
            $dropdown_menu = '';
        }else{
            $arrow = 'has-arrow';
            $dropdown_menu = 'dropdown-menu';
        }
        ?>
        <!-- Flag -->
        <li class="nav-item dropdown <?php echo e($arrow); ?> flag-nav">
            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button">
                <img src="<?php echo e(url('public/assets/img/flags/'.$current_lang_code.'.png')); ?>" alt="" height="20"> <span><?php echo e($current_lang); ?></span>
            </a>
            <div class="<?php echo e($dropdown_menu); ?> dropdown-menu-right">
                <?php $__currentLoopData = get_languages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if ($lang->name != $current_lang) { ?>
                <a href="<?php echo e(url('change/lang/'.$lang->name)); ?>" class="dropdown-item">
                    <img src="<?php echo e(url('public/assets/img/flags/'.$lang->code.'.png')); ?>" alt="" height="16"> <?php echo e($lang->name); ?>

                </a>
                <?php } ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </li>
        <!-- /Flag -->
        
        
        
        
        
        
        <li class="nav-item dropdown has-arrow">
            <a href="#" class="dropdown-toggle nav-link user-link" data-toggle="dropdown">
                <span class="user-img">
                    <?php if(empty(Auth::user()->profile_pic)): ?>
                    <img class="rounded-circle" src="<?php echo e(url('public/assets/img/user.jpg')); ?>" width="40" alt="Admin">
                    <?php else: ?>
                    <img class="rounded-circle" src="<?php echo e(url(env('img_path') .Auth::user()->profile_pic)); ?>" width="40" alt="Admin">
                    <?php endif; ?>
                    
                    <span class="status online"></span>
                </span>
                <span><?=ucfirst(Auth::user()->name)?></span>
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="<?php echo e(url('dashboard/profile/'.encrypt(Auth::user()->id))); ?>">Account Setting</a>
                <a class="dropdown-item" href="<?php echo e(url('dashboard/subscriptions/histories')); ?>">Subscriptions</a>
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a>
            </div>
        </li>
    </ul>
    <div class="dropdown mobile-user-menu float-right">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
        <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="<?php echo e(url('dashboard/profile/'.encrypt(Auth::user()->id))); ?>">Account Setting</a>
            <a class="dropdown-item" href="<?php echo e(url('dashboard/subscriptions/histories')); ?>">Subscriptions</a>
            <a class="dropdown-item" href="<?php echo e(url('public/profile/login')); ?>">Logout</a>
        </div>
    </div>
</div><?php /**PATH G:\server\htdocs\advance_ai\resources\views/layouts/header.blade.php ENDPATH**/ ?>