<div class="col-sm-8 col-md-8 col-lg-8 col-xl-9">
	<h6 class="card-title m-b-20">Pricing Page</h6>
	<form class="m-b-30" action="<?php echo e(route('webpage.update', $webpage->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
		<div class="card-box">
			<div class="row">
				
				<div class="col-md-12">
					<h4 class="card-title">Pricing Section</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Main Heading:</label>
								<input type="text" class="form-control" name="price_heading" value="<?php echo e($webpage->price_heading); ?>">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Sub Heading:</label>
								<input type="text" class="form-control" name="price_sub_heading" value="<?php echo e($webpage->price_sub_heading); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Featured Line:</label>
								<input type="text" class="form-control" name="price_featured_line" value="<?php echo e($webpage->price_featured_line); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Monthly:</label>
								<input type="text" class="form-control" name="price_monthly" value="<?php echo e($webpage->price_monthly); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Yearly:</label>
								<input type="text" class="form-control" name="price_yearly" value="<?php echo e($webpage->price_yearly); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>LifeTime:</label>
								<input type="text" class="form-control" name="price_life_time" value="<?php echo e($webpage->price_life_time); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Button:</label>
								<input type="text" class="form-control" name="price_button" value="<?php echo e($webpage->price_button); ?>">
							</div>
						</div>

						<div class="col-md-12">
							<div class="form-group">
								<label>End Line:</label>
								<input type="text" class="form-control" name="price_end_line" value="<?php echo e($webpage->price_end_line); ?>">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="text-right">
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
		</div>
	</form>
</div><?php /**PATH G:\server\htdocs\advance_ai\resources\views/web/forms/pricing_page.blade.php ENDPATH**/ ?>