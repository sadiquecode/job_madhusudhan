<div class="notification_icon" id="notification_icon">
    <div class="dropup dropupinbox" id="msg_round_icon">

        
        <ul class="dropdown-menu notifications border-0 px-2" id="msg_notification">
            <li class="dropdown-header text-center">
                <img src="<?php echo e(url('public/theme_assets/images/icons/notification.png')); ?>" alt="notification" width="26"
                height="35">
            </li>
            <li>
                <hr class="dropdown-divider">
            </li>






            
        </ul>
    </div>
</div><?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/theme_1/layouts/msg.blade.php ENDPATH**/ ?>