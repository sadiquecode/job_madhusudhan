<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <main class="mt-5 d-flex flex-column">
    <!-- Hero Section -->
    <?php echo $__env->make('theme_1.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- Subjects section -->
    <section id="subjects-section" class="mt-6">
      <div class="container-fluid container-lg">
        <!-- Title -->
        <div class="text-center">
          <h2 class="text-uppercase display-6 fw-semibold text-primary">Explore by <span
              class="text-warning">subject</span>
          </h2>
          <p class="text-secondary">Every tutor has its own subject specialization</p>
        </div>

        <!-- Subjects with Logos -->
        <div class="overflow-x-auto mx-auto pt-3 hover-logos-container d-flex d-lg-block">

      <?php
          $total_sets = ceil(count($TeachmeSubjects) / 7); // Calculate the total number of sets required
      ?>

      <?php for($i = 0; $i < $total_sets; $i++): ?>
          <div class="d-flex gap-xl-3 gap-xxl-5 justify-content-md-between justify-content-lg-around">
              <!-- Print 3 data for each set -->
              <?php $__currentLoopData = $TeachmeSubjects->skip($i * 7)->take(7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <a href="<?php echo e(url('find-tutors?subject_id='.$subject->id)); ?>" style="text-decoration: none;">
                    <figure class="figure">
                      <div class="figure-img-container">
                          <img src="<?php echo e(url(env('img_path'). $subject->subject_image)); ?>" alt="<?php echo e($subject->title); ?> subject" class="figure-img" style="border-radius: 50%;object-fit: cover;">
                      </div>
                      <figcaption class="figure-caption text-center text-sm-uppercase h5 text-primary fw-sm-bold">
                          <?php echo e(ucfirst($subject->nick_name)); ?>

                      </figcaption>
                  </figure>
                  </a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <!-- End of 3 data -->
          </div>
      <?php endfor; ?>


          </div>

        </div>
      </div>
      </div>
    </section>


    <!-- Languages section -->
    <section id="languages-section" class="py-5 mt-6">
      <div class="container-fluid py-4 py-lg-0 container-xl">
        <!-- Title -->
        <div class="text-center">
          <h2 class="text-uppercase display-6 fw-semibold text-white">Our Tutors Speak</h2>
          <p class="text-white">We have teachers who can speak different languages</p>
        </div>

        <!-- Languages with Logos -->
        <div class="overflow-x-auto mx-auto pt-3 hover-logos-container">



    <?php
        $total_sets = ceil(count($Languages) / 8); // Calculate the total number of sets required
    ?>

    <?php for($i = 0; $i < $total_sets; $i++): ?>
        <div class="d-flex gap-3 gap-xxl-5 justify-content-lg-around">
            <!-- Print 3 data for each set -->
            <?php $__currentLoopData = $Languages->skip($i * 8)->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('find-tutors?language_id='.$language->id)); ?>" style="text-decoration: none;">
                <figure class="figure">
                    <div class="figure-img-container">
                        <img src="<?php echo e(url(env('img_path'). $language->lang_img)); ?>" alt="<?php echo e($language->name); ?> language" class="figure-img" style="border-radius: 50%;object-fit: cover;">
                    </div>
                    <figcaption class="figure-caption text-center text-sm-uppercase h5 text-white fw-sm-bold">
                        <?php echo e(ucfirst($language->name)); ?>

                    </figcaption>
                </figure>
              </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End of 3 data -->
        </div>
    <?php endfor; ?>


        </div>
      </div>
    </section>


    <!-- Curriculum section -->
    <section id="curriculum-section" class="mt-8">
      <div class="container-fluid container-xl">
        <!-- Title -->
        <div class="text-center">
          <h2 class="text-uppercase display-6 fw-semibold text-primary">Explore by <span
              class="text-warning">curriculum</span>
          </h2>
          <p class="text-secondary">Every tutor has its own subject specialization</p>
        </div>

        <!-- Curriculum with Logos -->
        <div class="overflow-x-auto mx-auto pt-3 hover-logos-container">


<?php
    $total_sets = ceil(count($TeachmeCurriculums) / 6); // Calculate the total number of sets required
?>

<?php for($i = 0; $i < $total_sets; $i++): ?>
    <div class="d-flex gap-3 gap-sm-5 justify-content-between justify-content-lg-center">
        <!-- Print 3 data for each set -->
        <?php $__currentLoopData = $TeachmeCurriculums->skip($i * 6)->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('find-tutors?curriculum_id='.$curriculum->id)); ?>" style="text-decoration: none;">
            <figure class="figure">
                <div class="figure-img-container">
                    <img src="<?php echo e(url(env('img_path'). $curriculum->curriculum_image)); ?>" alt="<?php echo e($curriculum->title); ?> curriculum" class="figure-img">
                </div>
                <figcaption class="figure-caption text-center h5 text-primary fw-sm-bold">
                    <?php echo e(ucfirst($curriculum->title)); ?>

                </figcaption>
            </figure>
          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- End of 3 data -->
    </div>
<?php endfor; ?>

        </div>
      </div>
    </section>


    <!-- Why TeachMe section -->
    <section id="why-teachme-section" class="mt-8">
      <div class="container d-flex flex-column gap-5">
        <!-- Title -->
        <div class="text-center">
          <h2 class="text-uppercase display-6 fw-semibold text-primary">Why <span class="text-warning">TeachME</span>
          </h2>
          <p class="text-secondary text-capitalize">search for qualified tutors, find your match, and start learning
          </p>
        </div>

        <!-- Cards -->
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-4 g-lg-5">
          <div class="col">
            <div class="card border-0">
              <div class="card-body p-0">
                <img class="card-img mb-4" src="<?php echo e(url('public/theme_assets/images/page-landing/section-why-teachme/card-1.png')); ?>"
                  alt="Teacher teaching student from a book" loading="lazy" />
                <h4 class="fs-5 card-title fw-normal ">Filter tutors by subject, curriculum, language and location</h4>
                <p class="card-text text-body-tertiary">Its simple and easy. You're just one click away from finding the best tutors.</p>
                <a href="<?php echo e(url('find-tutors')); ?>" class="nav-link fw-semibold text-warning-hover">Find Tutors ›</a>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card border-0">
              <div class="card-body p-0">
                <img class="card-img mb-4" src="<?php echo e(url('public/theme_assets/images/page-landing/section-why-teachme/card-2.png')); ?>"
                  alt="Students studying together" loading="lazy" />
                <h4 class="fs-5 card-title fw-normal">Supporting the SEN community</h4>
                <p class="card-text text-body-tertiary">TeachME makes supporting kids with learning challenges a
                  priority. Search our database for qualified SEN tutors and Shadow Teachers.</p>
                <a href="<?php echo e(url('register')); ?>" class="nav-link fw-semibold text-warning-hover">Become a Tutor ›</a>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card border-0">
              <div class="card-body p-0">
                <img class="card-img mb-4" src="<?php echo e(url('public/theme_assets/images/page-landing/section-why-teachme/card-3.png')); ?>"
                  alt="Students raising hands to answer teacher's question" loading="lazy" />
                <h4 class="fs-5 card-title fw-normal">One-time payment with no hidden fees</h4>
                <p class="card-text text-body-tertiary">For a one time yearly payment you will have access to
                  tutors and students at your fingertips. We cut out the middle man by eliminating all hidden costs and
                  there is no commission fees. Keeping the cost low for our students!</p>
                <a href="<?php echo e(url('how-it-works')); ?>" class="nav-link fw-semibold text-warning-hover">How it works  ›</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


    <!-- Find Tutors section -->
    <section id="find-tutors-section" class="mt-8">
      <div class="container col-xxl-8 px-4 py-5">
        <div class="row flex-lg-row g-5 py-5">
          <div class="col-10 col-sm-8 col-lg-4">
            <img src="<?php echo e(url('public/theme_assets/images/page-landing/section-find-tutors/card-1.png')); ?>"
              class="d-block img-fluid rounded-5 move-lg-up" alt="Two students smiling with a book open" width="324"
              loading="lazy">
          </div>
          <div class="col-lg-7">
            <h2 class="display-7 display-lg-6 fw-semibold text-bg-primary mb-2">Find the best tutor,<br>who can teach
              you</h2>
            <p class="text-bg-primary lh-lg-lg">TeachME platform strives to provide a comprehensive database of tutors
              that cover a variety of subjects, languages, test preps and all major curriculums taught in the UAE. Users
              can search for Ministry Verified tutors according to their requirements. Ratings and Reviews from fellow
              users help to make an informed decision. Start now to support your child's education journey and set them
              on the path to success</p>
            <a href="./find-tutors" class="btn btn-outline-secondary px-4 py-3">Find
              Tutors</a>
          </div>
        </div>
        <div class="row flex-lg-row-reverse g-5 py-5">
          <div class="col-10 col-sm-8 col-lg-4">
            <img src="<?php echo e(url('public/theme_assets/images/page-landing/section-find-tutors/card-2.png')); ?>"
              class="d-block img-fluid rounded-5 move-lg-up" alt="A student and teacher smiling with a book open"
              width="324" loading="lazy">
          </div>
          <div class="col-lg-7">
            <h2 class="display-7 display-lg-6 fw-semibold text-bg-primary mb-2">Find students to teach</h2>
            <p class="text-bg-primary lh-lg-lg">Tutors are able to showcase their experience and expertise on the
              TeachME platform. For a one time payment you can advertise your services, upload a video introducing
              yourself, and provide key details like subjects taught, curriculum, educational background, languages
              spoken and areas of service. We take no commission or add any hidden fees. What you make is all yours!
              Sign up today</p>
            <a href="./register" class="btn btn-outline-secondary px-4 py-3">Become a Tutor</a>
          </div>
        </div>
      </div>
    </section>


    <!-- Verified tutors section -->
    <section id="verified-tutors-section" class="py-5 py-lg-8" style="display:none;">
      <div class="container d-flex flex-column gap-4 gap-lg-5">
        <!-- Title -->
        <div class="text-center">
          <h2 class="text-capitalize display-7 fw-semibold">Few of our verified tutors
          </h2>
          <p class="text-secondary text-capitalize">Our tutors are verified, have ratings and reviews, and detailed
            profile information
          </p>
        </div>
        <!-- Cards -->
        <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-4 g-2">


          <?php $__currentLoopData = $tutor_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tutor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
            <div class="card text-bg-dark border-0 rounded-4 position-relative overflow-hidden">
              <img src="<?php echo e(url(env('img_path'). $tutor->profile_pic)); ?>" class="card-img"
                alt="Tutor portrait">

              <div class="card-img-overlay">
                <!-- Verification pill -->
                <div
                  class="bg-success text-white small py-1 px-2 fw-light position-absolute top-0 end-0 rounded-start-2">
                  <i class="fa-regular fa-circle-check" aria-hidden="true"></i>
                  verified
                </div>

                <!-- Tutor details -->
                <div class="card-bottom-container px-2 py-3 rounded-4">
                  <div class="d-flex justify-content-between">
                    <h5 class="card-title fs-6 m-0 lh-base"><?php echo e($tutor->name.' '.$tutor->lname); ?></h5>
                    <div class="d-flex gap-1">
                      <i class="fa-solid fa-star text-warning" aria-hidden="true"></i>
                      <p class="m-0"><?php echo e(averageRating($tutor->id)); ?></p>
                    </div>
                  </div>
                  <div class="d-flex justify-content-between mt-1">
                    <div class="d-flex gap-1">
                      <img src="<?php echo e(url('public/theme_assets/images/icons/book.svg')); ?>" aria-hidden="true" />
                      
                    </div>
                    <div class="d-flex gap-1">
                      <img src="<?php echo e(url('public/theme_assets/images/icons/language.svg')); ?>" aria-hidden="true" />
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
      </div>
    </section>
<style>
    .carousel-cell .box4
    {
        background: #fff;
    border-radius: 20px;
    box-shadow: 5px 10px #f8d59a;
    }
</style>

    <!-- Testimonials section -->
    <section id="testimonials-section"
      class="container d-flex flex-column bg-body-tertiary position-relative mt-8 pt-5 rounded-5">
      <!-- Title -->
      <h2 class="text-center text-capitalize display-7 fw-semibold">What Our Clients Say About Us
      </h2>
      
      
      






      <div id="testimonials-carousel" class="pt-5">
        <div class="carousel-cell">
          <div class="card p-5 border-0 bg-transparent">
            <div class="card-body mt-n5 mb-5 text-center d-flex flex-column align-items-center box4">
              <img src="<?php echo e(url('public/theme_assets/images/testimonials.svg')); ?>" alt="Student photo" class="img-fluid rounded-circle mb-3"
                width="82" height="82">
              <h3 class="h5">Rihab</h3>
              <!--<span>Father, 6th Grade Student</span>-->
              <img src="<?php echo e(url('public/theme_assets/images/icons/quote.svg')); ?>" aria-hidden="true" class="img-fluid">
              <p>TeachME has helped our family cater to three kids at different grade levels. We found expert tutors who not only helped improve their grades but also boosted their confidence</p>
            </div>
          </div>
        </div>
          <div class="carousel-cell">
          <div class="card p-5 border-0 bg-transparent">
            <div class="card-body mt-n5 mb-5 text-center d-flex flex-column align-items-center box4">
              <img src="<?php echo e(url('public/theme_assets/images/testimonials.svg')); ?>" alt="Student photo" class="img-fluid rounded-circle mb-3"
                width="82" height="82">
              <h3 class="h5">Usama</h3>
              <!--<span>Father, 6th Grade Student</span>-->
              <img src="<?php echo e(url('public/theme_assets/images/icons/quote.svg')); ?>" aria-hidden="true" class="img-fluid">
              <p>TeachME is user-friendly, and the tutors are highly qualified. My kids actually look forward to their tutoring sessions and I can see improvment in their academic performance.</p>
            </div>
          </div>
        </div>
          <div class="carousel-cell">
          <div class="card p-5 border-0 bg-transparent">
            <div class="card-body mt-n5 mb-5 text-center d-flex flex-column align-items-center box4">
              <img src="<?php echo e(url('public/theme_assets/images/testimonials.svg')); ?>" alt="Student photo" class="img-fluid rounded-circle mb-3"
                width="82" height="82">
              <h3 class="h5">Alicia</h3>
              <!--<span>Father, 6th Grade Student</span>-->
              <img src="<?php echo e(url('public/theme_assets/images/icons/quote.svg')); ?>" aria-hidden="true" class="img-fluid">
              <p>TeachME has helped my son develop a genuine interest in the school. The personalized approach and interactive lessons have made all the difference. I would not hesitate to recommend TeachME to other parents.
</p>
            </div>
          </div>
          
        </div>
          <div class="carousel-cell">
          <div class="card p-5 border-0 bg-transparent">
            <div class="card-body mt-n5 mb-5 text-center d-flex flex-column align-items-center box4">
              <img src="<?php echo e(url('public/theme_assets/images/testimonials.svg')); ?>" alt="Student photo" class="img-fluid rounded-circle mb-3"
                width="82" height="82">
              <h3 class="h5">Farida</h3>
              <!--<span>Father, 6th Grade Student</span>-->
              <img src="<?php echo e(url('public/theme_assets/images/icons/quote.svg')); ?>" aria-hidden="true" class="img-fluid">
              <p>TeachME offers flexible scheduling options, which works for my family and our busy after school schedule. She can easily fit tutoring sessions into her busy schedule.
</p>
            </div>
          </div>
        </div>
          <div class="carousel-cell">
          <div class="card p-5 border-0 bg-transparent">
            <div class="card-body mt-n5 mb-5 text-center d-flex flex-column align-items-center box4">
              <img src="<?php echo e(url('public/theme_assets/images/testimonials.svg')); ?>" alt="Student photo" class="img-fluid rounded-circle mb-3"
                width="82" height="82">
              <h3 class="h5">Lama</h3>
              <!--<span>Father, 6th Grade Student</span>-->
              <img src="<?php echo e(url('public/theme_assets/images/icons/quote.svg')); ?>" aria-hidden="true" class="img-fluid">
              <p>TeachME connected us with a fantastic tutor. Thanks to their expertise and dedication, he is now reading beyond grade level and feeling more confident than ever.
</p>
            </div>
          </div>
        </div>

          <div class="carousel-cell">
          <div class="card p-5 border-0 bg-transparent">
            <div class="card-body mt-n5 mb-5 text-center d-flex flex-column align-items-center box4">
              <img src="<?php echo e(url('public/theme_assets/images/testimonials.svg')); ?>" alt="Student photo" class="img-fluid rounded-circle mb-3"
                width="82" height="82">
              <h3 class="h5">Sanah</h3>
              <!--<span>Father, 6th Grade Student</span>-->
              <img src="<?php echo e(url('public/theme_assets/images/icons/quote.svg')); ?>" aria-hidden="true" class="img-fluid">
              <p>"TeachME simplified the process of finding a tutor. The tutors are patient, encouraging, and skilled at keeping our kids engaged. Thanks to TeachME, our children are thriving academically, and we couldn't be happier!
</p>
            </div>
          </div>
        </div>
        
         <div class="carousel-cell">
          <div class="card p-5 border-0 bg-transparent">
            <div class="card-body mt-n5 mb-5 text-center d-flex flex-column align-items-center box4">
              <img src="<?php echo e(url('public/theme_assets/images/testimonials.svg')); ?>" alt="Student photo" class="img-fluid rounded-circle mb-3"
                width="82" height="82">
              <h3 class="h5">Bothayna</h3>
              <!--<span>Father, 6th Grade Student</span>-->
              <img src="<?php echo e(url('public/theme_assets/images/icons/quote.svg')); ?>" aria-hidden="true" class="img-fluid">
              <p>TeachME platform allowed us to find the right tutor for my child in various subjects in the right curriculum. My child has made significant improvement in his marks, and is better prepared for his tests at school.

</p>
            </div>
          </div>
        </div>
       
      </div>

    </section>



    <!-- Pricing section -->
    <section id="pricing-section" class="mt-7">
      <div class="container d-flex flex-wrap justify-content-center gap-5 mb-3 text-center">
        <!-- Tutor Card -->
        <div class="card mb-4 mx-4 mx-lg-0 py-5 px-lg-0 py-lg-6 rounded-5 border-0 tutor-card">
         
          <div class="card-header bg-transparent border-0 pb-3">
            <h3 class="mb-0 fw-semibold fs-2">For Tutor</h3>
          </div>
          <div class="card-body">
            <h1 class="card-title py-3 pricing-card-title"><small class="fs-4 me-1">AED</small><?php echo e($TeachmePackage_tutor->price); ?>.0<small
                class="fs-4">/year</small>
            </h1>
            <ul class="icon-list icon-list-warning list-unstyled my-4 d-flex align-items-center flex-column gap-4">
              <li>Get More Students</li>
              <li>Earn More income</li>
              <li>Get Better Exposure</li>
            </ul>

              <?php if(auth()->guard()->check()): ?>
              

                <a href="<?php echo e(url('login')); ?>" class="btn btn-outline-primary fw-semibold py-3 px-5 rounded-pill" type="submit">Get Started</a>
              <?php else: ?>
              <a href="<?php echo e(url('login')); ?>" class="btn btn-outline-primary fw-semibold py-3 px-5 rounded-pill">Get Started</a>
              <?php endif; ?>

          </div>
        </div>
        <!-- Student Card -->
        <div class="card mb-4 mx-4 mx-lg-0 py-5 px-lg-0 py-lg-6 rounded-5 border-0 student-card">
          <div class="card-header bg-transparent border-0 pb-3">
            <h3 class="mb-0 fw-semibold fs-2">For Student</h3>
          </div>
          <div class="card-body">
            <h1 class="card-title py-3 pricing-card-title"><small class="fs-4 me-1">AED</small><?php echo e($TeachmePackage_student->price); ?>.0<small
                class="fs-4">/year</small>
            </h1>
            <ul class="icon-list list-unstyled my-4 d-flex flex-column align-items-center gap-4">
              <li>Search the best tutor</li>
              <li>Filter any tutor you want</li>
              <li>Get your homework done</li>
            </ul>
            
            <?php if(auth()->guard()->check()): ?>
              <a href="<?php echo e(url('login')); ?>" class="btn btn-outline-primary fw-semibold py-3 px-5 rounded-pill" type="submit">Get Started</a>
              <?php else: ?>
              <a href="<?php echo e(url('login')); ?>" class="btn btn-outline-primary fw-semibold py-3 px-5 rounded-pill">Get Started</a>
              <?php endif; ?>

          </div>
        </div>
      </div>
    </section>


    <!-- Start learning section -->
    <section id="start-learning-section" class="mt-6">
      <div class="container d-flex flex-column gap-4 gap-lg-8">
        <!-- Title -->
        <div class="text-center">
          <h2 class="display-7 fw-semibold">Start learning today with TeachMe
          </h2>
          <p class="text-secondary">The best platform to connect tutors with students</p>
        </div>
      </div>

      <!-- Card -->
      <div class="container px-4 pb-5">
        <div class="row flex-lg-row g-4 py-5">
          <!-- Image -->
          <div class="col-12 col-lg-5 img-container">
            <img src="<?php echo e(url('public/theme_assets/images/page-landing/section-start-learning/students.png')); ?>" class="img-fluid w-100"
              alt="Five students smiling" loading="lazy">
          </div>

          <!-- Text -->
          <div class="col col-lg-7 d-flex align-items-center">
            <div class="d-flex p-4 text-container w-100 h-100 flex-column align-items-start justify-content-center">
              <h3 class="display-7 fw-semibold text-bg-primary mb-2">Start Learning</h3>
              <p class="text-bg-primary lh-lg">Sign up now with a one-time yearly subscription<br> that
                gives you
                access to </p>
              <ul class="d-flex flex-column gap-2 fw-medium">
                <li>Tutors across multiple subjects of expertise</li>
                <li>Test prep by curriculum</li>
                <li>SEN support</li>
                <li>Instruction in languages your child understands</li>
              </ul>
              <a href="./register" class="btn btn-outline-secondary py-3 px-5">Get
                Started</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/home.blade.php ENDPATH**/ ?>