    <!-- =============================Contact Us Start==============================-->
    <section class="contact_wrapper py-4 my-3">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-lg-3 col-7">
                    <div class="contect_detail d-flex align-items-center justify-content-between">
                        <h1 class="mb-0 <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.CONTACT2')); ?></h1>
                        <a href="https://api.whatsapp.com/send?phone=<?php echo e(get_general_settings()->contact_phone); ?>" target="_blank" class="text-dark">
                                <i class="fa-brands fa-whatsapp fa-3x"></i>
                            </a>
                        
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-5 align-self-center text-sm-start text-center">
                    <div class="contect_detail">
                        <h1 class="mb-0">
                            <a href="https://api.whatsapp.com/send?phone=<?php echo e(get_general_settings()->contact_phone); ?>" target="_blank" class="text-dark">
                                <?php echo e(get_general_settings()->contact_phone); ?>

                            </a>
                        </h1>

                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-6 d-none d-md-block">
                    <div class="contect_detail d-flex align-items-center justify-content-between">
                        <h1 class="mb-0 <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Follow Us')); ?></h1>
                        <a href="<?php echo e(get_general_settings()->instagram); ?>"><i class="fa-brands fa-instagram fa-3x"></i></a>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-6 align-self-center  d-none d-md-block">
                    <div class="contect_detail">
                        <h1 class="mb-0">
                        <a href="<?php echo e(get_general_settings()->instagram); ?>" class="text-dark">
                            <?php echo e(get_general_settings()->website_name); ?>

                        </a>
                        </h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- =============================Contact Us End==============================--><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/layouts/contact_us.blade.php ENDPATH**/ ?>