<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- ==============================Auction Card Start==============================-->
    <section class="auction_cardtrack py-5">
        <div class="container">
            <div class="justify-content-between align-items-center d-flex">
                <div class="heading flex-column d-flex">
                    <h4 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Ongoing Auctions')); ?></h4>
                </div>
                <div class="me-md-5 all_auction d-none d-lg-block">
                    <a href="<?php echo e(url('search?type=auction')); ?>" class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.View all')); ?></a>
                </div>
            </div>
        </div>
        <div class="container px-0 mx-auto">
            <div class="auctionslide__cards d-flex overflow-hidden">

                <?php $__currentLoopData = $post_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="px-2 py-5">
                <div class="card auction_card maincards border-0 px-0">
                    <div class="text-center active_btn position-relative">
                        <a href="#" class="d-block position-absolute text-capitalize cardactive_btn "><?php echo e($key->status); ?></a>
                        <a href="<?php echo e(url('tags/'.$key->slug)); ?>">
                        <img src="<?php echo e(url(env('img_path').post_img($key->id)->img )); ?>"
                            class="card-img-top img-fluid" alt="...">
                        </a>
                    </div>
                    <div class="card-body px-0 heading">
                        <a href="<?php echo e(url('tags/'.$key->slug)); ?>">
                            <h4 class="card-title mb-4"><?php echo e(strlen($key->product_name) > 25 ? substr($key->product_name, 0, 25) . '...' : $key->product_name); ?></h4>
                        </a>
                        <p class="card_text d-flex">
                            <small>
                            <?php if($key->type == 'auction'): ?>
                            <?php echo e(__('trans.Starting bid')); ?>

                            <?php else: ?>
                            <?php echo e(__('trans.price')); ?>

                            <?php endif; ?>
                            <?php echo e($key->starting_bid); ?>

                            </small>
                        </p>
                        <p class="card_text d-flex"><small><?php echo e(\Carbon\Carbon::parse($key->created_at)->format('d F H:i')); ?></small>
                        </p>
                        <p class=" card_text d-flex mb-5"><small>(<?php echo e(__('trans.GMT')); ?>+3) <?php echo e(__('trans.KSA')); ?></small></p>
                        <div class="d-flex align-items-center justify-content-center">
                                <a href="<?php echo e(url('tags/'.$key->slug)); ?>" class="card_bidbtn <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Bid')); ?></a>
                                
                            </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

            </div>
            <div class="me-md-5 all_auction d-block d-lg-none text-center">
                <a href="<?php echo e(url('search?type=auction')); ?>" class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.View all')); ?></a>
            </div>
        </div>
    </section>
    <!-- ==============================Upcoming Auction Card End ==============================-->
    <!-- ==============================Upcoming Auction Card Start ==============================-->
    <section class="auction_cardtrack">
        <div class="container">
            <div class="justify-content-between align-items-center d-flex">
                <div class="heading flex-column d-flex">
                    <h4 class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.selling product')); ?></h4>
                </div>
                <div class="me-md-5 all_auction d-none d-lg-block">
                    <a href="<?php echo e(url('search?type=non_auction')); ?>" class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.View all')); ?></a>
                </div>
            </div>
        </div>
        <div class="container px-0 pb-5 m-auto">
            <div class="auctionslide__cards d-flex overflow-hidden ">
                
                <?php $__currentLoopData = $sele_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="px-2 py-5">
                <div class="card auction_card maincards border-0 px-0">
                    <div class="text-center active_btn position-relative">
                        <a href="#" class="d-block position-absolute text-capitalize cardactive_btn "><?php echo e($key->status); ?></a>
                        <a href="<?php echo e(url('tags/'.$key->slug)); ?>">
                        <img src="<?php echo e(url(env('img_path').post_img($key->id)->img )); ?>"
                            class="card-img-top img-fluid" alt="...">
                        </a>
                    </div>
                    <div class="card-body px-0 heading">
                        <a href="<?php echo e(url('tags/'.$key->slug)); ?>">
                            <h4 class="card-title mb-4"><?php echo e(strlen($key->product_name) > 25 ? substr($key->product_name, 0, 25) . '...' : $key->product_name); ?></h4>
                        </a>
                        <p class="card_text d-flex">
                            <small>
                            <?php if($key->type == 'auction'): ?>
                            <?php echo e(__('trans.Starting bid')); ?>

                            <?php else: ?>
                            <?php echo e(__('trans.price')); ?>

                            <?php endif; ?>
                            <?php echo e($key->starting_bid); ?>

                            </small>
                        </p>
                        <p class="card_text d-flex"><small><?php echo e(\Carbon\Carbon::parse($key->created_at)->format('d F H:i')); ?></small>
                        </p>
                        <p class=" card_text d-flex mb-5"><small>(<?php echo e(__('trans.GMT')); ?>+3) <?php echo e(__('trans.KSA')); ?></small></p>
                        <div class="d-flex align-items-center justify-content-center">
<?php
    $user = get_user($key->user_id);
    ?>
    <?php if($user->phone): ?>
    <a class="card_bidbtn <?php echo e(session('ar_class')); ?>" href="tel:<?php echo e($user->phone); ?>"><?php echo e(__('trans.CONTACT US')); ?></a>
    <?php elseif($user->email): ?>
    <a class="card_bidbtn <?php echo e(session('ar_class')); ?>" href="mailto:<?php echo e($user->email); ?>"><?php echo e(__('trans.CONTACT US')); ?></a>
<?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="me-md-5 all_auction d-block d-lg-none text-center">
                <a href="<?php echo e(url('search?type=non_auction')); ?>" class="<?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.View all')); ?></a>
            </div>
        </div>

<?php if(auth()->guard()->check()): ?>
<?php echo $__env->make('theme_1.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php endif; ?>

    </section>
    <!-- ==============================Upcoming Auction End==============================-->
    <!-- ==============================Luxury Brand Start==============================-->
    <section class="Brand_wrapper">
        <div class="container">
            <div class="heading pt-5 text-center">
                <h4>Our Luxury Brands</h4>
                <hr class="mx-auto heading_hr">
            </div>
            <div class="row gy-3">
                <div class="col-md-2 col-12 d-none">
                    <div class="custom_control">
                        <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $title = ($code == 'en') ? $key->gender_en : $key->gender_ar;
                        ?>
                            <div class="custom_checks p-1 rounded d-inline-flex w-100 mb-2">
                                <input type="checkbox" class="form-check-input shadow-none" id="gen_<?php echo e($key->id); ?>">
                                <label class="form-check-label w-100 <?php echo e(session('ar_class')); ?>" for="gen_<?php echo e($key->id); ?>"><?php echo e($title); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
                <div class="col-md-2 col-12 d-none">
                    <div class="custom_control">

                        <?php $__currentLoopData = $manu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $title = ($code == 'en') ? $key->category_title_en : $key->category_title_ar;
                        ?>
                        <div class="custom_checks p-1 rounded d-inline-flex w-100 mb-2">
                                <input type="checkbox" class="form-check-input shadow-none" id="cat_<?php echo e($key->id); ?>">
                                <label class="form-check-label w-100 <?php echo e(session('ar_class')); ?>" for="cat_<?php echo e($key->id); ?>"><?php echo e($title); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <div class="col-md-12 col-12">
                    <div class="row">
                        <div class="col-10 mx-auto">
                            <div class="slideimgs slidertlimgs">
                        <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="slide_item">
                            <img src="<?php echo e(url(env('img_path').$key->brand_logo)); ?>" class="img-fluid m-auto" alt="montblance">
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- =============================Luxury Brand End==============================-->

<?php echo $__env->make('theme_1.layouts.contact_us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/theme_1/home.blade.php ENDPATH**/ ?>