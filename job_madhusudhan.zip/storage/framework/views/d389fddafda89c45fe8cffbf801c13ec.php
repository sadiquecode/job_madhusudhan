<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="page-title">Edit Profile</h4>
                </div>
            </div>


            <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <form action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" name="param" value="main">
                <div class="card-box">
                    <h3 class="card-title">Basic Informations</h3>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="profile-img-wrap">
                            <?php if(empty($user->profile_pic)): ?>
                                <img class="inline-block" src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="user">
                                <?php else: ?>
                                <img class="inline-block" src="<?php echo e(url(env('img_path'). $user->profile_pic)); ?>" alt="user" id="preview">
                                <?php endif; ?>
                                <div class="fileupload btn">
                                    <span class="btn-text">Change</span>
                                    <input class="upload" type="file" name="profile_pic" onchange="previewImage(event, 'preview')">
                                </div>
                            </div>
                            <div class="profile-basic">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group form-focus">
                                            <label class="focus-label">First Name</label>
                                            <input type="text" name="name" class="form-control floating" value="<?php echo e($user->name); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group form-focus">
                                            <label class="focus-label">Last Name</label>
                                            <input type="text" name="lname" class="form-control floating" value="<?php echo e($user->lname); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group form-focus">
                                            <label class="focus-label">Email</label>
                                            <input type="email" class="form-control floating" name="email" value="<?php echo e($user->email); ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group form-focus">
                                            <label class="focus-label">Phone</label>
                                            <input type="text" class="form-control floating" name="phone" value="<?php echo e($user->phone); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="text-right m-t-20 mb-4">
                    <button class="btn btn-primary btn-lg" type="submit">Update Profile</button>
                </div>
            </form>

                <form action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" name="param" value="reset_password">
                <div class="card-box">
                    <h3 class="card-title">Reset Password</h3>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group form-focus">
                                <label class="focus-label">Old Password</label>
                                <input type="password" class="form-control floating" name="oldpassword" autocomplete="new-password">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group form-focus">
                                <label class="focus-label">New Password</label>
                                <input type="password" class="form-control floating" name="password">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group form-focus">
                                <label class="focus-label">Confirm Password</label>
                                <input type="password" class="form-control floating" name="password_confirmation">
                            </div>
                        </div>
                    </div>
                </div>


                <div class="text-right m-t-20">
                    <button class="btn btn-primary btn-lg" type="submit">Reset Password</button>
                </div>
            </form>
        </div>
    </div>
</div>



<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\job_madhusudhan\resources\views/auth/profile.blade.php ENDPATH**/ ?>