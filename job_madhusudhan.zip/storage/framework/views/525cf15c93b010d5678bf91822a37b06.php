    <?php
    use App\Models\Translation\Language;
    $language = Language::where('status','active')->get();
    ?>

    <!-- Language Selection Modal --> 
    <div class="modal fade" id="languageModal" tabindex="-1" aria-labelledby="languageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="languageModalLabel">Select a Language</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-lg-4 col-12 d-grid">
                            <a class="btn btn-link btn-light text-start rtl_btn__dir text-dark" href="<?php echo e(route('home_change_lang', ['code' => $lang->code])); ?>" style="text-decoration: none;">
                                <img class="language-flag" src="<?php echo e(url('public/assets/img/flags/'.$lang->code.'.png')); ?>" alt="English">
                                <?php echo e($lang->name); ?>

                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
            </div>
        </div>
    </div><?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/theme_1/layouts/language.blade.php ENDPATH**/ ?>