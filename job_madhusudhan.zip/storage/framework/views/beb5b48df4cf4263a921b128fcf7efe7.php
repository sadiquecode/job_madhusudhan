<h2>Payment Success!</h2>
<a href="<?php echo e(url('/')); ?>">Home Page</a><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/payment/paymentsuccess.blade.php ENDPATH**/ ?>