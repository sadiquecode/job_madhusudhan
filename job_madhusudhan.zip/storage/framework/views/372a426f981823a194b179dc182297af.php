<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Main content -->
  <main id="sign-up-section" class="py-5 px-4 px-md-0 my-md-7 pb-md-7 bg-white">
<div class="container mt-3">
  <h2 class="fw-medium center">Privacy Policy</h2>
  <br>
  <p>The website "teachme.ae" is the property of Sandbox Data Group Company. By using this website, users are agreeing to the privacy policy set forth by our company. We are officially registered in Dubai under commercial license number 0000000.
</p>
  
  <p><strong>Last Updated:</strong> April 17, 2024</p>
  <div class="row">
      
      <p>  TeachME is committed to protecting the privacy of our users. This Privacy Policy outlines the types of information we collect, how we use it, and the choices users have regarding their personal data when using our online platform.</p>

<strong>1. Information We Collect</strong>

<p> We collect various types of information to provide and improve our Service. The types of information we collect may include:

Personal Information: When you register for an account or use our Service, we may collect personal information such as your name, email address, phone number, billing address, and payment information.

User Content: We may collect information that you provide when interacting with our Service, such as messages, feedback, and other content you submit.</p>
<strong>

2. How We Use Your Information </strong>

<p> We use the information we collect for various purposes, including:

Providing and maintaining the Service
Personalizing your experience and delivering tailored content
Processing transactions and payments
Communicating with you, including providing customer support and sending promotional messages
Analyzing usage trends and improving the quality of our Service
Complying with legal obligations
and protecting our rights and the rights of our users.
</p><strong>
3. Information Sharing and Disclosure</strong>

<p>We may share your information in the following circumstances:

With Service Providers: We may share your information with third-party service providers who help us operate our Service, such as payment processors, hosting providers, and analytics providers. These service providers are authorized to use your information only as necessary to provide services to us.


For Legal Purposes: We may disclose your information in response to lawful requests by public authorities, including to meet national security or law enforcement requirements, or when we believe disclosure is necessary to protect our rights, investigate fraud, or comply with a judicial proceeding, court order, or legal process.

In Connection with a Business Transaction: If we are involved in a merger, acquisition, financing, or sale of assets, your information may be transferred as part of that transaction. We will notify you via email and/or a prominent notice on our website of any change in ownership or uses of your information, as well as any choices you may have regarding your information.
</p>
<strong>4. Data Security</strong>

 <p> We take reasonable measures to protect your information from unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the internet or electronic storage is 100% secure, and we cannot guarantee the absolute security of your information.
</p>
<strong>5. Children's Privacy</strong>

 <p> Our Service is not directed at children under the age of 15, and we do not knowingly collect personal information from children under 15. If you believe that we have collected personal information from a child under 13, please contact us immediately, and we will take steps to remove that information from our servers.
</p>
<strong>6. Changes to This Privacy Policy</strong>

<p>We may update this Privacy Policy from time to time by posting a new version on this page. You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.
</p>
<strong>7. Contact Us</strong>

<p> If you have any questions about this Privacy Policy, please contact us at <a href="info@teachme.ae">info@teachme.ae</a>
</p>

<p>By using our Service, you consent to the collection and use of your information in accordance with this Privacy Policy.</p>


      
  </div>
</div>
  </main>

<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/teachme_privacy_policy_terms.blade.php ENDPATH**/ ?>