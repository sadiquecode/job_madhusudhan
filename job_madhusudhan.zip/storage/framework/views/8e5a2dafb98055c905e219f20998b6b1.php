<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
    .folder_size {
    font-size: 80px;
    }
    @media (max-width: 768px) {
    .folder_size {
    font-size: 60px;
    }
    }
    @media (max-width: 576px) {
    .folder_size {
    margin-top: 10px;
    font-size: 60px;
    }
    }
    </style>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-3">
                    <h4 class="page-title">All Folders</h4>
                </div>
                <div class="col-sm-8 col-9 text-right m-b-20">
                    <a href="#" class="btn btn-primary btn-rounded float-right" data-toggle="modal" data-target="#add_folder"><i class="fa fa-plus"></i> Add Folders</a>
                </div>
            </div>
            <form method="GET" action="<?php echo e(url('documents/folders')); ?>">
            <div class="row filter-row">
                <div class="col-sm-6 col-md-9">
                    <div class="form-group form-focus">
                        <label class="focus-label">Folders Name</label>
                        <input type="text" class="form-control floating" name="search">
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <button class="btn btn-success btn-block"> Search </button>
                </div>
            </div>
            </form>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <div class="row staff-grid-row">
                <?php if(count($folders) < 1): ?>
                <p class="p-4"><?php echo e('Folder Not Found!'); ?></p>
                <?php endif; ?>
                <?php $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
                    <div class="profile-widget">
                        <div class="profile-img">
                            <a href="<?php echo e(route('folder.document', $folder->slug)); ?>">
                                <i class="fa fa-folder folder_size"></i>
                            </a>
                        </div>
                        <div class="dropdown profile-action">
                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_folder_<?php echo e($folder->id); ?>"><i class="fas fa-pen m-r-5"></i> Edit</a>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_folder_<?php echo e($folder->id); ?>"><i class="far fa-trash-alt m-r-5"></i> Delete</a>
                            </div>
                        </div>
                        <h4 class="user-name m-t-10 m-b-0 text-ellipsis"><a href="<?php echo e(route('folder.document', $folder->slug)); ?>"><?php echo e($folder->folder_name); ?></a></h4>
                        <div class="small text-muted d-none">Web Designer</div>
                    </div>
                </div>
                <div id="edit_folder_<?php echo e($folder->id); ?>" class="modal custom-modal fade" role="dialog">
                    <div class="modal-dialog">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <div class="modal-content modal-lg">
                            <div class="modal-header">
                                <h4 class="modal-title">Edit Folders</h4>
                            </div>
                            <div class="modal-body">
                                <form class="m-b-30" action="<?php echo e(route('folders.update', $folder->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label class="col-form-label">Folder Name <span class="text-danger">*</span></label>
                                                <input class="form-control" name="folder_name" value="<?php echo e($folder->folder_name); ?>" type="text">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="m-t-20 text-center">
                                        <button type="submit" class="btn btn-primary btn-lg">Save Changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="delete_folder_<?php echo e($folder->id); ?>" class="modal custom-modal fade" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content modal-md">
                            <div class="modal-header">
                                <h4 class="modal-title">Delete Folders</h4>
                            </div>
                            <form action="<?php echo e(route('folders.destroy', $folder->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <div class="modal-body card-box">
                                    <p>Are you sure want to delete this?</p>
                                    <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo e($folders->links()); ?>

    </div>
</div>

<div id="add_folder" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="modal-content modal-lg">
            <div class="modal-header">
                <h4 class="modal-title">Add Folders</h4>
            </div>
            <div class="modal-body">
                <form class="m-b-30" action="<?php echo e(route('folders.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Folder Name <span class="text-danger">*</span></label>
                                <input type="text" name="folder_name" id="folder_name" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    <div class="m-t-20 text-center">
                        <button type="submit" class="btn btn-primary btn-lg">Create Folders</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/documents/folders_index.blade.php ENDPATH**/ ?>