
<!-- policy_data Modal -->
<div class="modal fade" id="privacy" tabindex="-1" aria-labelledby="privacy" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content rounded-0 <?php echo e(session('ar_class')); ?>">
        <div class="modal-header">
            <h1 class="modal-title fs-5 <?php echo e(session('ar_class')); ?>" id="privacy"><?php echo e(__('trans.privacy policy')); ?></h1>
            <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="mb-3 editprofile">
            <?php
            $code = session('locale');
            $heading_ = ($code == 'en') ? policy_data()->heading_en : policy_data()->heading_ar;
            $body_ = ($code == 'en') ? policy_data()->body_en : policy_data()->body_ar;
            ?>

            <p><?=$body_?></p>

            </div>
        </div>
</div>
</div>
</div>

<!-- policy_data -->
<div class="modal fade" id="Terms" tabindex="-1" aria-labelledby="Terms" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content rounded-0 <?php echo e(session('ar_class')); ?>">
        <div class="modal-header">
            <h1 class="modal-title fs-5 <?php echo e(session('ar_class')); ?>" id="Terms">
            <?php echo e(__('trans.Terms & conditions')); ?>

            </h1>
            <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="mb-3 editprofile">
            <?php
            $heading_ = ($code == 'en') ? term_data()->heading_en : term_data()->heading_ar;
            $body_ = ($code == 'en') ? term_data()->body_en : term_data()->body_ar;
            ?>
            <p><?=$body_?></p>
            </div>
        </div>
</div>
</div>
</div>
<?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/theme_1/layouts/terms_policy_popup.blade.php ENDPATH**/ ?>