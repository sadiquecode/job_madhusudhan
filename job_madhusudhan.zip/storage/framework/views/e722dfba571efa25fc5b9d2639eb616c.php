<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.setting_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">
<div class="content container-fluid">
<?php if($errors->any()): ?>
<div class="alert alert-danger">
<strong>Whoops!</strong> There were some problems with your input.<br><br>
<ul>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
<p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<div class="row">
<div class="col-md-12">
<h3 class="page-title">Payment Methods Settings</h3>
<div class="row">
<?php $__currentLoopData = $PaymentMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-sm-3 mt-3">
<a href="#" data-toggle="modal" data-target="#edit_pay_method_<?php echo e($payment->id); ?>">
<ul class="list-group">
    <li class="list-group-item p-4">
        <img class="inline-block" src="<?php echo e(url(env('img_path'). $payment->pay_logo)); ?>" alt="<?php echo e($payment->title); ?>">
        <div class="mt-3 material-switch float-right">
            <input id="staff_module" <?php if($payment->status == 1): ?>
            <?php echo e('checked'); ?>

            <?php endif; ?> type="checkbox">
            <label for="staff_module" class="badge-success"></label>
        </div>
    </li>
</ul>
</a>
</div>

<div id="edit_pay_method_<?php echo e($payment->id); ?>" class="modal custom-modal fade" role="dialog">
<div class="modal-dialog">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-content modal-lg">
    <div class="modal-header">
        <h4 class="modal-title"><?php echo e($payment->title); ?> Configuration</h4>
    </div>
    <div class="modal-body">
        <p><?php if(!empty($payment->explanation)): ?><?php echo e($payment->explanation); ?><?php endif; ?></p>
        <div class="m-b-30">
            <form action="<?php echo e(route('set_payment_methods')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    
                    <?php if($payment->title == 'Stripe'): ?>
                    <input type="hidden" value="<?php echo e($payment->title); ?>" name="title">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label>Stripe Key</label>
                            <input type="text" class="form-control floating" name="p_1" value="<?php echo e($payment->p_1); ?>">
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label>Stripe Secret</label>
                            <input type="text" class="form-control floating" name="p_2" value="<?php echo e($payment->p_2); ?>">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Status</label>
                            <select class="form-control select" name="status">
                                <?php
                                $status_arr=array('disable','enable');
                                ?>
                                <?php $__currentLoopData = $status_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($payment->status == $key): ?>
                                <option value="<?php echo e($key); ?>" selected><?php echo e(ucfirst($val)); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($key); ?>"><?php echo e(ucfirst($val)); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if($payment->title == 'Paypal'): ?>
                    <input type="hidden" value="<?php echo e($payment->title); ?>" name="title">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label>Paypal Client ID</label>
                            <input type="text" class="form-control floating" name="p_1" value="<?php echo e($payment->p_1); ?>">
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <label>Paypal Client Secret</label>
                            <input type="text" class="form-control floating" name="p_2" value="<?php echo e($payment->p_2); ?>">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Enable Test Sandbox Mode</label>
                            <select class="form-control select" name="p_3" value="<?php echo e($payment->p_3); ?>">
                                <?php
                                $status_arr=array('disable','enable');
                                ?>
                                <?php $__currentLoopData = $status_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($payment->p_3 == $val): ?>
                                <option value="<?php echo e($val); ?>" selected><?php echo e(ucfirst($val)); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($val); ?>"><?php echo e(ucfirst($val)); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Status</label>
                            <select class="form-control select" name="status">
                                <?php
                                $status_arr=array('disable','enable');
                                ?>
                                <?php $__currentLoopData = $status_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($payment->status == $key): ?>
                                <option value="<?php echo e($key); ?>" selected><?php echo e(ucfirst($val)); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($key); ?>"><?php echo e(ucfirst($val)); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if($payment->title != 'Paypal' && $payment->title != 'Stripe'): ?>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    <?php endif; ?>
                    <?php $btn_class = ''; ?>
                    <?php if($payment->title != 'Paypal' && $payment->title != 'Stripe'): ?> <?php $btn_class = 'd-none'; ?>
                    <?php endif; ?>
                </div>
                <div class="m-t-20 text-center <?php echo e($btn_class); ?>">
                    <button class="btn btn-primary btn-lg">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<h3 class="page-title mt-5">Offline Payment Method</h3>
<div class="row">
<div class="col-sm-3">
<a href="#" data-toggle="modal" data-target="#offline_pay_method">
<ul class="list-group">
    <li class="list-group-item p-4">
        <img class="inline-block" src="<?php echo e(url(env('img_path').'payment/offline.png')); ?>" alt="user" width="50">
        <div class="mt-3 material-switch float-right">
            <input id="staff_module" type="checkbox" <?php if($WebGeneralSetting->offline_payment_status == 1): ?>
            <?php echo e('checked'); ?>

            <?php endif; ?>>
            <label for="staff_module" class="badge-success"></label>
        </div>
    </li>
</ul>
</a>
</div>
</div>




<div id="offline_pay_method" class="modal custom-modal fade" role="dialog">
<div class="modal-dialog">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-content modal-lg">
    <div class="modal-header">
        <h4 class="modal-title">Offline Payment Method Configuration</h4>
    </div>
    <div class="modal-body">
        <div class="m-b-30">
            <form action="<?php echo e(route('set_payment_methods')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    
                    <input type="hidden" value="1" name="title">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Status</label>
                            <select class="form-control select" name="offline_payment_status">
                                <?php
                                $status_arr=array('disable','enable');
                                ?>
                                <?php $__currentLoopData = $status_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($WebGeneralSetting->offline_payment_status == $key): ?>
                                <option value="<?php echo e($key); ?>" selected><?php echo e(ucfirst($val)); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($key); ?>"><?php echo e(ucfirst($val)); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="m-t-20 text-center">
                    <button class="btn btn-primary btn-lg">Update</button>
                    <a href="<?php echo e(route('offline_payment')); ?>" class="btn-lg btn btn-success">Add Offline Payment Option</a>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
</div>


</div>
</div>
</div>
</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/settings/payment_methods.blade.php ENDPATH**/ ?>