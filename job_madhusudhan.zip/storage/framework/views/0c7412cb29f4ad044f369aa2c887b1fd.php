<?php

$user_id = auth()->id();
$current_user = get_user($user_id);

?>

<div class="sidebar-overlay" data-reff=""></div>  
    <script type="text/javascript" src="<?php echo e(url('public/assets/js/jquery-3.5.1.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/js/popper.min.js')); ?>"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/js/jquery.slimscroll.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/js/select2.min.js')); ?>"></script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/2.0.4/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/2.0.4/js/dataTables.bootstrap4.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.2/js/dataTables.buttons.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.bootstrap4.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.print.min.js"></script>


    <script type="text/javascript" src="<?php echo e(url('public/assets/js/moment.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/plugins/morris/morris.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/plugins/raphael/raphael.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/plugins/summernote/dist/summernote-bs4.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/plugins/light-gallery/js/lightgallery-all.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/js/app.js')); ?>"></script>

    
    <script type="text/javascript" src="<?php echo e(url('public/assets/daterange/moment.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/daterange/daterangepicker.min.js')); ?>"></script>



<script>
$(document).ready(function() {
    var dataTable = $('#teachme_table').DataTable();

    if (dataTable && $.fn.DataTable.isDataTable('#teachme_table')) {
        dataTable.destroy();
    }

    // Re-initialize DataTable
    $('#teachme_table').DataTable({
        "paging": true, // Enable pagination
        "searching": true, // Enable search bar
        "pageLength": 10,
        "dom": '<"top-left"f><"top-right"B>rt<"bottom-left"l><"bottom-right"ip>',
        "buttons": [ // Add export buttons
            'copy', // Copy to clipboard
            'csv', // Export to CSV
            'excel', // Export to Excel
            'pdf', // Export to PDF
            'print' // Print button
        ]
    });

});




    document.querySelectorAll('.expand-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const shortText = this.parentElement.querySelector('.short-text');
            const fullText = this.parentElement.querySelector('.full-text');

            if (shortText.style.display === 'none') {
                shortText.style.display = 'inline';
                fullText.style.display = 'none';
                this.textContent = 'Read More';
            } else {
                shortText.style.display = 'none';
                fullText.style.display = 'inline';
                this.textContent = 'Read Less';
            }
        });
    });

    function previewImage(event, previewId) {
        var input = event.target;
        var reader = new FileReader();

        reader.onload = function(){
            var preview = document.getElementById(previewId);
            console.log(reader.result); // Debugging line
            preview.src = reader.result;
            preview.style.display = 'block';
        };

        reader.readAsDataURL(input.files[0]);
    }

    $('#blog_lang').change(function () {
        var code = $(this).val();
        var base_url = "<?php echo e(url('/')); ?>";
        $.ajax({
        type: 'GET',
        url: base_url+'/get_blog_cat',
        data: { code: code },
        dataType: 'json',
        success: function (response) {
                if (response.status === 201) {
                    var bCategory = response.data;
                    var selectElement = $('select[name="category_id"]');
                    selectElement.empty();
                    for (var i = 0; i < bCategory.length; i++) {
                        var category = bCategory[i];
                        selectElement.append('<option value="' + category.id + '">' + category.cat_title + '</option>');
                    }
                }
            },
            error: function (xhr, status, error) {
                console.error(error);
            }
        });
    });




    $(document).ready(function() {
        $('.editbutton').click(function() {
            $(this).hide();
            var container = $(this).closest('form').find('[data-id]');
            container.show();
            $(this).closest('form').find('.text').hide()
        });

        $('.cancelbutton').click(function() {
            var container = $(this).closest('form').find('[data-id]');
            container.hide();
            $('.editbutton').show();
            $(this).closest('form').find('.text').show()
            var inputField = container.find('[name="lang_value"]');
            // inputField.val('');
        });

        $('.savebutton').click(function() {
            var form = $(this).closest('form');
            var dataId = form.find('.edit-container').data('id');
            var lang_code = form.find('[name="lang_code"]').val();
            var lang_key = form.find('[name="lang_key"]').val();
            var lang_value = form.find('[name="lang_value"]').val();
            // Submit the form
            // form.submit();
            if(lang_value == ''){
                showErrorMessage('Fill Data');
                return;
            }
            var base_url = "<?php echo e(url('/')); ?>";
                $.ajax({
                    type: 'POST',
                    url: base_url+'/update_val',
                    data: {
                        dataId: dataId,
                        lang_code: lang_code,
                        lang_key: lang_key,
                        lang_value: lang_value,
                        _token: '<?php echo e(csrf_token()); ?>',
                    },
                    success: function (data) {
                        if(data.status == 200){
                        form.find('.edit-container').hide();
                        $('.editbutton').show();
                        form.find('.text').show()
                        form.find('.text').text(data.res)
                        showSuccessMessage(data.msg);
                        }else{
                            showErrorMessage('Something Wrong!');
                        }

                    },
                    error: function (xhr, status, error) {
                        // console.log('AJAX Error: ' + error);
                        showErrorMessage('Something Wrong!');
                    }
                });


        });

    });

// toggleFavorite
function toggleFavorite(templateId) {
  var base_url = "<?php echo e(url('/')); ?>";
    // Send an AJAX request to the server to add/delete the template from favorites
    $.ajax({
        type: 'POST',
        url: base_url+'/toggle-favorite',
        data: {
            template_id: templateId,
            _token: '<?php echo e(csrf_token()); ?>',
        },
        success: function (data) {
            // If the request is successful, update the heart icon color based on the response
            if (data.is_favorite) {
                $('.temp_'+templateId).addClass('text-danger').removeClass('text-secondary');
                showSuccessMessage('Template favorited!');
            } else {
                $('.temp_'+templateId).addClass('text-secondary').removeClass('text-danger');
                showSuccessMessage('Template unfavorited!');
            }
        },
        error: function (xhr, status, error) {
            // console.log('AJAX Error: ' + error);
            showErrorMessage('Something Wrong!');
        }
    });
}

// Success message Function 
function showSuccessMessage(message) {
    var alertContainer = $('#alert-container');
    var alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">' +
        '<strong>Success!</strong> ' + message +
        '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' +
        '<span aria-hidden="true">&times;</span>' +
        '</button>' +
        '</div>';
    alertContainer.html(alert);
    alertContainer.show();
}

// Error message Function 
function showErrorMessage(message) {
    var alertContainer = $('#alert-container');
    var alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">' +
        '<strong>Error!</strong> ' + message +
        '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' +
        '<span aria-hidden="true">&times;</span>' +
        '</button>' +
        '</div>';
    alertContainer.html(alert);
    alertContainer.show();
}
  </script>

</body>

</html><?php /**PATH G:\server\htdocs\techme_latest\resources\views/layouts/footer.blade.php ENDPATH**/ ?>