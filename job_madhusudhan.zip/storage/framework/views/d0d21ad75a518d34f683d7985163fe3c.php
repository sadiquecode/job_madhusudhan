    <!-- Hero Section -->
    <section id="hero-section" class="position-relative overflow-x-hidden">
      <div class="container">
        <div class="row position-relative">
          <!-- Text -->
          <div class="col-12 col-lg-7 d-flex flex-column gap-3">
            <h1 class="text-primary display-5 display-xxl-3 fw-semibold mt-5">
              Are you or your child struggling to keep up with <span class="text-warning" style="min-height:100px;" id="mtext">schoolwork?</span>
            </h1>

            <ul class="icon-list fs-4">
              <li>
                Access to qualified & verified tutors
              </li>
              <li>One-time payment of <span class="text-primary ms-2 fw-bold">100 AED</span></li>
              <li>No commission / Hidden fees</li>
              <li>Direct communication with tutors</li>
            </ul>

            <div class="d-flex flex-wrap gap-4">
              <a href="<?php echo e(url('find-tutors')); ?>" class="btn btn-warning text-white text-warning-hover bg-transparent-hover px-4 py-3" style="font-size:1.2rem;">Find a Tutor</a>
              <a href="<?php echo e(url('register')); ?>" class="btn btn-outline-secondary px-4 py-3" style="font-size:1.2rem;background: #0a428e !important;
    color: #fff !important;" >Become a Tutor</a>
            </div>
          </div>

          <!-- Student Image -->
          <div class="col-lg d-flex justify-content-center pt-4 pt-lg-0" id="hero-student-container">
            <img class="img-fluid" src="<?php echo e(url('public/theme_assets/images/page-landing/section-hero/hero-student.png')); ?>"
              alt="Smiling student holding a purple book">
          </div>
        </div>
      </div>
    </section><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/layouts/header.blade.php ENDPATH**/ ?>