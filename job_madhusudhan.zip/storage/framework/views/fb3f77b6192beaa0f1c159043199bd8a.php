<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-3">
                    <h4 class="page-title">Most Used Templates </h4>
                </div>
            </div>

            <form action="<?php echo e(url('reports/most-used-templates')); ?>" method="GET">
            <div class="row filter-row">
                <div class="col-sm-12 col-md-6">
                    <div class="form-group form-focus">
                        <label class="focus-label">Search</label>
                        <input type="text" class="form-control floating" name="query">
                    </div>
                </div>

                <div class="col-sm-6 col-md-3">
                    <div class="form-group form-focus select-focus">
                        <label class="focus-label">Order</label>
                        <select class="select floating" name="order">
                            <option value="DESC">High -> Low</option>
                            <option value="ASC">Low -> High</option>
                        </select>
                    </div>
                </div>

                <div class="col-sm-6 col-md-3">
                    <button type="submit" class="btn btn-success btn-block"> Search </button>
                </div>
            </div>
            </form>
            <div class="row">
                <?php if(count($most_used_templates) > 0): ?>
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped custom-table datatable">
                            <thead>
                                <tr>
                                    <th>S/L</th>
                                    <th>Template Name</th>
                                    <th>Total Words</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $most_used_templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($index + 1); ?></td>
                                    <td><?php echo e($doc->template); ?></td>
                                    <td><?php echo e($doc->words_generated); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                        </tbody>
                    </table>
                </div>
                
            </div>
            <?php else: ?>
            <p class="p-4"><?php echo e('Templates Not Found!'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/reports/most_used_templates.blade.php ENDPATH**/ ?>