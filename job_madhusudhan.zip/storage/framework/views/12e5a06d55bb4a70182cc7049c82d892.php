<?php if(!function_exists('printLocation')): ?>
    <?php
    // Define the recursive function within PHP tags
    function printLocation($locations, $parentId, $level = 0) {
        $output = '';
        foreach ($locations as $location) {
            if ($location->parent_id == $parentId) {
                // Start a new row for the current location
                $output .= '<tr>';
                // Add cells for indentation
                for ($i = 0; $i < $level; $i++) {
                    $output .= '<td></td>';
                }
                // Add cell for location name
                $output .= '<td>' . $location->name . '</td>';
                $output .= '</tr>';
                // Recursively call printLocation for child locations
                $output .= printLocation($locations, $location->id, $level + 1);
            }
        }
        return $output;
    }
    ?>
<?php endif; ?>
<?php /**PATH G:\server\htdocs\techme_latest\resources\views/golbal_details/printLocation.blade.php ENDPATH**/ ?>