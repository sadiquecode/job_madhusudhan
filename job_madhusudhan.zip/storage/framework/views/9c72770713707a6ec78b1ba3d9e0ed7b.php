<div class="notification_icon justify-content-center flex-column d-flex d-none_" id="other_notification_popup">
    <!-- Default dropup button -->
    <style>
    .dropupnotif  {
    position: fixed;
    bottom: 10px;
    left: 5px;
    z-index: 1;
    }
    .dropupinbox  {
    position: fixed;
    bottom: 10px;
    right:  20px;
    z-index: 1;
    }
    </style>
    <div class="dropup dropupnotif">
        <a href="#"
            class="dropdown-toggle notification_toggle d-flex align-items-center justify-content-center  rounded-circle"
            data-bs-toggle="dropdown" aria-expanded="false">
            <img src="<?php echo e(url('public/theme_assets/images/icons/notification.png')); ?>" alt="notification" width="36" height="49">
            <span class="badge bg-danger badge-number rounded-circle" id="total_notifi"></span>
        </a>
        <ul class="dropdown-menu notifications border-0 px-2" id="other_notification">
            <li class="dropdown-header text-center">
                <img src="<?php echo e(url('public/theme_assets/images/icons/notification.png')); ?>" alt="notification" width="26"
                height="35">
            </li>
            <li>
                <hr class="dropdown-divider">
            </li>



        </ul>
    </div>
</div><?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/theme_1/layouts/notification.blade.php ENDPATH**/ ?>