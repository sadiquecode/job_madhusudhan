<?php $code = session('locale'); ?>
<header class="fixed-top">
        <div class="container-fluid p-0">
            <div class="top-navbar">
                <p><?php echo e(__('trans.Generate upto 5,000 words for FREE')); ?></p>
                <div class="icons rtl_icon">
                    <a href="#"><?php echo e(__('trans.Start Today')); ?> <img src="<?php echo e(url('public/theme_one_assets/images/icon/right-arrow.png')); ?>" alt="right-arrow" width="20"
                            height="20"></a>
                </div>
            </div>
        </div>
        <!-- ============================== top Navbar End ==============================-->

        <!-- ============================== Navbar Start ==============================-->
        <nav class="navbar navbar-expand-lg navbar-dark py-4 navbar_wrapper">
            <div class="container">
                <a class="navbar-brand d-flex gap-1" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('public/theme_one_assets/images/logo/logo.svg')); ?>" width="33"
                        height="27" alt="Logo">
                    <h1>GravityWrite</h1>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav gap-4 text-center">
                        <?php $count = 0; ?>
                        <?php for($i = 0; $i < 3; $i++): ?>
                            <?php if($count < count($manu)): ?>
                                <li class="nav-item">
                                    <a class="nav-link custom-btn" href="<?php echo e(url($slugs[$i]['page_slug'])); ?>"><?php echo e($manu[$count]->page_title); ?></a>
                                </li>
                                <?php $count++; ?>
                            <?php endif; ?>
                        <?php endfor; ?>

                        <button class="btn" data-bs-toggle="modal" data-bs-target="#languageModal">
                            <img class="language-flag" src="<?php echo e(url('public/assets/img/flags/'.$code.'.png')); ?>" alt="Language"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="Languages">
                        </button>

                        <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item">
                            <a class="nav-link custom-btn" href="<?php echo e(url('logout')); ?>"><?php echo e(__('trans.Logout')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link custom-btn bg-primary btn-lg text-center px-2" href="<?php echo e(url('dashboard')); ?>"><?php echo e(__('trans.dashboard')); ?></a>
                        </li>
                        <?php else: ?>
                        <?php $count = 3; ?>
                        <?php for($i = 3; $i < 5; $i++): ?>
                            <?php if($count < count($manu)): ?>
                                <li class="nav-item">
                                    <a class="nav-link custom-btn" href="<?php echo e(url($slugs[$i]['page_slug'])); ?>"><?php echo e($manu[$count]->page_title); ?></a>
                                </li>
                                <?php $count++; ?>
                            <?php endif; ?>
                        <?php endfor; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>


    <?php echo $__env->make('theme_1.layouts.language', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/theme_1/layouts/topheader.blade.php ENDPATH**/ ?>