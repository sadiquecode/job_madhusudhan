<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(Auth::user()->role == 'student'): ?>
  <?php echo $__env->make('theme_1.userprofile.student_edit_profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
  <!-- Main content -->
  <main id="profile-section" class="py-5 px-2 px-sm-4 mb-5">
    <div class="container rounded-5 p-4 gap-4 gap-md-5 box-shadow-md bg-white d-sm-flex">
      <!-- Tabs -->
      <ul
        class="nav nav-pills flex-sm-column flex-nowrap flex-sm-wrap overflow-x-auto overflow-x-sm-hidden overflow-x-md-visible gap-3 pe-sm-5 pe-md-4 pt-2 pb-2 pb-sm-0 border-end-sm justify-content-start border-bottom border-bottom-sm-0 "
        id="profile-tabs" role="tablist">
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php echo e($itsmainbtn); ?>" id="edit-tab" data-bs-toggle="tab" data-bs-target="#edit-tab-pane"
            type="button" role="tab" aria-controls="edit-tab-pane" aria-selected="true">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/user-square-light.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Profile</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php echo e($itsexpertisebtn); ?>" id="expertise-tab" data-bs-toggle="tab" data-bs-target="#expertise-tab-pane"
            type="button" role="tab" aria-controls="expertise-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/book-saved-light.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Expertise</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php echo e($itseducationbtn); ?>" id="education-tab" data-bs-toggle="tab" data-bs-target="#education-tab-pane"
            type="button" role="tab" aria-controls="education-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/teacher.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Education</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php echo e($itsexperiencebtn); ?>" id="experience-tab" data-bs-toggle="tab" data-bs-target="#experience-tab-pane"
            type="button" role="tab" aria-controls="experience-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/invoice.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Experience</span>
          </button>
        </li>

        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php echo e($itslicensebtn); ?>" id="documents-tab" data-bs-toggle="tab" data-bs-target="#documents-tab-pane"
            type="button" role="tab" aria-controls="documents-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/document.svg')); ?>" aria-hidden="true" class="me-3">
            <span>License</span>
          </button>
        </li>

        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php echo e($itspayment); ?>" id="payments-tab" data-bs-toggle="tab" data-bs-target="#payments-tab-pane"
            type="button" role="tab" aria-controls="payments-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/card.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Payments</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php echo e($itssettingbtn); ?>" id="settings-tab" data-bs-toggle="tab" data-bs-target="#settings-tab-pane"
            type="button" role="tab" aria-controls="settings-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/video-octagon-light.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Setting</span>
          </button>
        </li>
      </ul>

      <!-- Tab Panes -->
      <div class="tab-content mt-2 flex-grow-1" id="profile-tabs-content">

        <?php echo $__env->make('theme_1.userprofile.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Profile Panel -->
        <form name="profile-info-form" class="tab-pane fade <?php echo e($itsmain); ?>" id="edit-tab-pane" role="tabpanel" aria-labelledby="edit-tab" tabindex="0" action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <input type="hidden" name="param" value="main">
        <input type="hidden" name="zip_code" value="">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">My Profile</h3>

            <button class="btn btn-success rounded-pill btn-sm border-secondary-subtle text-white" type="submit">Save<i class="ms-2 fa-solid fa-save" style="font-size: 12px;"></i>
            </button>
          </div>

          <!-- Profile Info -->
          <div class="card mt-4 p-1">
            <div class="card-body d-flex align-items-center gap-2">
              <div class="position-relative">
               

                <?php if(empty($user->profile_pic)): ?>
                <img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="Tutor Avatar" class="img-fluid rounded-circle" style="height: 70px;" width="70" height="70" id="preview">
                <?php else: ?>
                <img alt="Tutor Avatar" class="img-fluid rounded-circle" width="70" height="70" style="height: 70px;" src="<?php echo e(url(env('img_path'). $user->profile_pic)); ?>" id="preview">
                <?php endif; ?>

                <label class="btn btn-primary btn-sm rounded-circle box-shadow-sm position-absolute"
                  style="bottom: -5px; right: -5px;">
                  <i class="fa-solid fa-pencil"></i>
                  <span class="visually-hidden">Upload New Profile Photo</span>
                  <input type="file" name="profile_pic" class="visually-hidden" onchange="previewImage(event, 'preview')">

                  <input type="hidden" name="old_profile_pic" value="<?php echo e($user->profile_pic); ?>">
                </label>

              </div>

              <div class="fw-semibold text-uppercase">
                <span class="text-warning" style="font-size:12px;"><?php echo e(ucfirst($user->role)); ?></span>
                <h4 class="fs-6 fw-semibold mb-0"><?php echo e(ucfirst($user->name.' '.$user->lname)); ?></h4>
                <span class="text-primary" style="font-size:12px;">
                  
                  <?php echo e($TeachmeLocationRelationship ? sub_location_name($TeachmeLocationRelationship->sub_location_id)->name ?? 'null' : 'null'); ?>,
                  
                  <?php echo e($TeachmeLocationRelationship ? sub_location_name($TeachmeLocationRelationship->location_id)->name ?? 'null' : 'null'); ?>

                  
              </span>
              </div>
            </div>
          </div>

          <!-- Mode of Instruction -->
          <fieldset name="personal-information" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-4">Availability</h3>

              <div class="p-2 mt-2">
              <div class="row gutter">
<div class="col-12 col-sm-12 col-xl-12">
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="checkbox" name="virtual_mode" id="mode-virtual" value="virtual" <?php echo e(old('virtual', $user->virtual_mode) === 'virtual' ? 'checked' : ''); ?>>
        <label class="form-check-label" for="mode-virtual">Virtual</label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="checkbox" name="in_person_mode" id="mode-inperson" value="in_person" <?php echo e(old('in_person_mode', $user->in_person_mode) === 'in_person' ? 'checked' : ''); ?>>
        <label class="form-check-label" for="mode-inperson">In Person</label>
    </div>
</div>

              </div>
            </div>
            </div>
          </fieldset>

          <!-- Personal Info -->
          <fieldset name="personal-information" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-4">Personal Information</h3>

              <div class="p-2 mt-2">
                <div class="row gutter">
                  <!-- First Name -->
                  <div class="col-12 col-md-6 col-xl-4">
                    <label class="w-100">
                      <p class="title">First Name</p>
                      <input class="form-control mt-2 rounded-3" name="name" placeholder="Ahsan" required value="<?php echo e(old('name', $user->name)); ?>">
                    </label>
                  </div>
                  <!-- Last Name -->
                  <div class="col-12 col-md-6 col-xl-4">
                    <label class="w-100">
                      <p class="title">Last Name</p>
                      <input class="form-control mt-2 rounded-3" name="lname" placeholder="" required value="<?php echo e(old('lname', $user->lname)); ?>">
                    </label>
                  </div>
                  <div class="d-none d-xl-block col-xl-4"></div>
                  <!-- Email -->
                  <div class="col-12 col-md-6 col-xl-4">
                    <label class="w-100">
                      <p class="title">Email Address</p>
                      <input class="form-control mt-2 rounded-3" type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>"
                        disabled required>
                    </label>
                  </div>
                  <!-- Phone -->

            <div class="col-12 col-md-6 col-xl-4">
                    <label class="w-100">
                      <p class="title">Whatsapp Number (Optional)</p>
                      <input class="form-control mt-2 rounded-3" name="phone" inputmode="numeric" placeholder="+971 0000000" value="<?php echo e(old('phone', $user->phone)); ?>">
                    </label>
                  </div>
                </div>
                 <p style="margin-top: 5%;
    color: #4CAF50;"><i class="fa fa-info-circle"> </i> We will share the above mentioned email and whatsapp number with the students. </p>
              </div>
              
            </div>
          </fieldset>

          <!-- Bio -->
          <fieldset name="description" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-2">Bio</h3>

              <div class="py-2 pe-3 col-8">
                <!-- Bio -->
                <textarea name="description" placeholder="Tell us about yourself" class="form-control" rows="5" style="resize:none;" required aria-label="description"><?=old('description', $user->description)?></textarea>
              </div>
            </div>
          </fieldset>

          <!-- Intro-video -->
          <fieldset name="intro-video" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-2">Youtube intro video url <small>(optional)</small> </h3>

              <div class="py-2 pe-3 col-8">
                  <input class="form-control mt-2 rounded-3" type="url" name="video_url" placeholder="youtu.be/dummyurl" aria-label="intro video url" value="<?=old('video_url', $user->video_url)?>">
              </div>
            </div>
          </fieldset>


                    <!-- Address -->
          <fieldset name="address" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-4">Address</h3>
              <div class="p-2 mt-2">
                <div class="row gutter">
                  <!-- Country -->
<div class="col-12 col-md-6 col-xl-4">
    <label class="w-100">
        <p class="title">Country</p>
        <select class="form-control" name="location_id" id="location_id_" required>
            
                <option value="<?php echo e($TeachmeLocation->id); ?>" <?php echo e(old('location_id', $TeachmeLocationRelationship ? $TeachmeLocationRelationship->location_id : '') == $TeachmeLocation->id ? 'selected' : ''); ?>>
                    <?php echo e($TeachmeLocation->name); ?>

                </option>
        </select>
    </label>
</div>
<!-- City/State -->
<div class="col-12 col-md-6 col-xl-4">
    <label class="w-100">
        <p class="title">City/State</p>
        <select class="form-control" name="sub_location" id="sub_location_">

          <?php $__currentLoopData = $subTeachmeLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


              <?php if($TeachmeLocationRelationship != null && $TeachmeLocationRelationship->sub_location_id == $sub_location->id): ?>
                <option value="<?php echo e($sub_location->id); ?>" selected><?php echo e($sub_location->name); ?></option>
                <?php else: ?>
                <option value="<?php echo e($sub_location->id); ?>"><?php echo e($sub_location->name); ?></option>
                <?php endif; ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




        </select>
    </label>
</div>

                  <div class="d-none d-xl-block col-xl-4"></div>
                  <!-- Postal Code -->
                  <div class="col-12 col-md-6 col-xl-4 d-none">
                    <label class="w-100">
                      <p class="title">Postal Code</p>
                      <input class="form-control mt-2 rounded-3" value="<?php echo e(old('zip_code',$user->zip_code)); ?>" name="zip_code" placeholder="ERT 2345">
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </fieldset>

        </form>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var virtualCheckbox = document.getElementById('mode-virtual');
    var inPersonCheckbox = document.getElementById('mode-inperson');

    // Function to validate checkboxes
    function validateCheckboxes() {
        if (!virtualCheckbox.checked && !inPersonCheckbox.checked) {
            alert('Please select at least one option for Mode of Instruction.');
            return false;
        }
        return true;
    }

    // Validate on form submit
    document.querySelector('form').addEventListener('submit', function (event) {
        if (!validateCheckboxes()) {
            event.preventDefault();
        }
    });
});
</script>


        <!-- Expertise Panel -->
        <form name="expertise-form" class="tab-pane fade <?php echo e($itsexpertise); ?>" id="expertise-tab-pane" role="tabpanel" aria-labelledby="expertise-tab" tabindex="0" action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <input type="hidden" name="param" value="expertise">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
          <h3 class="fs-5">Expertise</h3>
          <button class="btn btn-success rounded-pill btn-sm border-secondary-subtle text-white" type="submit">Save<i class="ms-2 fa-solid fa-save" style="font-size: 12px;"></i>
            </button>
          </div>
          <!-- Curriculum -->
          <div class="card mt-4 p-2">
          <div class="card-body">
              <!-- Header -->
              <h3 class="fs-6 fw-semibold">Curriculum</h3>

              <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4" style="padding-inline:.8rem;">
                  <?php $__currentLoopData = $TeachmeCurriculum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col form-check">
                          <?php
                              $checked = optional($user->teachme_curriculum_relationships)->contains('curriculum_id', $curriculum->id);
                          ?>
                          <input class="form-check-input" type="checkbox" value="<?php echo e($curriculum->id); ?>" id="curriculum-<?php echo e($curriculum->id); ?>" <?php if($checked): ?> checked <?php endif; ?> name="curriculum_id[]">
                          <label class="form-check-label" for="curriculum-<?php echo e($curriculum->id); ?>">
                              <?php echo e($curriculum->title); ?>

                          </label>
                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
          </div>



          </div>

          <!-- Grades -->
          <div class="card mt-4 p-2">
<div class="card-body">
    <!-- Header -->
    <h3 class="fs-6 fw-semibold">Grades</h3>

    <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4" style="padding-inline:.8rem;">
        <?php $__currentLoopData = $TeachmeGrade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col form-check">
                <?php
                    $checked = optional($user->teachme_grades_relationships)->contains('grade_id', $grade->id);
                ?>
                <input class="form-check-input" type="checkbox" value="<?php echo e($grade->id); ?>" id="grade-<?php echo e($grade->id); ?>" <?php if($checked): ?> checked <?php endif; ?> name="grade_id[]">
                <label class="form-check-label" for="grade-<?php echo e($grade->id); ?>">
                    <?php echo e($grade->title); ?>

                </label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
          </div>

          <!-- Subjects -->
          <div class="card mt-4 p-2">
<div class="card-body">
    <!-- Header -->
    <h3 class="fs-6 fw-semibold">Subjects</h3>

    <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4" style="padding-inline:.8rem;">
        <?php $__currentLoopData = $TeachmeSubject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col form-check">
                <?php
                    $checked = optional($user->teachme_subject_relationships)->contains('subject_id', $subject->id);
                ?>
                <input class="form-check-input" type="checkbox" value="<?php echo e($subject->id); ?>" id="subject-<?php echo e($subject->id); ?>" <?php if($checked): ?> checked <?php endif; ?> name="subject_id[]">
                <label class="form-check-label" for="subject-<?php echo e($subject->id); ?>">
                    <?php echo e($subject->title); ?>

                </label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
          </div>

          <!-- Languages -->
          <div class="card mt-4 p-2">
<div class="card-body">
    <!-- Header -->
    <h3 class="fs-6 fw-semibold">Languages</h3>

    <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4" style="padding-inline:.8rem;">
        <?php $__currentLoopData = $TeachmeLanguage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col form-check">
                <?php
                    $checked = optional($user->teachme_languages_relationships)->contains('language_id', $language->id);
                ?>
                <input class="form-check-input" type="checkbox" value="<?php echo e($language->id); ?>" id="language-<?php echo e($language->id); ?>" <?php if($checked): ?> checked <?php endif; ?> name="language_id[]">
                <label class="form-check-label" for="language-<?php echo e($language->id); ?>">
                    <?php echo e($language->name); ?>

                </label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
          </div>
        </form>


<script>
    document.getElementById('expertise-tab-pane').addEventListener('submit', function(event) {
        const curriculum_id = document.querySelectorAll('input[name="curriculum_id[]"]:checked');
        if (curriculum_id.length === 0) {
            event.preventDefault(); // Prevent form submission
            alert('At least one curriculum must be selected.');
            return;
        } else if (curriculum_id.length > 2) {
            event.preventDefault(); // Prevent form submission
            alert('Please choose a maximum of 2 curriculums from the available options.');
            return;
        }

        const grade_id = document.querySelectorAll('input[name="grade_id[]"]:checked');
        if (grade_id.length === 0) {
            event.preventDefault(); // Prevent form submission
            alert('At least one grade must be selected.');
            return;
        } else if (grade_id.length > 3) {
            event.preventDefault(); // Prevent form submission
            alert('Please choose a maximum of 3 grades from the available options.');
            return;
        }
        
        const subject_id = document.querySelectorAll('input[name="subject_id[]"]:checked');
        if (subject_id.length === 0) {
            event.preventDefault(); // Prevent form submission
            alert('At least one subject must be selected.');
            return;
        } else if (subject_id.length > 6) {
            event.preventDefault(); // Prevent form submission
            alert('Please choose a maximum of 6 subjects from the available options.');
            return;
        }
        
        const language_id = document.querySelectorAll('input[name="language_id[]"]:checked');
        if (language_id.length === 0) {
            event.preventDefault(); // Prevent form submission
            alert('At least one language must be selected.');
            return;
        } else if (language_id.length > 3) {
            event.preventDefault(); // Prevent form submission
            alert('Please choose a maximum of 3 languages from the available options.');
            return;
        }
    });
</script>


<?php if($addeducation == true): ?>
        <!-- Education Panel -->
        <form name="education-form" class="tab-pane fade <?php echo e($itseducation); ?>" id="education-tab-pane" role="tabpanel" aria-labelledby="education-tab" tabindex="0" action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <input type="hidden" name="param" value="addeducation">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Education</h3>

            <button class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle d-none">Add<i
                class="ms-2 fa-solid fa-plus" style="font-size: 12px;"></i>
              </button>
          </div>

          <!-- Educations List -->
          <ul class="list-unstyled d-flex flex-column gap-2 mt-4">
            <li class="bg-body-tertiary rounded-3 p-3">
              <div class="row row-cols-1 row-cols-md-2 g-4">
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Degree</span>
                    <input class="form-control mt-2 rounded-3" name="degree" placeholder="i.e BS Physics"
                      required>
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Institution Name</span>
                    <input class="form-control mt-2 rounded-3" name="institution"
                      placeholder="i.e Harvard University" required>
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Start Date</span>
                    <input class="form-control mt-2 rounded-3" type="month" name="start_date" required>
                  </label>
                </div>
                <div class="col" id="end_date_container">
                  <label class="w-100">
                    <span class="text-muted">End Date</span>
                    <input class="form-control mt-2 rounded-3" type="month" name="end_date" id="education_end_date" required>
                  </label>
                </div>

                <div class="col">
                  <div class="form-check" style="margin-top: 2.5rem !important;">
                    <input class="form-check-input" type="checkbox" value="1" name="currently_studying" id="currently-education">
                    <label class="form-check-label" for="currently-education">
                      Currently Studying
                    </label>
                  </div>
                </div>

              </div>
              <div class="mt-4 d-flex gap-3 flex-wrap justify-content-end">
                <button type="reset" class="btn btn-outline-secondary rounded-pill"><i
                    class="me-2 fa-solid fa-close"></i>Discard</button>
                <button type="submit" class="btn btn-success text-white rounded-pill"><i
                    class="me-2 fa-solid fa-save"></i>Save</button>
              </div>
            </li>
          </ul>
        </form>
<?php endif; ?>


<?php if($editeducation == true): ?>
          <!-- Education Panel -->
        <form name="education-form" class="tab-pane fade <?php echo e($itseducation); ?>" id="education-tab-pane" role="tabpanel" aria-labelledby="education-tab" tabindex="0" action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <input type="hidden" name="param" value="editeducation">
        <input type="hidden" name="education_id" value="<?php echo e($education_data->id); ?>">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Education</h3>

            <button class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle d-none">Add<i
                class="ms-2 fa-solid fa-plus" style="font-size: 12px;"></i>
              </button>
          </div>

          <!-- Educations List -->
          <ul class="list-unstyled d-flex flex-column gap-2 mt-4">
            <li class="bg-body-tertiary rounded-3 p-3">
              <div class="row row-cols-1 row-cols-md-2 g-4">
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Degree</span>
                    <input class="form-control mt-2 rounded-3" name="degree" placeholder="PHD, Applied Sciences"
                      required value="<?php echo e($education_data->degree); ?>">
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Institution Name</span>
                    <input class="form-control mt-2 rounded-3" name="institution" placeholder="London South Bank University, London" required value="<?php echo e($education_data->institution); ?>">
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Start Date</span>
                    <input class="form-control mt-2 rounded-3" type="month" name="start_date" required value="<?php echo e($education_data->start_date); ?>">
                  </label>
                </div>
                <div class="col" id="end_date_container">
                  <label class="w-100">
                    <span class="text-muted">End Date</span>
                    <input class="form-control mt-2 rounded-3" type="month" name="end_date" required value="<?php echo e($education_data->end_date); ?>">
                  </label>
                </div>
                <div class="col">
                  <div class="form-check" style="margin-top: 2.5rem !important;">
                      <input class="form-check-input" type="checkbox" value="currently-studying" id="currently-education" <?php if($education_data->currently_studying): ?> checked <?php endif; ?> name="currently_studying">
                      <label class="form-check-label" for="currently-education">
                          Currently Studying
                      </label>
                  </div>

                </div>
              </div>
              <div class="mt-4 d-flex gap-3 flex-wrap justify-content-end">
                <button type="reset" class="btn btn-outline-secondary rounded-pill"><i
                    class="me-2 fa-solid fa-close"></i>Discard</button>
                <button type="submit" class="btn btn-success text-white rounded-pill"><i
                    class="me-2 fa-solid fa-save"></i>Save</button>
              </div>
            </li>
          </ul>
        </form>
<?php endif; ?>

<script>
    var endDateContainer = document.getElementById('end_date_container');
    var endDateInput = document.getElementById('education_end_date');
    var currentlyStudyingCheckbox = document.getElementById('currently-education');

    currentlyStudyingCheckbox.addEventListener('change', function() {
        if (this.checked) {
            endDateContainer.style.display = 'none';
            endDateInput.required = false;
            endDateInput.disabled = true;
        } else {
            endDateContainer.style.display = 'block';
            endDateInput.required = true;
            endDateInput.disabled = false;
        }
    });

    // Initialize the state based on the initial checkbox state
    if (currentlyStudyingCheckbox.checked) {
        endDateContainer.style.display = 'none';
        endDateInput.required = false;
        endDateInput.disabled = true;
    } else {
        endDateContainer.style.display = 'block';
        endDateInput.required = true;
        endDateInput.disabled = false;
    }
</script>

<?php if($addexperience == true): ?>
        <!-- Experience Panel -->
        <form name="experience-form" class="tab-pane fade <?php echo e($itsexperience); ?>" id="experience-tab-pane" role="tabpanel" aria-labelledby="experience-tab" tabindex="0" action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <input type="hidden" name="param" value="addexperience">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Experience</h3>

            <button class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle d-none">Add<i
                class="ms-2 fa-solid fa-plus" style="font-size: 12px;"></i></button>
          </div>

          <!-- Experiences List -->
          <ul class="list-unstyled d-flex flex-column gap-2 mt-4">
            <li class="bg-body-tertiary rounded-3 p-3">
              <div class="row row-cols-1 row-cols-md-2 g-4">
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Title</span>
                    <input class="form-control mt-2 rounded-3" name="company" placeholder="i.e Science Teacher" required>
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Institution Name</span>
                    <input class="form-control mt-2 rounded-3" name="position" placeholder="i.e Repton School" required>
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Start Date</span>
                    <input class="form-control mt-2 rounded-3" type="month" name="start_date" required>
                  </label>
                </div>
                <div class="col" id="experience_end_date_container">
                  <label class="w-100">
                    <span class="text-muted">End Date</span>
                    <input class="form-control mt-2 rounded-3" type="month" name="end_date" id="experience_end_date" required>
                  </label>
                </div>
                <div class="col">
                  <div class="form-check" style="margin-top: 2.5rem !important;">
                    <input class="form-check-input" type="checkbox" value="1" name="currently_working" id="currently-working">
                    <label class="form-check-label" for="currently-working">
                      Currently Working
                    </label>
                  </div>
                </div>
              </div>
              <div class="mt-4 d-flex gap-3 flex-wrap justify-content-end">
                <button type="reset" class="btn btn-outline-secondary rounded-pill"><i
                    class="me-2 fa-solid fa-close"></i>Discard</button>
                <button type="submit" class="btn btn-success text-white rounded-pill"><i
                    class="me-2 fa-solid fa-save"></i>Save</button>
              </div>
            </li>
          </ul>
        </form>
<?php endif; ?>


<?php if($editexperience == true): ?>
        <!-- Experience Panel -->
        <form name="experience-form" class="tab-pane fade <?php echo e($itsexperience); ?>" id="experience-tab-pane" role="tabpanel" aria-labelledby="experience-tab" tabindex="0" action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <input type="hidden" name="param" value="editexperience">
        <input type="hidden" name="experience_id" value="<?php echo e($experience_data->id); ?>">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Experience</h3>

            <button class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle d-none">Add<i
                class="ms-2 fa-solid fa-plus" style="font-size: 12px;"></i></button>
          </div>

          <!-- Experiences List -->
          <ul class="list-unstyled d-flex flex-column gap-2 mt-4">
            <li class="bg-body-tertiary rounded-3 p-3">
              <div class="row row-cols-1 row-cols-md-2 g-4">
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Title</span>
                    <input class="form-control mt-2 rounded-3" name="company" placeholder="Science Teacher" required value="<?php echo e($experience_data->company); ?>">
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Institution Name</span>
                    <input class="form-control mt-2 rounded-3" name="position" placeholder="London South Bank University, London" required value="<?php echo e($experience_data->position); ?>">
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Start Date</span>
                    <input class="form-control mt-2 rounded-3" type="month" name="start_date" required value="<?php echo e($experience_data->start_date); ?>">
                  </label>
                </div>
                <div class="col" id="experience_end_date_container">
                  <label class="w-100">
                    <span class="text-muted">End Date</span>
                    <input class="form-control mt-2 rounded-3" type="month" name="end_date" id="experience_end_date" required value="<?php echo e($experience_data->end_date); ?>">
                  </label>
                </div>
                <div class="col">
                  <div class="form-check" style="margin-top: 2.5rem !important;">
                      <input class="form-check-input" type="checkbox" value="currently-working" id="currently-working" <?php if($experience_data->currently_working): ?> checked <?php endif; ?> name="currently_working">
                      <label class="form-check-label" for="currently-working">
                          Currently Working
                      </label>
                  </div>

                </div>
              </div>
              <div class="mt-4 d-flex gap-3 flex-wrap justify-content-end">
                <button type="reset" class="btn btn-outline-secondary rounded-pill"><i
                    class="me-2 fa-solid fa-close"></i>Discard</button>
                <button type="submit" class="btn btn-success text-white rounded-pill"><i
                    class="me-2 fa-solid fa-save"></i>Save</button>
              </div>
            </li>
          </ul>
        </form>
<?php endif; ?>

<script>
    var endDateContainer_exp = document.getElementById('experience_end_date_container');
    var endDateInput_exp = document.getElementById('experience_end_date');
    var currentlyStudyingCheckbox_exp = document.getElementById('currently-working');

    currentlyStudyingCheckbox_exp.addEventListener('change', function() {
        if (this.checked) {
            endDateContainer_exp.style.display = 'none';
            endDateInput_exp.required = false;
            endDateInput_exp.disabled = true;
        } else {
            endDateContainer_exp.style.display = 'block';
            endDateInput_exp.required = true;
            endDateInput_exp.disabled = false;
        }
    });

    // Initialize the state based on the initial checkbox state
    if (currentlyStudyingCheckbox_exp.checked) {
        endDateContainer_exp.style.display = 'none';
        endDateInput_exp.required = false;
        endDateInput_exp.disabled = true;
    } else {
        endDateContainer_exp.style.display = 'block';
        endDateInput_exp.required = true;
        endDateInput_exp.disabled = false;
    }
</script>

<?php if($check_profile->status == 2 && $totaldocument_data < 1 || $check_profile->status == 0 && $check_profile->msg == 'license not found' || $adddocument == true && $check_profile->status == 0 && $check_profile->msg == 'license not found'): ?>
        <!-- Documents Panel -->
        <form name="documents-form" class="tab-pane fade <?php echo e($itslicense); ?>" id="documents-tab-pane" role="tabpanel" aria-labelledby="documents-tab" tabindex="0" action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <input type="hidden" name="param" value="adddocument">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">License</h3>
          </div>

          <!-- Experiences List -->
          <ul class="list-unstyled d-flex flex-column gap-2 mt-4">
            <li class="bg-body-tertiary rounded-3 p-3">
              <div class="row row-cols-1 row-cols-md-12 g-4">
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Title</span>
                    <input class="form-control mt-2 rounded-3" name="title" placeholder="Private Teacher Permit" value="Private Teacher Permit" readonly>
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">File</span>
                    <input type="file" class="form-control mt-2 rounded-3" name="document" placeholder="Upload File" required>
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                      <span class="text-muted">Expiry Date</span>
                      <input class="form-control mt-2 rounded-3" type="date" name="expiry_date" required min="<?php echo e(date('Y-m-d')); ?>">
                  </label>
              </div>

              </div>
              <div class="mt-4 d-flex gap-3 flex-wrap justify-content-end">
                <button type="submit" class="btn btn-success text-white rounded-pill"><i
                    class="me-2 fa-solid fa-save"></i>Save</button>
              </div>
            </li>
          </ul>
        </form>
<?php else: ?>

<form name="documents-form" class="tab-pane fade <?php echo e($itslicense); ?>" id="documents-tab-pane" role="tabpanel" aria-labelledby="documents-tab" tabindex="0" acti on="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
  <div class="d-flex justify-content-between">
        <h3 class="fs-5">License</h3>

          <?php if(Auth::user()->role != 'admin'): ?>
            <a href="<?php echo e(url('profile/'.encrypt(Auth::user()->id))); ?>?itspayments=yes" class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle"><i
                class="ms-2 fa-solid fa-arrow-left" style="font-size: 12px;"></i> Check License</a>
            <?php endif; ?>
          </div>
<?php if($check_profile->status == 2 && $totaldocument_data > 0): ?>
  <?php echo e('Your license has been uploaded'); ?>

<?php elseif($check_profile->msg == 'license have active date'): ?>
  <?php echo e('Your License is active, please submit for approval'); ?>

<?php else: ?>
  <p><?php echo e(ucfirst($check_profile->msg)); ?> <?php if($user->reject_status == 1): ?>
    But Rejected, please update your license.
  <?php endif; ?></p>
<?php endif; ?>

</form>


<?php endif; ?>


<?php if($editdocument == true && $check_profile->status == 0 && $check_profile->msg == 'license have expiry date' || $editdocument == true && $user->reject_status == 1): ?>
        <!-- Document Panel -->
        <form name="documents-form" class="tab-pane fade <?php echo e($itslicense); ?>" id="documents-tab-pane" role="tabpanel" aria-labelledby="documents-tab" tabindex="0" action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <input type="hidden" name="param" value="editdocument">
          <input type="hidden" name="document_id" value="<?php echo e($document_data->id); ?>">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Document</h3>
          </div>
          <!-- Document List -->
          <ul class="list-unstyled d-flex flex-column gap-2 mt-4">
            <li class="bg-body-tertiary rounded-3 p-3">
              <div class="row row-cols-1 row-cols-md-12 g-4">
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Title</span>
                    <input class="form-control mt-2 rounded-3" name="title" required placeholder="Private Teacher Permit" value="Private Teacher Permit" readonly>
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">File</span>
                    <?php if($document_data->document): ?>
                    <a target="_blank" href="<?php echo e(url(env('img_path'). $document_data->document)); ?>">Old File</a>
                    <?php endif; ?>
                    <input type="file" class="form-control mt-2 rounded-3" name="document" placeholder="Document">
                    <input type="hidden" name="old_document" value="<?php echo e($document_data->document); ?>">
                  </label>
                </div>
                <div class="col">
                  <label class="w-100">
                    <span class="text-muted">Expiry Date</span>
                    <input class="form-control mt-2 rounded-3" type="date" name="expiry_date" value="<?php echo e($document_data->expiry_date); ?>" required  min="<?php echo e(date('Y-m-d')); ?>">
                  </label>
                </div>
              </div>
              <div class="mt-4 d-flex gap-3 flex-wrap justify-content-end">
                <button type="submit" class="btn btn-success text-white rounded-pill"><i
                class="me-2 fa-solid fa-save"></i>Save</button>
              </div>
            </li>
          </ul>
        </form>
<?php endif; ?>

        <!-- Payments Panel -->
        <div class="tab-pane fade <?php echo e($itspayment); ?>" id="payments-tab-pane" role="tabpanel" aria-labelledby="setting-tab" tabindex="0">
          <!-- Heading -->
           <div class="d-flex justify-content-between">
          
          <h3 class="fs-5">
            <i class="fa fa-bookmark-o"></i>
          Subscription
          </h3>

          <?php if(Auth::user()->role != 'admin'): ?>
            <a href="<?php echo e(url('profile/'.encrypt(Auth::user()->id))); ?>?itspayments=yes" class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle"><i
                class="ms-2 fa-solid fa-arrow-left" style="font-size: 12px;"></i> Back</a>
            <?php endif; ?>
          </div>
          <br><br>

        <?php 
          if ($user->approval_status == 0 && auth()->user()->role == 'tutor') {
            $approved_msg = 'To proceed with purchasing a subscription, you must await approval from the TeachMe team.';
          }
        ?>

    <?php if($TeachmePayment && $TeachmePayment->stripe_status == 'canceled' && $TeachmePayment->ends_at < now()): ?>
        <a href="<?php echo e(url('plans/2')); ?>" class="btn btn-success fw-semibold py-3 px-5 rounded-pill" type="submit"> Subscribe</a>
    <?php elseif(!$TeachmePayment): ?>
        <?php if($user->approval_status == 0 && auth()->user()->role == 'tutor'): ?>
            <p style="color:orange;"><?php echo e($approved_msg); ?></p>
        <?php else: ?>
            <a href="<?php echo e(url('plans/2')); ?>" class="btn btn-outline-primary fw-semibold py-3 px-5 rounded-pill" type="submit">Subscribe</a>
        <?php endif; ?>
    <?php endif; ?>



          <!-- Content -->
          <div class="mt-4 row g-3">
            <!-- Subscription -->
            <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Subscription</span>
            </div>
            <?php if($TeachmePayment != null): ?>
            <div class="col-12 col-sm-6 col-xl-9 d-flex flex-column">
              <span>Plan Type: 100 AED / Year</span>
              <span>Subscription: <?php echo e(ucfirst($TeachmePayment->stripe_status)); ?></span>
            </div>

            <!-- Billing Date -->
            <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Billing Date</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-9">
              
              <span class="d-block">
                <?php if($TeachmePayment->stripe_status == 'active'): ?>
                  Your next billing date is 
                  <?php echo e(\Carbon\Carbon::parse($TeachmePayment->created_at)->addYear()->format('F d, Y')); ?>.

                  <br><a href="<?php echo e(url('cancel-subscribe/'.$TeachmePayment->type)); ?>" class="mt-2 btn btn-outline-secondary px-5" type="button" onclick="return confirm('Are you sure you want to cancel?')">Cancel Membership</a>
                <?php else: ?>
                Your subscription has been cancelled, but you remain a premium member until your purchased subscription expires on 
                <?php echo e(\Carbon\Carbon::parse($TeachmePayment->ends_at)->format('F d, Y')); ?>.
                <?php endif; ?>
                </span>

              
            </div>

            <?php else: ?>
            <div class="col-12 col-sm-6 col-xl-9 d-flex flex-column">
              <span>Plan Type: 100 AED / Year</span>
              <span>Subscription: Inactive</span>
            </div>
            <?php endif; ?>
            

            <?php if($TeachmePayment): ?>
            <!-- Payment Methods -->
            <div class="col-12 col-sm-6 col-xl-3">
              <p class="fw-semibold">Payment Method</p>
            </div>
            <div class="col-12 col-sm-6 col-xl-9">
              <div class="d-flex gap-3 flex-wrap align-items-center">
                <div class="d-flex flex-column flex-sm-row align-items-sm-center gap-2 gap-sm-3">
                  <img src="<?php echo e(asset('public/theme_assets/images/credit-card.webp')); ?>" class="rounded" width="70" />
                  <div class="d-flex flex-column">
                    <span class="h6 mb-1">Credit Card</span>
                    <span class="small text-muted"><?php echo e('**** **** **** ' . $user->pm_last_four); ?>

                    </span>
                  </div>
                </div>
                <div>
                  <button class="btn btn-outline-secondary" data-bs-toggle="collapse" data-bs-target="#update-card-info"
                    aria-expanded="false" aria-controls="update-card-info" type="button">
                    <i class="fa-solid fa-pencil"></i>
                    <span class="visually-hidden">Update</span>
                  </button>
                </div>
              </div>
            </div>
            <?php endif; ?>

            <div class="col-12">
              <!-- Update Card Content -->
              <form name="update-card-info" class="collapse row py-3" id="update-card-info" action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <input type="hidden" name="param" value="payments_card">

                <div class="col-12 col-lg-8 offset-lg-3">
                  <div class="card" style="border-radius: 15px;">
                    <div class="card-body p-4 row g-4">

                      <label class="col-12 col-md-12">
                        <span>Cardholder's Name</span>
                        <input class="form-control mt-2" size="17" name="card_holder" id="card-holder-name" required />
                      </label>

                      <label class="col-12 col-md-12">
                        <span>Card details</span>
                       <div id="card-element" style="width: 100%;"></div>
                        <div id="card-errors" role="alert"></div>
                      </label>

                      <div class="col d-flex justify-content-end">
                        <button class="btn btn-success text-white rounded-pill" id="submit-button">
                          <i class="me-2 fa-solid fa-save"></i>
                          Save
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </form>


<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript"></script>

<script src="https://js.stripe.com/v3/"></script>
<script>
  // Create an instance of Elements
        const stripe = Stripe('<?php echo e(env('STRIPE_KEY')); ?>')
        var elements = stripe.elements();

        // Create an instance of the card Element
        var card = elements.create('card', {hidePostalCode: true});

        // Add an instance of the card Element into the `card-element` div
        card.mount('#card-element');

        // Handle real-time validation errors from the card Element
        card.addEventListener('change', function(event) {
            var displayError = document.getElementById('card-errors');
            if (event.error) {
                displayError.textContent = event.error.message;
            } else {
                displayError.textContent = '';
            }
        });

        // Handle form submission
        var form = document.getElementById('update-card-info');
        var submitButton = document.getElementById('submit-button');

        form.addEventListener('submit', function(event) {
            event.preventDefault();

            submitButton.disabled = true;

            // Create a token with the card information
            stripe.createToken(card, {
                name: document.getElementById('card-holder-name').value
            }).then(function(result) {
                if (result.error) {
                    // Inform the user if there was an error
                    var errorElement = document.getElementById('card-errors');
                    errorElement.textContent = result.error.message;
                    submitButton.disabled = false;
                } else {
                    // Send the token to your server
                    stripeTokenHandler(result.token);
                }
            });
        });

        // Submit the form with the token ID
        function stripeTokenHandler(token) {
            // Insert the token ID into the form so it gets submitted to the server
            var form = document.getElementById('update-card-info');
            var hiddenInput = document.createElement('input');
            hiddenInput.setAttribute('type', 'hidden');
            hiddenInput.setAttribute('name', 'payment_method_id');
            hiddenInput.setAttribute('value', token.id);
            form.appendChild(hiddenInput);

            // Submit the form
            form.submit();
        }
    </script>






            </div>
          </div>
        </div>

        <!-- Settings Panel -->
        <form name="settings-form" class="tab-pane fade <?php echo e($itssetting); ?>" id="settings-tab-pane" role="tabpanel" aria-labelledby="setting-tab" tabindex="0" action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <input type="hidden" name="param" value="reset_password">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Rest Password</h3>

            <button class="btn btn-success text-white rounded-pill btn-sm">Save<i class="ms-2 fa-solid fa-save"
                style="font-size: 12px;"></i></button>
          </div>

          <div class="mt-4 row g-3">
            

            <div class="col-12 col-sm-4 col-xl-3">
              <span class="fw-semibold">Password</span>
            </div>
            <div class="col-12 col-sm-8 col-xl-9">
              <div class="row g-4">
                <label class="col-12 col-lg-6">
                  <span class="small">Current Password</span>
                  <input class="form-control mt-2" type="password" name="oldpassword" required />
                </label>
                <div class="col-lg-6 d-lg-block d-none"></div>
                <label class="col-12 col-lg-6">
                  <span class="small">New Password</span>
                  <input class="form-control mt-2" type="password" name="password" required />
                </label>
                <label class="col-12 col-lg-6">
                  <span class="small">Confirm Password</span>
                  <input class="form-control mt-2" type="password" name="password_confirmation" required />
                </label>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </main>
  <?php endif; ?>
  <?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/userprofile/edit_profile.blade.php ENDPATH**/ ?>