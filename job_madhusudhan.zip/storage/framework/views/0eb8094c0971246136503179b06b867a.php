<div class="row py-5 px-4 gx-2">
    
    <?php if($post_data->isEmpty()): ?>
    <p class="py-3">Data Not Found!</p>
    <?php else: ?>
    <?php $__currentLoopData = $post_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-6 col-md-4 col-lg-3 col-12">
        <div class="card auction_card border-0 px-0">
            <div class="text-center terminat_btn_ active_btn position-relative">
                <a href="#" class="d-block position-absolute cardactive_btn">
                    <?php echo e($key->status); ?>

                </a>
                <a href="<?php echo e(url('tags/'.$key->slug)); ?>">
                    <img src="<?php echo e(url(env('img_path').post_img($key->id)->img )); ?>"
                    class="card-img-top img-fluid" alt="...">
                </a>
            </div>
            <div class="card-body px-0 heading">
                <a href="<?php echo e(url('tags/'.$key->slug)); ?>"> <h4 class="card_title mb-4"><?php echo e($key->product_name); ?></h4></a>
                <p class="card_text d-flex">
                    <small>
                    <?php if($key->type == 'auction'): ?>
                    <?php echo e(__('trans.Starting bid')); ?>

                    <?php else: ?>
                    <?php echo e(__('trans.price')); ?>

                    <?php endif; ?>
                    <?php echo e($key->starting_bid); ?>

                    </small>
                </p>
                <p class="card_text d-flex"><small><?php echo e(\Carbon\Carbon::parse($key->created_at)->format('d F H:i')); ?></small>
                </p>
                <p class=" card_text d-flex mb-5"><small>(<?php echo e(__('trans.GMT')); ?>+3) <?php echo e(__('trans.KSA')); ?></small></p>
                <style> .all_action_btn a{ width: 30%; } </style>
                <?php if($title == 'Auctions' && $isOwner || $title == 'Non-Auctions' && $isOwner): ?>
                <div class="d-flex align-items-center justify-content-center all_action_btn mt-0">
                    <a href="<?php echo e(url('tags/'.$key->slug)); ?>" class="card_bidbtn_ btn btn-sm btn-success p-2 m-2 <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.view')); ?></a>
                    <a href="<?php echo e(route('post.edit', $key->id)); ?>" class="card_bidbtn_ btn btn-sm btn-primary p-2 m-2 <?php echo e(session('ar_class')); ?>" onclick="return confirm('<?php echo e(__('trans.Are You Sure?')); ?>')"><?php echo e(__('trans.edit')); ?></a>
                    <form action="<?php echo e(route('post.destroy', $key->id)); ?>" class="<?php echo e(session('ar_class')); ?>" method="POST" onsubmit="return confirm('<?php echo e(__('trans.Are You Sure?')); ?>')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="card_bidbtn_ btn btn-sm btn-danger p-2 m-2 <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.delete')); ?></button>
                    </form>
                    
                </div>
                <?php else: ?>
                <?php if($key->type == 'auction'): ?>
                <div class="d-flex align-items-center justify-content-center">
                    <a href="<?php echo e(url('tags/'.$key->slug)); ?>" class="card_bidbtn <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Bid')); ?></a>
                </div>
                <?php else: ?>
                <div class="d-flex align-items-center justify-content-center">
<?php
    $user = get_user($key->user_id);
    ?>
    <?php if($user->phone): ?>
    <a class="card_bidbtn <?php echo e(session('ar_class')); ?>" href="tel:<?php echo e($user->phone); ?>"><?php echo e(__('trans.CONTACT US')); ?></a>
    <?php elseif($user->email): ?>
    <a class="card_bidbtn <?php echo e(session('ar_class')); ?>" href="mailto:<?php echo e($user->email); ?>"><?php echo e(__('trans.CONTACT US')); ?></a>
<?php endif; ?>
                </div>
                <?php endif; ?>
                <?php endif; ?>
                
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div><?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/theme_1/post/all_post_data.blade.php ENDPATH**/ ?>