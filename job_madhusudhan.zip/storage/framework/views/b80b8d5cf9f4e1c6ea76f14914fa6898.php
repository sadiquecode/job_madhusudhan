<h2>Payment Cancel!</h2>
<a href="<?php echo e(url('/')); ?>">Home Page</a><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/payment/paymentcancel.blade.php ENDPATH**/ ?>