<?php

$user_id = auth()->id();
$current_user = get_user($user_id);
$current_week_data = get_main_details($current_user->type)['current_week'];
$report = get_main_details($current_user->type);
?>

<div class="sidebar-overlay" data-reff=""></div>  
    <script type="text/javascript" src="<?php echo e(url('public/assets/js/jquery-3.5.1.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/js/popper.min.js')); ?>"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/js/jquery.slimscroll.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/js/select2.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/js/moment.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/plugins/morris/morris.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/plugins/raphael/raphael.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/plugins/summernote/dist/summernote-bs4.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('public/assets/plugins/light-gallery/js/lightgallery-all.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('public/assets/js/app.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(url('public/assets/custom/categories.js')); ?>" data-base-url="<?php echo e(url('/')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('public/assets/custom/aitemplate.js')); ?>" data-base-url="<?php echo e(url('/')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('public/assets/custom/aitemplate_editor.js')); ?>" data-base-url="<?php echo e(url('/')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('public/assets/custom/subscriptions.js')); ?>" data-base-url="<?php echo e(url('/')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('public/assets/custom/bote_category.js')); ?>" data-base-url="<?php echo e(url('/')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('public/assets/custom/sic.js')); ?>" data-base-url="<?php echo e(url('/')); ?>"></script>


<script type="text/javascript" src="<?php echo e(url('public/assets/daterange/moment.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('public/assets/daterange/daterangepicker.min.js')); ?>"></script>
<script>

CKEDITOR.replace('body', {
    filebrowserUploadUrl: "<?php echo e(route('ckeditor.image-upload', ['_token' => csrf_token() ])); ?>",
    filebrowserUploadMethod: 'form'
});
CKEDITOR.disableAutoInline = true;
$(document).ready(function () {
    $('.ckeditor').ckeditor();
});



$(document).ready(function() {
    $('.menu_show img').addClass('img-fluid');
    var errorMessage = <?php echo json_encode(session('error'), 15, 512) ?>;
    if(errorMessage){
        document.getElementById("pageMessages").style.display = "block";
    }
    return;
});

$(function() {
  $('#daterange').daterangepicker({
    opens: 'left'
  }, function(start, end, label) {
    $('#from').val(start.format('YYYY-MM-DD'));
    $('#to').val(end.format('YYYY-MM-DD'));
    // console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
  });
});

    $('#offline_pay_details').change(function(){
        var id = $(this).val();
        var base_url = "<?php echo e(url('/')); ?>";
        $.ajax({
        type: 'GET',
        url: base_url+'/get_pay_details',
        data: { id: id },
        dataType: 'json',
        success: function (response) {
                if (response.status === 201) {
                    var pay_details = response.data;
                    $('#pay_details').text(pay_details.Description);
                }
            },
            error: function (xhr, status, error) {
                console.error(error);
            }
        });
    });

    $('#blog_lang').change(function () {
        var code = $(this).val();
        var base_url = "<?php echo e(url('/')); ?>";
        $.ajax({
        type: 'GET',
        url: base_url+'/get_blog_cat',
        data: { code: code },
        dataType: 'json',
        success: function (response) {
                if (response.status === 201) {
                    var bCategory = response.data;
                    var selectElement = $('select[name="category_id"]');
                    selectElement.empty();
                    for (var i = 0; i < bCategory.length; i++) {
                        var category = bCategory[i];
                        selectElement.append('<option value="' + category.id + '">' + category.cat_title + '</option>');
                    }
                }
            },
            error: function (xhr, status, error) {
                console.error(error);
            }
        });
    });

</script>
      <script>
    // Sample data for words per date
    // const salesData_ = [
    //   { date: "2023-06-17", words: 50000 },
    //   { date: "2023-06-18", words: 100000 },
    //   { date: "2023-06-19", words: 300000 },
    //   { date: "2023-06-20", words: 200000 },
    //   { date: "2023-06-21", words: 250000 },
    //   { date: "2023-06-22", words: 150000 },
    //   { date: "2023-06-23", words: 350000 },
    //   // Add more data for each date of the week
    // ];

    var salesData = <?php echo json_encode($current_week_data, 15, 512) ?>;

    // Extract dates and words values for the current week
    const currentDate = new Date();
    const currentWeek = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date(currentDate);
      date.setDate(currentDate.getDate() - i);
      const formattedDate = date.toISOString().split('T')[0];
      const data = salesData.find((item) => item.date === formattedDate);
      const words = data ? data.words : 0;
      currentWeek.unshift({ date: formattedDate, words: words });
    }

    // Extract dates and words values from the current week data
    // const dates = currentWeek.map((data) => data.date);
    const dates = currentWeek.map((data) => {
      const dateObj = new Date(data.date);
      const options = { month: 'short', day: 'numeric' };
      return dateObj.toLocaleString('en-US', options);
    });
    const words = currentWeek.map((data) => data.words);

    // Draw the line graph with filled area using jQuery and Highcharts
    $(function () {
      $('#used_words').highcharts({
        chart: {
          type: 'area'
        },
        title: {
          text: 'Total Words Generated (Current Week)',
          x: -20
        },
        xAxis: {
          categories: dates
        },
        yAxis: {
          title: {
            text: 'Words: <?php echo e($report['total_words']); ?>'
          }
        },
        series: [{
          name: 'Words: <?php echo e($report['total_words']); ?>',
          data: words,
          fillColor: {
            linearGradient: [0, 0, 0, $('#used_words').height()],
            stops: [
              [0, Highcharts.getOptions().colors[0]],
              [1, 'rgba(0,0,0,0)']
            ]
          },
          marker: {
            radius: 2
          },
          lineWidth: 1,
          states: {
            hover: {
              lineWidth: 1
            }
          },
          threshold: null
        }]
      });
    });



    // Chart
    if ($("#donutChart_").length > 0) {
        var colors = [
            '#55ce63',
            '#009efb',
            '#ffbc34',
            '#f62d51'
        ];

        Morris.Donut({
            element: 'donutChart_',
            data: [{
                    value: <?php echo e($report['module']['words']); ?>,
                    label: 'Words'
                },
                {
                    value: <?php echo e($report['module']['image']); ?>,
                    label: 'Images'
                },
                {
                    value: <?php echo e($report['module']['code']); ?>,
                    label: 'Code'
                },
                {
                    value: <?php echo e($report['module']['speech']); ?>,
                    label: 'Speech'
                }
            ],
            labelColor: '#333',
            resize: true,
            colors: colors
        });
    }




function showLoader() {
  // Show the loader by setting its display style to "block"
  document.getElementById('img_loader').style.display = 'block';
}


$(document).ready(function () {
    $('#languageSelect').on('change', function () {
        $('#languageForm').submit();
    });
});

$(document).ready(function () {
    $('#FeatureslanguageSelect').on('change', function () {
        $('#FeatureslanguageForm').submit();
    });
});

$(document).ready(function () {
    $('#FaqlanguageSelect').on('change', function () {
        $('#FaqlanguageForm').submit();
    });
});
    $(document).ready(function() {
        $('.editbutton').click(function() {
            $(this).hide();
            var container = $(this).closest('form').find('[data-id]');
            container.show();
            $(this).closest('form').find('.text').hide()
        });

        $('.cancelbutton').click(function() {
            var container = $(this).closest('form').find('[data-id]');
            container.hide();
            $('.editbutton').show();
            $(this).closest('form').find('.text').show()
            var inputField = container.find('[name="lang_value"]');
            // inputField.val('');
        });

        $('.savebutton').click(function() {
            var form = $(this).closest('form');
            var dataId = form.find('.edit-container').data('id');
            var lang_code = form.find('[name="lang_code"]').val();
            var lang_key = form.find('[name="lang_key"]').val();
            var lang_value = form.find('[name="lang_value"]').val();
            // Submit the form
            // form.submit();
            if(lang_value == ''){
                showErrorMessage('Fill Data');
                return;
            }
            var base_url = "<?php echo e(url('/')); ?>";
                $.ajax({
                    type: 'POST',
                    url: base_url+'/update_val',
                    data: {
                        dataId: dataId,
                        lang_code: lang_code,
                        lang_key: lang_key,
                        lang_value: lang_value,
                        _token: '<?php echo e(csrf_token()); ?>',
                    },
                    success: function (data) {
                        if(data.status == 200){
                        form.find('.edit-container').hide();
                        $('.editbutton').show();
                        form.find('.text').show()
                        form.find('.text').text(data.res)
                        showSuccessMessage(data.msg);
                        }else{
                            showErrorMessage('Something Wrong!');
                        }

                    },
                    error: function (xhr, status, error) {
                        // console.log('AJAX Error: ' + error);
                        showErrorMessage('Something Wrong!');
                    }
                });


        });

    });

// toggleFavorite
function toggleFavorite(templateId) {
  var base_url = "<?php echo e(url('/')); ?>";
    // Send an AJAX request to the server to add/delete the template from favorites
    $.ajax({
        type: 'POST',
        url: base_url+'/toggle-favorite',
        data: {
            template_id: templateId,
            _token: '<?php echo e(csrf_token()); ?>',
        },
        success: function (data) {
            // If the request is successful, update the heart icon color based on the response
            if (data.is_favorite) {
                $('.temp_'+templateId).addClass('text-danger').removeClass('text-secondary');
                showSuccessMessage('Template favorited!');
            } else {
                $('.temp_'+templateId).addClass('text-secondary').removeClass('text-danger');
                showSuccessMessage('Template unfavorited!');
            }
        },
        error: function (xhr, status, error) {
            // console.log('AJAX Error: ' + error);
            showErrorMessage('Something Wrong!');
        }
    });
}

// Success message Function 
function showSuccessMessage(message) {
    var alertContainer = $('#alert-container');
    var alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">' +
        '<strong>Success!</strong> ' + message +
        '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' +
        '<span aria-hidden="true">&times;</span>' +
        '</button>' +
        '</div>';
    alertContainer.html(alert);
    alertContainer.show();
}

// Error message Function 
function showErrorMessage(message) {
    var alertContainer = $('#alert-container');
    var alert = '<div class="alert alert-danger alert-dismissible fade show" role="alert">' +
        '<strong>Error!</strong> ' + message +
        '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' +
        '<span aria-hidden="true">&times;</span>' +
        '</button>' +
        '</div>';
    alertContainer.html(alert);
    alertContainer.show();
}
  </script>

</body>

</html><?php /**PATH G:\server\htdocs\advance_ai\resources\views/layouts/footer.blade.php ENDPATH**/ ?>