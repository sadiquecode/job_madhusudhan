<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<div class="main-wrapper">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">
<div class="content container-fluid">
    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
    <?php endif; ?>

    <?php if (Auth::user()->type == 'admin') { ?>


    <div class="row">
        <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
            <div class="dash-widget dash-widget5">
                <a href="<?php echo e(url('dashboard/customers')); ?>">
                <span class="dash-widget-icon bg-success">
                    <i class="far fa-user"></i>
                </span>
                </a>
                <div class="dash-widget-info">
                    <h3><?php echo e($total_users); ?></h3>
                    <span>Total Users</span>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
            <div class="dash-widget dash-widget5">
                <a href="<?php echo e(url('dashboard/brand')); ?>">
                    <span class="dash-widget-icon bg-info">
                    <i class="fa fa-pen"></i>
                </span>
                </a>
                <div class="dash-widget-info">
                    <h3><?php echo e($total_brand); ?></h3>
                    <span>Total Brand</span>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
            <div class="dash-widget dash-widget5">
            <a href="<?php echo e(url('dashboard/region')); ?>">
                <span class="dash-widget-icon bg-warning">
                    <i class="fa fa-pen"></i>
                </span>
            </a>
                <div class="dash-widget-info">
                    <h3><?php echo e($total_region); ?></h3>
                    <span>Total Region</span>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
            <div class="dash-widget dash-widget5">
                <a href="<?php echo e(url('search')); ?>" target="_blank">
                <span class="dash-widget-icon bg-danger">
                    <i class="fa fa-pen"></i>
                </span>
                </a>
                <div class="dash-widget-info">
                    <h3><?php echo e($total_post); ?></h3>
                    <span>Total Post</span>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-md-12">
            <div class="card card-table">
                <div class="card-header bg-white">
                    <h4 class="card-title m-b-0">Recent Users</h4>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped custom-table m-b-0">
                        <thead>
                            <tr>
                                <th>S/L</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Created Date</th>
                                <th class="text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            

                            <?php if($latest_users->isEmpty()): ?>
                                <?php echo e('User Not Found!'); ?>

                            <?php else: ?>
                            <?php $count = 1; ?>
                            <?php $__currentLoopData = $latest_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($count); ?></td>
                                    <td><?php echo e($user->name.' '.$user->lname); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->phone); ?></td>
                                    <td><?php echo e(date('m/d/y', strtotime($user->created_at))); ?></td>
                                    <td class="text-right">
                                        <div class="dropdown dropdown-action">
                                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="<?php echo e(url('profile/'.Crypt::encrypt($user->id))); ?>"><i class="fas fa-eye m-r-5"></i> Profile</a>
                                                
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php $count++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                                


                        </tbody>
                    </table>
                </div>
                <div class="card-footer bg-white text-center">
                    <a href="<?php echo e(url('dashboard/customers')); ?>" class="text-muted">View All Users</a>
                </div>
            </div>
        </div>
    </div>

<!-- User Dashboard -->
    <?php }?>
</div>

</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/main/dashboard.blade.php ENDPATH**/ ?>