<div class="sidebar" id="sidebar"> 
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul class="">
                <li class="">
                    <a href="<?php echo e(url('/')); ?>" target="_blank"><i class="fa fa-globe"></i>Website</a>
                </li>
            </ul>
            <!-- Supper admin -->
            <ul>
                <li class="menu-title">MAIN</li>
                <li class="<?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('/dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                </li>


                <li class="menu-title">USERS</li>
                <li class="<?php echo e(request()->is('dashboard/customers') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('dashboard/customers')); ?>"><i class="fas fa-users"></i> Students</a>
                </li>
                <li class="<?php echo e(request()->is('dashboard/tutor') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('dashboard/tutor')); ?>"><i class="fas fa-graduation-cap"></i> Tutors</a>
                </li>

                <li class="menu-title">Global</li>
                <li class="<?php echo e(request()->is('dashboard/location') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('dashboard/location')); ?>"><i class="fas fa-compass"></i> Locations</a>
                </li>

                <li class="<?php echo e(request()->is('dashboard/subject') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('dashboard/subject')); ?>"><i class="fas fa-book"></i> Subjects</a>
                </li>
                <li class="<?php echo e(request()->is('dashboard/grade') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('dashboard/grade')); ?>"><i class="fas fa-ribbon"></i> Grades</a>
                </li>
                <li class="<?php echo e(request()->is('dashboard/curriculum') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('dashboard/curriculum')); ?>"><i class="fas fa-school"></i> Curriculums</a>
                </li>
                <li class="<?php echo e(request()->is('dashboard/review') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('dashboard/review')); ?>"><i class="fas fa-comments"></i> Reviews</a>
                </li>

                <li class="<?php echo e(request()->is('all_languages') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('all_languages')); ?>"><i class="fas fa-language"></i> Languages</a>
                </li>

                <li class="<?php echo e(request()->is('dashboard/package') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('dashboard/package')); ?>"><i class="fas fa-box-open"></i> Packages</a>
                </li>

                <li class="<?php echo e(request()->is('dashboard/payment') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('dashboard/payment')); ?>"><i class="fas fa-credit-card"></i> Payments</a>
                </li>

                <li class="<?php echo e(request()->is('dashboard/contacts') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('dashboard/contacts')); ?>"><i class="fas fa-sms"></i> Inquiries</a>
                </li>



                

                <li class="menu-title d-none">MANAGE CONTENTS</li>
                <li class="submenu  d-none">
                    <a href="#"><i class="fas fa-home"></i> <span> Home Page</span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                    <li><a href="<?php echo e(url('dashboard/menu')); ?>">Menus</a></li>
                    <li><a href="<?php echo e(url('dashboard/slider')); ?>">Slider</a></li>
                    <li><a href="<?php echo e(url('about-page')); ?>">Other Pages</a></li>
                    
                    </ul>
                </li>
                
                
                

                <li class="menu-title">MANAGE SETTINGS</li>
                <li>
                    <a href="<?php echo e(url('dashboard/settings/general-settings')); ?>"><i class="fas fa-cog"></i> General</a>
                </li>
                <li class="d-none">
                    <a href="<?php echo e(url('all_languages')); ?>"><i class="fas fa-language"></i> Languages</a>
                </li>
                <br><br><br>
            </ul>

        </div>
    </div>
</div><?php /**PATH G:\server\htdocs\techme_latest\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>