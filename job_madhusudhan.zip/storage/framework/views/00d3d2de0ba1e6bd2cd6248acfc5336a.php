<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="page-title">Page View</h4>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-8">
                    <div class="blog-view">
                        <article class="blog blog-single-post">
                            <h3 class="blog-title"><?=$page->page_title?></h3>
                            <div class="blog-info clearfix">
                                <div class="post-left">
                                    <ul>
                                        <li><a href="#."><i class="far fa-calendar-alt"></i> <span><?php echo e(date('M d Y', strtotime($page->created_at))); ?></span></a></li>
                                    </ul>
                                </div>
                                <div class="post-right"><i class="fa fa-language"></i><?php echo e(get_lang($page->lang_code)->name); ?></div>
                            </div>
                            <div class="blog-content menu_show">
                                <?=$page->body?>
                            </div>
                        </article>
                    </div>
                </div>
                <aside class="col-md-4">
                    <div class="widget search-widget">
                        <h5>SEO Details</h5>
                        <div class="blog-view">
                            <article class="blog blog-single-post">
                                <h6>Meta Title</h6>
                                <h3 class="blog-title">
                                <?php
                                $meta_title = $page->meta_title;
                                if (!empty($meta_title)) {
                                echo $meta_title;
                                } else {
                                echo "Not Found";
                                }
                                ?>
                                </h3>
                                <h6>Meta Image</h6>
                                <div class="blog-image">
                                    <a href="#."><?php if(!empty($page->meta_image)): ?>
                                        <img alt="" src="<?php echo e(url(env('img_path') . $page->meta_image)); ?>" class="img-fluid">
                                        <?php else: ?>
                                        <img alt="Not Found" src="<?php echo e(url('public/assets/img/blog/blog-thumb-01.jpg')); ?>" class="img-fluid">
                                        <?php endif; ?>
                                    </a>
                                </div>
                                <h6>Meta Description</h6>
                                <div class="blog-content">
                                    <?php
                                    $meta_desc = $page->meta_desc;
                                    if (!empty($meta_desc)) {
                                    echo $meta_desc;
                                    } else {
                                    echo "Not Found";
                                    }
                                    ?>
                                </div>
                            </article>
                        </div>
                    </div>
                </aside>
            </div>
            
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/web/all_menu_show.blade.php ENDPATH**/ ?>