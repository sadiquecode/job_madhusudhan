<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<div class="main-wrapper">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">


<style>
    .color_blue{ background-color: #00428b; }
    .color_yellow{ background-color: #f8a723; }
</style>

<div class="content container-fluid">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-md-6 col-lg-6 col-xl-3">
                        <div class="dash-widget dash-widget5">
                            <span class="dash-widget-icon color_blue"><i class="fas fa-users" aria-hidden="true"></i></span>
                            <div class="dash-widget-info">
                                <h3><?php echo e($total_users); ?></h3>
                                <span>Students</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-md-6 col-lg-6 col-xl-3">
                        <div class="dash-widget dash-widget5">
                            <span class="dash-widget-icon color_yellow"><i class="fas fa-graduation-cap"></i></span>
                            <div class="dash-widget-info">
                                <h3><?php echo e($total_tutor); ?></h3>
                                <span>Tutors</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-md-6 col-lg-6 col-xl-3">
                        <div class="dash-widget dash-widget5">
                            <span class="dash-widget-icon color_blue"><i class="fas fa-book"></i></span>
                            <div class="dash-widget-info">
                                <h3><?php echo e($total_subjects); ?></h3>
                                <span>Subjects</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-md-6 col-lg-6 col-xl-3">
                        <div class="dash-widget dash-widget5">
                            <span class="dash-widget-icon color_yellow"><i class="fas fa-money-bill" aria-hidden="true"></i></span>
                            <div class="dash-widget-info">
                                <h3><?php echo e($total_subscriptionss); ?></h3>
                                <span>Subscriptions</span>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-md-6 col-sm-6 col-md-6 col-lg-6 col-xl-3">
                        <div class="dash-widget dash-widget5">
                            <span class="dash-widget-icon color_blue"><i class="fas fa-ribbon" aria-hidden="true"></i></span>
                            <div class="dash-widget-info">
                                <h3><?php echo e($total_grades); ?></h3>
                                <span>Grades</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-md-6 col-lg-6 col-xl-3">
                        <div class="dash-widget dash-widget5">
                            <span class="dash-widget-icon color_yellow"><i class="fas fa-school"></i></span>
                            <div class="dash-widget-info">
                                <h3><?php echo e($total_curriculums); ?></h3>
                                <span>Curriculums</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-md-6 col-lg-6 col-xl-3">
                        <div class="dash-widget dash-widget5">
                            <span class="dash-widget-icon color_blue"><i class="fas fa-comments"></i></span>
                            <div class="dash-widget-info">
                                <h3><?php echo e($total_reviews); ?></h3>
                                <span>Reviews</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-md-6 col-lg-6 col-xl-3">
                        <div class="dash-widget dash-widget5">
                            <span class="dash-widget-icon color_yellow"><i class="fas fa-language" aria-hidden="true"></i></span>
                            <div class="dash-widget-info">
                                <h3><?php echo e($total_languages); ?></h3>
                                <span>Languages</span>
                            </div>
                        </div>
                    </div>
                </div>


<div class="row d-none">
            <div class="col-md-12">
                <div class="card card-table card-table-top">
                    <div class="card-header bg-white">
                        <h4 class="card-title m-b-0">Payments</h4>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-striped custom-table m-b-0">
                                <thead>
                                    <tr>
                                        <th>Invoice ID</th>
                                        <th>Client</th>
                                        <th>Payment Type</th>
                                        <th>Paid Date</th>
                                        <th>Paid Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><a href="invoice-view.html">#INV-0004</a></td>
                                        <td>
                                            <h2><a href="#">Barry Cuda</a></h2>
                                        </td>
                                        <td>Stripe</td>
                                        <td>11 Jun 2017</td>
                                        <td>$380</td>
                                    </tr>
                                    <tr>
                                        <td><a href="invoice-view.html">#INV-0005</a></td>
                                        <td>
                                            <h2><a href="#">Tressa Wexler</a></h2>
                                        </td>
                                        <td>Stripe</td>
                                        <td>21 Jul 2017</td>
                                        <td>$500</td>
                                    </tr>
                                    <tr>
                                        <td><a href="invoice-view.html">#INV-0006</a></td>
                                        <td>
                                            <h2><a href="#">Ruby Bartlett</a></h2>
                                        </td>
                                        <td>Stripe</td>
                                        <td>28 Aug 2017</td>
                                        <td>$60</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer text-center bg-white">
                        <a href="#" class="text-muted">View all payments</a>
                    </div>
                </div>
            </div>
        </div>
</div>





</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH G:\server\htdocs\techme_latest\resources\views/main/dashboard.blade.php ENDPATH**/ ?>