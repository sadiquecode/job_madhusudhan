<div class="row py-5 px-4 gx-2">
                
                <?php if($post_data->isEmpty()): ?>
                <p class="py-3">Data Not Found!</p>
                <?php else: ?>
                <?php $__currentLoopData = $post_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-sm-6 col-md-4 col-lg-3 col-12">
                        <div class="card auction_card border-0 px-0">
                            <div class="text-center terminat_btn_ active_btn position-relative">
                                <a href="#" class="d-block position-absolute"><?php echo e($key->status); ?></a>
                                <img src="<?php echo e(url(env('img_path').post_img($key->id)->img )); ?>"
                                class="card-img-top img-fluid" alt="...">
                            </div>
                            <div class="card-body px-0 heading">
                                <a href="<?php echo e(url('tags/'.$key->slug)); ?>"> <h4 class="card_title mb-4"><?php echo e($key->product_name); ?></h4></a>
                                <p class="card_text d-flex"><small><?php echo e(\Carbon\Carbon::parse($key->created_at)->format('d F H:i')); ?></small>
                                </p>
                                <p class=" card_text d-flex mb-5"><small>(GMT+3) KSA</small></p>
                            <?php if($key->type == 'auction'): ?>
                            <div class="d-flex align-items-center justify-content-center">
                                <a href="<?php echo e(url('tags/'.$key->slug)); ?>" class="card_bidbtn"><?php echo e(__('trans.Bid')); ?></a>
                                
                            </div>
                            <?php else: ?>
                            <div class="d-flex align-items-center justify-content-center">
                                <a href="<?php echo e(url('chat/'.$key->user_id)); ?>" class="card_bidbtn <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Contract')); ?></a>
                            </div>
                            <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div><?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/theme_1/post/all_post_data.blade.php ENDPATH**/ ?>