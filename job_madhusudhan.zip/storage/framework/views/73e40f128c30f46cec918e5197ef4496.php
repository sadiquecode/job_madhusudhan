<div class="col-sm-8 col-md-8 col-lg-8 col-xl-9">
	<h6 class="card-title m-b-20">SignUp Page</h6>
	<form class="m-b-30" action="<?php echo e(route('webpage.update', $webpage->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
		<div class="card-box">
			<div class="row">
				
				<div class="col-md-12">
					<h4 class="card-title">SignUp Section</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Heading:</label>
								<input type="text" class="form-control" name="signup_heading" value="<?php echo e($webpage->signup_heading); ?>">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Name:</label>
								<input type="text" class="form-control" name="signup_name" value="<?php echo e($webpage->signup_name); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Email:</label>
								<input type="text" class="form-control" name="signup_email" value="<?php echo e($webpage->signup_email); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Password:</label>
								<input type="text" class="form-control" name="signup_password" value="<?php echo e($webpage->signup_password); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Confirm Password:</label>
								<input type="text" class="form-control" name="signup_cpassword" value="<?php echo e($webpage->signup_cpassword); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Submit:</label>
								<input type="text" class="form-control" name="signup_button" value="<?php echo e($webpage->signup_button); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Or:</label>
								<input type="text" class="form-control" name="signup_or" value="<?php echo e($webpage->signup_or); ?>">
							</div>
						</div>

						<div class="col-md-12">
							<div class="form-group">
								<label>Google SignUp:</label>
								<input type="text" class="form-control" name="signup_google" value="<?php echo e($webpage->signup_google); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Facebook SignUp:</label>
								<input type="text" class="form-control" name="signup_fb" value="<?php echo e($webpage->signup_fb); ?>">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="text-right">
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
		</div>
	</form>
</div><?php /**PATH G:\server\htdocs\advance_ai\resources\views/web/forms/signup_page.blade.php ENDPATH**/ ?>