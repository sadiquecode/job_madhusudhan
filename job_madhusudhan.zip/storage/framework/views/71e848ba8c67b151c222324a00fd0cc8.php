<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.topheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ============================== Banner Start ==============================-->
    <section class="banner">
        <div class="container">
            <div class="banner_wrapper text-center py-5 mx-auto">
                <h1>Drive better results instantly</h1>
                <p>Write more eCommerce product content and watch your performance on SERPs and conversions skyrocket
                </p>
                <div class="banner_btn">
                    <a href="#" class="btn btn-lg mt-4 py-3 px-4">Get Started for Free</a>
                </div>
            </div>
        </div>
    </section>
    <!-- ============================== Banner End ==============================-->


    <!-- ================blog=========-->
    <div class="how__start py-5">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="card mt-5">
                        <img src="<?php echo e(url('public/theme_one_assets/images/blog/1.png')); ?>" class="card-img-top" alt="...">
                        <div class="blog card-body">
                            <h5 class="card-title"><a href="blog_details.html" class="text-dark">From 169 Customers to
                                    8,266 in 28 Days: How Frase Built the Biggest AppSumo Launch Ever</a></h5>
                            <a href="#" class="btn btn-dark">Read More...</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="card mt-5">
                        <img src="<?php echo e(url('public/theme_one_assets/images/blog/2.png')); ?>" class="card-img-top" alt="...">
                        <div class="blog card-body">
                            <h5 class="card-title"><a href="blog_details.html" class="text-dark">From 169 Customers to
                                    8,266 in 28 Days: How Frase Built the Biggest AppSumo Launch Ever</a></h5>
                            <a href="#" class="btn btn-dark">Read More...</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="card mt-5">
                        <img src="<?php echo e(url('public/theme_one_assets/images/blog/1.png')); ?>" class="card-img-top" alt="...">
                        <div class="blog card-body">
                            <h5 class="card-title"><a href="blog_details.html" class="text-dark">From 169 Customers to
                                    8,266 in 28 Days: How Frase Built the Biggest AppSumo Launch Ever</a></h5>
                            <a href="#" class="btn btn-dark">Read More...</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="card mt-5">
                        <img src="<?php echo e(url('public/theme_one_assets/images/blog/2.png')); ?>" class="card-img-top" alt="...">
                        <div class="blog card-body">
                            <h5 class="card-title"><a href="blog_details.html" class="text-dark">From 169 Customers to
                                    8,266 in 28 Days: How Frase Built the Biggest AppSumo Launch Ever</a></h5>
                            <a href="#" class="btn btn-dark">Read More...</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ===============end blog========-->
<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/theme_1/blog.blade.php ENDPATH**/ ?>