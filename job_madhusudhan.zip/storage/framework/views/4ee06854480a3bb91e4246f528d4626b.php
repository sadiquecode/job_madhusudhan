<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <meta name="robots" content="index, follow"> -->
    <meta name="robots" content="noindex">
    <meta name="title" content="<?=$title?>">
    <meta name="description" content="<?=$description?>">

    <meta name="author" content="TeachMe">
    <!-- MEDA FOR SEARCH ENGINES AND SOCIAL PLATFORMS -->
    <meta property="og:locale" content="en_US" />
    <meta property="og:title" content="<?=$title?>">
    <meta property="og:description" content="<?=$description?>">
    
    <meta property="og:image" content="">
    <meta property="og:site_name" content="TeachMe"/>
    <meta property="og:url" content="<?php echo e(url('/')); ?>">
    <meta property="og:publisher" content="TeachMe"/>
    <!-- TWITTER CARD -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:site" content="@'TeachMe' | <?=$title?>" />
    <meta name="twitter:title" content="<?=$title?>" />
    <meta name="twitter:description" content="<?=$description?>" />
    <meta name="twitter:image" content="">
    <link rel="icon" href="assets/images/logo/favicon.png">
    <title>Teach Me | <?=$title?></title>
    <link rel="canonical" href="<?php echo e(url()->current()); ?>" />
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="<?php echo e(url(env('img_path').get_general_settings()->favicon)); ?>" type="image/png"/>
    <link rel="stylesheet" href="<?php echo e(url('public/theme_assets/css/styles.css')); ?>">
    <link rel="stylesheet" href="https://unpkg.com/flickity@2/dist/flickity.min.css">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(url('public/theme_assets/assets/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(url('public/theme_assets/assets/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('public/theme_assets/assets/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(url('public/theme_assets/assets/site.webmanifest')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
      rel="stylesheet">
      <style>
      
      .alert
      {
      margin-top: 3% !important;
      }
      
      /* width */
      
      
      ::-webkit-scrollbar
      {
      width: 6px;
      }
      /* Track */
      ::-webkit-scrollbar-track {
      background: #f1f1f1;
      }
      /* Handle */
      ::-webkit-scrollbar-thumb {
      background: #888;
      }
      /* Handle on hover */
      ::-webkit-scrollbar-thumb:hover {
      background: #555;
      }
      </style>
    </head>
    <body class="<?php echo e(request()->is('login') || request()->is('register') ? 'bg-body-tertiary' : ''); ?>">
      <!-- Header -->
      <header class="header-bg border-bottom border-1 border-primary border-opacity-25">
        <div class="container py-2">
          <nav class="navbar navbar-expand-lg" aria-label="Offcanvas navbar large">
            <div class="container-fluid">
              <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img class="img-fluid" src="<?php echo e(url(env('img_path') .get_general_settings()->logo)); ?>" role="img"
              alt="Teach me logo"></a>
              <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar"
              aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
              </button>
              <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar"
                aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                  <img class="img-fluid" src="<?php echo e(url(env('img_path') .get_general_settings()->logo)); ?>" role="img" alt="Teach me logo">
                  <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                  <ul class="navbar-nav justify-content-end flex-grow-1 pe-3 gap-xl-4">
                    <li class="nav-item"><a href="<?php echo e(url('/')); ?>" class="nav-link">Home</a></li>
                    <li class="nav-item"><a href="<?php echo e(url('find-tutors')); ?>" class="nav-link">Find Tutors</a></li>
                    <li class="nav-item"><a href="<?php echo e(url('how-it-works')); ?>" class="nav-link">How it works</a></li>
                    <li class="nav-item"><a href="<?php echo e(url('contact-us')); ?>" class="nav-link">Contact Us</a></li>
                    <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item">
                      <div class="dropdown">
                        <button id="profile-btn"
                        class="btn btn-link btn-sm text-decoration-none dropdown-toggle d-flex align-items-center gap-2"
                        type="button" data-bs-toggle="dropdown" aria-expanded="false" data-tm-target="instruction-mode">
                        
                        <?php if(empty(Auth::user()->profile_pic)): ?>
                        <img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="Tutor Avatar" class="box-shadow-md" width="40" height="40">
                        <?php else: ?>
                        <img alt="Tutor Avatar" class="box-shadow-md" width="40" height="40" src="<?php echo e(url(env('img_path'). Auth::user()->profile_pic)); ?>">
                        <?php endif; ?>
                        <div class="text-uppercase fw-semibold d-flex flex-column text-start">
                          <span class="text-primary title"><?php echo e(ucfirst(Auth::user()->role)); ?></span>
                          <span class="name"><?php echo e(ucfirst(Auth::user()->name)); ?></span>
                        </div>
                        </button>
                        <div id="profile-menu" class="dropdown-menu mt-3 border-0">
                          <!-- List of available instruction Mode -->
                          <div class="list-group px-2 gap-2 border-0">
                            <?php
                            if (Auth::user()->type == 'admin') {
                            ?>
                            
                            <a href="<?php echo e(url('dashboard')); ?>" class="list-group-item list-group-item-action rounded-4 py-2">
                              <img src="<?php echo e(asset('public/theme_assets/images/icons/profile-circle.svg')); ?>" aria-hidden="true" class="me-2">Dashboard
                            </a>
                            <?php }else{ ?>
                            <a href="<?php echo e(url('profile/'.encrypt(Auth::user()->id))); ?>" class="list-group-item list-group-item-action rounded-4 py-2">
                              <img src="<?php echo e(asset('public/theme_assets/images/icons/profile-circle.svg')); ?>" aria-hidden="true" class="me-2">Profile
                            </a>
                            <?php } ?>
                            <a href="<?php echo e(url('logout')); ?>" class="list-group-item list-group-item-action rounded-4 py-2">
                              <img src="<?php echo e(asset('public/theme_assets/images/icons/logout.svg')); ?>" aria-hidden="true" class="me-2">Logout
                            </a>
                            
                          </div>
                        </div>
                      </div>
                    </li>
                    <?php else: ?>
                    <li class="nav-item"><a href="<?php echo e(url('login')); ?>" class="btn btn-primary py-2 px-4" aria-current="page">Join Today</a></li>
                    <?php endif; ?>
                  </ul>
                </div>
              </div>
            </div>
          </nav>
        </div>
      </header><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/layouts/head.blade.php ENDPATH**/ ?>