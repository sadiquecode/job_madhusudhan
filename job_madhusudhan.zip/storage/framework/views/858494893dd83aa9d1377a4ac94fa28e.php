    <!-- ==============================Banner Start==============================-->
    <section class="banner_carousel">
        <div class="container-fluid px-0">
            <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php $count = 1; ?>
                    <?php $__currentLoopData = $sliderData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item item_carousel <?php if($count === 1): ?> active <?php endif; ?>" data-bs-interval="10000">
                            <img src="<?php echo e(url(env('img_path').$slider['img'])); ?>" class="d-block w-100 img-fluid" alt="...">
                            <div class="carousel-caption caption_carousel">
                                <h5 class="<?php echo e(session('ar_class')); ?> mb-4">
                                    <?php echo e($slider['heading']); ?>

                                </h5>
                                <a href="#" class="<?php echo e(session('ar_class')); ?>">
                                    <?php echo e($slider['btn']); ?>

                                </a>
                            </div>
                        </div>
                        <?php $count++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </section>
    <!-- ==============================Banner End==============================-->
    <!-- ==============================Modal Start==============================-->
<?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/theme_1/layouts/header.blade.php ENDPATH**/ ?>