<?php app()->setLocale(session('locale')); ?>
<!doctype HTML>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AI Chat Assistants | Web</title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(url('public/theme_one_assets/images/logo/favicon.svg')); ?>" type="image/svgicon">
    <!-- font Awesome  -->
    <script src="https://kit.fontawesome.com/31cf530d7e.js" crossorigin="anonymous"></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(url('public/theme_one_assets/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/theme_one_assets/bootstrap/bootstrap.min.css.map')); ?>">
    <!-- Custom CSS -->
    <?php if(!empty(session('direction')) && session('direction') == 'rtl'): ?>
    <link rel="stylesheet" href="<?php echo e(url('public/theme_one_assets/css/style-rtl.css')); ?>">
    <?php else: ?>
    <link rel="stylesheet" href="<?php echo e(url('public/theme_one_assets/css/style.css')); ?>">
    <?php endif; ?>

        <style>
            <?php if(session('locale') == 'ar' || session('locale') == 'ur'): ?>
                @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic:wght@300&display=swap');

                @import url('https://fonts.googleapis.com/css2?family=Noto+Nastaliq+Urdu&family=Noto+Sans+Arabic:wght@200;300&display=swap');

                body{
                    font-family: 'Noto Sans Arabic', sans-serif;
                }
            <?php endif; ?>
        </style>

</head>

<body><?php /**PATH G:\server\htdocs\advance_ai\resources\views/theme_1/layouts/head.blade.php ENDPATH**/ ?>