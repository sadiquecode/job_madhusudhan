<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-3">
                    <h4 class="page-title">All Manue & Pages</h4>
                </div>
            </div>
            <div class="row filter-row">
                <div class="col-sm-12 col-md-8">
                    <form id="FaqlanguageForm" method="GET" action="<?php echo e(url('all_menu')); ?>">
                    <div class="form-group form-focus select-focus">
                        <label class="focus-label">Language</label>
                        <select class="select floating" id="FaqlanguageSelect" name="lang_code">
                        
                            <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option value="<?php echo e($lang->code); ?>" <?php if($lang->code == $code): ?>
                            <?php echo e('selected'); ?>

                        <?php endif; ?>><?php echo e($lang->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    </form>
                </div>
                <div class="col-sm-12 col-md-4">
                    <a href="#" class="btn btn-success btn-block" data-toggle="modal" data-target="#add_all_menu"> Add Menu </a>
                </div>
            </div>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <div class="row">
                <?php if(count($all_pages) > 0): ?>
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped custom-table datatable">
                            <thead>
                                <tr>
                                    <th>S/L</th>
                                    <th>Title</th>
                                    <th>Lang</th>
                                    <th>Status</th>
                                    <th>View</th>
                                    <th>section</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $all_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($index + 1); ?></td>
                                    <td><?php echo e($page->page_title); ?></td>
                                    <td><?php echo e($page->lang_code); ?></td>
                                    <td><?php echo e($page->status); ?></td>
                                    <td>
                                        <a class="btn-sm btn btn-primary" href="<?php echo e(route('all_menu.show', $page->id)); ?>">View</a>
                                    </td>
                                    <td><?php if($index + 1 < 6): ?>
                                        <?php echo e('Header '.$index + 1); ?> <?php else: ?> <?php echo e('Footer '.$index - 5 + 1); ?> <?php endif; ?>
                                    </td>
                                    <td class="text-right">
                                        <div class="dropdown dropdown-action">
                                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="<?php echo e(route('all_menu.edit', $page->id)); ?>"><i class="fas fa-pen m-r-5"></i> Edit</a>
                                                <?php if($index + 1 > 5 || $page->lang_code != 'en'): ?>
                                                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_page_<?php echo e($page->id); ?>"><i class="far fa-trash-alt m-r-5"></i> Delete</a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <div id="delete_page_<?php echo e($page->id); ?>" class="modal custom-modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content modal-md">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Delete Menu</h4>
                                            </div>
                                            <form action="<?php echo e(route('all_menu.destroy', $page->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <div class="modal-body card-box">
                                                    <p>Are you sure want to delete this?</p>
                                                    <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
            </div>
            <?php else: ?>
            <p class="p-4"><?php echo e('Menu Not Found!'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>



<div id="add_all_menu" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="modal-content modal-lg">
            <div class="modal-header">
                <h4 class="modal-title">Add Menu & Content</h4>
            </div>
            <div class="modal-body">
                <form class="m-b-30" action="<?php echo e(route('all_menu.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Language <span class="text-danger">*</span></label>
                                <input type="text" name="lang_code" class="form-control" value="<?php echo e($code); ?>" readonly>
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Title <span class="text-danger">*</span></label>
                                <input type="text" name="page_title" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Content <span class="text-danger">*</span></label>
                                <textarea class="form-control ckeditor" rows="5" name="body" id="ckeditor1"></textarea>
                            </div>
                        </div>

                    <div class="col-sm-12">
                        <div class="form-group">
                            <label class="display-block">Status</label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="temp_cat_enable" value="enable" checked>
                                <label class="form-check-label" for="temp_cat_enable">
                                    enable
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="temp_cat_disable" value="disable">
                                <label class="form-check-label" for="temp_cat_disable">
                                    disable
                                </label>
                            </div>
                        </div>
                    </div>
                    </div>
                    <hr>
                    <b>SEO Section</b>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Meta Title <span class="text-danger"></span></label>
                                <input type="text" name="meta_title" class="form-control">
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Meta Image <span class="text-danger"></span></label>
                                <input type="file" name="meta_image" class="form-control">
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Meta Description <span class="text-danger"></span></label>
                                <textarea class="form-control" rows="5" name="meta_desc"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="m-t-20 text-center mb-5">
                        <button type="submit" class="btn btn-primary btn-lg">Create Menu</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/web/all_menu.blade.php ENDPATH**/ ?>