<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-3">
                    <h4 class="page-title">Code Report </h4>
                </div>
            </div>

            <form action="<?php echo e(url('reports/codes-generated')); ?>" method="GET">
            <div class="row filter-row">
                <div class="col-sm-6 col-md-4">
                    <div class="form-group form-focus">
                        <label class="focus-label">
                            <b class="text-dark">Codes (<?php echo e(formatNumber($totalcodes)); ?>)</b>
                        </label>
                    </div>
                </div>

                    <?php
                    if (!empty($start_date) && !empty($end_date)) {
                        $end_date = date('m/d/Y', strtotime($end_date));
                        $start_date = date('m/d/Y', strtotime($start_date));
                    } else {
                        $end_date = date('m/d/Y');
                        $start_date = date('m/d/Y', strtotime('-1 week', strtotime($end_date)));
                    }
                    ?>
                
                    <div class="col-sm-6 col-md-4">
                    <div class="form-group form-focus">
                        <label class="focus-label">From & To Date</label>
                        <input type="text" class="form-control floating" id="daterange" value="<?php echo e($start_date); ?> - <?php echo e($end_date); ?>">
                        <input type="hidden" name="from" id="from">
                        <input type="hidden" name="to" id="to">
                    </div>
                </div>
                <div class="col-sm-12 col-md-4">
                    <button type="submit" class="btn btn-success btn-block"> Search </button>
                </div>
            </div>
            </form>
            <div class="row">
                <?php if(count($reports_codes_generated) > 0): ?>
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped custom-table datatable">
                            <thead>
                                <tr>
                                    <th>S/L</th>
                                    <th>Title</th>
                                    <th>Generated On</th>
                                    <th>Words</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $reports_codes_generated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($index + 1); ?></td>
                                    <td><?php echo e($doc->project_name); ?></td>
                                    <td><?php echo e(date('d M, Y', strtotime($doc->created_date))); ?></td>
                                    <td><?php echo e($doc->words_size); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                        </tbody>
                    </table>
                </div>
                <?php echo e($reports_codes_generated->links()); ?>

            </div>
            <?php else: ?>
            <p class="p-4"><?php echo e('Codes Not Found!'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/reports/reports_codes_generated.blade.php ENDPATH**/ ?>