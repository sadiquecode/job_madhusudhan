<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if (Auth::user()->type == 'admin') { ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-3">
                    <h4 class="page-title">Histories</h4>
                </div>
            </div>
            <form method="GET" action="<?php echo e(url('dashboard/subscriptions/histories')); ?>">
                <div class="row filter-row">
                    <div class="col-sm-6 col-md-9">
                        <div class="form-group form-focus">
                            <label class="focus-label">Search By Name and Package</label>
                            <input type="text" class="form-control floating" name="search">
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <button class="btn btn-success btn-block"> Search </button>
                    </div>
                </div>
            </form>
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped custom-table datatable">
                            <thead>
                                <tr>
                                    <th>S/L</th>
                                    <th>User</th>
                                    <th>Package</th>
                                    <th>Price</th>
                                    <th>Payment</th>
                                    <th>Start Date</th>
                                    <th>Expire Date</th>
                                    <th class="text-center">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($index + 1); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('dashboard/profile/'.encrypt($item['user_id']))); ?>" class="avatar">
                                            <?php if(empty($item['profile_pic'])): ?>
                                            <img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="Profile Pic">
                                            <?php else: ?>
                                            <img src="<?php echo e(url(env('img_path') . $item['profile_pic'])); ?>" alt="Profile Pic">
                                            <?php endif; ?>
                                        </a>
                                        <h2><a href="<?php echo e(url('dashboard/profile/'.encrypt($item['user_id']))); ?>"><?php echo e($item['user_name']); ?></a></h2>
                                    </td>
                                    <td><?php echo e($item['package_name']); ?>/<?php echo e($item['package_type']); ?></td>
                                    <td>$<?php echo e($item['price']); ?></td>
                                    <td>
                                        <?php if($item['package_name'] == 'Free Trial'): ?>
                                        <?php echo e("Free"); ?>

                                        <?php else: ?>
                                        <?php echo e(get_payment_name($item['payment_method_id'],$item['offline_method_id'])); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(date('d M, Y', strtotime($item['start_date']))); ?></td>
                                    <td><?php echo e(date('d M, Y', strtotime($item['expire_date']))); ?></td>
                                    <td class="text-center">
                                        <div class="dropdown action-label">
                                            <a class="btn btn-white btn-sm btn-rounded dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                                <?php if($item['status'] == '1'): ?>
                                                <i class="far fa-dot-circle text-success"></i> Active
                                                <?php else: ?>
                                                <i class="far fa-dot-circle text-danger"></i> Inactive
                                                <?php endif; ?>
                                            </a>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item" href="#"><i class="far fa-dot-circle text-success"></i> Active</a>
                                                <a class="dropdown-item" href="#"><i class="far fa-dot-circle text-danger"></i> Inactive</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($data->links()); ?>

                </div>
            </div>
        </div>
    </div>
    <?php }else{ ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-3">
                    <h4 class="page-title">Histories</h4>
                </div>
            </div>
            <form method="GET" action="<?php echo e(url('dashboard/subscriptions/histories')); ?>">
                <div class="row filter-row">
                    <div class="col-sm-6 col-md-9">
                        <div class="form-group form-focus">
                            <label class="focus-label">Search By Package</label>
                            <input type="text" class="form-control floating" name="search">
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <button class="btn btn-success btn-block"> Search </button>
                    </div>
                </div>
            </form>
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <?php if(count($data) > 0): ?>
                        <table class="table table-striped custom-table datatable">
                            <thead>
                                <tr>
                                    <th>S/L</th>
                                    <th>Package</th>
                                    <th>Price</th>
                                    <th>Payment</th>
                                    <th>Start Date</th>
                                    <th>Expire Date</th>
                                    <th class="text-center">Status</th>
                                </tr>
                            </thead>
                            
                            <tbody>
                                
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($index + 1); ?></td>
                                    <td><?php echo e($item['package_name']); ?>/<?php echo e($item['package_type']); ?></td>
                                    <td>$<?php echo e($item['price']); ?></td>
                                    <td>
                                        <?php if($item['package_name'] == 'Free Trial'): ?>
                                        <?php echo e("Free"); ?>

                                        <?php else: ?>
                                        <?php echo e(get_payment_name($item['payment_method_id'],$item['offline_method_id'])); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(date('d M, Y', strtotime($item['start_date']))); ?></td>
                                    <td><?php echo e(date('d M, Y', strtotime($item['expire_date']))); ?></td>
                                    <td class="text-center">
                                        <div class="dropdown_ action-label">
                                            <a class="btn btn-white btn-sm btn-rounded dropdown-toggle_" data-toggle="dropdown" aria-expanded="false">
                                                <?php if($item['status'] == '1'): ?>
                                                <i class="far fa-dot-circle text-success"></i> Active
                                                <?php else: ?>
                                                <i class="far fa-dot-circle text-danger"></i> Inactive
                                                <?php endif; ?>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                        <?php else: ?>
                        <?php echo e('Package Not Active Yet'); ?>

                        <?php endif; ?>
                    </div>
                    <?php echo e($data->links()); ?>

                </div>
            </div>
        </div>
    </div>
    <?php } ?>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/subscriptions/history.blade.php ENDPATH**/ ?>