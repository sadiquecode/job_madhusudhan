<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="page-title"><?php echo e($aiTemplates->template); ?></h4>
                    <div class="word-used-wrapper ml-2">
                        <i class="icon-feather-bar-chart-2"></i>
                        <i id="quick-words-left"><?php echo e(get_main_details(auth()->user()->type)['used_words']); ?></i> / <?php echo e(get_main_details(auth()->user()->type)['useable_words']); ?> <strong>Words Used</strong>
                    </div>
                </div>
            </div>

                            
            <div id="alert-container" class="mt-3" style="display: none;"></div>

            <div class="row">
                <div class="col-md-4">
                    <div class="card-box">
                        <h4 class="card-title">
                        <i class="<?php echo e($aiTemplates->icon); ?> fa-2x_"></i>
                        <?php echo e($aiTemplates->template); ?>

                        </h4><hr>
                        <form class="mt-4" id="content_editor" enctype="multipart/form-data">
                            
                            <div class="alert alert-success" role="alert">
                                <?php echo e($aiTemplates->description); ?>

                            </div>
                            <?php if(!empty($aiTemplates->parameters)): ?>
                            <?php $__currentLoopData = json_decode($aiTemplates->parameters, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $inputName = ucwords(str_replace('_', ' ', $parameter['input_name'])); ?>
                            <div class="form-group">
                                <label><?php echo e($inputName); ?></label>
                                <?php if($parameter['type'] == 'text'): ?>
                                <span class="float-right">0/400</span>
                                <input type="text" class="form-control" name="_<?php echo e($parameter['input_name']); ?>_">
                                <span class="form-text text-muted">Describe your blog here...</span>
                                <?php elseif($parameter['type'] == 'textarea'): ?>
                                <span class="float-right">0/400</span>
                                <textarea class="form-control" name="_<?php echo e($parameter['input_name']); ?>_"></textarea>
                                <span class="form-text text-muted">Describe your blog here...</span>
                                <?php else: ?>
                                <?php
                                $options = $parameter['options'] ? explode(', ', $parameter['options']) : null;
                                ?>
                                <select class="select form-control" name="_<?php echo e($parameter['input_name']); ?>_">
                                    <option>Select State</option>
                                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <div class="form-group">
                                <label>Language</label>
                                <select class="select" name="lang">
                                    <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($lang->name == 'English'): ?>
                                        <option value="English" selected>English</option>
                                        <?php else: ?>
                                        <option value="<?php echo e($lang->name); ?>"><?php echo e($lang->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div> 
                            <div class="form-group">
                                <label>Quality type</label>
                                <select class="select" name="quality_type">
                                    <?php $__currentLoopData = $AIQuality; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($AISettings->quality_type_id == $quality->id): ?>
                                    <option value="<?php echo e($quality->quality); ?>" selected><?php echo e($quality->quality); ?></option>
                                    <?php else: ?>
                                    <option value="<?php echo e($quality->quality); ?>"><?php echo e($quality->quality); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Tone of Voice</label>
                                <span class="float-right"><i class="fa fa-question text-white rounded-circle" data-toggle="tooltip" title="Set the tone of the result." style="background: #333; cursor: pointer; padding: 0.3rem!important; font-size: .50em;"></i></span>
                                <select class="select" name="tone">
                                <?php $__currentLoopData = $AiTone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($AISettings->tone_of_voice_id == $tone->id): ?>
                                    <option value="<?php echo e($tone->tone); ?>" selected><?php echo e($tone->tone); ?></option>
                                    <?php else: ?>
                                    <option value="<?php echo e($tone->tone); ?>"><?php echo e($tone->tone); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                            
                            <div class="form-group">
                                <label>Number of Results</label>
                                <select class="select" name="res_no">
                                <?php $number_arr = array(1,2,3,4,5); ?>
                                    <?php $__currentLoopData = $number_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($val == $AISettings->number_of_results): ?>
                                        <option value="<?php echo e($val); ?>" selected><?php echo e($val); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($val); ?>"><?php echo e($val); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Max Results Length</label>
                                <span class="float-right"><i class="fa fa-question text-white rounded-circle" data-toggle="tooltip" title="Maximum words for each result." style="background: #333; cursor: pointer; padding: 0.3rem!important; font-size: .50em;"></i></span>
                                <input name="length" type="number" class="form-control" value="<?php echo e($AISettings->max_results_length); ?>" readonly>
                            </div>
                            
                            <input type="hidden" name="type" value="Content">
                            <input type="hidden" name="prompt_form" value="yes">
                            <input type="hidden" name="folder_id" value="0">
                            <input type="hidden" name="project_name" value="Untitled Document">
                            <input type="hidden" name="template_id" value="<?php echo e($aiTemplates->id); ?>">
                            <input type="hidden" name="slug" value="<?php echo e($aiTemplates->slug); ?>">
                            <input type="hidden" name="data_id" value="0" id="content_editor_id">

                            <div class="text-right">
                                <button class="btn btn-primary get_content">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="card-box">
                        <div class="d-flex align-items-center mb-3">
                            <h4 class="card-title">Generated Result</h4>
                            <div class="ml-auto">
                                <a class="btn btn-white" data-toggle="tooltip" data-placement="top" title="Export as Word Document">
                                    <i class="fa fa-file-word"></i>
                                </a>
                                <a class="btn btn-white" data-toggle="tooltip" data-placement="top" title="Export as Text File">
                                    <i class="fa fa-file"></i>
                                </a>
                                <a class="btn btn-white" data-toggle="tooltip" data-placement="top" title="Copy Text">
                                    <i class="fa fa-copy"></i>
                                </a>
                            </div>
                        </div>
                        <form action="#" id="content_res" enctype="multipart/form-data">
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="save_file" data-toggle="tooltip" data-placement="top" title="Save Document" style="cursor: pointer;"><i class="fa fa-save" ></i></span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Untitled Document" aria-label="Untitled Document" name="project_name" value="Untitled Document" aria-describedby="save_file">
                                    </div>
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="save_file_folder" data-toggle="tooltip" data-placement="top" title="Move to Folder" style="cursor: pointer;"><i class="fa fa-folder" ></i></span>
                                        </div>
                                        <select class="c-select form-control" name="folder_id">
                                            <option value="0" selected>Move to Folder</option>
                                            <?php $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($folder->id); ?>">
                                                <?php echo e(ucfirst($folder->folder_name)); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <textarea rows="4" cols="5" class="form-control summernote" placeholder="Enter your message here" name="content" id="res"></textarea>
                            </div>


                            <input type="hidden" name="type" value="Content">
                            <input type="hidden" name="prompt_form" value="no">
                            <input type="hidden" name="template_id" value="<?php echo e($aiTemplates->id); ?>">
                            <input type="hidden" name="slug" value="<?php echo e($aiTemplates->slug); ?>">
                            <input type="hidden" name="data_id" value="0" id="content_res_id">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/sic/ai_content.blade.php ENDPATH**/ ?>