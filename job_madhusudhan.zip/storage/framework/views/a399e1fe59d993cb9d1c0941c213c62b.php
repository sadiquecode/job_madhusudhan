<!-- Student profile content -->
<main id="profile-section" class="py-5 px-2 px-sm-4 mb-5">
  <div class="container rounded-5 p-4 gap-4 gap-md-5 box-shadow-md bg-white d-sm-flex">

    <!-- Tabs -->
      <ul
        class="nav nav-pills flex-sm-column flex-nowrap flex-sm-wrap overflow-x-auto overflow-x-sm-hidden overflow-x-md-visible gap-3 pe-sm-5 pe-md-4 pt-2 pb-2 pb-sm-0 border-end-sm justify-content-start border-bottom border-bottom-sm-0 "
        id="profile-tabs" role="tablist">
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php echo e($itsmainbtn); ?>" id="edit-tab" data-bs-toggle="tab" data-bs-target="#edit-tab-pane"
            type="button" role="tab" aria-controls="edit-tab-pane" aria-selected="true">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/user-square-light.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Profile</span>
          </button>
        </li>


        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php echo e($itseducationbtn); ?>" id="education-tab" data-bs-toggle="tab" data-bs-target="#education-tab-pane"
            type="button" role="tab" aria-controls="education-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/teacher.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Education</span>
          </button>
        </li>

        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php echo e($itspaymentbtn); ?>" id="payments-tab" data-bs-toggle="tab" data-bs-target="#payments-tab-pane"
            type="button" role="tab" aria-controls="payments-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/card.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Subscription</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link <?php echo e($itssettingbtn); ?>" id="settings-tab" data-bs-toggle="tab" data-bs-target="#settings-tab-pane"
            type="button" role="tab" aria-controls="settings-tab-pane" aria-selected="false">
            <img src="<?php echo e(asset('public/theme_assets/images/icons/video-octagon-light.svg')); ?>" aria-hidden="true" class="me-3">
            <span>Settings</span>
          </button>
        </li>
      </ul>

    <!-- Tab Panes -->
    <div class="tab-content mt-2 flex-grow-1" id="profile-tabs-content">
      <?php echo $__env->make('theme_1.userprofile.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Profile Panel -->
      <form name="profile-info-form" class="tab-pane fade <?php echo e($itsmain); ?>" id="edit-tab-pane" role="tabpanel" aria-labelledby="edit-tab" tabindex="0" action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="hidden" name="param" value="main">
        <input type="hidden" name="phone" value="0000000000">
        <input type="hidden" name="video_url" value="">
        <input type="hidden" name="virtual_mode" value="">
        <input type="hidden" name="in_person_mode" value="">
        <input type="hidden" name="zip_code" value="">
        <!-- Heading -->
        <div class="d-flex justify-content-between">
          <h3 class="fs-5">My Profile</h3>
          <button class="btn btn-success rounded-pill btn-sm border-secondary-subtle text-white" type="submit">Save<i class="ms-2 fa-solid fa-save" style="font-size: 12px;"></i>
          </button>
        </div>
        <!-- Profile Info -->
        <div class="card mt-4 p-1">
          <div class="card-body d-flex align-items-center gap-2">
            <div class="position-relative">
              
              <?php if(empty($user->profile_pic)): ?>
              <img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="Tutor Avatar" class="img-fluid rounded-circle" width="70" height="70" id="preview">
              <?php else: ?>
              <img alt="Tutor Avatar" class="img-fluid rounded-circle" width="70" height="70" src="<?php echo e(url(env('img_path'). $user->profile_pic)); ?>" id="preview">
              <?php endif; ?>
              <label class="btn btn-primary btn-sm rounded-circle box-shadow-sm position-absolute"
                style="bottom: -5px; right: -5px;">
                <i class="fa-solid fa-pencil"></i>
                <span class="visually-hidden">Upload New Profile Photo</span>
                <input type="file" name="profile_pic" class="visually-hidden" onchange="previewImage(event, 'preview')">
                <input type="hidden" name="old_profile_pic" value="<?php echo e($user->profile_pic); ?>">
              </label>
            </div>
            <div class="fw-semibold text-uppercase">
              <span class="text-warning" style="font-size:12px;"><?php echo e(ucfirst($user->role)); ?></span>
              <h4 class="fs-6 fw-semibold mb-0"><?php echo e(ucfirst($user->name.' '.$user->lname)); ?></h4>
              <span class="text-primary" style="font-size:12px;">
                
                <?php echo e($TeachmeLocationRelationship ? sub_location_name($TeachmeLocationRelationship->sub_location_id)->name ?? 'null' : 'null'); ?>,
                
                <?php echo e($TeachmeLocationRelationship ? sub_location_name($TeachmeLocationRelationship->location_id)->name ?? 'null' : 'null'); ?>

                
              </span>
            </div>
          </div>
        </div>

        <!-- Personal Info -->
        <fieldset name="personal-information" class="card mt-4 p-1">
          <div class="card-body">
            <!-- Header -->
            <h3 class="fs-5 mb-4">Personal Information</h3>
            <div class="p-2 mt-2">
              <div class="row gutter">
                <!-- First Name -->
                <div class="col-12 col-md-4 col-xl-4">
                  <label class="w-100">
                    <p class="title">First Name</p>
                    <input class="form-control mt-2 rounded-3" name="name" placeholder="Ahsan" required value="<?php echo e(old('name', $user->name)); ?>">
                  </label>
                </div>
                <!-- Last Name -->
                <div class="col-12 col-md-4 col-xl-4">
                  <label class="w-100">
                    <p class="title">Last Name</p>
                    <input class="form-control mt-2 rounded-3" name="lname" placeholder="Ali" required value="<?php echo e(old('lname',$user->lname)); ?>">
                  </label>
                </div>
                <!-- Email -->
                <div class="col-12 col-md-4 col-xl-4">
                  <label class="w-100">
                    <p class="title">Email Address</p>
                    <input class="form-control mt-2 rounded-3" type="email" name="email" value="<?php echo e($user->email); ?>"
                    disabled required>
                  </label>
                </div>

              </div>
            </div>
          </div>
        </fieldset>
        <!-- Bio -->
        <fieldset name="description" class="card mt-4 p-1">
          <div class="card-body">
            <!-- Header -->
            <h3 class="fs-5 mb-2">Bio</h3>
            <div class="py-2 pe-3 col-12">
              <!-- Bio -->
              <textarea name="description" placeholder="Tell us about yourself" class="form-control" rows="5" style="resize:none;" required aria-label="description"><?=old('description', $user->description)?></textarea>
            </div>
          </div>
        </fieldset>

        <!-- Address -->
        <fieldset name="address" class="card mt-4 p-1">
          <div class="card-body">
            <!-- Header -->
            <h3 class="fs-5 mb-4">Address</h3>
            <div class="p-2 mt-2">
              <div class="row gutter">


                
                  <!-- Country -->
<div class="col-12 col-md-6 col-xl-4">
    <label class="w-100">
        <p class="title">Country</p>
        <select class="form-control" name="location_id" id="location_id_" required>
            
                <option value="<?php echo e($TeachmeLocation->id); ?>" <?php echo e(old('location_id', $TeachmeLocationRelationship ? $TeachmeLocationRelationship->location_id : '') == $TeachmeLocation->id ? 'selected' : ''); ?>>
                    <?php echo e($TeachmeLocation->name); ?>

                </option>
        </select>
    </label>
</div>
<!-- City/State -->
<div class="col-12 col-md-6 col-xl-4">
    <label class="w-100">
        <p class="title">City/State</p>
        <select class="form-control" name="sub_location" id="sub_location_">

          <?php $__currentLoopData = $subTeachmeLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


              <?php if($TeachmeLocationRelationship != null && $TeachmeLocationRelationship->sub_location_id == $sub_location->id): ?>
                <option value="<?php echo e($sub_location->id); ?>" selected><?php echo e($sub_location->name); ?></option>
                <?php else: ?>
                <option value="<?php echo e($sub_location->id); ?>"><?php echo e($sub_location->name); ?></option>
                <?php endif; ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




        </select>
    </label>
</div>
                <div class="d-none d-xl-block col-xl-4"></div>
              </div>
            </div>
          </div>
        </fieldset>
      </form>
    

        <!-- Education Panel -->
        <form name="education-form" class="tab-pane fade <?php echo e($itseducation); ?>" id="education-tab-pane" role="tabpanel" aria-labelledby="education-tab" tabindex="0" action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
            <input type="hidden" name="param" value="add_student_education">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Education </h3>
          </div>
          <!-- Educations List -->
          <ul class="list-unstyled d-flex flex-column gap-2 mt-4">
            <li class="bg-body-tertiary rounded-3 p-3">
              <div class="row row-cols-1 row-cols-md-2 g-4">
              
                <div class="col-lg-6">
                  <label class="w-100">
                    <span class="text-muted">Curriculum</span>
                    <select class="form-select mt-2 rounded-3" name="student_curriculum" required>
                      <?php $__currentLoopData = $TeachmeCurriculum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($curriculum->id == auth()->user()->student_curriculum): ?>
                      <option value="<?php echo e($curriculum->id); ?>" selected><?php echo e($curriculum->title); ?></option>
                      <?php else: ?>
                      <option value="<?php echo e($curriculum->id); ?>"><?php echo e($curriculum->title); ?></option>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </label>
                </div>
                <div class="col-lg-6">
                  <label class="w-100">
                    <span class="text-muted">Grade</span>
                    <select class="form-select mt-2 rounded-3" name="student_grade" required>
                      <?php $__currentLoopData = $TeachmeGrade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($grade->id == auth()->user()->student_grade): ?>
                      <option value="<?php echo e($grade->id); ?>" selected><?php echo e($grade->title); ?></option>
                      <?php else: ?>
                      <option value="<?php echo e($grade->id); ?>"><?php echo e($grade->title); ?></option>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </label>
                </div>
                  <div class="col-lg-12">
                  <label class="w-100">
                    <span class="text-muted">School Name (optional)</span>
                    <input class="form-control mt-2 rounded-3" type="text" name="student_school" value="<?php echo e(auth()->user()->student_school); ?>">
                  </label>
                </div>
              </div>
              <div class="mt-4 d-flex gap-3 flex-wrap justify-content-end">
                <button type="submit" class="btn btn-success text-white rounded-pill"><i
                class="me-2 fa-solid fa-save"></i>Save</button>
              </div>
            </li>
          </ul>
        </form>



        <!-- Payments Panel -->
        <div class="tab-pane fade <?php echo e($itspayment); ?>" id="payments-tab-pane" role="tabpanel" aria-labelledby="setting-tab" tabindex="0">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
          
          <h3 class="fs-5">
            <i class="fa fa-bookmark-o"></i>
          Payments
          </h3>

          <?php if(Auth::user()->role != 'admin'): ?>
            <a href="<?php echo e(url('profile/'.encrypt(Auth::user()->id))); ?>?itspayments=yes" class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">back<i
                class="ms-2 fa-solid fa-pencil" style="font-size: 12px;"></i></a>
            <?php endif; ?>
          </div>
          
        <?php if($TeachmePayment && $TeachmePayment->stripe_status == 'canceled' && $TeachmePayment->ends_at < now()): ?>
            <a href="<?php echo e(url('plans/1')); ?>" class="btn btn-outline-primary fw-semibold py-3 px-5 rounded-pill" type="submit">Subscription</a>
        <?php endif; ?>

        <?php if(!$TeachmePayment): ?>
          <a href="<?php echo e(url('plans/1')); ?>" class="btn btn-outline-primary fw-semibold py-3 px-5 rounded-pill" type="submit">Subscription</a>
        <?php endif; ?>

          <!-- Content -->
          <div class="mt-4 row g-3">
            <!-- Subscription -->
            <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Subscription</span>
            </div>
            <?php if($TeachmePayment): ?>
            <div class="col-12 col-sm-6 col-xl-9 d-flex flex-column">
              <span>Plan Type: 100 AED / Year</span>
              <span>Subscription: <?php echo e(ucfirst($TeachmePayment->stripe_status)); ?></span>
            </div>

            <!-- Billing Date -->
            <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Billing Date</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-9">
              
              <span class="d-block">
                <?php if($TeachmePayment->stripe_status == 'active'): ?>
                  Your next billing date is
                  <?php echo e(\Carbon\Carbon::parse($TeachmePayment->created_at)->addYear()->format('F d, Y')); ?>.

                  <br>
                  <a href="<?php echo e(url('cancel-subscribe/'.$TeachmePayment->type)); ?>" class="mt-2 btn btn-outline-secondary px-5" type="button" onclick="return confirm('Are you sure you want to cancel?')">Cancel Membership</a>
                <?php else: ?>
                Your subscription has been cancelled, but you remain a premium member until your purchased subscription expires on
                <?php echo e(\Carbon\Carbon::parse($TeachmePayment->ends_at)->format('F d, Y')); ?>.
                <?php endif; ?>
                </span>

              
            </div>

            <?php else: ?>
            <div class="col-12 col-sm-6 col-xl-9 d-flex flex-column">
              <span>Plan Type: 100 AED / Year</span>
              <span>Subscription: Inactive</span>
            </div>
            <?php endif; ?>
            
            <?php if($TeachmePayment): ?>
            <!-- Payment Methods -->
            <div class="col-12 col-sm-6 col-xl-3">
              <p class="fw-semibold">Payment Method</p>
            </div>
            <div class="col-12 col-sm-6 col-xl-9">
              <div class="d-flex gap-3 flex-wrap align-items-center">
                <div class="d-flex flex-column flex-sm-row align-items-sm-center gap-2 gap-sm-3">
                  <img src="<?php echo e(asset('public/theme_assets/images/credit-card.webp')); ?>" class="rounded" width="70" />
                  <div class="d-flex flex-column">
                    <span class="h6 mb-1">Credit Card</span>
                    <span class="small text-muted"><?php echo e('**** **** **** ' . $user->pm_last_four); ?>

                    </span>
                  </div>
                </div>
                <div>
                  <button class="btn btn-outline-secondary" data-bs-toggle="collapse" data-bs-target="#update-card-info"
                    aria-expanded="false" aria-controls="update-card-info" type="button">
                    <i class="fa-solid fa-pencil"></i>
                    <span class="visually-hidden">Update</span>
                  </button>
                </div>
              </div>
            </div>
            <?php endif; ?>

            <div class="col-12">
              <!-- Update Card Content -->
              <form name="update-card-info" class="collapse row py-3" id="update-card-info" action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <input type="hidden" name="param" value="payments_card">

                <div class="col-12 col-lg-8 offset-lg-3">
                  <div class="card" style="border-radius: 15px;">
                    <div class="card-body p-4 row g-4">

                      <label class="col-12 col-md-12">
                        <span>Cardholder's Name</span>
                        <input class="form-control mt-2" size="17" name="card_holder" id="card-holder-name" required />
                      </label>

                      <label class="col-12 col-md-12">
                        <span>Card details</span>
                       <div id="card-element" style="width: 100%;"></div>
                        <div id="card-errors" role="alert"></div>
                      </label>

                      <div class="col d-flex justify-content-end">
                        <button class="btn btn-success text-white rounded-pill" id="submit-button">
                          <i class="me-2 fa-solid fa-save"></i>
                          Save
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </form>


<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript"></script>

<script src="https://js.stripe.com/v3/"></script>
<script>
  // Create an instance of Elements
        const stripe = Stripe('<?php echo e(env('STRIPE_KEY')); ?>')
        var elements = stripe.elements();

        // Create an instance of the card Element
        var card = elements.create('card', {hidePostalCode: true});

        // Add an instance of the card Element into the `card-element` div
        card.mount('#card-element');

        // Handle real-time validation errors from the card Element
        card.addEventListener('change', function(event) {
            var displayError = document.getElementById('card-errors');
            if (event.error) {
                displayError.textContent = event.error.message;
            } else {
                displayError.textContent = '';
            }
        });

        // Handle form submission
        var form = document.getElementById('update-card-info');
        var submitButton = document.getElementById('submit-button');

        form.addEventListener('submit', function(event) {
            event.preventDefault();

            submitButton.disabled = true;

            // Create a token with the card information
            stripe.createToken(card, {
                name: document.getElementById('card-holder-name').value
            }).then(function(result) {
                if (result.error) {
                    // Inform the user if there was an error
                    var errorElement = document.getElementById('card-errors');
                    errorElement.textContent = result.error.message;
                    submitButton.disabled = false;
                } else {
                    // Send the token to your server
                    stripeTokenHandler(result.token);
                }
            });
        });

        // Submit the form with the token ID
        function stripeTokenHandler(token) {
            // Insert the token ID into the form so it gets submitted to the server
            var form = document.getElementById('update-card-info');
            var hiddenInput = document.createElement('input');
            hiddenInput.setAttribute('type', 'hidden');
            hiddenInput.setAttribute('name', 'payment_method_id');
            hiddenInput.setAttribute('value', token.id);
            form.appendChild(hiddenInput);

            // Submit the form
            form.submit();
        }
    </script>






            </div>
          </div>
        </div>


                <!-- Settings Panel -->
        <form name="settings-form" class="tab-pane fade <?php echo e($itssetting); ?>" id="settings-tab-pane" role="tabpanel" aria-labelledby="setting-tab" tabindex="0" action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <input type="hidden" name="param" value="reset_password">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Rest Password</h3>

            <button class="btn btn-success text-white rounded-pill btn-sm">Save<i class="ms-2 fa-solid fa-save"
                style="font-size: 12px;"></i></button>
          </div>

          <div class="mt-4 row g-3">
            

            <div class="col-12 col-sm-4 col-xl-3">
              <span class="fw-semibold">Password</span>
            </div>
            <div class="col-12 col-sm-8 col-xl-9">
              <div class="row g-4">
                <label class="col-12 col-lg-6">
                  <span class="small">Current Password</span>
                  <input class="form-control mt-2" type="password" name="oldpassword" required />
                </label>
                <div class="col-lg-6 d-lg-block d-none"></div>
                <label class="col-12 col-lg-6">
                  <span class="small">New Password</span>
                  <input class="form-control mt-2" type="password" name="password" required />
                </label>
                <label class="col-12 col-lg-6">
                  <span class="small">Confirm Password</span>
                  <input class="form-control mt-2" type="password" name="password_confirmation" required />
                </label>
              </div>
            </div>
          </div>
        </form>
    </div>
  </div>
</main><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/userprofile/student_edit_profile.blade.php ENDPATH**/ ?>