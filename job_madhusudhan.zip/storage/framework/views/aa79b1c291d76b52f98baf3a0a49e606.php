<div class="sidebar" id="sidebar"> 
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="">
                    <a href="<?php echo e(url('/')); ?>" target="_blank"><i class="fa fa-globe"></i>Website</a>
                </li>
            </ul>
            <!-- Supper admin -->
            <?php if (Auth::user()->type == 'admin') { ?>
            <ul>
                <li class="menu-title">MAIN</li>
                <li class="active">
                    <a href="<?php echo e(url('/dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                </li>


                <li class="menu-title">USERS</li>
                <li class="">
                    <a href="<?php echo e(url('dashboard/customers')); ?>"><i class="fas fa-users"></i> Users</a>
                </li>
                

                <li class="menu-title">MANAGE MENU</li>
                <li class="">
                    <a href="<?php echo e(url('dashboard/brand')); ?>"><i class="fas fa-pen"></i> Brand</a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('dashboard/region')); ?>"><i class="fas fa-pen"></i> Region</a>
                </li>

                <li class="menu-title">MANAGE CONTENTS</li>
                <li class="submenu">
                    <a href="#"><i class="fas fa-home"></i> <span> Home Page</span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                    <li><a href="<?php echo e(url('dashboard/menu')); ?>">Menus</a></li>
                    <li><a href="<?php echo e(url('dashboard/slider')); ?>">Slider</a></li>
                    <li><a href="<?php echo e(url('about-page')); ?>">Other Pages</a></li>
                    
                    </ul>
                </li>
                
                
                

                <li class="menu-title">MANAGE SETTINGS</li>
                <li>
                    <a href="<?php echo e(url('dashboard/settings/general-settings')); ?>"><i class="fas fa-cog"></i> General</a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('all_languages')); ?>"><i class="fas fa-language"></i> Languages</a>
                </li>
                <br><br><br>
            </ul>


            <!-- User -->
        <?php }else{ ?>
            <ul>
                <li class="menu-title">Main</li>
                <li class="active">
                    <a href="<?php echo e(url('dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                </li>
                <li class="submenu">
                    <a href="#"><i class="fas fa-box"></i> <span> Subscriptions</span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a href="<?php echo e(url('dashboard/subscriptions/histories')); ?>">Histories</a></li>
                        <li><a href="<?php echo e(url('dashboard/subscriptions')); ?>">Package</a></li>
                    </ul>
                </li>
                <li class="submenu d-none">
                    <a href="#"><i class="fas fa-percent"></i> <span> Affiliate System</span> <span class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li><a href="<?php echo e(url('affiliate/overview')); ?>">Overview</a></li>
                        <li><a href="<?php echo e(url('affiliate/configure-payouts')); ?>">Payout Configurations</a></li>
                        <li><a href="<?php echo e(url('affiliate/withdraw-requests')); ?>">Withdraw Requests</a></li>
                        <li><a href="<?php echo e(url('affiliate/earning-histories')); ?>">Earning Histories</a></li>
                        <li><a href="<?php echo e(url('affiliate/payments')); ?>">Payments Histories</a></li>
                    </ul>
                </li>
                <li class="menu-title">MANAGE DOCUMENTS</li>
                <li class="">
                    <a href="<?php echo e(url('documents/folders')); ?>"><i class="fas fa-folder"></i> Folders</a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('documents/projects')); ?>"><i class="fa fa-copy"></i> All Projects</a>
                </li>
                <li class="menu-title">AI TOOLS</li>

                <li class="">
                    <a href="<?php echo e(url('chat-bots/ai-chat-bots')); ?>"><i class="fa fa-comments"></i>AI Chat Bote</a>
                </li>

                <li class="">
                    <a href="<?php echo e(url('templates/ai-templates')); ?>"><i class="fa fa-edit"></i> Templates</a>
                </li>
                
                <li class="">
                    <a href="<?php echo e(url('speech/ai-speech-text')); ?>"><i class="fas fa-microphone"></i> Speech To Text</a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('images/ai-images')); ?>"><i class="fa fa-image"></i> Generate Images</a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('code/ai-code')); ?>"><i class="fa fa-code"></i> AI Code</a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('templates/popular')); ?>"><i class="fas fa-chart-line"></i> Popular Templates</a>
                </li>
                <li class="">
                    <a href="<?php echo e(url('templates/favorites')); ?>"><i class="fas fa-heart"></i> Favorite Templatess</a>
                </li>
            </ul>
        <?php } ?>
        </div>
    </div>
</div><?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>