<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Main content -->
  <!-- Main content -->
  <main id="profile-section" class="py-5 px-2 px-sm-4 mb-5">
    <div class="container rounded-5 p-4 gap-4 gap-md-5 box-shadow-md bg-white d-sm-flex">
      <!-- Tabs -->
      <ul
        class="nav nav-pills flex-sm-column flex-nowrap flex-sm-wrap overflow-x-auto overflow-x-sm-hidden overflow-x-md-visible gap-3 pe-sm-5 pe-md-4 pt-2 pb-2 pb-sm-0 border-end-sm justify-content-start border-bottom border-bottom-sm-0 "
        id="profile-tabs" role="tablist">
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link active" id="edit-tab" data-bs-toggle="tab" data-bs-target="#edit-tab-pane"
            type="button" role="tab" aria-controls="edit-tab-pane" aria-selected="true">
            <img src="./images/icons/user-square-light.svg" aria-hidden="true" class="me-3">
            <span>Profile</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="expertise-tab" data-bs-toggle="tab" data-bs-target="#expertise-tab-pane"
            type="button" role="tab" aria-controls="expertise-tab-pane" aria-selected="false">
            <img src="./images/icons/book-saved-light.svg" aria-hidden="true" class="me-3">
            <span>Expertise</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="education-tab" data-bs-toggle="tab" data-bs-target="#education-tab-pane"
            type="button" role="tab" aria-controls="education-tab-pane" aria-selected="false">
            <img src="./images/icons/teacher.svg" aria-hidden="true" class="me-3">
            <span>Education</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="experience-tab" data-bs-toggle="tab" data-bs-target="#experience-tab-pane"
            type="button" role="tab" aria-controls="experience-tab-pane" aria-selected="false">
            <img src="./images/icons/invoice.svg" aria-hidden="true" class="me-3">
            <span>Experience</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="payments-tab" data-bs-toggle="tab" data-bs-target="#payments-tab-pane"
            type="button" role="tab" aria-controls="payments-tab-pane" aria-selected="false">
            <img src="./images/icons/card.svg" aria-hidden="true" class="me-3">
            <span>Payments</span>
          </button>
        </li>
        <li class="nav-item fw-medium" role="presentation">
          <button class="nav-link" id="settings-tab" data-bs-toggle="tab" data-bs-target="#settings-tab-pane"
            type="button" role="tab" aria-controls="settings-tab-pane" aria-selected="false">
            <img src="./images/icons/video-octagon-light.svg" aria-hidden="true" class="me-3">
            <span>Settings</span>
          </button>
        </li>
      </ul>

      <!-- Tab Panes -->
      <div class="tab-content mt-2 flex-grow-1" id="profile-tabs-content">
        <!-- Profile Panel -->
        <form name="profile-info-form" class="tab-pane fade show active" id="edit-tab-pane" role="tabpanel"
          aria-labelledby="edit-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">My Profile</h3>

            <button class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Edit<i
                class="ms-2 fa-solid fa-pencil text-decoration-underline" style="font-size: 12px;"></i></button>
          </div>

          <!-- Profile Info -->
          <div class="card mt-4 p-1">
            <div class="card-body d-flex align-items-center gap-2">
              <img src="./images/avatar-tutor.png" alt="Tutor Avatar" class="img-fluid" width="70" height="70">

              <div class="fw-semibold text-uppercase">
                <span class="text-warning" style="font-size:12px;">Tutor</span>
                <h4 class="fs-6 fw-semibold mb-0">Esha Ahmad</h4>
                <span class="text-primary" style="font-size:12px;">Abu Dhabi, UAE</span>
              </div>
            </div>
          </div>

          <!-- Personal Info -->
          <fieldset name="personal-information" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-4">Personal Information</h3>

              <div class="p-2 mt-2">
                <div class="row gutter">
                  <!-- First Name -->
                  <div class="col-12 col-md-6 col-xl-4">
                    <p class="title">First Name</p>
                    <span class="text-secondary">Ahsan</span>
                  </div>
                  <!-- Last Name -->
                  <div class="col-12 col-md-6 col-xl-8">
                    <p class="title">Last Name</p>
                    <span class="text-secondary">Ali</span>
                  </div>
                  <!-- Email -->
                  <div class="col-12 col-md-6 col-xl-4">
                    <p class="title">Email Address</p>
                    <span class="text-secondary">ahsanali@gmail.com</span>
                  </div>
                  <!-- Phone -->
                  <div class="col-12 col-md-6 col-xl-8">
                    <p class="title">Phone</p>
                    <span class="text-secondary">+971 1231234</span>
                  </div>
                </div>
              </div>
            </div>
          </fieldset>

          <!-- Bio -->
          <fieldset name="bio" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-2">Bio</h3>

              <p class="py-2 mb-0">
                Meet Ms. Sarah, a passionate and dedicated primary school teacher who brings the world of learning alive
                for her young students. With a warm smile and boundless enthusiasm, Ms. Sarah creates a nurturing
                environment where children thrive and develop a love for learning.
              </p>
              <p class="py-2 mb-0">
                Born and raised in a multicultural environment, Ms. Sarah is fluent in both English and Arabic, allowing
                her to connect with students from diverse backgrounds. Her bilingual proficiency not only enriches her
                teaching but also fosters a sense of inclusivity in her classroom.
              </p>
              <p class="py-2 mb-0">
                Ms. Sarah's journey into education began with a deep-rooted desire to make a positive difference in the
                lives of children. Armed with a degree in Education and a wealth of experience, she embarked on her
                teaching career with a clear mission: to inspire, empower, and ignite a passion for learning in her
                young learners.
              </p>
            </div>
          </fieldset>

          <!-- Intro video -->
          <fieldset name="intro video" class="card mt-4 p-1">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-5 mb-2">Intro Video</h3>

              <div class="py-2 mb-0">
                <div class="embedded-video-container bg-black rounded-4">
                  <iframe src="https://www.youtube.com/embed/NpEaa2P7qZI" title="Introduction video" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen></iframe>
                </div>
              </div>
              
            </div>
          </fieldset>

        </form>

        <!-- Expertise Panel -->
        <form name="expertise-form" class="tab-pane fade" id="expertise-tab-pane" role="tabpanel"
          aria-labelledby="expertise-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <h3 class="fs-5">Expertise</h3>

          <!-- Curriculum -->
          <fieldset name="curriculum" class="card mt-4 p-2">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-6 fw-semibold">Curriculum</h3>

              <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4"
                style="padding-inline:.8rem;">
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="american" id="curriculum-american">
                  <label class="form-check-label" for="curriculum-american">
                    American
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="british" id="curriculum-british">
                  <label class="form-check-label" for="curriculum-british">
                    British
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="canadian" id="curriculum-canadian">
                  <label class="form-check-label" for="curriculum-canadian">
                    Canadian
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="sabis" id="curriculum-sabis">
                  <label class="form-check-label" for="curriculum-sabis">
                    Sabis
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="international" id="curriculum-international">
                  <label class="form-check-label" for="curriculum-international">
                    International
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="ib" id="curriculum-ib">
                  <label class="form-check-label" for="curriculum-ib">
                    IB
                  </label>
                </div>
              </div>
            </div>
          </fieldset>

          <!-- Grades -->
          <fieldset name="grades" class="card mt-4 p-2">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-6 fw-semibold">Grades</h3>

              <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4"
                style="padding-inline:.8rem;">
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="early-years-kg" id="grade-early-years-kg">
                  <label class="form-check-label" for="grade-early-years-kg">
                    Early Years/KG
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="primary" id="grade-primary">
                  <label class="form-check-label" for="grade-primary">
                    Primary/Elementary
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="middle-school" id="grade-middle-school">
                  <label class="form-check-label" for="grade-middle-school">
                    Middle School
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="secondary-gsce" id="grade-secondary-gsce">
                  <label class="form-check-label" for="grade-secondary-gsce">
                    Secondary/GSCE
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="sixth-form-a-levels"
                    id="grade-sixth-form-a-levels">
                  <label class="form-check-label" for="grade-sixth-form-a-levels">
                    Sixth Form/A Levels
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="sen-tutor" id="grade-sen-tutor">
                  <label class="form-check-label" for="grade-sen-tutor">
                    SEN Tutor
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="shadow-teacher" id="grade-shadow-teacher">
                  <label class="form-check-label" for="grade-shadow-teacher">
                    Shadow Teacher
                  </label>
                </div>
              </div>
            </div>
          </fieldset>

          <!-- Subjects -->
          <fieldset name="subjects" class="card mt-4 p-2">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-6 fw-semibold">Subjects</h3>

              <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4"
                style="padding-inline:.8rem;">
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="english" id="subject-english">
                  <label class="form-check-label" for="subject-english">
                    English
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="chemistry" id="subject-chemistry">
                  <label class="form-check-label" for="subject-chemistry">
                    Chemistry
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="physics" id="subject-physics">
                  <label class="form-check-label" for="subject-physics">
                    Physics
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="math" id="subject-math">
                  <label class="form-check-label" for="subject-math">
                    Math
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="arabic" id="subject-arabic">
                  <label class="form-check-label" for="subject-arabic">
                    Arabic
                  </label>
                </div>
              </div>
            </div>
          </fieldset>

          <!-- Languages -->
          <fieldset name="languages" class="card mt-4 p-2">
            <div class="card-body">
              <!-- Header -->
              <h3 class="fs-6 fw-semibold">Languages spoken</h3>
              <div class="mt-1 row row-cols-1 row-cols-sm-2 row-cols-xl-4 g-4"
                style="padding-inline:.8rem;">
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="english" id="language-english">
                  <label class="form-check-label" for="language-english">
                    English
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="spanish" id="language-spanish">
                  <label class="form-check-label" for="language-spanish">
                    Spanish
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="french" id="language-french">
                  <label class="form-check-label" for="language-french">
                    French
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="german" id="language-german">
                  <label class="form-check-label" for="language-german">
                    German
                  </label>
                </div>
                <div class="col form-check">
                  <input class="form-check-input" type="checkbox" value="mandarin" id="language-mandarin">
                  <label class="form-check-label" for="language-mandarin">
                    Mandarin
                  </label>
                </div>
                <div class="col">
                  <button class="btn btn-link btn-sm text-warning-hover" type="button">See More</button>
                </div>
              </div>
            </div>
          </fieldset>
        </form>

        <!-- Education Panel -->
        <form name="education-form" class="tab-pane fade" id="education-tab-pane" role="tabpanel"
          aria-labelledby="education-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Education</h3>

            <button class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Add<i
                class="ms-2 fa-solid fa-plus" style="font-size: 12px;"></i></button>
          </div>

          <!-- Education -->
          <ul class="list-unstyled d-flex flex-column gap-2 mt-4">
            <li
              class="bg-body-tertiary rounded-3 p-3 d-flex flex-column flex-sm-row justify-content-between align-items-end align-items-sm-center gap-2">
              <div>
                <p class="fw-bold mb-1 opacity-75">PHD, Applied Sciences</p>
                <div class="d-flex gap-2 flex-wrap">
                  <span class="opacity-75">London South Bank University, London</span>
                  <span class="fw-medium"><strong>Sep</strong> 2017 - <strong>Sep</strong> 2021</span>
                </div>
              </div>
              <div class="d-flex flex-wrap gap-2">
                <button class="btn btn-outline-primary" data-bs-toggle="tooltip" data-bs-title="Edit">
                  <i class="fa-solid fa-pencil"></i>
                  <span class="visually-hidden">Edit</span>
                </button>
                <button class="btn btn-outline-danger" data-bs-toggle="tooltip" data-bs-title="Delete">
                  <i class="fa-solid fa-trash"></i>
                  <span class="visually-hidden">Delete</span>
                </button>
              </div>
            </li>
            <li
              class="bg-body-tertiary rounded-3 p-3 d-flex flex-column flex-sm-row justify-content-between align-items-end align-items-sm-center gap-2">
              <div>
                <p class="fw-bold mb-1 opacity-75">MS - Science</p>
                <div class="d-flex gap-2 flex-wrap">
                  <span class="opacity-75">University of Dubai - London</span>
                  <span class="fw-medium"><strong>Feb</strong> 2015 - <strong>Aug</strong> 2017</span>
                </div>
              </div>
              <div class="d-flex flex-wrap gap-2">
                <button class="btn btn-outline-primary" data-bs-toggle="tooltip" data-bs-title="Edit">
                  <i class="fa-solid fa-pencil"></i>
                  <span class="visually-hidden">Edit</span>
                </button>
                <button class="btn btn-outline-danger" data-bs-toggle="tooltip" data-bs-title="Delete">
                  <i class="fa-solid fa-trash"></i>
                  <span class="visually-hidden">Delete</span>
                </button>
              </div>
            </li>
            <li
              class="bg-body-tertiary rounded-3 p-3 d-flex flex-column flex-sm-row justify-content-between align-items-end align-items-sm-center gap-2">
              <div>
                <p class="fw-bold mb-1 opacity-75">Bachelors of Arts</p>
                <div class="d-flex gap-2 flex-wrap">
                  <span class="opacity-75">London South Bank University - London</span>
                  <span class="fw-medium"><strong>Feb</strong> 2010 - <strong>Jun</strong> 2014</span>
                </div>
              </div>
              <div class="d-flex flex-wrap gap-2">
                <button class="btn btn-outline-primary" data-bs-toggle="tooltip" data-bs-title="Edit">
                  <i class="fa-solid fa-pencil"></i>
                  <span class="visually-hidden">Edit</span>
                </button>
                <button class="btn btn-outline-danger" data-bs-toggle="tooltip" data-bs-title="Delete">
                  <i class="fa-solid fa-trash"></i>
                  <span class="visually-hidden">Delete</span>
                </button>
              </div>
            </li>
          </ul>
        </form>

        <!-- Experience Panel -->
        <form name="experience-form" class="tab-pane fade" id="experience-tab-pane" role="tabpanel"
          aria-labelledby="experience-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Experience</h3>

            <button class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Add<i
                class="ms-2 fa-solid fa-plus" style="font-size: 12px;"></i></button>
          </div>

          <!-- Education -->
          <ul class="list-unstyled d-flex flex-column gap-2 mt-4">
            <li
              class="bg-body-tertiary rounded-3 p-3 d-flex flex-column flex-sm-row justify-content-between align-items-end align-items-sm-center gap-2">
              <div>
                <p class="fw-bold mb-1 opacity-75">Science Teacher</p>
                <div class="d-flex gap-2 flex-wrap">
                  <span class="opacity-75">London Square School - London</span>
                  <span class="fw-medium"><strong>April</strong> 2021 - Present</span>
                </div>
              </div>
              <div class="d-flex flex-wrap gap-2">
                <button class="btn btn-outline-primary" data-bs-toggle="tooltip" data-bs-title="Edit">
                  <i class="fa-solid fa-pencil"></i>
                  <span class="visually-hidden">Edit</span>
                </button>
                <button class="btn btn-outline-danger" data-bs-toggle="tooltip" data-bs-title="Delete">
                  <i class="fa-solid fa-trash"></i>
                  <span class="visually-hidden">Delete</span>
                </button>
              </div>
            </li>
            <li
              class="bg-body-tertiary rounded-3 p-3 d-flex flex-column flex-sm-row justify-content-between align-items-end align-items-sm-center gap-2">
              <div>
                <p class="fw-bold mb-1 opacity-75">Biology Teacher</p>
                <div class="d-flex gap-2 flex-wrap">
                  <span class="opacity-75">Army Public School - London</span>
                  <span class="fw-medium"><strong>Jun</strong> 2020 - <strong>Mar</strong> 2021</span>
                </div>
              </div>
              <div class="d-flex flex-wrap gap-2">
                <button class="btn btn-outline-primary" data-bs-toggle="tooltip" data-bs-title="Edit">
                  <i class="fa-solid fa-pencil"></i>
                  <span class="visually-hidden">Edit</span>
                </button>
                <button class="btn btn-outline-danger" data-bs-toggle="tooltip" data-bs-title="Delete">
                  <i class="fa-solid fa-trash"></i>
                  <span class="visually-hidden">Delete</span>
                </button>
              </div>
            </li>
            <li
              class="bg-body-tertiary rounded-3 p-3 d-flex flex-column flex-sm-row justify-content-between align-items-end align-items-sm-center gap-2">
              <div>
                <p class="fw-bold mb-1 opacity-75">Physics Teacher</p>
                <div class="d-flex gap-2 flex-wrap">
                  <span class="opacity-75">American International School, Dubai</span>
                  <span class="fw-medium"><strong>Jan</strong> 2019 - <strong>Jun</strong> 2020</span>
                </div>
              </div>
              <div class="d-flex flex-wrap gap-2">
                <button class="btn btn-outline-primary" data-bs-toggle="tooltip" data-bs-title="Edit">
                  <i class="fa-solid fa-pencil"></i>
                  <span class="visually-hidden">Edit</span>
                </button>
                <button class="btn btn-outline-danger" data-bs-toggle="tooltip" data-bs-title="Delete">
                  <i class="fa-solid fa-trash"></i>
                  <span class="visually-hidden">Delete</span>
                </button>
              </div>
            </li>
          </ul>
        </form>

        <!-- Payments Panel -->
        <form name="payments-form" class="tab-pane fade" id="payments-tab-pane" role="tabpanel"
          aria-labelledby="setting-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Payments</h3>

            <button class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Manage<i
                class="ms-2 fa-solid fa-pencil" style="font-size: 12px;"></i></button>
          </div>

          <div class="mt-4 row g-3">
            <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Subscription</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-9 d-flex flex-column">
              <span>Plan Type: 100 AED / Year</span>
              <span>Status: Active</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Billing Date</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-9">
              <span class="d-block">Your next billing date is March 26, 2024.</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-3">
              <p class="fw-semibold">Payment Method</p>
            </div>
            <div class="col-12 col-sm-6 col-xl-9">
              <div class="d-flex flex-column flex-sm-row align-items-sm-center gap-2 gap-sm-3">
                <img src="./images/credit-card.webp" class="rounded" width="70" />
                <div class="d-flex flex-column">
                  <span class="h6 mb-1">Credit Card</span>
                  <span class="small text-muted">**** **** **** 2570</span>
                </div>
              </div>
            </div>
          </div>
        </form>

        <!-- Settings Panel -->
        <form name="settings-form" class="tab-pane fade" id="settings-tab-pane" role="tabpanel"
          aria-labelledby="setting-tab" tabindex="0" action="./profile-edit">
          <!-- Heading -->
          <div class="d-flex justify-content-between">
            <h3 class="fs-5">Settings</h3>

            <button class="btn btn-outline-primary rounded-pill btn-sm border-secondary-subtle">Edit<i
                class="ms-2 fa-solid fa-pencil text-decoration-underline" style="font-size: 12px;"></i></button>
          </div>

          <div class="mt-4 row g-3">
            <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Mode of Instruction</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-9">
              <span>Virtual</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-3">
              <span class="fw-semibold">Password</span>
            </div>
            <div class="col-12 col-sm-6 col-xl-9">
              <span>*********</span>
            </div>
          </div>
        </form>
      </div>
    </div>
  </main>
  <?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/teachme_profile.blade.php ENDPATH**/ ?>