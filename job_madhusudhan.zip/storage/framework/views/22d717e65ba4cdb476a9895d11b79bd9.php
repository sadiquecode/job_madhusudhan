<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Main content -->
  <main id="sign-up-section" class="py-5 px-4 px-md-0 my-md-7 pb-md-7 bg-white">
<div class="container mt-3">
  <h2 class="fw-medium center">Terms and Conditions</h2>
  <br>
  <p>The website "teachme.ae" is the property of Sandbox Data Group Company. By using this website, users are agreeing to the terms set forth by our company. We are officially registered in Dubai under commercial license number 0000000.
</p>
  <!-- Nav tabs -->
  <ul class="nav nav-tabs" role="tablist">
    <li class="nav-item">
      <a class="nav-link active" data-bs-toggle="tab" href="#Terms-and-Conditions-for-TEACHME">For Students/Parents</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="tab" href="#Tutors-at-TEACHME">For Tutors</a>
    </li>
  </ul>

  <!-- Tab panes -->
  <div class="tab-content">
    <div id="Terms-and-Conditions-for-TEACHME" class="container tab-pane active"><br>
            <h2></h2>
<p><strong>Last Updated:</strong> April 1, 2024</p>
<p>Welcome to TEACHME, an online platform designed to provide comprehensive educational support resources across various subjects and curriculums. By registering with us as a parent/student or using our services, you agree to the following terms and conditions:</p>
<ol>
  <li>
    <strong>Services Offered</strong>
    <p>TEACHME offers a comprehensive list of qualified and verified tutors in various subjects/curriculums for students of different ages and educational levels for a one time yearly subscription fee. We connect parents/students to the right tutor for you. All payments and scheduling are done between parent/student and tutor, TEACHME is not involved in any scheduling of sessions or payment of sessions.</p>
  </li>
  <li>
    <strong>Registration and Accounts</strong>
    <p>Parents or legal guardians must register on behalf of students under 18 years old. By creating an account, you confirm that the information provided is accurate and that you will keep your login information confidential.</p>
  </li>
  <li>
    <strong>Payment Terms</strong>
    <p>A one time yearly subscription fee allows you access to all tutors on the platform. Any fees associated with tutoring sessions is between the parent/student and tutor.</p>
  </li>
  <li>
    <strong>Cancellation and Refunds</strong>
    <p>We do not offer cancellation or refunds on subscriptions. Refunds/cancellations for tutoring sessions are to be managed between the parent/student and tutor. TEACHME will not be involved in tutor payement transactions.</p>
  </li>
  <li>
    <strong>Privacy and Data Protection</strong>
    <p>We are committed to protecting the privacy of our users. Personal information collected is used only to provide our services and will not be shared with third parties without consent, except as required by law.</p>
  </li>
  <li>
    <strong>User Conduct</strong>
    <p>Users are expected to maintain a respectful and professional demeanor during tutoring sessions. Harassment, abuse, or inappropriate behavior will result in immediate account termination.</p>
  </li>
  <li>
    <strong>Limitations of Liability</strong>
    <p>TEACHME is not liable for any direct, indirect, incidental, or consequential damages arising from the use of our services, including but not limited to academic performance outcomes.</p>
  </li>
  <li>
    <strong>Changes to Terms and Conditions</strong>
    <p>We reserve the right to modify these terms and conditions at any time. Continued use of our services after such changes constitutes acceptance of the new terms.</p>
  </li>
  <li>
    <strong>Governing Law</strong>
    <p>These terms and conditions are governed by the laws of UAE, and any disputes will be subject to the exclusive jurisdiction of its courts.</p>
  </li>
  <li>
    <strong>Contact Us</strong>
    <p>For any questions or concerns regarding these terms and conditions, please contact us at [Contact Information].</p>
  </li>
</ol>
    </div>
    <div id="Tutors-at-TEACHME" class="container tab-pane fade"><br>
      
<p><strong>Effective Date:</strong> April 1, 2024</p>
<p>Welcome to TEACHME. We provide a platform where tutors can offer educational services to students. These Terms and Conditions outline the agreement between TEACHME (the "Platform") and you, the Tutor, regarding the use of our service.</p>
<ol>
  <li>
    <strong>Tutor Registration and Profile</strong>
    <p>To become a tutor on TEACHME, you must complete the registration process, providing accurate and current information about your qualifications, experience, and subjects of expertise. The Platform reserves the right to verify this information and to approve or deny applications based on our internal criteria. You must provide a valid UAE private tutor license in order to be featured on the platform.</p>
  </li>
  <li>
    <strong>Tutor Responsibilities</strong>
    <p>Tutors are responsible for preparing and delivering high-quality educational content, maintaining professionalism during sessions, and following the Platform’s policies on conduct. Tutors must also ensure they have a reliable internet connection and the necessary equipment to conduct online tutoring sessions.</p>
  </li>
  <li>
    <strong>Payment Terms</strong>
    <p>Tutors will be required to manage payment for tutoring sessions with the parent/student. TEACHME will take a one time yearly subscription fee to allow a tutor to be featured on the platform. Any subsequent payments linked to tutoring sessions are to be managed by the tutor.</p>
  </li>
  <li>
    <strong>Cancellations and No-Shows</strong>
    <p>Tutors are required to notify the student, at least 24 hours in advance if they need to cancel a scheduled session. Repeated cancellations or no-shows may result in penalties, including removal from the Platform.</p>
  </li>
  <li>
    <strong>Confidentiality and Privacy</strong>
    <p>Tutors must respect the privacy and confidentiality of students and their learning data. Any sharing of personal information, session content, or educational records without consent is strictly prohibited. Violation of privacy will result in removal from the platform.</p>
  </li>
  <li>
    <strong>Platform Services and Fees</strong>
    <p>TEACHME provides a service that connects tutors with students. We do not handle scheduling or processes payments. Tutors agree to a one time yearly subscription fee to be featured on the platform.</p>
  </li>
  <li>
    <strong>Termination</strong>
    <p>TEACHME reserves the right to terminate a tutor subscription with no refund if the private tutor license is not valid, and if any of the terms and conditions are violated.</p>
  </li>
  <li>
    <strong>Indemnification</strong>
    <p>Tutors agree to indemnify and hold harmless TEACHME and its affiliates, officers, agents, and employees from any claim arising out of their actions or omissions in connection with the tutoring services provided.</p>
  </li>
  <li>
    <strong>Amendments</strong>
    <p>The Platform reserves the right to modify these Terms and Conditions at any time. Tutors will be notified of any changes, which will become effective upon posting to the Platform’s website.</p>
  </li>
  <li>
    <strong>Governing Law</strong>
    <p>This agreement shall be governed by the laws of UAE, and any disputes will be resolved in accordance with the laws of this jurisdiction.</p>
  </li>
  <li>
    <strong>Contact Information</strong>
    <p>For questions or concerns regarding these Terms and Conditions, please contact us at <a href="info@teachme.ae">info@teachme.ae</a></p>
  </li>
</ol>
    </div>
  </div>
</div>
  </main>

<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/theme_1/teachme_privacy_policy.blade.php ENDPATH**/ ?>