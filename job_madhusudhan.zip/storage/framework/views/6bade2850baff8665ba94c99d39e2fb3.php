<div class="col-sm-8 col-md-8 col-lg-8 col-xl-9">
	
	<form class="m-b-30" action="<?php echo e(route('about-page.update', $webpage->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
		<div class="card-box">
			<div class="row">
				
				<div class="col-md-12">
					<h4 class="card-title"><?php echo e($head); ?> Section</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Heading (en):</label>
								<input type="text" class="form-control" name="heading_en" value="<?php echo e($webpage->heading_en); ?>"><input type="hidden" class="form-control" name="slug" value="<?php echo e($webpage->slug); ?>">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Heading (ar):</label>
								<input type="text" class="form-control" name="heading_ar" value="<?php echo e($webpage->heading_ar); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
	                            <label>Body (en)</label>
	                            <textarea cols="20" rows="4" class="form-control ckeditor" name="body_en"><?php echo e($webpage->body_en); ?></textarea>
	                        </div>
						</div>

						<div class="col-md-12">
							<div class="form-group">
	                            <label>Body (ar)</label>
	                            <textarea cols="20" rows="4" class="form-control ckeditor" name="body_ar"><?php echo e($webpage->body_ar); ?></textarea>
	                        </div>
						</div>

						<div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Status <span class="text-danger">*</span></label>
                                <select name="status" class="select floating">
                                    <option value="active" <?php if($webpage->status === 'active'): ?> selected <?php endif; ?>>Active</option>
                                    <option value="inactive" <?php if($webpage->status === 'inactive'): ?> selected <?php endif; ?>>Inactive</option>
                                </select>
                            </div>
                        </div>

					</div>
				</div>
			</div>
			<div class="text-right">
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
		</div>
	</form>
</div><?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/web/forms/pages.blade.php ENDPATH**/ ?>