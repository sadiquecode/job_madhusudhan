<?php $code = session('locale'); ?>
    <!-- =============================Footer Start==============================--> 
    <div class="footer_top_line">
        <hr>
    </div>
    <section class="py-5 footer_none">
        <div class="container">
            <div class="row gy-3">
                <div class="col-md-4">
                    <div>
                        <a href="<?php echo e(url('/')); ?>" class="branding">
                            <img src="<?php echo e(url('public/theme_assets/images/logo/Logojeddah_11zon.png')); ?>" alt="logo">
                        </a>
                    </div>
                    <div class="social_btn d-flex align-items-center justify-content-between mt-3 mt-md-0">
                        <a href="<?php echo e(get_general_settings()->facebook); ?>">Facebook</a>
                        <a href="<?php echo e(get_general_settings()->twitter); ?>">Twitter</a>
                        <a href="<?php echo e(get_general_settings()->instagram); ?>">Instagram</a>
                        <a href="<?php echo e(get_general_settings()->snapchat); ?>" class="">Snapchat</a>
                        
                    </div>
                </div>
                <div class="col-md-8">
            
                    <div class="newsletter d-flex align-items-center <?php echo e(($code == 'en') ? 'justify-content-md-end' : ''); ?>" dir="<?php echo e(($code == 'en') ? 'ltr' : 'rtl'); ?>">
                        <h5 class="mb-0 me-3 <?php echo e(session('ar_class')); ?>"><?php echo e(__('trans.Newsletter')); ?></h5>
                        <div class="newsletter_email">
                            <form class="newsletter_form d-flex align-items-center w-100 <?php echo e(session('ar_class')); ?>" method="POST" action="<?php echo e(url('subscribe')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="email" placeholder="<?php echo e(__('trans.Enter your email address here')); ?>" title="Enter email" name="email" />
                                <button type="submit"><i class="fa-solid fa-paper-plane"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row pt-5">
                <div class="col-md-6">
                    <div class="footer_end">
                        <div class="text-center text-md-start <?php echo e(session('ar_class')); ?>">
                            <p>© <?= date('Y')?> <b>Jeddah Mazad</b>. <?php echo e(__('trans.All Rights Reserved')); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="footer_end justify-content-between d-flex">
                        <?php $__currentLoopData = $other_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $title = ($code == 'en') ? $key->heading_en : $key->heading_ar;
                        ?>
                        <a href="<?php echo e(url('page/'.$key->slug)); ?>" class="text-capitalize <?php echo e(session('ar_class')); ?>"><?php echo e($title); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
    </section>
    <section class="footer_block">
        <div class="footer_block_btn">
            <ul>
                <li class="list-unstyled mb-3 <?php echo e(session('ar_class')); ?>">
                    <a href="<?php echo e(url('page/contact-us')); ?>" target="_blank" rel="noopener noreferrer"><?php echo e(__('trans.CONTACT US')); ?>

                    </a>
                </li>
                <li class="list-unstyled mb-3 <?php echo e(session('ar_class')); ?>">
                    <a href="<?php echo e(url('page/terms')); ?>" target="_blank" rel="noopener noreferrer"><?php echo e(__('trans.Terms & conditions')); ?>/
                    </a>

                    <a href="<?php echo e(url('page/policy')); ?>" target="_blank" rel="noopener noreferrer"><?php echo e(__('trans.privacy policy')); ?>

                    </a>
                </li>
                
                </li>
            </ul>
            <p class="<?php echo e(session('ar_class')); ?>">© <?= date('Y')?> <a href="<?php echo e(url('/')); ?>"><b>Jeddah Mazad.</b></a> <?php echo e(__('trans.All Rights Reserved')); ?></p>
        </div>
    </section>


    <!-- =============================Footer End==============================-->
    <!-- jQuery link  -->
    <script type="text/javascript" src="<?php echo e(url('public/theme_assets/jquery/jquery-3.6.0.min.js')); ?>"></script>
    <!-- Slick slider js  -->
    <script type="text/javascript" src="<?php echo e(url('public/theme_assets/js/slick.min.js')); ?>"></script>
    <!-- Bootstrap JS -->
    <script src="<?php echo e(url('public/theme_assets/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Custom JS -->
    <script src="<?php echo e(url('public/theme_assets/js/main.js')); ?>"></script>
    <!-- select2  -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js')}}"></script> -->
<script src="<?php echo e(url('public/theme_assets/select-2/select2.min.js')); ?>"></script>
    <script>

    const getmsgNotification = `<?php echo e(route('getmsgNotification')); ?>`;
    const getotherNotification = `<?php echo e(route('getotherNotification')); ?>`;


        var jq = jQuery.noConflict();
        jq(document).ready(function () {
            jq('#myFirstSelect2Basic').select2();
            jq('#myFirstSelect2Basic_').select2();
        });



    function togglePermission(id,status) {
        if (confirm('Are you sure?')) {
            var base_url = "<?php echo e(url('/')); ?>";
                $.ajax({
                    type: 'POST',
                    url: base_url+'/update-permission',
                    data: {
                        data_id: id,
                        data_status: status,
                        _token: '<?php echo e(csrf_token()); ?>',
                    },
                    success: function (data) {
                        const label = document.querySelector(`label[data-id="${id}"]`);
                            if (data.dstatus === 1) {
                                label.classList.add('active');
                            } else {
                                label.classList.remove('active');
                            }
                        // alert('Status Updated successfully!');
                    },
                    error: function (xhr, status, error) {
                        alert('Something Wrong!');
                    }
                });
        }
    }


    </script>
    
    <script src="<?php echo e(url('public/theme_assets/jquery/jquery-3.6.0.min.js')); ?>"></script>
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>

    <script type="text/javascript">
        (function ($) {
            $.fn.picZoomer = function (options) {
                var opts = $.extend({}, $.fn.picZoomer.defaults, options),
                    $this = this,
                    $picBD = $('<div class="picZoomer-pic-wp"></div>')
                        .css({ width: opts.picWidth + "px", height: opts.picHeight + "px" })
                        .appendTo($this),
                    $pic = $this.children("img").addClass("picZoomer-pic").appendTo($picBD),
                    $cursor = $(
                        '<div class="picZoomer-cursor"><i class="f-is picZoomCursor-ico"></i></div>'
                    ).appendTo($picBD),
                    cursorSizeHalf = { w: $cursor.width() / 2, h: $cursor.height() / 2 },
                    $zoomWP = $(
                        '<div class="picZoomer-zoom-wp"><img src="" alt="" class="picZoomer-zoom-pic"></div>'
                    ).appendTo($this),
                    $zoomPic = $zoomWP.find(".picZoomer-zoom-pic"),
                    picBDOffset = { x: $picBD.offset().left, y: $picBD.offset().top };

                opts.zoomWidth = opts.zoomWidth || opts.picWidth;
                opts.zoomHeight = opts.zoomHeight || opts.picHeight;
                var zoomWPSizeHalf = { w: opts.zoomWidth / 2, h: opts.zoomHeight / 2 };

    
                $zoomWP.css({
                    width: opts.zoomWidth + "px",
                    height: opts.zoomHeight + "px"
                });
                $zoomWP.css(
                    opts.zoomerPosition || { top: 0, left: opts.picWidth + 30 + "px" }
                );
                $zoomPic.css({
                    width: opts.picWidth * opts.scale + "px",
                    height: opts.picHeight * opts.scale + "px"
                });

                $picBD
                    .on("mouseenter", function (event) {
                        $cursor.show();
                        $zoomWP.show();
                        $zoomPic.attr("src", $pic.attr("src"));
                    })
                    .on("mouseleave", function (event) {
                        $cursor.hide();
                        $zoomWP.hide();
                    })
                    .on("mousemove", function (event) {
                        var x = event.pageX - picBDOffset.x,
                            y = event.pageY - picBDOffset.y;

                        $cursor.css({
                            left: x - cursorSizeHalf.w + "px",
                            top: y - cursorSizeHalf.h + "px"
                        });
                        $zoomPic.css({
                            left: -(x * opts.scale - zoomWPSizeHalf.w) + "px",
                            top: -(y * opts.scale - zoomWPSizeHalf.h) + "px"
                        });
                    });
                return $this;
            };
            $.fn.picZoomer.defaults = {
                picHeight: 460,
                scale: 2.5,
                zoomerPosition: { top: "0", left: "380px" },

                zoomWidth: 400,
                zoomHeight: 460
            };
        })(jQuery);

        $(document).ready(function () {
            $(".picZoomer").picZoomer();
            $(".piclist li").on("click", function (event) {
                var $pic = $(this).find("img");
                $(".picZoomer-pic").attr("src", $pic.attr("src"));
            });
        });













// Initialize Pusher
const pusher = new Pusher('<?php echo e(config('broadcasting.connections.pusher.key')); ?>', {
    cluster: '<?php echo e(config('broadcasting.connections.pusher.options.cluster')); ?>',
});



// Subscribe to the Pusher channel for real-time updates
const channel = pusher.subscribe('jeddah_mazad_chat');
    channel.bind('jeddah_mazad_message', function (data) {
        display_other_notification();
});
display_other_notification();




const msg_notification = $('#msg_notification');
function display_msg_notification_() {
        $.ajax({
        url: getmsgNotification,
        type: 'GET',
        success: function (data) {
            msg_notification.html('');
            var res = data.msg_data;
            var msg_content = data.msg_content;
            var view_btn = data.view_btn;
            var latest_user_route = data.latest_user_route;



            if(latest_user_route){
                var msg_round_icon = $('#msg_round_icon');
                msg_round_icon.html('');
                var latest_msg_data = `<a href="${latest_user_route}" class="dropdown-toggle notification_toggle d-flex align-items-center justify-content-center  rounded-circle"><img src="<?php echo e(url('public/theme_assets/images/icons/inbox.png')); ?>" alt="inbox" width="50" height="47"><span class="badge bg-danger badge-number rounded-circle" id="total_msg"></span>
                    </a>`;
                    msg_round_icon.append(latest_msg_data);
                    $('#total_msg').text(data.total_Notifin);
            }else{
                $('#msg_round_icon').hide();
            }


            if (res.length > 0) {
                $.each(res, function (index, notification) {
                    var notificationItem = 
                    `<li class="notification-item">
                            <div class="justify-content-between align-items-center d-flex">
                                <div class="d-flex align-items-start">
                                    <div class="flex-column d-flex">
                                        <p class="mb-0">
                                        <small>
                                        ${notification.content}
                                        </small></p>
                                    </div>
                                </div>
                                <div class="view_btn me-2">
                                    <a href="${notification.route}"><small>${notification.view_btn}</small></a>
                                </div>
                            </div>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>`;
                    msg_notification.append(notificationItem);
                });
            }else{
                $('#msg_notification').hide();
            }


        },

        error: function (error) {
            console.log(error);
        }
    });
}




const other_notification = $('#other_notification');
function display_other_notification() {
        $.ajax({
        url: getotherNotification,
        type: 'GET',
        success: function (data) {
            other_notification.html('');
            var res = data.msg_data;
            var msg_content = data.msg_content;
            var view_btn = data.view_btn;
            
             $('#total_notifi').text(data.total_Notifin);
            if (res.length > 0) {
                $.each(res, function (index, notification) {
                    var notificationItem = 
                    `<li class="notification-item">
                            <div class="justify-content-between align-items-center d-flex">
                                <div class="d-flex align-items-start">
                                    <div class="flex-column d-flex">
                                        <p class="mb-0">
                                        <small>
                                        ${notification.content}
                                        </small></p>
                                    </div>
                                </div>
                                <div class="view_btn me-2">
                                    <a href="${notification.route}"><small>${notification.view_btn}</small></a>
                                </div>
                            </div>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>`;
                    other_notification.append(notificationItem);
                });
            }else{
                $('#other_notification').hide();
            }


        },

        error: function (error) {
            console.log(error);
        }
    });
}








    </script>
</body>


</html><?php /**PATH G:\server\htdocs\jeddah_mazad_\resources\views/theme_1/layouts/footer.blade.php ENDPATH**/ ?>