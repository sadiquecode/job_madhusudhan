<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.topheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ============================== TOOLKIT Start ==============================-->
    <section>
        <div class="container">
            <div class="toolkit_wrapper py-5 mx-auto text-center">
                <p><?php echo e($home_page->writing_line); ?></p>
                <h1><?php echo e($home_page->writing_heading); ?></h1>
            </div>
            <div class="py-4">
                <div class="row g-4 mb-4">
                    <?php $__currentLoopData = $aiTemplates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-lg-4">
                        <a target="_blank" href="<?php echo e(url('ai-template/'.$template->slug)); ?>"  style="color:black">
                            <div class="card card_content border-0 rounded-4 text-center">
                            <div class="card-body">
                                
                                <i class="<?php echo e($template->icon); ?>" style="font-size:20px; color: #1a73e8; background-color:#eee; padding:15px;"></i>
                                <h3 class="mt-3"><?php echo e($template->template); ?></h3>
                                <p><?php echo e($template->description); ?></p>
                                <div class="arrow_img">
                                    <img src="<?php echo e(url('public/theme_one_assets/images/icon/right-arrow.png')); ?>" alt="right-arrow" width="20"
                                        height="20">
                                </div>
                            </div>
                        </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="banner_btn mb-5 text-center">
                    <a target="_blank" href="<?php echo e(url('templates/ai-templates')); ?>" class="btn btn-lg mt-4 py-3 px-4"><?php echo e($home_page->writing_button); ?></a>
                </div>
            </div>
        </div>
    </section>
    <!-- ============================== TOOLKIT End ==============================-->

    <!-- ============================== AI image Start ==============================-->
    <section class="container-fluid p-0 image_wrapper">
        <div class="container">
            <div class="toolkit_wrapper py-5 mx-auto text-center">
                <p><?php echo e($home_page->img_line); ?></p>
                <h1><?php echo e($home_page->img_heading); ?></h1>
            </div>

            <div class="row pb-5 gx-0">
                <?php $__currentLoopData = $aiimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4">
                    <div class="text-center ai_image position-relative">
                        <p class="d-none position-absolute top-50 start-50"><?php echo e($img->prompt); ?></p>
                        <img src="<?php echo e($img->content); ?>" alt="Aigenerator">
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="banner_btn pb-5 text-center">
                <a target="_blank" href="<?php echo e(url('images/ai-images')); ?>" class="btn btn-lg mt-4 py-3 px-4"><?php echo e($home_page->img_button); ?></a>
            </div>
        </div>
    </section>
    <!-- ============================== AI image End ==============================-->

    <!-- ============================== AI Chat Start ==============================-->
    <section class="container-fluid p-0 chat_wrapper ">
        <div class="container">
            <div class="toolkit_wrapper py-5 mx-auto text-center">
                <p class="text-dark"><?php echo e($home_page->bot_line); ?></p>
                <h1 class="text-white"><?php echo e($home_page->bot_heading); ?></h1>
            </div>
            <div class="chat_image pb-5">
                <img src="<?php echo e(url('public/theme_one_assets/images/main/main.png')); ?>" alt="Chat" class="img-fluid">
                <!--style="width: 100%; height: auto;" -->
            </div>
            <div class="banner_btn pb-5 text-center">
                <a target="_blank" href="<?php echo e(url('chat-bots/ai-chat-bots')); ?>" class="btn btn-lg mt-4 py-3 px-4"><?php echo e($home_page->bot_button); ?></a>
            </div>
        </div>
    </section>
    <!-- ============================== AI Chat End ==============================-->

    <!-- ============================== FAQ Start ==============================-->
    <section class="faq_wrapper pb-5">
        <div class="container">
            <div class="chat_content pt-5 mx-auto text-center">
                <h1><?php echo e($home_page->faq_heading); ?></h1>
            </div>
            <div class="accordion accordion-flush py-5 px-5" id="accordionFlushExample">

                <?php $__currentLoopData = $Webfaq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="flush-headingOne">
                        <button class="accordion-button collapsed accordion__btn accordion__btn__rtl fw-bold" type="button"
                            data-bs-toggle="collapse" data-bs-target="#faq_<?php echo e($faq->id); ?>" aria-expanded="false"
                            aria-controls="faq_<?php echo e($faq->id); ?>">
                            <?php echo e($faq->question); ?>

                        </button>
                    </h2>
                    <div id="faq_<?php echo e($faq->id); ?>" class="accordion-collapse collapse" aria-labelledby="flush-headingOne"
                        data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body accordion__body">
                           <?php echo e($faq->answer); ?>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="banner_btn pb-5 text-center">
                    <a target="_blank" href="<?php echo e(url('register')); ?>" class="btn btn-lg mt-4 py-3 px-4"><?php echo e($home_page->faq_button); ?></a>
                </div>
            </div>
        </div>
    </section>
    <!-- ============================== FAQ End ==============================-->

<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/theme_1/home.blade.php ENDPATH**/ ?>