<?php echo $__env->make('theme_1.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme_1.layouts.topheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ============================== Banner Start ==============================-->
    <section class="banner">
        <div class="container">
            <div class="banner_wrapper text-center py-5 mx-auto">
                <h1><?php echo e($feature_page->feature_heading); ?></h1>
                <p><?php echo e($feature_page->feature_sub_heading); ?>

                </p>
                <div class="banner_btn">
                    <a href="#" class="btn btn-lg mt-4 py-3 px-4"><?php echo e($feature_page->feature_button); ?></a>
                </div>
            </div>
        </div>
    </section>
    <!-- ============================== Banner End ==============================-->

    <!-- ============================== Company Start ==============================-->
    <section>
        <div class="container">
            <div class="company_wrapper py-5">
                <!--data-aos="fade-up" -->
                <div class="row align-items-center">
                    <div class="col-lg-2 col-4">
                        <div class="company_wrapper">
                            <img src="<?php echo e(url('public/theme_one_assets/images/company/VIGO_prev_ui.png')); ?>" alt="vigo" class="img-fluid w-75">
                        </div>
                    </div>
                    <div class="col-lg-2 col-4">
                        <div class="company_wrapper">
                            <img src="<?php echo e(url('public/theme_one_assets/images/company/marshalls.png')); ?>" alt="marshalls" class="img-fluid w-75">
                        </div>
                    </div>
                    <div class="col-lg-2 col-4">
                        <div class="company_wrapper">
                            <img src="<?php echo e(url('public/theme_one_assets/images/company/27058.png')); ?>" alt="designer eye" class="img-fluid w-75">
                        </div>
                    </div>
                    <div class="col-lg-2 col-4">
                        <div class="company_wrapper">
                            <img src="<?php echo e(url('public/theme_one_assets/images/company/ocado.png')); ?>" alt="ocado" class="img-fluid w-75">
                        </div>
                    </div>
                    <div class="col-lg-2 col-4">
                        <div class="company_wrapper">
                            <img src="<?php echo e(url('public/theme_one_assets/images/company/target.png')); ?>" alt="target" class="img-fluid w-75">
                        </div>
                    </div>
                    <div class="col-lg-2 col-4">
                        <div class="company_wrapper">
                            <img src="<?php echo e(url('public/theme_one_assets/images/company/hom-furniture-logo-vector_prev_ui.png')); ?>" alt="furniture"
                                class="img-fluid w-75">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ============================== Company End ==============================-->

    <!-- ============================== How Work Start ==============================-->
    <section>
        <div class="container" style="max-width: 1050px !important;">
            <div class="content_wrapper text-center pb-5">
                <h2><?php echo e($feature_page->feature_list_heading); ?></h2>
            </div>
            <div class="product__content p-lg-5 p-md-3 p-3">
                <div class="row g-3">
                    <div class="col-lg-6 col-md-6 col-12 text-center">
                        <img src="<?php echo e(url('public/theme_one_assets/images/main/Group-53.png')); ?>" alt="Group" class="img-fluid">
                    </div>
                    <div class="col-lg-6 col-md-6 col-12 d-flex align-items-center">
                        <div class="product__text">
                            <h2>High-quality Product Descriptions</h2>
                            <p>With Describely, the ability to create high-quality product content is just a few clicks
                                away. Write product descriptions, bullet points, titles and tags easily and at scale
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="product__content p-lg-5 p-md-3 p-3 my-5">
                <div class="row g-3">
                    <div class="col-lg-6 col-md-6 col-12  d-flex align-items-center">
                        <div class="product__text">
                            <h2>Optimize for SEO</h2>
                            <p>Our SEO tools are built to help you rank #1 no matter where you sell your products
                                online
                                <br><br>
                                Let Describely plan your keywords for you, score your existing content against SEO
                                best
                                practices and give recommendations on keywords that help your content rank faster
                                than
                                ever before
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12 text-center">
                        <img src="<?php echo e(url('public/theme_one_assets/images/main/SEO-meta-description.png')); ?>" alt="SEO-meta" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ============================== How Work End ==============================-->
    <!-- ============================== Footer Start ==============================-->

<?php echo $__env->make('theme_1.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/theme_1/features.blade.php ENDPATH**/ ?>