<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-3">
                    <h4 class="page-title">All Payments</h4>
                </div>
                <div class="col-sm-8 col-9 text-right m-b-20 d-none">
                    <a href="#" class="btn btn-primary btn-rounded float-right" data-toggle="modal" data-target="#add_package"><i class="fa fa-plus"></i> Add Package</a>
                </div>
            </div>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped custom-table m-b-0" id="teachme_table">
                            <thead>
                                <tr>
                                    <th>Invoice ID</th>
                                    <th style="width: 10% !important;">Client</th>
                                    <th>Package</th>
                                    
                                    <th>Paid Date</th>
                                    <th>End Date</th>
                                    <th>Paid Amount</th>
                                    <th>Payment Status</th>
                                    <th>Subscription Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($subscription->stripe_id); ?></td>
                                    <td style="width: 10% !important;">
                                        <?php if($subscription->customer_id): ?>
                                            <a href="<?php echo e(url('profile/'.encrypt($subscription->customer_id))); ?>">
                                                <?php echo e($subscription->fname.' '.$subscription->lname); ?>

                                            </a>
                                        <?php else: ?>
                                        <?php echo e('User Not Found!'); ?>

                                        <?php endif; ?>
                                        
                                    </td>
                                    <td>
                                        <h2><a href="#"><?php echo e($subscription->title); ?></a></h2>
                                    </td>
                                    
                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($subscription->created_at)->format('F d, Y')); ?>

                                    </td>
                                    <td>
                                        
                                        <?php if($subscription->ends_at == null): ?>
                                        <?php echo e(\Carbon\Carbon::parse($subscription->created_at)->addYear()->format('F d, Y')); ?>

                                        <?php else: ?>
                                        
                                        <?php echo e(\Carbon\Carbon::parse($subscription->ends_at)->format('F d, Y')); ?>

                                        <?php endif; ?>
                                        
                                    </td>
                                    <td><?php echo e($subscription->price); ?> AED</td>
                                    <td>Paid</td>
                                    <td><?php echo e($subscription->stripe_status); ?></td>
                                    
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer text-center bg-white">
                        <a href="#" class="text-muted">View all payments</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\techme_latest\resources\views/golbal_details/payment.blade.php ENDPATH**/ ?>