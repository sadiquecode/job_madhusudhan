<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="page-title">Edit Profile</h4>
                </div>
            </div>


<?php if($errors->any()): ?>
<div class="alert alert-danger">
<strong>Whoops!</strong> There were some problems with your input.<br><br>
<ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
<p><?php echo e($message); ?></p>
</div>
<?php endif; ?>


            <form action="<?php echo e(route('update_profile.update', ['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="card-box">
                    <h3 class="card-title">Basic Informations</h3>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="profile-img-wrap">
                            <?php if(empty($user->profile_pic)): ?>
                                <img class="inline-block" src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="user">
                                <?php else: ?>
                                <img class="inline-block" src="<?php echo e(url(env('img_path'). $user->profile_pic)); ?>" alt="user">
                                <?php endif; ?>
                                <div class="fileupload btn">
                                    <span class="btn-text">Pic</span>
                                    <input class="upload" type="file" name="profile_pic">
                                </div>
                            </div>
                            <div class="profile-basic">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group form-focus">
                                            <label class="focus-label">First Name</label>
                                            <input type="text" name="name" class="form-control floating" value="<?php echo e($user->name); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group form-focus">
                                            <label class="focus-label">Last Name</label>
                                            <input type="text" name="lname" class="form-control floating" value="<?php echo e($user->lname); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group form-focus">
                                            <label class="focus-label">Email</label>
                                            <input type="email" class="form-control floating" name="email" value="<?php echo e($user->email); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group form-focus">
                                            <label class="focus-label">Phone</label>
                                            <input type="text" class="form-control floating" name="phone" value="<?php echo e($user->phone); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                <div class="card-box_">
                    <h3 class="card-title">Reset Password</h3>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group form-focus">
                                <label class="focus-label">Password</label>
                                <input type="password" class="form-control floating" name="password">
                            </div>
                        </div>
                        
                    </div>
                </div>

                </div>


                <div class="text-center m-t-20">
                    <button class="btn btn-primary btn-lg" type="submit">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/auth/profile.blade.php ENDPATH**/ ?>