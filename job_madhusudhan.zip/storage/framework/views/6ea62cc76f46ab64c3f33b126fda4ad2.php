<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="sidebar" id="sidebar">
<div class="sidebar-inner slimscroll">
    <style>
    .sidebar-menu ul li:hover {
    background-color: #e0e0e0;
    }
    </style>
    <div class="sidebar-menu">
        <ul>
            <li>
                <a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-home back-icon"></i> Back to Home</a>
            </li>
            

            <?php $__currentLoopData = $aiChatBots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aiChatBot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="<?php echo e(request()->route('id') == $aiChatBot->id ? 'active' : ''); ?>">
            <a href="<?php echo e(route('chatbot.conversations.show', $aiChatBot->id)); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e($aiChatBot->role); ?>"><span class="chat-avatar-sm user-img">

            <?php if(empty($aiChatBot->profile_pic)): ?>
            <img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="" class="rounded-circle">
            <?php else: ?>
            <img src="<?php echo e(url(env('img_path'). $aiChatBot->profile_pic)); ?>" alt="" class="rounded-circle">
            <?php endif; ?>

                    <span class="status online"></span></span> <?php echo e($aiChatBot->name); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
    </div>
</div>
</div>
<div class="page-wrapper">
<div class="chat-main-row">
    <div class="chat-main-wrapper">
        <div class="col-lg-9 message-view task-view">
            <div class="chat-window">
                <div class="fixed-header">
                    <div class="navbar">
                        <div class="user-details mr-auto">
                            <div class="float-left user-img m-r-10">
                                

                                <?php if(!empty($ChatBot->profile_pic)): ?>
                                <a href="<?php echo e(route('chatbot.conversations.show', $ChatBot->id)); ?>" title="<?php echo e($ChatBot->name); ?>"><img src="<?php echo e(url(env('img_path'). $ChatBot->profile_pic)); ?>" alt="<?php echo e($ChatBot->name); ?>" class="w-40 rounded-circle"><span class="status online"></span></a>
                                <?php else: ?>
                                <a href="<?php echo e(route('chatbot.conversations.show', $ChatBot->id)); ?>" title="<?php echo e($ChatBot->name); ?>"><img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="" class="w-40 rounded-circle"><span class="status online"></span></a>
                                <?php endif; ?>
                            </div>
                            <div class="user-info float-left">
                                <a href="<?php echo e(route('chatbot.conversations.show', $ChatBot->id)); ?>" title="Mike Litorus"><span class="font-bold"><?php echo e($ChatBot->name); ?></span> 
                                    <i class="typing-text" id="chattyping"></i>
                                </a>
                                <span class="last-seen" id="current-time"></span>
                            </div>
                        </div>
                                                    
            
                        <div class="search-box d-none">
                            <div class="input-group input-group-sm">
                                <input type="text" class="form-control" placeholder="Search" required="">
                                <span class="input-group-append">
                                    <button class="btn" type="button"><i class="fa fa-search"></i></button>
                                </span>
                            </div>
                        </div>
                        <ul class="nav custom-menu">

                            <li class="nav-item">
                                <a href="#chat_sidebar" class="nav-link task-chat profile-rightbar float-right" data-toggle="tooltip" data-placement="top" title="User Profile"><i class="fa fa-user" aria-hidden="true"></i></a>
                            </li>
                            <?php if(count($AllChat) > 0): ?>
                            <li class="nav-item">
                                <a href="javascript:void(0);" class="nav-link" data-toggle="tooltip" data-placement="top" title="Export Conversations"><i class="fas fa-download"></i></a>
                            </li>

                            <li class="nav-item">
                                <a href="<?php echo e(url('chat-bots/conversations').'/'.$ChatBot->id); ?>" onclick="confirm('Are You sure?')" class="nav-link"  data-toggle="tooltip" data-placement="top" title="Delete Conversations"><i class="fas fa-trash"></i></a>
                            </li>

                            
                            <li class="nav-item">
                                <a href="javascript:void(0);" data-placement="top" title="All Conversations" class="nav-link" data-toggle="modal" data-target="#all_chats"><i class="fa fa-comments"></i>
                                    
                                        <span class="badge badge-pill bg-danger text-white float-right" style="position: absolute;
                                        right: 30px;
                                        top: -3px;
                                        font-size:46%;
                                    font-weight: 700;"><?php echo e(count($AllChat)); ?></span>
                                    
                                    </a>
                                </li>
                                

                                <li class="nav-item">
                                    <a href="javascript:void(0);" id="new_chat" class="nav-link" data-toggle="tooltip" data-placement="top" title="New Conversations"><i class="fas fa-comment"></i></a>
                                </li>
                                <?php endif; ?>

                                <li class="nav-item dropdown dropdown-action d-none">
                                    <a href="" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-cog"></i></a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a class="dropdown-item" href="javascript:void(0)">Delete Conversations</a>
                                        <a class="dropdown-item" href="javascript:void(0)">Settings</a>
                                    </div>
                                </li>


                            </ul>
                        </div>
                    </div>
                    <div class="chat-contents">
                        <div class="chat-content-wrap">
                            <div class="chat-wrap-inner">
                                <div class="chat-box">
                                    <div class="chats" id="chatContainer"></div>
                                    <div id="alert-container" class="text-center" style="display: none;"></div>


                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="chat-footer">
                        <div class="message-bar">
                            <div class="message-inner">
                                <a class="link attach-icon" href="#" data-toggle="modal" data-target="#drag_files" data-placement="top" title="Prompt Library" >
                                    <i class="fa fa-book"></i>
                                </a>
                                <input type="hidden" name="chat_data_id" value="0" id="chat_data_id">
                                <div class="message-area">
                                    <div class="input-group">
                                        <textarea class="form-control" placeholder="Type message..." id="messageTextarea"></textarea>
                                        <span class="input-group-append">
                                            <button class="btn btn-primary" type="button" id="bot_chat"><i class="fas fa-paper-plane"></i></button>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 message-view chat-profile-view chat-sidebar" id="chat_sidebar">
                <div class="chat-window video-window">
                    <div class="fixed-header">
                        <ul class="nav nav-tabs nav-tabs-bottom">
                            <li class="nav-item"><a class="nav-link active" href="#profile_tab" data-toggle="tab">Profile</a></li>
                        </ul>
                    </div>
                    <div class="tab-content chat-contents">
                        <div class="content-full tab-pane show active" id="profile_tab">
                            <div class="display-table">
                                <div class="table-row">
                                    <div class="table-body">
                                        <div class="table-content">
                                            <div class="chat-profile-img">
                                            <div class="edit-profile-img">
                                            <?php if(empty($ChatBot->profile_pic)): ?>
                                            <img src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="">
                                            <span class="change-img"><?php echo e($ChatBot->name); ?></span>
                                            <?php else: ?>
                                            <img src="<?php echo e(url(env('img_path'). $ChatBot->profile_pic)); ?>" alt="">
                                            <span class="change-img"><?php echo e($ChatBot->name); ?></span>
                                            <?php endif; ?>
                                                </div>
                                                <h3 class="user-name m-t-10 m-b-0"><?php echo e($ChatBot->name); ?></h3>
                                                <small class="text-muted"><?php echo e($ChatBot->role); ?></small>
                                            </div>
                                            <?php if(count($AllChat) > 0): ?>
                                            <input type="hidden" id="chat_history" value="latest_chat">
                                            <?php endif; ?>
                                            <input type="hidden" id="chatBot_id" value="<?php echo e($ChatBot->id); ?>">
                                            <input type="hidden" id="currentUserId" value="<?php echo e(Auth::id()); ?>">
                                            <div class="chat-profile-info">
                                                <ul class="user-det-list">
                                                    <li>
                                                        <span>Category:</span>
                                                        <span class="float-right text-muted"><?php echo e($category->title); ?></span>
                                                    </li>
                                                    <li>
                                                        <span><?php echo e($ChatBot->welcome_msg); ?></span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="drag_files" class="modal custom-modal fade" role="dialog">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">Prompt Library</h3>
                </div>
                <div class="modal-body">
                    <div class="input-group m-b-30">
                        <input placeholder="Search Prompts" class="form-control search-input" id="btn-input" type="text">
                        
                    </div>
                    <div>
                        <h5>Use Any Prompt On Click</h5>
                        <ul class="chat-user-list">
                            <?php $__currentLoopData = $aiChatPrompts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prompt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                <a href="#" class="prompt_description">
                                    <div class="media">
                                        <span class="avatar align-self-center">
                                            <i class="fa fa-book"></i>
                                        </span>

                                        <div class="media-body align-self-center text-nowrap">
                                            <div class="user-name"><?php echo e($prompt->title); ?></div>
                                            <span class="designation"><?php echo e($prompt->description); ?></span>

                                            <span class="designation bot_prompt_data d-none"><?php echo e($prompt->prompt); ?></span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="all_chats" class="modal custom-modal fade" role="dialog">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="modal-dialog modal-dialog-centered">
            

            <div class="modal-content">
                <div id="alert-container" class="mt-3" style="display: none;"></div>
                <?php if(count($AllChat) > 0): ?>
                <div class="modal-header">
                    <h3 class="modal-title">All Chat With <?php echo e($ChatBot->name); ?></h3>
                </div>
                <div class="modal-body">
                    <div class="input-group m-b-30">
                        <input placeholder="Search to start a chat" class="form-control search-input" id="btn-input" type="text">
                        <span class="input-group-append">
                            <button class="btn btn-primary">Search</button>
                        </span>
                    </div>


                        <style type="text/css">
.chat-container {
    height: 400px; /* Set the height of the container */
    overflow-y: scroll; /* Show vertical scrollbar when content overflows */
    border: 1px solid #ccc;
    border-radius: 5px;
    padding: 10px;
}

/* Right side scrollbar design */
.chat-container::-webkit-scrollbar {
    width: 5px; /* Width of the scrollbar */
}

.chat-container::-webkit-scrollbar-thumb {
    background-color: #888; /* Color of the scrollbar thumb */
    border-radius: 5px; /* Rounded corners */
}

.chat-container::-webkit-scrollbar-track {
    background-color: #f0f0f0; /* Color of the scrollbar track */
}




                        </style>                    
                    <div class="chat-container">

                        <h5>Recent Conversations</h5>
                        <ul class="chat-user-list" id="chatList" class="list-unstyled chat-list">
                            
<?php $__currentLoopData = $AllChat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li class="media-list">
    <div class="media">
        <div class="media-body align-self-center text-nowrap">
            <div class="user-name my_file_name" contenteditable="true" data-gramm="false" wt-ignore-input="true" style="width:50%;" data-name="title" data-chat_id="<?php echo e($chat_data->id); ?>"><?php echo e($chat_data->title); ?></div>
            <span class="designation"><?php echo e(Str::limit(get_last_conversation($chat_data->id), 40)); ?></span>
            <div class="online-date timestamp"><?php echo e($chat_data->created_at->diffForHumans()); ?></div>
        </div>
        <div class="text-nowrap align-self-center">
            <a href="#" class="file_rename" data-id="<?php echo e($chat_data->id); ?>" data-toggle="tooltip" data-placement="top" title="Rename">
                <span class="avatar align-self-center">
                    <i class="fas fa-pencil-alt mb-4"></i>
                </span>
            </a>
            <a href="#" class="get_chat_history" data-id="<?php echo e($chat_data->id); ?>" chatBot_id="<?php echo e($ChatBot->id); ?>" currentUserId="<?php echo e(Auth::id()); ?>" data-toggle="tooltip" data-placement="top" title="View">
                <span class="avatar align-self-center">
                    <i class="fa fa-eye"></i>
                </span>
            </a>
        </div>
    </div>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            


                        </ul>
                        
                    </div>
                </div>

                <?php else: ?>
                <h5>Conversations Not Found!</h5>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</div>

<script type="text/javascript" src="<?php echo e(url('public/assets/js/jquery-3.5.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('public/assets/custom/chat.js')); ?>" data-base-url="<?php echo e(url('/')); ?>"></script>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/chatbote/chat.blade.php ENDPATH**/ ?>