 <!-- ============================== Footer Start ==============================-->
<footer class="footer">
        <div class="container">
            <div class="footer_wrapper pt-5 pb-5">
<div class="row pb-5 m-5">
    <div class="col-md-3 col-3 d-none d-md-block"></div> <!-- Empty columns for medium and large screens -->
    <div class="col-md-3 col-lg-3 col-6 text-left">
        <h2>Manue</h2>
        <ul>
            <?php $count = 0; ?>
            <?php for($i = 0; $i < 5; $i++): ?>
                <?php if($count < count($manu)): ?>
                    <li>
                        <a href="<?php echo e(url($slugs[$i]['page_slug'])); ?>"><?php echo e($manu[$count]->page_title); ?></a>
                    </li>
                    <?php $count++; ?>
                <?php endif; ?>
            <?php endfor; ?>
        </ul>
    </div>

    <div class="col-md-3 col-lg-3 col-6 text-right">
        <h2>Company</h2>
        <ul>
            <?php $fcount = 0; ?>
            <?php for($i = 0; $i < 5; $i++): ?>
                <?php if($fcount < count($fmanu)): ?>
                    <li>
                        <a href="<?php echo e(url('pages/'.$fslugs[$i]['page_slug'].'/'.$fmanu[$fcount]->page_title)); ?>"><?php echo e($fmanu[$fcount]->page_title); ?></a>
                    </li>
                    <?php $fcount++; ?>
                <?php endif; ?>
            <?php endfor; ?>
        </ul>
    </div>
    <div class="col-md-3 col-3 d-none d-md-block"></div> <!-- Empty columns for medium and large screens -->
</div>



            </div>
            <div class="social_icon text-center py-4 d-none">
                <a href="#"><i class="fa-brands fa-facebook-f fa-2x" style="color: #ffffff;"></i></a>
                <a href="#"><i class="fa-brands fa-x-twitter fa-2x" style="color: #ffffff;"></i></a>
                <a href="#"><i class="fa-brands fa-instagram fa-2x" style="color: #ffffff;"></i></a>
                <a href="#"><i class="fa-brands fa-linkedin-in fa-2x" style="color: #ffffff;"></i></a>
                <a href="#"><i class="fa-brands fa-youtube fa-2x" style="color: #ffffff;"></i></a>
            </div>
            <div class="end_buttons pb-3">
                <ul class="d-flex justify-content-center">
                    <li>
                        <p>Powered by FASTAI</p>
                    </li>

                </ul>
            </div>
        </div>
    </footer>
    <!-- ============================== Footer End ==============================-->
</body>
<!-- Bootstrap JS -->
<script src="<?php echo e(url('public/theme_one_assets/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('public/theme_one_assets/bootstrap/bootstrap.bundle.min.js.map')); ?>"></script>
<!-- Custom JS -->
<script src="<?php echo e(url('public/theme_one_assets/js/main.js')); ?>"></script>

<script type="text/javascript">
    let tooltipelements = document.querySelectorAll("[data-bs-toggle='tooltip']");
    tooltipelements.forEach((el) => {
        new bootstrap.Tooltip(el);
    });
</script>

</html><?php /**PATH G:\server\htdocs\advance_ai\resources\views/theme_1/layouts/footer.blade.php ENDPATH**/ ?>