<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <h4 class="page-title">Update Menu</h4>
                </div>
            </div>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <form class="m-b-30" action="<?php echo e(route('all_menu.update', $page->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label class="col-form-label">Language <span class="text-danger">*</span></label>
                            <input type="text" name="lang_code" class="form-control" value="<?php echo e($page->lang_code); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Title <span class="text-danger">*</span></label>
                            <input type="text" name="page_title" class="form-control" required placeholder="Title" value="<?=$page->page_title?>">
                        </div>
                        
                        <div class="form-group">
                            <label>Content</label>
                            <textarea cols="20" rows="4" class="form-control ckeditor" name="body"><?=$page->body?></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label class="display-block">Status</label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="temp_cat_enable" value="enable" <?php echo e($page->status === 'enable' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="temp_cat_enable">
                                    enable
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="temp_cat_disable" value="disable" <?php echo e($page->status === 'disable' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="temp_cat_disable">
                                    disable
                                </label>
                            </div>
                        </div>
                        <hr>
                        <h4>SEO</h4>
                        <div class="form-group">
                            <label class="col-form-label">Meta Title <span class="text-danger"></span></label>
                            <input type="text" name="meta_title" class="form-control" placeholder="Meta Title" value="<?=$page->meta_title?>">
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Meta Image <span class="text-danger"></span></label>
                            <input class="form-control" type="file" name="meta_image" placeholder="Meta Image" value="<?=$page->meta_image?>">
                        </div>
                        <input type="hidden" name="old_meta_image" value="<?=$page->meta_image?>">

                        <div class="form-group">
                            <label class="col-form-label">Meta Desc <span class="text-danger"></span></label>
                            <textarea name="meta_desc" class="form-control" placeholder="Meta Desc"><?=$page->meta_desc?></textarea>
                        </div>
                        <div class="m-t-20 text-center">
                            <button class="btn btn-primary btn-lg">Update Menu</button>
                        </div>
                    </form>
                </div>
            </div>
            
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/web/all_menu_edit.blade.php ENDPATH**/ ?>