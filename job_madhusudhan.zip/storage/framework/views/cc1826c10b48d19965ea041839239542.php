<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-3">
                    <h4 class="page-title">All Menus</h4>
                </div>
                <div class="col-sm-8 col-9 text-right m-b-20">
                    <a href="#" class="btn btn-primary btn-rounded float-right" data-toggle="modal" data-target="#add_menus"><i class="fa fa-plus"></i> Add Menus</a>
                </div>
            </div>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <div class="row">
                <?php if(count($menus) > 0): ?>
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped custom-table datatable">
                            <thead>
                                <tr>
                                    <th>S/L</th>
                                    <th>Gender (Trans)</th>
                                    <th>Name (Trans)</th>
                                    <th>Brand (Trans)</th>
                                    <th>Status</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($index + 1); ?></td>

                                    <td><?php echo e($menu->gender_en); ?><br>
                                        <?php echo e($menu->gender_ar); ?></td>

                                    <td><?php echo e($menu->category_title_en); ?><br>
                                    <?php echo e($menu->category_title_ar); ?></td>

                                    <td><button type="button" class="btn-sm btn btn-danger" data-toggle="modal" data-target="#check_brand_<?php echo e($menu->id); ?>"><i class="fa fa-eye"></i></button></td>

                                    <td>
                                        <?php if($menu->status === 'active'): ?>
                                            <span class="p-2 badge badge-primary">Active</span>
                                        <?php else: ?>
                                            <span class="p-2 badge badge-secondary">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-right">
                                        <div class="dropdown dropdown-action">
                                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_menus_<?php echo e($menu->id); ?>"><i class="fas fa-pen m-r-5"></i> Edit</a>
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_menus_<?php echo e($menu->id); ?>"><i class="far fa-trash-alt m-r-5"></i> Delete</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <div id="delete_menus_<?php echo e($menu->id); ?>" class="modal custom-modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content modal-md">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Delete Data</h4>
                                            </div>
                                            <form action="<?php echo e(route('menu.destroy', $menu->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <div class="modal-body card-box">
                                                    <p>Are you sure want to delete this?</p>
                                                    <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                <div id="edit_menus_<?php echo e($menu->id); ?>" class="modal custom-modal fade" role="dialog">
                    <div class="modal-dialog">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <div class="modal-content modal-lg">
                            <div class="modal-header">
                                <h4 class="modal-title">Edit Menu</h4>
                            </div>
                            <div class="modal-body">
                                
            <form class="m-b-30" action="<?php echo e(route('menu.update', $menu->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="row">

                        <div class="col-sm-12">
                        <div class="form-group form-focus select-focus">
                        <label class="focus-label">Gender</label>
                        <select class="select floating" name="gender_id">
                            <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($menu->gender_id == $gender->id): ?>
                                <option value="<?php echo e($gender->id); ?>" selected>
                                    <?=$gender->gender_en?><br>
                                    <?=$gender->gender_ar?><br>
                                </option>
                                <?php else: ?>
                                <option value="<?php echo e($gender->id); ?>">
                                    <?=$gender->gender_en?><br>
                                    <?=$gender->gender_ar?><br>
                                </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Name (en)<span class="text-danger">*</span></label>
                                <input type="text" name="category_title_en" class="form-control" value="<?php echo e($menu->category_title_en); ?>">
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Translation <span class="text-danger">*</span></label>
                                <input type="text" name="category_title_ar" class="form-control" value="<?php echo e($menu->category_title_ar); ?>">
                            </div>
                        </div>

                    <div class="col-sm-12">
                        <div class="form-group form-focus select-focus">
                            <select class="select floating" name="brands[]" multiple="multiple" data-placeholder="Choose Brand">
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($brand->id); ?>"
                            <?php if(get_category_brand($menu->id)->contains('brand_id', $brand->id)): ?> selected <?php endif; ?>>
                                    <?=$brand->brand_title_en?><br>
                                    <?=$brand->brand_title_ar?><br>
                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Status <span class="text-danger">*</span></label>
                                <select name="status" class="select floating">
                                    <option value="active" <?php if($menu->status === 'active'): ?> selected <?php endif; ?>>Active</option>
                                    <option value="inactive" <?php if($menu->status === 'inactive'): ?> selected <?php endif; ?>>Inactive</option>
                                </select>
                            </div>
                        </div>

                    </div>



                    <div class="m-t-20 text-center mb-5">
                        <button type="submit" class="btn btn-primary btn-lg">Update Menu</button>
                    </div>
                </form>

                            </div>
                        </div>
                    </div>
                </div>









<div id="check_brand_<?php echo e($menu->id); ?>" class="modal custom-modal fade" role="dialog" style="background: white !important;">
    <div class="modal-dialog">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="modal-content modal-lg">
            <div class="modal-header">
                <h4 class="modal-title"><?php echo e($menu->category_title_en); ?> Brand<hr></h4>
            </div>
            <div class="modal-body">
                
                <div class="row">
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(get_category_brand($menu->id)->contains('brand_id', $brand->id)): ?>  
                        <div class="col-sm-2">
                            <img src="<?php echo e(url(env('img_path'). $brand->brand_logo)); ?>" alt="brand" class="img-fluid" width="200" height="200">
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($menus->links()); ?>

            </div>
            <?php else: ?>
            <p class="p-4"><?php echo e('Menu Not Found!'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>







<div id="add_menus" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="modal-content modal-lg">
            <div class="modal-header">
                <h4 class="modal-title">Add Menu</h4>
            </div>
            <div class="modal-body">
                <form class="m-b-30" action="<?php echo e(route('menu.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">

                        <div class="col-sm-12">
                        <div class="form-group form-focus select-focus">
                        <label class="focus-label">Gender</label>
                        <select class="select floating" name="gender_id">
                            <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($gender->id); ?>">
                                    <?=$gender->gender_en?><br>
                                    <?=$gender->gender_ar?><br>
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Name (en)<span class="text-danger">*</span></label>
                                <input type="text" name="category_title_en" class="form-control">
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Translation <span class="text-danger">*</span></label>
                                <input type="text" name="category_title_ar" class="form-control" required>
                            </div>
                        </div>

                    <div class="col-sm-12">
                        <div class="form-group form-focus select-focus">
                            <select class="select floating" name="brands[]" multiple="multiple" data-placeholder="Choose Brand">
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($brand->id); ?>">
                                    <?=$brand->brand_title_en?><br>
                                    <?=$brand->brand_title_ar?><br>
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
             

                        <div class="col-sm-12">
                        <div class="form-group form-focus select-focus">
                                <label class="focus-label">Status</label>
                                <select class="select floating" name="status">
                                <option value="active">Active</option>
                                <option value="inactive">InActive</option>
                            </select>
                        </div>
                        </div>

                    </div>
                    <div class="m-t-20 text-center mb-5">
                        <button type="submit" class="btn btn-primary btn-lg">Create Menu</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/menus/menu.blade.php ENDPATH**/ ?>