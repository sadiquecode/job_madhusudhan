<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-3">
                    <h4 class="page-title">All Features List</h4>
                </div>
            </div>
            <div class="row filter-row">
                <div class="col-sm-12 col-md-8">
                    <form id="languageForm" method="GET" action="<?php echo e(url('web_features_list')); ?>">
                    <div class="form-group form-focus select-focus">
                        <label class="focus-label">Language</label>
                        <select class="select floating" id="languageSelect" name="lang_code">
                        
                            <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($lang->code); ?>"><?php echo e($lang->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    </form>
                </div>
                <div class="col-sm-12 col-md-4">
                    <a href="#" class="btn btn-success btn-block" data-toggle="modal" data-target="#add_feature"> Add Feature List</a>
                </div>
            </div>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <div class="row">
                <?php if(count($webFeatures) > 0): ?>
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped custom-table datatable">
                            <thead>
                                <tr>
                                    <th>S/L</th>
                                    <th>Heading</th>
                                    <th>Details</th>
                                    <th>Image</th>
                                    <th>Image Direction</th>
                                    <th>Lang</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $webFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($index + 1); ?></td>
                                    <td><?php echo e($feature->heading); ?></td>
                                    <td><?php echo e($feature->details); ?></td>
                                    <td><img src="<?php echo e(url(env('img_path') . $feature->image)); ?>" width="50" height="50"></td>
                                    <td><?php echo e($feature->image_direction); ?></td>
                                    <td><?php echo e($feature->lang_code); ?></td>
                                    <td class="text-right">
                                        <div class="dropdown dropdown-action">
                                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_feature_<?php echo e($feature->id); ?>"><i class="fas fa-pen m-r-5"></i> Edit</a>
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_feature_<?php echo e($feature->id); ?>"><i class="far fa-trash-alt m-r-5"></i> Delete</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <div id="delete_feature_<?php echo e($feature->id); ?>" class="modal custom-modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content modal-md">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Delete Client</h4>
                                            </div>
                                            <form action="<?php echo e(route('web_features_list.destroy', $feature->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <div class="modal-body card-box">
                                                    <p>Are you sure want to delete this?</p>
                                                    <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                <div id="edit_feature_<?php echo e($feature->id); ?>" class="modal custom-modal fade" role="dialog">
                    <div class="modal-dialog">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <div class="modal-content modal-lg">
                            <div class="modal-header">
                                <h4 class="modal-title">Edit Feature</h4>
                            </div>
                            <div class="modal-body">
                                
                <form class="m-b-30" action="<?php echo e(route('web_features_list.update', $feature->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Language <span class="text-danger">*</span></label>
                                <input type="text" name="lang_code" class="form-control" value="<?php echo e($feature->lang_code); ?>" readonly>
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Heading <span class="text-danger">*</span></label>
                                <input type="text" name="heading" class="form-control" value="<?php echo e($feature->heading); ?>" required>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Details <span class="text-danger">*</span></label>
                                <textarea class="form-control" rows="5" name="details" value="<?php echo e($feature->details); ?>"><?php echo e($feature->details); ?></textarea>
                            </div>
                        </div>

<div class="col-sm-12">
    <div class="form-group">
        <label class="col-form-label">Old Image <span class="text-danger">*</span></label>
        <?php if($feature->image): ?>
            <img src="<?php echo e(url(env('img_path') . $feature->image)); ?>" alt="Old Image" width="100">
        <?php else: ?>
            <p>No old image available</p>
        <?php endif; ?>
    </div>
</div>

<div class="col-sm-12">
    <div class="form-group">
        <label class="col-form-label">New Image <span class="text-danger">*</span></label>
        <input type="file" name="image" class="form-control">
        <small class="text-muted">Leave empty to keep the old image.</small>
    </div>
</div>






                    <div class="col-sm-12">
                        <div class="form-group form-focus select-focus">
                            <label class="focus-label">Image Direction</label>
                            <select class="select floating" name="image_direction">
                                <option>Add Direction</option>
                                <option value="rtl" <?php echo e($feature->image_direction === 'rtl' ? 'selected' : ''); ?>>RTL</option>
                                <option value="ltr" <?php echo e($feature->image_direction === 'ltr' ? 'selected' : ''); ?>>LTR</option>
                            </select>
                        </div>
                    </div>

                    </div>
                    <div class="m-t-20 text-center mb-5">
                        <button type="submit" class="btn btn-primary btn-lg">Update Features List</button>
                    </div>
                </form>

                            </div>
                        </div>
                    </div>
                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($webFeatures->links()); ?>

            </div>
            <?php else: ?>
            <p class="p-4"><?php echo e('Features List Not Found!'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>







<div id="add_feature" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="modal-content modal-lg">
            <div class="modal-header">
                <h4 class="modal-title">Add Features List</h4>
            </div>
            <div class="modal-body">
                <form class="m-b-30" action="<?php echo e(route('web_features_list.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Language <span class="text-danger">*</span></label>
                                <input type="text" name="lang_code" class="form-control" value="<?php echo e($code); ?>" readonly>
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Heading <span class="text-danger">*</span></label>
                                <input type="text" name="heading" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Details <span class="text-danger">*</span></label>
                                <textarea class="form-control" rows="5" name="details"></textarea>
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="form-group">
                                <label class="col-form-label">Image <span class="text-danger">*</span></label>
                                <input type="file" name="image" class="form-control" required>
                            </div>
                        </div>

                        <div class="col-sm-12">
                        <div class="form-group form-focus select-focus">
                                <label class="focus-label">Image Direction</label>
                                <select class="select floating" name="image_direction">
                                <option>Add Direction</option>
                                <option value="rtl">RTL</option>
                                <option value="ltr">LTR</option>
                            </select>
                        </div>
                        </div>
                    </div>
                    <div class="m-t-20 text-center mb-5">
                        <button type="submit" class="btn btn-primary btn-lg">Create Features List</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/web/features_list.blade.php ENDPATH**/ ?>