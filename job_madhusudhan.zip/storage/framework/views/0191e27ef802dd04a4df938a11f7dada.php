<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-4">
                    <h4 class="page-title">Popular Templates</h4>
                </div>
            </div>
            
            
            <div id="alert-container" class="mt-3" style="display: none;"></div>
            <div class="card-box">
                <div class="row filter-row">
                    <div class="col-sm-12 col-md-8 mx-auto my-5">
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" id="ai_temp_search" placeholder="Search your favorite template..." aria-label="Recipient's username" aria-describedby="button-addon2" style="border-radius: 25px 25px 25px 25px; height: 50px;" >
                            
                        </div>
                        <div style="display: none;" class="no_data_found text-center mt-5">Data not found</div>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $popularTemplates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-sm-6 col-md-4 col-xl-3" id="aitemp_data">
                        <div class="card-box project-box">
                            
                            
                            <div class="text-center bg-primary rounded-circle text-white justify-content-center align-items-center d-flex mb-2" style="border-radius:50px_; height: 50px; width: 50px;">
                                <i class="<?php echo e($popular->icon); ?> fa-2x text-center"></i>
                            </div>
                            <h4 class="project-title">
                            <a href="<?php echo e(route('ai-templates.ai_content', ['slug' => $popular->slug])); ?>"><?php echo e($popular->template); ?></a>
                            </h4>
                            <small class="block_ text-ellipsis m-b-15 d-none">
                            <span class="text-xs">1</span> <span class="text-muted">open tasks, </span>
                            <span class="text-xs">9</span> <span class="text-muted">tasks completed</span>
                            </small>
                            <p class="text-muted"><?php echo e($popular->description); ?>

                            </p>
                            <div class="d-flex align-items-center">
                                <div class="pro-deadline m-b-15_">
                                    <div class="sub-title">
                                        <?php echo e($popular->words_generated); ?>  Words Generated
                                    </div>
                                </div>
                                <div class="ml-auto">
                                    <div class="pro-deadline m-b-15_">
                                        <a href="javascript:void(0);" onclick="toggleFavorite(<?php echo e($popular->id); ?>)">
                                            <i class="fa fa-heart temp_<?php echo e($popular->id); ?> <?php echo e(isTemplateFavorite($popular->id) ? 'text-danger' : 'text-secondary'); ?>"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/template/popular_and_favorite.blade.php ENDPATH**/ ?>