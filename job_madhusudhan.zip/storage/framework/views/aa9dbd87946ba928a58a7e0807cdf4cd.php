<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">
<div class="content container-fluid">
<div class="row">
<div class="col-sm-4 col-3">
    <h4 class="page-title">All AI Bot</h4>
</div>
<?php if (Auth::user()->type == 'admin') { ?>
<div class="col-sm-8 col-9 text-right m-b-20">
    <a href="#" class="btn btn-primary btn-rounded float-right" data-toggle="modal" data-target="#add_ai_bot"><i class="fa fa-plus"></i> Add AI Bot</a>
    <div class="view-icons d-none">
        <a href="clients.html" class="grid-view btn btn-link active"><i class="fa fa-th"></i></a>
        <a href="clients-list.html" class="list-view btn btn-link"><i class="fa fa-bars"></i></a>
    </div>
</div>
<?php } ?>
</div>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
<strong>Whoops!</strong> There were some problems with your input.<br><br>
<ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
<p><?php echo e($message); ?></p>
</div>
<?php endif; ?>

<form method="GET" action="<?php echo e(url('chat-bots/ai-chat-bots')); ?>">
    <div class="row filter-row">
        <div class="col-sm-6 col-md-9">
            <div class="form-group form-focus">
                <label class="focus-label">Search By Bot Name or Role</label>
                <input type="text" class="form-control floating" name="search">
            </div>
        </div>
        <div class="col-sm-6 col-md-3">
            <button class="btn btn-success btn-block"> Search </button>
        </div>
    </div>
</form>

<div class="row staff-grid-row">
<?php $__currentLoopData = $aiChatBots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aiChatBot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
    <div class="profile-widget">
        <div class="profile-img">
            <?php if(empty($aiChatBot->profile_pic)): ?>
            <a href="" class="avatar"><?php echo e(substr($aiChatBot->name, 0, 1)); ?></a>
            <?php else: ?>
            <a href="" class="avatar"><img src="<?php echo e(url(env('img_path') . $aiChatBot->profile_pic)); ?>"></a>
            <?php endif; ?>
        </div>

        <?php if (Auth::user()->type == 'admin') { ?>
        <div class="dropdown profile-action">
            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
            <div class="dropdown-menu dropdown-menu-right">
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_ai_bot_<?php echo e($aiChatBot->id); ?>"><i class="fas fa-pen m-r-5"></i> Edit</a>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_ai_bot_<?php echo e($aiChatBot->id); ?>"><i class="far fa-trash-alt m-r-5"></i> Delete</a>
            </div>
        </div>
        <?php } ?>

        
        <h5 class="user-name m-t-10 m-b-0 text-ellipsis"><a href=""><?php echo e($aiChatBot->name); ?></a></h5>
        <div class="small text-muted"><?php echo e($aiChatBot->role); ?></div>
        <p><?php echo e(Str::limit($aiChatBot->welcome_msg, 60)); ?></p>
        <?php if (Auth::user()->type != 'admin') { ?>
        <a href="<?php echo e(route('chatbot.conversations.show', $aiChatBot->id)); ?>" class="btn btn-white btn-sm m-t-10">Message</a>
        <?php } ?>
        
    </div>
</div>

<div id="edit_ai_bot_<?php echo e($aiChatBot->id); ?>" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="modal-content modal-lg">
            <div class="modal-header">
                <h4 class="modal-title">Edit AI Bot</h4>
            </div>
            <div class="modal-body">
                <div class="m-b-30">
                    <form action="<?php echo e(route('ai_chat_bots.update', ['aiChatBot' => $aiChatBot->id])); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="profile-img-wrap">
                                    <?php if(empty($aiChatBot->profile_pic)): ?>
                                    <img class="inline-block" src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="user">
                                    <?php else: ?>
                                    <img class="inline-block" src="<?php echo e(url(env('img_path') . $aiChatBot->profile_pic)); ?>" alt="user">
                                    <?php endif; ?>
                                    <div class="fileupload btn">
                                        <span class="btn-text">Pic</span>
                                        <input class="upload" type="file" name="profile_pic">
                                    </div>
                                </div>
                                <div class="profile-basic">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group form-focus">
                                                <label class="focus-label">Name</label>
                                                <input type="text" class="form-control floating" name="name" value="<?php echo e($aiChatBot->name); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group form-focus">
                                                <label class="focus-label">Role</label>
                                                <input type="text" class="form-control floating" name="role" value="<?php echo e($aiChatBot->role); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group form-focus select-focus">
                                                <label class="focus-label">Category</label>
                                                <select class="select form-control floating" name="bote_category_id">
                                                    <?php $__currentLoopData = $BoteCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>" <?php echo e($category->id === $aiChatBot->bote_category_id ? 'selected' : ''); ?>>
                                                        <?php echo e($category->title); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label>Welcome Message</label>
                                    <textarea rows="4" cols="5" class="form-control summernote_" placeholder="Enter Welcome Message here" name="welcome_msg"><?php echo e($aiChatBot->welcome_msg); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label>Prompt</label>
                                    <textarea rows="4" cols="5" class="form-control summernote_" placeholder="Enter your prompt here" name="prompt"><?php echo e($aiChatBot->prompt); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="display-block">Status</label>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status" id="temp_cat_enable" value="enable" <?php echo e($aiChatBot->status === 'enable' ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="temp_cat_enable">
                                            enable
                                        </label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status" id="temp_cat_disable" value="disable" <?php echo e($aiChatBot->status === 'disable' ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="temp_cat_disable">
                                            disable
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="m-t-20 text-center">
                            <button class="btn btn-primary btn-lg">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="delete_ai_bot_<?php echo e($aiChatBot->id); ?>" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content modal-md">
            <div class="modal-header">
                <h4 class="modal-title">Delete AI Bot</h4>
            </div>
            <div class="modal-body card-box">
                <p>Are you sure you want to delete this AI Bot?</p>
                <div class="m-t-20">
                    <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                    <form action="<?php echo e(route('ai_chat_bots.destroy', ['aiChatBot' => $aiChatBot->id])); ?>" method="POST" style="display:inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php echo e($aiChatBots->links()); ?>

</div>
</div>

<div id="add_ai_bot" class="modal custom-modal fade" role="dialog">
<div class="modal-dialog">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-content modal-lg">
<div class="modal-header">
    <h4 class="modal-title">Add AI Bot</h4>
</div>
<div class="modal-body">
    <div class="m-b-30">
        <form action="<?php echo e(route('ai_chat_bots.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="profile-img-wrap">
                        <img class="inline-block" src="<?php echo e(url('public/assets/img/user.jpg')); ?>" alt="user">
                        <div class="fileupload btn">
                            <span class="btn-text">Pic</span>
                            <input class="upload" type="file" name="profile_pic">
                        </div>
                    </div>
                    <div class="profile-basic">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group form-focus">
                                    <label class="focus-label">Name</label>
                                    <input type="text" class="form-control floating" name="name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group form-focus">
                                    <label class="focus-label">Role</label>
                                    <input type="text" class="form-control floating" name="role">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group form-focus select-focus">
                                    <label class="focus-label">Category</label>
                                    <select class="select form-control floating" name="bote_category_id">
                                        <?php $__currentLoopData = $BoteCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($b_category->id); ?>"><?php echo e($b_category->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label>Welcome Message</label>
                        <textarea rows="4" cols="5" class="form-control summernote_" placeholder="Enter Welcome Message here" name="welcome_msg"></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label>Prompt</label>
                        <textarea rows="4" cols="5" class="form-control summernote_" placeholder="Enter your prompt here" name="prompt"></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label class="display-block">Status</label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="status" id="temp_cat_enable" value="enable" checked>
                            <label class="form-check-label" for="temp_cat_enable">
                                enable
                            </label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="status" id="temp_cat_disable" value="disable">
                            <label class="form-check-label" for="temp_cat_disable">
                                disable
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="m-t-20 text-center">
                <button class="btn btn-primary btn-lg">Create AI Bot</button>
            </div>
        </form>
    </div>
</div>
</div>
</div>
</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/chatbote/index.blade.php ENDPATH**/ ?>