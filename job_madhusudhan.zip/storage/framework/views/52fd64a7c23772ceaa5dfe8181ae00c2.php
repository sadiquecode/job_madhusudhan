<div class="col-sm-8 col-md-8 col-lg-8 col-xl-9">
	<h6 class="card-title m-b-20">Signin Page</h6>
	<form class="m-b-30" action="<?php echo e(route('webpage.update', $webpage->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
		<div class="card-box">
			<div class="row">
				
				<div class="col-md-12">
					<h4 class="card-title">Signin Section</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Heading:</label>
								<input type="text" class="form-control" name="signin_heading" value="<?php echo e($webpage->signin_heading); ?>">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label>Email:</label>
								<input type="text" class="form-control" name="signin_email" value="<?php echo e($webpage->signin_email); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Password:</label>
								<input type="text" class="form-control" name="signin_password" value="<?php echo e($webpage->signin_password); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Submit Button:</label>
								<input type="text" class="form-control" name="signin_button" value="<?php echo e($webpage->signin_button); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>OR:</label>
								<input type="text" class="form-control" name="signin_or" value="<?php echo e($webpage->signin_or); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Google Login:</label>
								<input type="text" class="form-control" name="signin_google" value="<?php echo e($webpage->signin_google); ?>">
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>Facebook Login:</label>
								<input type="text" class="form-control" name="signin_fb" value="<?php echo e($webpage->signin_fb); ?>">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="text-right">
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
		</div>
	</form>
</div><?php /**PATH G:\server\htdocs\advance_ai\resources\views/web/forms/signin_page.blade.php ENDPATH**/ ?>