<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div class="sidebar-menu">
            <ul>
                <li>
                    <a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-home back-icon"></i> Back to Home</a>
                </li>
                <li class="menu-title">Settings</li>
                <li class="<?php if($url == 'general-settings'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                    <a href="<?php echo e(url('dashboard/settings/general-settings')); ?>">General</a>
                </li>
                <li class="<?php if($url == 'auth'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                    <a href="<?php echo e(url('dashboard/settings/auth')); ?>">Auth Settings</a>
                </li>
                <li class="<?php if($url == 'smtp'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                    <a href="<?php echo e(url('dashboard/settings/smtp')); ?>">SMTP</a>
                </li>
                <li class="<?php if($url == 'offline-payment'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                    <a href="<?php echo e(url('dashboard/settings/offline-payment')); ?>">Offline Payment</a>
                </li>
                <li class="<?php if($url == 'payment-methods'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                    <a href="<?php echo e(url('dashboard/settings/payment-methods')); ?>">Payment Methods</a>
                </li>
                <li class="<?php if($url == 'social-media-login'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                    <a href="<?php echo e(url('dashboard/settings/social-media-login')); ?>">Social Login</a>
                </li>
                <li class="<?php if($url == 'purchase-code'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                    <a href="<?php echo e(url('dashboard/settings/purchase-code')); ?>">Purchase Code</a>
                </li>
            </ul>
        </div>
    </div>
</div><?php /**PATH G:\server\htdocs\advance_ai\resources\views/layouts/setting_sidebar.blade.php ENDPATH**/ ?>