<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jeddah Mazad Website</title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(url('public/theme_assets/images/logo/OG Logo.png')); ?>" type="image/svgicon">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(url('public/theme_assets/bootstrap/bootstrap.min.css')); ?>">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(url('public/theme_assets/css/style.css')); ?>">
    <!-- fontawesome kit  -->
    <script src="<?php echo e(url('public/theme_assets/js/kit-fontawesome.js')); ?>"></script>
</head>

<body>
    <section>
        <div class="text-center py-3 smallscrnav_none">
            <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('public/theme_assets/images/logo/Logojeddah_11zon.png')); ?>" style="width: 185px;" alt="logo"></a>
        </div>
        <div>
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => ['class' => 'mb-4 text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4 text-center']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <?php if(session('status')): ?>
            <div class="mb-4 font-medium text-sm text-green-600 text-center">
                <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('register')); ?>" class="mb-5 <?php echo e(session('ar_class')); ?>">
                <?php echo csrf_field(); ?>
                <div class="container">
                    <div class="mt-5 col-md-5 mx-auto">
                        <div class="content">
                            <div class="text-center">
                                <h2><?php echo e(__('trans.Create an account')); ?></h2>
                                <p><?php echo e(__('trans.account line')); ?></p>
                            </div>
                            <div class="form-floating mb-3">
                                <input class="form-control shadow-none" type="email" name="email" :value="old('email')" required autofocus autocomplete="email" placeholder="email@domain.com">
                                <label for="email"><?php echo e(__('trans.email address')); ?></label>
                            </div>

                        <div class="form-floating mb-3 position-relative password_eye">
                            <input class="form-control" type="password" name="password" :value="old('password')" required autofocus autocomplete="password" placeholder="password" id="password1">
                            <i class="fas fa-eye position-absolute togglePassword" data-target="password1"></i>
                            <label for="password1"><?php echo e(__('trans.password')); ?></label>
                        </div>

                        <div class="form-floating mb-3 position-relative password_eye">
                            <input class="form-control shadow-none" type="password" name="password_confirmation" :value="old('password_confirmation')" required autofocus autocomplete="password_confirmation" placeholder="Confirm password" id="password2">
                            <i class="fas fa-eye position-absolute togglePassword" data-target="password2"></i>
                            <label for="password2"><?php echo e(__('trans.Confirm Password')); ?></label>
                        </div>

                            <div class="">
                                <p><?php echo e(__('trans.enter your legal name')); ?></p>
                            </div>
                            <div class="row g-3">
                                <div class="col-4">
                                    <div class="form-floating mb-3">
                                        <input type="title" class="form-control shadow-none" id="title"
                                            placeholder="Mr/Ms" name="title" required="">
                                        <label for="title"><?php echo e(__('trans.Title')); ?></label>
                                    </div>
                                </div>

                                <div class="col-8">
                                    <div class="form-floating mb-3">
                                        <input class="form-control shadow-none" type="text" name="name" :value="old('name')" required autofocus autocomplete="name" placeholder="fName">
                                        <label for="firstname"><?php echo e(__('trans.fname')); ?></label>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-floating mb-3">
                                        <input class="form-control shadow-none" type="text" name="lname" :value="old('name')" required autofocus autocomplete="name" placeholder="lName">
                                        <label for="lastname"><?php echo e(__('trans.lname')); ?></label>
                                    </div>
                                </div>
                            </div>
                            <div class="justify-content-between align-items-center d-flex d-none">
                                <div class="d-flex align-items-start">
                                    <div class="policieschecks">
                                        <input type="checkbox" class="form-check-input shadow-none mt-0 me-2"
                                            id="emailupdates">
                                    </div>
                                    <div class="flex-column d-flex">
                                        <p>I would like to receive email updates from Jeddah Mazad about upcoming
                                            auctions,
                                            events, and more
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="justify-content-between align-items-center d-flex">
                                <div class="d-flex align-items-start">
                                    <div class="policieschecks">
                                        <input type="checkbox" class="form-check-input shadow-none mt-0 me-2"
                                            id="policiescheck" name="policiescheck" value="0">
                                    </div>
                                    <div class="flex-column d-flex">
                                    <p><?php echo e(__('trans.I have read and agree to the')); ?> <a href="#" data-bs-toggle="modal" data-bs-target="#privacy"
                                            rel="noopener noreferrer"><?php echo e(__('trans.privacy policy')); ?></a> <?php echo e(__('trans.&')); ?>

                                        jeddahmazad.com <a href="#" data-bs-toggle="modal" data-bs-target="#Terms" rel="noopener noreferrer"><?php echo e(__('trans.Terms & conditions')); ?></a>
                                    </p>
                                </div>
                                </div>
                            </div>
                            <div class="btn-box pt-0 pb-2">
                                <div class="login_button">
                                    <button id="submitBTN" type="submit" class="btn w-100 shadow-none"><?php echo e(__('trans.SignUp')); ?></button>
                                </div>
                                <div class="mt-3 row text-center">
                                    <div class="col-12 text-center">
                                        <p>
                                            <?php echo e(__('trans.already account')); ?>

                                            <a href="<?php echo e(url('login')); ?>" target="_blank" rel="noopener noreferrer"> <?php echo e(__('trans.Login')); ?>

                                            </a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
    <!-- ===============Contact Us Start=============-->
    <?php echo $__env->make('theme_1.layouts.contact_us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ============Contact Us End==========-->
    <div class="footer_top_line">
        <hr>
    </div>
    <section class="footer_block">
        <div class="footer_block_btn">
            <ul>
                <li class="list-unstyled mb-3"><a href="#" target="_blank" rel="noopener noreferrer">CONTACT US</a></li>
                <li class="list-unstyled mb-3"><a href="#" target="_blank" rel="noopener noreferrer">TERMS &
                        CONDITIONS</a>
                </li>
                <li class="list-unstyled mb-3"><a href="#" target="_blank" rel="noopener noreferrer">PRIVACY POLICY</a>
                </li>
            </ul>
            <p>© 2023 <a href="#"><b>Jeddah Mazad.</b></a> All Rights Reserved</p>
        </div>
    </section>
    <?php echo $__env->make('theme_1.layouts.terms_policy_popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- jQuery link  -->
    <script type="text/javascript" src="<?php echo e(url('public/theme_assets/jquery/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/theme_assets/js/main.js')); ?>"></script>
    <!-- Bootstrap JS -->
    <script src="<?php echo e(url('public/theme_assets/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Custom JS -->
</body>


</html><?php /**PATH G:\server\htdocs\jeddah_mazad\resources\views/auth/webregister.blade.php ENDPATH**/ ?>