<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="page-wrapper">
            <div class="content container-fluid">
                <div class="row">
                    <div class="col-sm-12 col-12">
                        <h4 class="page-title">Version Upgrade</h4>
                    </div>
                    <div class="col-sm-4 col-8 text-right m-b-30 d-none">
                        <a href="#" class="btn btn-primary btn-rounded float-right" data-toggle="modal" data-target="#add_ticket"><i class="fa fa-plus"></i> Add New Ticket</a>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="card-box">
                             <p>Zip Module: <button class="btn-sm btn-rounded btn btn-success">OK</button></p>
                             <p><b>CURRENT VERSION: 3.8</b></p>
                             <p>No update is available</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/settings/global_update.blade.php ENDPATH**/ ?>