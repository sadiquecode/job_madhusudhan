    <section class="banner_bg">
        <div class="container">
            <div class="text-center py-5">
                <div class="banner_heading mx-auto">
                    <p class="writeone"><?php echo e($home_page->head_line); ?></p>
                    <h1><?php echo e($home_page->main_heading); ?></h1>
                    <p class="writetwo"><?php echo e($home_page->sub_heading); ?></p>
                    <div class="mb-5">
                        <a href="#" class="btn btn-warning rounded-0 btn-lg mt-4 py-3 px-4 font-weight-bold"><?php echo e($home_page->main_button); ?></a>
                    </div>
                </div>
                
                <?php echo $__env->make('theme_1.layouts.company_logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </section><?php /**PATH G:\server\htdocs\advance_ai\resources\views/theme_1/layouts/header.blade.php ENDPATH**/ ?>