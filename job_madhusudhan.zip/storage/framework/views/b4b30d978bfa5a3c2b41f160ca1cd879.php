<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if (Auth::user()->type == 'admin') { ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-sm-4 col-3">
                    <h4 class="page-title">AI Images</h4>
                </div>
            </div>
            
            <form method="GET" action="<?php echo e(url('images/ai-images')); ?>">
            <div class="row filter-row">
                <div class="col-sm-12 col-md-4">
                    <div class="form-group form-focus">
                        <label class="focus-label">Project Name</label>
                        <input type="text" class="form-control floating" name="name">
                    </div>
                </div>
                <div class="col-sm-12 col-md-4">
                    <div class="form-group form-focus">
                        <label class="focus-label">Prompt</label>
                        <input type="text" class="form-control floating" name="prompt">
                    </div>
                </div>
                <div class="col-sm-12 col-md-4">
                    <button class="btn btn-success btn-block"> Search </button>
                </div>
            </div>
            </form>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <div class="row">
                <?php if(count($all_images) > 0): ?>
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped custom-table datatable">
                            <thead>
                                <tr>
                                    <th>S/L</th>
                                    <th>Image</th>
                                    <th>Resolution</th>
                                    <th>User</th>
                                    <th>Created Date</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $all_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>#<?php echo e($index + 1); ?></td>
                                    
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <a href="<?php echo e($doc->content); ?>" target="_blank" data-tippy-placement="top" data-tippy="" data-original-title="View" class="">
                                                <img src="<?php echo e($doc->content); ?>" alt="<?php echo e($doc->project_name); ?>" width="60">
                                            </a>
                                            <div class="ml-3">
                                                <div><strong><?php echo e($doc->project_name); ?></strong></div>
                                                <small><?php echo e($doc->prompt); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo e($doc->words_size); ?></td>
                                    <td><?php echo e(get_user($doc->user_id)->name); ?></td>
                                    <td><?php echo e($doc->created_date); ?></td>
                                    <td class="text-right">
                                        <div class="dropdown dropdown-action">
                                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <?php if($doc->type === 'Image'): ?>
                                                <a class="dropdown-item" href="<?php echo e($doc->content); ?>" download><i class="fas fa-download m-r-5"></i> Download</a>
                                                <?php else: ?>
                                                <a class="dropdown-item" href="<?php echo e(route('documents.edit', $doc->id)); ?>"><i class="fas fa-pen m-r-5"></i> Edit</a>
                                                <?php endif; ?>
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_documnet_<?php echo e($doc->id); ?>"><i class="far fa-trash-alt m-r-5"></i> Delete</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <div id="delete_documnet_<?php echo e($doc->id); ?>" class="modal custom-modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content modal-md">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Delete Client</h4>
                                            </div>
                                            <form action="<?php echo e(route('documents.destroy', $doc->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <div class="modal-body card-box">
                                                    <p>Are you sure want to delete this?</p>
                                                    <div class="m-t-20"> <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                        </tbody>
                    </table>
                </div>
                <?php echo e($all_images->links()); ?>

            </div>
            <?php else: ?>
            <p class="p-4"><?php echo e('Folder Not Found!'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php }else{ ?>
<style type="text/css">

.img_loader {
/* Set the loader to cover the entire screen */
position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
background-color: rgba(255, 255, 255, 0.7); /* Semi-transparent background */
display: flex;
justify-content: center;
align-items: center;
z-index: 9999; /* Ensure it appears above other elements */
}
.img_loader p {
/* Style the loader text */
font-size: 18px;
font-weight: bold;
text-align: center; /* Center the text horizontally */
position: absolute; /* Position the text inside the loader */
top: 50%; /* Move the text to the vertical center */
left: 50%; /* Move the text to the horizontal center */
transform: translate(-50%, -50%);
}
</style>
<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="row">
            <div class="col-sm-12 col-12">
                <h4 class="page-title">AI Images</h4>
            </div>
        </div>
        <div id="img_loader" class="img_loader" style="display: none;">
            <p>Please wait...</p>
        </div>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        
        <div id="alert-container" class="mt-3" style="display: none;"></div>
        
        <div class="row">
            <div class="col-md-12 ">
                <div class="card-box">
<form action="<?php echo e(route('ai_image_generate')); ?>" method="POST" onsubmit="showLoader()">
    <?php echo csrf_field(); ?>
    <div class="row filter-row">
        <div class="col-sm-12 col-md-8 mx-auto my-5">
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Type your image title or description that you are looking for" aria-label="Recipient's username" aria-describedby="button-addon2" style="border-radius: 25px 0 0 25px; height: 50px;" name="img_prompt">
                <div class="input-group-append ">
                    <button class="btn btn-success" style="border-radius: 0 25px 25px 0;" type="submit" id="button-addon2">Generate Image</button>
                </div>
            </div>
        </div>
    </div>
    <button class="btn-sm btn btn-outline-success mb-2" type="button" data-toggle="collapse" data-target="#formCollapse" aria-expanded="false" aria-controls="formCollapse">
    Advance Search
    </button>
    <div class="collapse" id="formCollapse">
        <div class="row">
            <div class="col-md-12">
                <div class="card-box">
                    <div class="row">
                        <div class="col-md-12">
                            <h4 class="card-title">Advance Setting</h4>
                            <div class="form-group row">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 mt-2">
                                            <label>Image Title</label>
                                            <input type="text" placeholder="Image Title" class="form-control" name="title">
                                        </div>
                                        <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 mt-2">
                                            <label>Art style</label>
                                            <select class="select" name="art_style">
                                                <option selected value="None">None</option>
                                                <option value="Pixel">Pixel</option>
                                                <option value="Sticker">Sticker</option>
                                                <option value="Realistic">Realistic</option>
                                                <option value="Isometric">Isometric</option>
                                                <option value="Cyberpunk">Cyberpunk</option>
                                                <option value="Line art">Line art</option>
                                                <option value="Pencil drawing">Pencil drawing</option>
                                                <option value="Ballpoint pen drawing">Ballpoint pen drawing</option>
                                                <option value="Watercolor">Watercolor</option>
                                                <option value="Origami">Origami</option>
                                                <option value="Cartoon">Cartoon</option>
                                                <option value="Retro">Retro</option>
                                                <option value="Anime">Anime</option>
                                                <option value="Renaissance">Renaissance</option>
                                                <option value="Clay">Clay</option>
                                                <option value="Vaporwave">Vaporwave</option>
                                                <option value="Steampunk">Steampunk</option>
                                                <option value="Glitchcore">Glitchcore</option>
                                                <option value="Bauhaus">Bauhaus</option>
                                                <option value="Vector">Vector</option>
                                                <option value="Low poly">Low poly</option>
                                                <option value="Ukiyo-e">Ukiyo-e</option>
                                                <option value="Cubism">Cubism</option>
                                                <option value="Modern">Modern</option>
                                                <option value="Pop">Pop</option>
                                                <option value="Contemporary">Contemporary</option>
                                                <option value="Impressionism">Impressionism</option>
                                                <option value="Pointillism">Pointillism</option>
                                                <option value="Minimalism">Minimalism</option>
                                            </select>
                                        </div>
                                        <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 mt-2">
                                            <label>Lighting style</label>
                                            <select class="select" name="lighting_style">
                                                <option selected value="None">None</option>
                                                <option value="Warm">Warm</option>
                                                <option value="Cold">Cold</option>
                                                <option value="Golden Hour">Golden Hour</option>
                                                <option value="Blue Hour">Blue Hour</option>
                                                <option value="Ambient">Ambient</option>
                                                <option value="Studio">Studio</option>
                                                <option value="Neon">Neon</option>
                                                <option value="Dramatic">Dramatic</option>
                                                <option value="Cinematic">Cinematic</option>
                                                <option value="Natural">Natural</option>
                                                <option value="Foggy">Foggy</option>
                                                <option value="Backlight">Backlight</option>
                                                <option value="Hard">Hard</option>
                                            </select>
                                        </div>
                                        <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 mt-2">
                                            <label>Mood</label>
                                            <select class="select" name="mood">
                                                <option selected value="None">None</option>
                                                <option value="Aggressive">Aggressive</option>
                                                <option value="Angry">Angry</option>
                                                <option value="Boring">Boring</option>
                                                <option value="Bright">Bright</option>
                                                <option value="Calm">Calm</option>
                                                <option value="Cheerful">Cheerful</option>
                                                <option value="Chilling">Chilling</option>
                                                <option value="Colorful">Colorful</option>
                                                <option value="Dark">Dark</option>
                                                <option value="Neutral">Neutral</option>
                                            </select>
                                        </div>
                                        
                                        <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 mt-2">
                                            <label>Image Resolution</label>
                                            <select class="select" name="img_resolution">
                                                <option value="256" selected>256x256</option>
                                                <option value="512">512x512</option>
                                                <option value="1024">1024x1024</option>
                                            </select>
                                        </div>
                                        
                                        <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 mt-2">
                                            <label>Number of Images</label>
                                            <select class="select" name="number_of_images">
                                                <option value="1" selected>1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
                    <div id="lightgallery" class="row">
                        <?php $__currentLoopData = $all_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 m-b-20">
                            <a href="<?php echo e($img->content); ?>">
                                <img class="img-thumbnail" src="<?php echo e($img->content); ?>" alt="<?php echo e($img->prompt); ?>">
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                    <?php echo e($all_images->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/sic/ai_image.blade.php ENDPATH**/ ?>