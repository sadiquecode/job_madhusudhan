<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.setting_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">
<div class="content container-fluid">
<div class="row">
<div class="col-sm-4 col-3">
    <h4 class="page-title">Offline Payment Method</h4>
</div>
<div class="col-sm-8 col-9 text-right m-b-20">
    <a href="#" class="btn btn-primary btn-rounded float-right" data-toggle="modal" data-target="#add_offline_payment"><i class="fa fa-plus"></i> Add New</a>
    <div class="view-icons d-none">
        <a href="clients.html" class="grid-view btn btn-link active"><i class="fa fa-th"></i></a>
        <a href="clients-list.html" class="list-view btn btn-link"><i class="fa fa-bars"></i></a>
    </div>
</div>
</div>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
<strong>Whoops!</strong> There were some problems with your input.<br><br>
<ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
<p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<div class="row filter-row d-none">
<div class="col-sm-6 col-md-9">
    <div class="form-group form-focus">
        <label class="focus-label">Client Name</label>
        <input type="text" class="form-control floating">
    </div>
</div>
<div class="col-sm-6 col-md-3">
    <a href="#" class="btn btn-success btn-block"> Search </a>
</div>
</div>

<div class="row staff-grid-row">
<div class="col-md-12">
    <div class="table-responsive">
        <table class="table table-striped custom-table datatable">
            <thead>
                <tr>
                    <th>S/L</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th class="text-right">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $count = 1; ?>
                <?php $__currentLoopData = $OfflinePaymentMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offline_payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>#<?php echo e($count); ?></td>
                    <td><?php echo e($offline_payment->Name); ?></td>
                    <td><?php echo e($offline_payment->Description); ?></td>
                    <td><?php echo e(ucfirst($offline_payment->Status)); ?></td>
                    <td class="text-right">
                        <div class="dropdown dropdown-action">
                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_offline_payment_update_<?php echo e($offline_payment->id); ?>"><i class="far fa-pencil-alt m-r-5"></i> Edit</a>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_offline_payment_update_<?php echo e($offline_payment->id); ?>"><i class="far fa-trash-alt m-r-5"></i> Delete</a>
                            </div>
                        </div>
                    </td>
                </tr>



                
<div id="edit_offline_payment_update_<?php echo e($offline_payment->id); ?>" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="modal-content modal-lg">
            <div class="modal-header">
                <h4 class="modal-title">Edit Offline Payment</h4>
            </div>
            <div class="modal-body">
                <div class="m-b-30">
                    <form class="m-b-30" action="<?php echo e(route('offline_payment_update', $offline_payment->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <label class="focus-label">Name</label>
                                <input type="text" class="form-control floating" name="Name" value="<?php echo e($offline_payment->Name); ?>">
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea class="form-control floating" name="Description" rows="4"><?php echo e($offline_payment->Description); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="display-block">Status</label>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="Status" id="offline_pay_active" value="active" <?php echo e($offline_payment->Status === 'active' ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="offline_pay_active">
                                            Active
                                        </label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="Status" id="offline_pay_inactive" value="inactive" <?php echo e($offline_payment->Status === 'inactive' ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="offline_pay_inactive">
                                            Inactive
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="m-t-20 text-center">
                            <button class="btn btn-primary btn-lg">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>




<div id="delete_offline_payment_update_<?php echo e($offline_payment->id); ?>" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content modal-md">
            <div class="modal-header">
                <h4 class="modal-title">Delete Offline Payment</h4>
            </div>
            <div class="modal-body card-box">
                <p>Are you sure you want to delete this User?</p>
                <div class="m-t-20">
                <a href="#" class="btn btn-white" data-dismiss="modal">Close</a>
                    <form class="m-b-30" action="<?php echo e(route('offline_payment_destroy', $offline_payment->id)); ?>" method="POST" style="display:inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>






</div>
</div>
</div>

<div id="add_offline_payment" class="modal custom-modal fade" role="dialog">
<div class="modal-dialog">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-content modal-lg">
<div class="modal-header">
    <h4 class="modal-title">Add Offline Payment</h4>
</div>
<div class="modal-body">
    <div class="m-b-30">
        <form action="<?php echo e(route('offline_payment_store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-12">
                    <label class="focus-label">Name</label>
                    <input type="text" class="form-control floating" name="Name">
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control floating" name="Description" rows="4"></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label class="display-block">Status</label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="Status" id="status_enable" value="active" checked>
                            <label class="form-check-label" for="status_enable">
                                Active
                            </label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="Status" id="status_disable" value="inactive">
                            <label class="form-check-label" for="status_disable">
                                Inactive
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="m-t-20 text-center">
                <button class="btn btn-primary btn-lg">Create Offline Payment</button>
            </div>
        </form>
    </div>
</div>
</div>
</div>
</div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\server\htdocs\advance_ai\resources\views/settings/offline_payment.blade.php ENDPATH**/ ?>