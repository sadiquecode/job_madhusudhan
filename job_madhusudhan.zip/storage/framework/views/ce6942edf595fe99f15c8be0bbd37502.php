<div class="sidebar" :class="[{'is-hidden': ! sidebar}]">
    <?php echo $index; ?>

</div><?php /**PATH G:\server\htdocs\techme_latest\resources\views/vendor/larecipe/partials/sidebar.blade.php ENDPATH**/ ?>