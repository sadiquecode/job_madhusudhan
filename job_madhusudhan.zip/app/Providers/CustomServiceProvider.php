<?php
namespace App\Providers;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;
use DB;

class CustomServiceProvider extends ServiceProvider
{
    public function register()
    {
        
    }

    // ...
}